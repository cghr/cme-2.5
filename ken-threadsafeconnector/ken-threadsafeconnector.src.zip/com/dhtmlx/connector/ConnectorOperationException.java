/*  1:   */ package com.dhtmlx.connector;
/*  2:   */ 
/*  3:   */ public class ConnectorOperationException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -7170611402641940431L;
/*  7:   */   
/*  8:   */   public ConnectorOperationException(String message)
/*  9:   */   {
/* 10:22 */     super(message);
/* 11:   */   }
/* 12:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-threadsafeconnector\ken-threadsafeconnector.jar
 * Qualified Name:     com.dhtmlx.connector.ConnectorOperationException
 * JD-Core Version:    0.7.0.1
 */