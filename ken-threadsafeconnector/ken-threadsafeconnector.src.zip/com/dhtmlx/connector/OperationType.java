package com.dhtmlx.connector;

public enum OperationType
{
  Read,  Insert,  Update,  Delete;
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-threadsafeconnector\ken-threadsafeconnector.jar
 * Qualified Name:     com.dhtmlx.connector.OperationType
 * JD-Core Version:    0.7.0.1
 */