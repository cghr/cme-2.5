package com.dhtmlx.connector;

public enum TransactionType
{
  NONE,  OPERATION,  GLOBAL;
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-threadsafeconnector\ken-threadsafeconnector.jar
 * Qualified Name:     com.dhtmlx.connector.TransactionType
 * JD-Core Version:    0.7.0.1
 */