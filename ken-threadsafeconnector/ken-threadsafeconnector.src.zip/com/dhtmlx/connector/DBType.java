package com.dhtmlx.connector;

public enum DBType
{
  SQL,  MySQL,  Oracle,  MSSQL,  PostgreSQL,  Custom;
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-threadsafeconnector\ken-threadsafeconnector.jar
 * Qualified Name:     com.dhtmlx.connector.DBType
 * JD-Core Version:    0.7.0.1
 */