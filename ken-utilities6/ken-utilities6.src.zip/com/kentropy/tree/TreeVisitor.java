package com.kentropy.tree;

public abstract interface TreeVisitor
{
  public abstract void doTask(DBNode paramDBNode);
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-utilities6\ken-utilities6.jar
 * Qualified Name:     com.kentropy.tree.TreeVisitor
 * JD-Core Version:    0.7.0.1
 */