package com.kentropy.formtest;

public class Test1
{
  public static void main(String[] args) {}
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-utilities6\ken-utilities6.jar
 * Qualified Name:     com.kentropy.formtest.Test1
 * JD-Core Version:    0.7.0.1
 */