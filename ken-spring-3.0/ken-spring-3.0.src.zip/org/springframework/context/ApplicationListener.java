package org.springframework.context;

import java.util.EventListener;

public abstract interface ApplicationListener<E extends ApplicationEvent>
  extends EventListener
{
  public abstract void onApplicationEvent(E paramE);
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-spring-3.0\ken-spring-3.0.jar
 * Qualified Name:     org.springframework.context.ApplicationListener
 * JD-Core Version:    0.7.0.1
 */