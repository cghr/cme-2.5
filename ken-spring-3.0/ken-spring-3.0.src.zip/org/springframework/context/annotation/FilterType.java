package org.springframework.context.annotation;

public enum FilterType
{
  ANNOTATION,  ASSIGNABLE_TYPE,  CUSTOM;
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-spring-3.0\ken-spring-3.0.jar
 * Qualified Name:     org.springframework.context.annotation.FilterType
 * JD-Core Version:    0.7.0.1
 */