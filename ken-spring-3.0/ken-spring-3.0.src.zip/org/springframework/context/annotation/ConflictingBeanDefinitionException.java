/*  1:   */ package org.springframework.context.annotation;
/*  2:   */ 
/*  3:   */ class ConflictingBeanDefinitionException
/*  4:   */   extends IllegalStateException
/*  5:   */ {
/*  6:   */   public ConflictingBeanDefinitionException(String message)
/*  7:   */   {
/*  8:30 */     super(message);
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-spring-3.0\ken-spring-3.0.jar
 * Qualified Name:     org.springframework.context.annotation.ConflictingBeanDefinitionException
 * JD-Core Version:    0.7.0.1
 */