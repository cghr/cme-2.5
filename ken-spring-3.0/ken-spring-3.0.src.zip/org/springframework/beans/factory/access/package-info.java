package org.springframework.beans.factory.access;

abstract interface package-info {}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-spring-3.0\ken-spring-3.0.jar
 * Qualified Name:     org.springframework.beans.factory.access.package-info
 * JD-Core Version:    0.7.0.1
 */