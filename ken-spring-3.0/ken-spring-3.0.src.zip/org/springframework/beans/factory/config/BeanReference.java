package org.springframework.beans.factory.config;

import org.springframework.beans.BeanMetadataElement;

public abstract interface BeanReference
  extends BeanMetadataElement
{
  public abstract String getBeanName();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-spring-3.0\ken-spring-3.0.jar
 * Qualified Name:     org.springframework.beans.factory.config.BeanReference
 * JD-Core Version:    0.7.0.1
 */