package org.springframework.beans.factory.wiring;

public abstract interface BeanWiringInfoResolver
{
  public abstract BeanWiringInfo resolveWiringInfo(Object paramObject);
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-spring-3.0\ken-spring-3.0.jar
 * Qualified Name:     org.springframework.beans.factory.wiring.BeanWiringInfoResolver
 * JD-Core Version:    0.7.0.1
 */