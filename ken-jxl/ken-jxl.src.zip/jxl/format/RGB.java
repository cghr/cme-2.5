/*  1:   */ package jxl.format;
/*  2:   */ 
/*  3:   */ public final class RGB
/*  4:   */ {
/*  5:   */   private int red;
/*  6:   */   private int green;
/*  7:   */   private int blue;
/*  8:   */   
/*  9:   */   public RGB(int r, int g, int b)
/* 10:   */   {
/* 11:52 */     this.red = r;
/* 12:53 */     this.green = g;
/* 13:54 */     this.blue = b;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getRed()
/* 17:   */   {
/* 18:64 */     return this.red;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public int getGreen()
/* 22:   */   {
/* 23:74 */     return this.green;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int getBlue()
/* 27:   */   {
/* 28:84 */     return this.blue;
/* 29:   */   }
/* 30:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.format.RGB
 * JD-Core Version:    0.7.0.1
 */