package jxl.format;

public abstract interface Format
{
  public abstract String getFormatString();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.format.Format
 * JD-Core Version:    0.7.0.1
 */