/*  1:   */ package jxl.format;
/*  2:   */ 
/*  3:   */ public class PageOrder
/*  4:   */ {
/*  5:37 */   public static PageOrder DOWN_THEN_RIGHT = new PageOrder();
/*  6:42 */   public static PageOrder RIGHT_THEN_DOWN = new PageOrder();
/*  7:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.format.PageOrder
 * JD-Core Version:    0.7.0.1
 */