/*  1:   */ package jxl.format;
/*  2:   */ 
/*  3:   */ public final class PageOrientation
/*  4:   */ {
/*  5:38 */   public static PageOrientation PORTRAIT = new PageOrientation();
/*  6:42 */   public static PageOrientation LANDSCAPE = new PageOrientation();
/*  7:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.format.PageOrientation
 * JD-Core Version:    0.7.0.1
 */