package jxl;

public abstract interface BooleanCell
  extends Cell
{
  public abstract boolean getValue();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.BooleanCell
 * JD-Core Version:    0.7.0.1
 */