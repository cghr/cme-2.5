/*  1:   */ package jxl;
/*  2:   */ 
/*  3:   */ public class JXLException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   protected JXLException(String message)
/*  7:   */   {
/*  8:34 */     super(message);
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.JXLException
 * JD-Core Version:    0.7.0.1
 */