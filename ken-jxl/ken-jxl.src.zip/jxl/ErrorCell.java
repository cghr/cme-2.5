package jxl;

public abstract interface ErrorCell
  extends Cell
{
  public abstract int getErrorCode();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.ErrorCell
 * JD-Core Version:    0.7.0.1
 */