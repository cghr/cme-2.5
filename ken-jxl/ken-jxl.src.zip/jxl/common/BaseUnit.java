/*  1:   */ package jxl.common;
/*  2:   */ 
/*  3:   */ public class BaseUnit
/*  4:   */ {
/*  5:   */   private int index;
/*  6:   */   
/*  7:   */   protected BaseUnit(int ind)
/*  8:   */   {
/*  9:28 */     this.index = ind;
/* 10:   */   }
/* 11:   */   
/* 12:   */   protected int getIndex()
/* 13:   */   {
/* 14:33 */     return this.index;
/* 15:   */   }
/* 16:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.common.BaseUnit
 * JD-Core Version:    0.7.0.1
 */