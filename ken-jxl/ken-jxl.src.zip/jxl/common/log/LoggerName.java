/*  1:   */ package jxl.common.log;
/*  2:   */ 
/*  3:   */ public class LoggerName
/*  4:   */ {
/*  5:30 */   public static final String NAME = SimpleLogger.class.getName();
/*  6:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.common.log.LoggerName
 * JD-Core Version:    0.7.0.1
 */