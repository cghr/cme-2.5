/*  1:   */ package jxl.common.log;
/*  2:   */ 
/*  3:   */ public class Log4jLoggerName
/*  4:   */ {
/*  5:29 */   public static final String NAME = Log4JLogger.class.getName();
/*  6:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.common.log.Log4jLoggerName
 * JD-Core Version:    0.7.0.1
 */