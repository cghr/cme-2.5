package jxl;

public abstract interface LabelCell
  extends Cell
{
  public abstract String getString();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.LabelCell
 * JD-Core Version:    0.7.0.1
 */