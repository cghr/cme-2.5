/*  1:   */ package jxl.read.biff;
/*  2:   */ 
/*  3:   */ public class PasswordException
/*  4:   */   extends BiffException
/*  5:   */ {
/*  6:   */   public PasswordException()
/*  7:   */   {
/*  8:33 */     super(passwordProtected);
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.read.biff.PasswordException
 * JD-Core Version:    0.7.0.1
 */