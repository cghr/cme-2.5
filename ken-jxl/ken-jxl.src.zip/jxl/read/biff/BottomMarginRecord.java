/*  1:   */ package jxl.read.biff;
/*  2:   */ 
/*  3:   */ import jxl.biff.Type;
/*  4:   */ 
/*  5:   */ class BottomMarginRecord
/*  6:   */   extends MarginRecord
/*  7:   */ {
/*  8:   */   BottomMarginRecord(Record r)
/*  9:   */   {
/* 10:36 */     super(Type.BOTTOMMARGIN, r);
/* 11:   */   }
/* 12:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.read.biff.BottomMarginRecord
 * JD-Core Version:    0.7.0.1
 */