package jxl.read.biff;

import jxl.Cell;

public abstract interface Formula
  extends Cell
{
  public abstract byte[] getFormulaData();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.read.biff.Formula
 * JD-Core Version:    0.7.0.1
 */