/*  1:   */ package jxl.read.biff;
/*  2:   */ 
/*  3:   */ import jxl.biff.Type;
/*  4:   */ 
/*  5:   */ class TopMarginRecord
/*  6:   */   extends MarginRecord
/*  7:   */ {
/*  8:   */   TopMarginRecord(Record r)
/*  9:   */   {
/* 10:35 */     super(Type.TOPMARGIN, r);
/* 11:   */   }
/* 12:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.read.biff.TopMarginRecord
 * JD-Core Version:    0.7.0.1
 */