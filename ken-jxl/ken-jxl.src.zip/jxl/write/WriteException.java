/*  1:   */ package jxl.write;
/*  2:   */ 
/*  3:   */ import jxl.JXLException;
/*  4:   */ 
/*  5:   */ public abstract class WriteException
/*  6:   */   extends JXLException
/*  7:   */ {
/*  8:   */   protected WriteException(String s)
/*  9:   */   {
/* 10:36 */     super(s);
/* 11:   */   }
/* 12:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.WriteException
 * JD-Core Version:    0.7.0.1
 */