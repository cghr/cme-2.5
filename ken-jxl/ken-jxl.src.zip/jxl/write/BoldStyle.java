/*  1:   */ package jxl.write;
/*  2:   */ 
/*  3:   */ public final class BoldStyle
/*  4:   */   extends jxl.format.BoldStyle
/*  5:   */ {
/*  6:   */   private BoldStyle(int val)
/*  7:   */   {
/*  8:34 */     super(0, "");
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.BoldStyle
 * JD-Core Version:    0.7.0.1
 */