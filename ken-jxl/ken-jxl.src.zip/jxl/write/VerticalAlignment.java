/*  1:   */ package jxl.write;
/*  2:   */ 
/*  3:   */ /**
/*  4:   */  * @deprecated
/*  5:   */  */
/*  6:   */ public final class VerticalAlignment
/*  7:   */   extends jxl.format.VerticalAlignment
/*  8:   */ {
/*  9:   */   private VerticalAlignment()
/* 10:   */   {
/* 11:34 */     super(0, null);
/* 12:   */   }
/* 13:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.VerticalAlignment
 * JD-Core Version:    0.7.0.1
 */