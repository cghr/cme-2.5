/*  1:   */ package jxl.write;
/*  2:   */ 
/*  3:   */ /**
/*  4:   */  * @deprecated
/*  5:   */  */
/*  6:   */ public final class Colour
/*  7:   */   extends jxl.format.Colour
/*  8:   */ {
/*  9:   */   private Colour()
/* 10:   */   {
/* 11:36 */     super(0, null, 0, 0, 0);
/* 12:   */   }
/* 13:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.Colour
 * JD-Core Version:    0.7.0.1
 */