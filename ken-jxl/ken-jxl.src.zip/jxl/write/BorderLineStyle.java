/*  1:   */ package jxl.write;
/*  2:   */ 
/*  3:   */ /**
/*  4:   */  * @deprecated
/*  5:   */  */
/*  6:   */ public final class BorderLineStyle
/*  7:   */   extends jxl.format.BorderLineStyle
/*  8:   */ {
/*  9:   */   private BorderLineStyle()
/* 10:   */   {
/* 11:32 */     super(0, null);
/* 12:   */   }
/* 13:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.BorderLineStyle
 * JD-Core Version:    0.7.0.1
 */