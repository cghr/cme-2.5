/*  1:   */ package jxl.write.biff;
/*  2:   */ 
/*  3:   */ import jxl.biff.Type;
/*  4:   */ 
/*  5:   */ class TopMarginRecord
/*  6:   */   extends MarginRecord
/*  7:   */ {
/*  8:   */   TopMarginRecord(double v)
/*  9:   */   {
/* 10:31 */     super(Type.TOPMARGIN, v);
/* 11:   */   }
/* 12:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.biff.TopMarginRecord
 * JD-Core Version:    0.7.0.1
 */