/*  1:   */ package jxl.write.biff;
/*  2:   */ 
/*  3:   */ public class CopyAdditionalPropertySetsException
/*  4:   */   extends JxlWriteException
/*  5:   */ {
/*  6:   */   public CopyAdditionalPropertySetsException()
/*  7:   */   {
/*  8:33 */     super(copyPropertySets);
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.biff.CopyAdditionalPropertySetsException
 * JD-Core Version:    0.7.0.1
 */