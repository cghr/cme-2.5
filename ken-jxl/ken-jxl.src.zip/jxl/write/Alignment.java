/*  1:   */ package jxl.write;
/*  2:   */ 
/*  3:   */ /**
/*  4:   */  * @deprecated
/*  5:   */  */
/*  6:   */ public final class Alignment
/*  7:   */   extends jxl.format.Alignment
/*  8:   */ {
/*  9:   */   private Alignment()
/* 10:   */   {
/* 11:36 */     super(0, null);
/* 12:   */   }
/* 13:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.write.Alignment
 * JD-Core Version:    0.7.0.1
 */