package jxl;

public abstract interface BooleanFormulaCell
  extends BooleanCell, FormulaCell
{}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.BooleanFormulaCell
 * JD-Core Version:    0.7.0.1
 */