/*  1:   */ package jxl.biff;
/*  2:   */ 
/*  3:   */ public class NumFormatRecordsException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   public NumFormatRecordsException()
/*  7:   */   {
/*  8:34 */     super("Internal error:  max number of FORMAT records exceeded");
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.NumFormatRecordsException
 * JD-Core Version:    0.7.0.1
 */