package jxl.biff;

public abstract interface ByteData
{
  public abstract byte[] getBytes();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.ByteData
 * JD-Core Version:    0.7.0.1
 */