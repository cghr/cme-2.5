/*  1:   */ package jxl.biff.drawing;
/*  2:   */ 
/*  3:   */ class DgContainer
/*  4:   */   extends EscherContainer
/*  5:   */ {
/*  6:   */   public DgContainer()
/*  7:   */   {
/*  8:32 */     super(EscherRecordType.DG_CONTAINER);
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.drawing.DgContainer
 * JD-Core Version:    0.7.0.1
 */