/*  1:   */ package jxl.biff.drawing;
/*  2:   */ 
/*  3:   */ class SpContainer
/*  4:   */   extends EscherContainer
/*  5:   */ {
/*  6:   */   public SpContainer()
/*  7:   */   {
/*  8:32 */     super(EscherRecordType.SP_CONTAINER);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public SpContainer(EscherRecordData erd)
/* 12:   */   {
/* 13:42 */     super(erd);
/* 14:   */   }
/* 15:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.drawing.SpContainer
 * JD-Core Version:    0.7.0.1
 */