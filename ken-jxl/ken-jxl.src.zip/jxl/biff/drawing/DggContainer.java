/*  1:   */ package jxl.biff.drawing;
/*  2:   */ 
/*  3:   */ class DggContainer
/*  4:   */   extends EscherContainer
/*  5:   */ {
/*  6:   */   public DggContainer()
/*  7:   */   {
/*  8:32 */     super(EscherRecordType.DGG_CONTAINER);
/*  9:   */   }
/* 10:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.drawing.DggContainer
 * JD-Core Version:    0.7.0.1
 */