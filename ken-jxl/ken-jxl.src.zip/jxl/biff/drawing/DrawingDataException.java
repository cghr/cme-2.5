/*  1:   */ package jxl.biff.drawing;
/*  2:   */ 
/*  3:   */ public class DrawingDataException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:31 */   private static String message = "Drawing number exceeds available SpContainers";
/*  7:   */   
/*  8:   */   DrawingDataException()
/*  9:   */   {
/* 10:35 */     super(message);
/* 11:   */   }
/* 12:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.drawing.DrawingDataException
 * JD-Core Version:    0.7.0.1
 */