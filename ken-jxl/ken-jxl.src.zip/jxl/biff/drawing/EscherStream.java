package jxl.biff.drawing;

abstract interface EscherStream
{
  public abstract byte[] getData();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.drawing.EscherStream
 * JD-Core Version:    0.7.0.1
 */