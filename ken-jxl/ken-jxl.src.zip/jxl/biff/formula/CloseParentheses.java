package jxl.biff.formula;

class CloseParentheses
  extends StringParseItem
{}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.formula.CloseParentheses
 * JD-Core Version:    0.7.0.1
 */