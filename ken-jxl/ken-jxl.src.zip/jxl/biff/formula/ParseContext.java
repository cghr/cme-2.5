/*  1:   */ package jxl.biff.formula;
/*  2:   */ 
/*  3:   */ public class ParseContext
/*  4:   */ {
/*  5:27 */   public static ParseContext DEFAULT = new ParseContext();
/*  6:28 */   public static ParseContext DATA_VALIDATION = new ParseContext();
/*  7:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.formula.ParseContext
 * JD-Core Version:    0.7.0.1
 */