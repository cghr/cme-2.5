package jxl.biff.formula;

class OpenParentheses
  extends StringParseItem
{}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.formula.OpenParentheses
 * JD-Core Version:    0.7.0.1
 */