/*  1:   */ package jxl.biff;
/*  2:   */ 
/*  3:   */ import jxl.JXLException;
/*  4:   */ 
/*  5:   */ public class NameRangeException
/*  6:   */   extends JXLException
/*  7:   */ {
/*  8:   */   public NameRangeException()
/*  9:   */   {
/* 10:35 */     super("");
/* 11:   */   }
/* 12:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-jxl\ken-jxl.jar
 * Qualified Name:     jxl.biff.NameRangeException
 * JD-Core Version:    0.7.0.1
 */