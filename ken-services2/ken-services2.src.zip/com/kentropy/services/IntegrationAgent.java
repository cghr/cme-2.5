package com.kentropy.services;

public abstract interface IntegrationAgent
{
  public abstract void run();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-services2\ken-services2.jar
 * Qualified Name:     com.kentropy.services.IntegrationAgent
 * JD-Core Version:    0.7.0.1
 */