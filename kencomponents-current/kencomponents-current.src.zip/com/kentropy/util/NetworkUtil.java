/*   1:    */ package com.kentropy.util;
/*   2:    */ 
/*   3:    */ import java.awt.Desktop;
/*   4:    */ import java.awt.Desktop.Action;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.Font;
/*   7:    */ import java.awt.Frame;
/*   8:    */ import java.awt.Toolkit;
/*   9:    */ import java.awt.event.ActionEvent;
/*  10:    */ import java.awt.event.ActionListener;
/*  11:    */ import java.awt.event.MouseEvent;
/*  12:    */ import java.awt.event.MouseListener;
/*  13:    */ import java.io.FileInputStream;
/*  14:    */ import java.io.FileOutputStream;
/*  15:    */ import java.io.IOException;
/*  16:    */ import java.io.InputStream;
/*  17:    */ import java.io.PrintStream;
/*  18:    */ import java.net.ConnectException;
/*  19:    */ import java.net.InetAddress;
/*  20:    */ import java.net.MalformedURLException;
/*  21:    */ import java.net.NoRouteToHostException;
/*  22:    */ import java.net.URI;
/*  23:    */ import java.net.URISyntaxException;
/*  24:    */ import java.net.URL;
/*  25:    */ import java.net.URLConnection;
/*  26:    */ import java.net.UnknownHostException;
/*  27:    */ import java.util.Properties;
/*  28:    */ import net.xoetrope.awt.XButton;
/*  29:    */ import net.xoetrope.awt.XEdit;
/*  30:    */ import net.xoetrope.awt.XLabel;
/*  31:    */ import net.xoetrope.awt.XPanel;
/*  32:    */ import net.xoetrope.awt.XRadioButton;
/*  33:    */ 
/*  34:    */ public class NetworkUtil
/*  35:    */   extends XPanel
/*  36:    */   implements ActionListener, MouseListener
/*  37:    */ {
/*  38: 46 */   private static int FRAME_WIDTH = 350;
/*  39: 47 */   private static int FRAME_HEIGHT = 400;
/*  40: 48 */   private static int MARGIN_LEFT = 20;
/*  41: 49 */   private static int MARGIN_CENTER = 40;
/*  42: 50 */   private static int LABEL_WIDTH = 100;
/*  43: 51 */   private static int LABEL_HEIGHT = 20;
/*  44: 52 */   private static int FIELD_WIDTH = 160;
/*  45: 53 */   private static int FIELD_HEIGHT = 20;
/*  46: 54 */   private static int FIELD_LEFT = 120;
/*  47: 55 */   private static int FIELD_MARGIN_TOP = 20;
/*  48: 56 */   private static int BUTTON_WIDTH = 100;
/*  49: 57 */   private static int BUTTON_HEIGHT = 25;
/*  50: 63 */   private XLabel infoLabel = new XLabel();
/*  51: 64 */   private XLabel headingLabel = new XLabel();
/*  52: 65 */   private XLabel proxyHostLabel = new XLabel();
/*  53: 66 */   private XEdit proxyHostField = new XEdit();
/*  54: 67 */   private XLabel proxyPortLabel = new XLabel();
/*  55: 68 */   private XEdit proxyPortField = new XEdit();
/*  56: 69 */   public XButton reconnectButton = new XButton();
/*  57: 70 */   public XButton cancelButton = new XButton();
/*  58: 71 */   private XRadioButton noProxyRadioButton = new XRadioButton();
/*  59: 72 */   private XRadioButton proxyRadioButton = new XRadioButton();
/*  60: 74 */   private static Properties props = new Properties();
/*  61:    */   
/*  62:    */   static
/*  63:    */   {
/*  64: 78 */     FileInputStream fin = null;
/*  65:    */     try
/*  66:    */     {
/*  67: 81 */       fin = new FileInputStream("resources/proxy.properties");
/*  68: 82 */       props.load(fin);
/*  69:    */       
/*  70: 84 */       setProxy1(props.getProperty("proxySet"), props.getProperty("proxyHost"), props.getProperty("proxyPort"));
/*  71:    */     }
/*  72:    */     catch (IOException e)
/*  73:    */     {
/*  74: 87 */       e.printStackTrace();
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static void setProxy1(String proxyEnabled, String proxyHost, String proxyPort)
/*  79:    */   {
/*  80: 94 */     System.getProperties().put("proxySet", proxyEnabled);
/*  81: 95 */     if ((proxyHost != null) && (proxyPort != null) && (proxyEnabled.equals("true")))
/*  82:    */     {
/*  83: 96 */       System.getProperties().put("proxyHost", proxyHost);
/*  84: 97 */       System.getProperties().put("proxyPort", proxyPort);
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static void setProxy(String proxyEnabled, String proxyHost, String proxyPort)
/*  89:    */     throws IOException
/*  90:    */   {
/*  91:103 */     if (proxyEnabled.equals("true"))
/*  92:    */     {
/*  93:104 */       if ((proxyHost.trim().equals("")) || (proxyPort.trim().equals("")))
/*  94:    */       {
/*  95:106 */         System.out.println("Both Proxy host and Proxy port must be specified.");
/*  96:    */       }
/*  97:    */       else
/*  98:    */       {
/*  99:108 */         System.out.println("Setting Proxy Host:port\t" + proxyHost + 
/* 100:109 */           ":" + proxyPort);
/* 101:    */         
/* 102:111 */         props.put("proxySet", "true");
/* 103:112 */         props.put("proxyHost", proxyHost);
/* 104:113 */         props.put("proxyPort", proxyPort);
/* 105:    */         
/* 106:115 */         FileOutputStream fout = null;
/* 107:116 */         fout = new FileOutputStream("resources/proxy.properties");
/* 108:117 */         props.save(fout, "Proxy Settings for CME Application");
/* 109:118 */         fout.close();
/* 110:119 */         setProxy1(proxyEnabled, proxyHost, proxyPort);
/* 111:    */       }
/* 112:    */     }
/* 113:    */     else
/* 114:    */     {
/* 115:122 */       System.out.println("Removing proxy settings");
/* 116:    */       
/* 117:124 */       props.put("proxySet", "false");
/* 118:    */       
/* 119:    */ 
/* 120:127 */       FileOutputStream fout = new FileOutputStream("resources/proxy.properties");
/* 121:128 */       props.save(fout, "Proxy Settings for CME Application");
/* 122:129 */       fout.close();
/* 123:    */       
/* 124:131 */       setProxy1(proxyEnabled, proxyHost, proxyPort);
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static boolean ping(String addressName)
/* 129:    */     throws UnknownHostException, IOException
/* 130:    */   {
/* 131:139 */     InetAddress add = InetAddress.getByName(addressName);
/* 132:140 */     boolean isReachable = add.isReachable(5000);
/* 133:141 */     System.out.println("Reachable:" + isReachable);
/* 134:142 */     return isReachable;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public URLConnection getConnection(String urlString)
/* 138:    */     throws MalformedURLException, IOException, InterruptedException
/* 139:    */   {
/* 140:147 */     URL url = new URL(urlString);
/* 141:148 */     return getConnection(url);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public URLConnection getConnection(URL url)
/* 145:    */     throws MalformedURLException, InterruptedException
/* 146:    */   {
/* 147:153 */     URLConnection connection = null;
/* 148:154 */     boolean connected = false;
/* 149:155 */     int count = 0;
/* 150:    */     
/* 151:157 */     count++;
/* 152:158 */     System.out.println("Retry: " + count);
/* 153:    */     try
/* 154:    */     {
/* 155:160 */       connection = url.openConnection();
/* 156:161 */       connection.connect();
/* 157:162 */       connected = true;
/* 158:163 */       System.out.println("After");
/* 159:    */     }
/* 160:    */     catch (NoRouteToHostException e)
/* 161:    */     {
/* 162:165 */       e.printStackTrace();
/* 163:166 */       init();
/* 164:    */     }
/* 165:    */     catch (ConnectException e)
/* 166:    */     {
/* 167:169 */       System.out.println("Inside ConnectException catch block");
/* 168:170 */       e.printStackTrace();
/* 169:171 */       init();
/* 170:    */     }
/* 171:    */     catch (IOException e)
/* 172:    */     {
/* 173:174 */       e.printStackTrace();
/* 174:    */     }
/* 175:176 */     System.out.println("End of While");
/* 176:    */     
/* 177:    */ 
/* 178:179 */     return connection;
/* 179:    */   }
/* 180:    */   
/* 181:    */   private void selectProxy(boolean b)
/* 182:    */   {
/* 183:183 */     this.proxyRadioButton.setState(b);
/* 184:184 */     this.noProxyRadioButton.setState(!b);
/* 185:185 */     this.proxyHostField.setEditable(b);
/* 186:186 */     this.proxyPortField.setEditable(b);
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void actionPerformed(ActionEvent arg0)
/* 190:    */   {
/* 191:190 */     if (arg0.getActionCommand().equals("Retry")) {
/* 192:    */       try
/* 193:    */       {
/* 194:192 */         String proxyEnabled = "";
/* 195:197 */         if (this.proxyRadioButton.getState())
/* 196:    */         {
/* 197:198 */           proxyEnabled = "true";
/* 198:199 */           selectProxy(true);
/* 199:    */         }
/* 200:    */         else
/* 201:    */         {
/* 202:201 */           proxyEnabled = "false";
/* 203:202 */           selectProxy(false);
/* 204:    */         }
/* 205:205 */         setProxy(proxyEnabled, this.proxyHostField.getText(), 
/* 206:206 */           this.proxyPortField.getText());
/* 207:    */       }
/* 208:    */       catch (IOException e)
/* 209:    */       {
/* 210:209 */         e.printStackTrace();
/* 211:    */       }
/* 212:213 */     } else if (arg0.getActionCommand().equals("Cancel")) {
/* 213:214 */       setVisible(false);
/* 214:    */     }
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void init()
/* 218:    */     throws InterruptedException
/* 219:    */   {
/* 220:221 */     this.infoLabel.setText("Could not contact the server. Please ensure that you have an active internet connection.\n      If you are directly connected to the internet, click Retry.\n      If you are behind a proxy, please provide the proxy \n      information below.");
/* 221:222 */     this.headingLabel.setText("HTTP Proxy Settings");
/* 222:223 */     this.proxyHostLabel.setText("Proxy Host");
/* 223:224 */     this.proxyPortLabel.setText("Proxy Port");
/* 224:225 */     this.cancelButton.setText("Cancel");
/* 225:226 */     this.reconnectButton.setText("Retry");
/* 226:227 */     this.noProxyRadioButton.setText("I am directly connected to the internet");
/* 227:228 */     this.proxyRadioButton.setText("I am connected through a proxy");
/* 228:    */     
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:234 */     selectProxy(false);
/* 234:    */     
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:240 */     Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
/* 240:    */     
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:246 */     this.headingLabel.setFont(new Font("Arial", 1, 15));
/* 246:247 */     this.infoLabel.setFont(new Font("Arial", 1, 11));
/* 247:    */     
/* 248:249 */     this.infoLabel.setBounds(MARGIN_LEFT, 2, FRAME_WIDTH, LABEL_HEIGHT * 4);
/* 249:250 */     this.headingLabel.setBounds(90, this.infoLabel.getY() + this.infoLabel.getHeight(), FRAME_WIDTH / 2, 20);
/* 250:    */     
/* 251:252 */     this.noProxyRadioButton.setBounds(MARGIN_LEFT, this.headingLabel.getY() + this.headingLabel.getHeight() + FIELD_MARGIN_TOP, FRAME_WIDTH - MARGIN_LEFT * 2, LABEL_HEIGHT);
/* 252:253 */     this.proxyRadioButton.setBounds(MARGIN_LEFT, this.noProxyRadioButton.getY() + FIELD_MARGIN_TOP, FRAME_WIDTH - MARGIN_LEFT * 2, LABEL_HEIGHT);
/* 253:254 */     this.proxyHostLabel.setBounds(MARGIN_LEFT, this.proxyRadioButton.getY() + this.proxyRadioButton.getHeight() + 
/* 254:255 */       FIELD_MARGIN_TOP, LABEL_WIDTH, LABEL_HEIGHT);
/* 255:256 */     this.proxyHostField.setBounds(FIELD_LEFT, this.proxyHostLabel.getY(), 
/* 256:257 */       FIELD_WIDTH, FIELD_HEIGHT);
/* 257:258 */     this.proxyPortLabel.setBounds(MARGIN_LEFT, this.proxyHostLabel.getY() + this.proxyHostLabel.getHeight() + 
/* 258:259 */       FIELD_MARGIN_TOP, LABEL_WIDTH, LABEL_HEIGHT);
/* 259:260 */     this.proxyPortField.setBounds(FIELD_LEFT, this.proxyPortLabel.getY(), 
/* 260:261 */       FIELD_WIDTH, FIELD_HEIGHT);
/* 261:262 */     this.reconnectButton.setBounds(40, 
/* 262:263 */       (int)(this.proxyPortLabel.getY() + this.proxyPortLabel.getHeight() + FIELD_MARGIN_TOP * 1.5D), 
/* 263:264 */       BUTTON_WIDTH, BUTTON_HEIGHT);
/* 264:265 */     this.cancelButton.setBounds(170, 
/* 265:266 */       this.reconnectButton.getY(), 
/* 266:267 */       BUTTON_WIDTH, BUTTON_HEIGHT);
/* 267:    */     
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:    */ 
/* 272:    */ 
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:277 */     this.reconnectButton.addActionListener(this);
/* 277:278 */     this.cancelButton.addActionListener(this);
/* 278:    */     
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:    */ 
/* 305:    */ 
/* 306:    */ 
/* 307:308 */     this.noProxyRadioButton.addMouseListener(this);
/* 308:    */     
/* 309:    */ 
/* 310:    */ 
/* 311:    */ 
/* 312:    */ 
/* 313:    */ 
/* 314:    */ 
/* 315:    */ 
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:320 */     this.proxyRadioButton.addMouseListener(this);
/* 320:    */     
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:    */ 
/* 325:    */ 
/* 326:    */ 
/* 327:    */ 
/* 328:    */ 
/* 329:    */ 
/* 330:331 */     add(this.infoLabel);
/* 331:332 */     add(this.headingLabel);
/* 332:    */     
/* 333:334 */     add(this.noProxyRadioButton);
/* 334:335 */     add(this.proxyRadioButton);
/* 335:336 */     add(this.cancelButton);
/* 336:337 */     add(this.proxyHostLabel);
/* 337:338 */     add(this.proxyHostField);
/* 338:339 */     add(this.proxyPortLabel);
/* 339:340 */     add(this.proxyPortField);
/* 340:341 */     add(this.reconnectButton);
/* 341:    */     
/* 342:343 */     setVisible(true);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public static void main(String[] args)
/* 346:    */     throws IOException, URISyntaxException
/* 347:    */   {
/* 348:352 */     NetworkUtil util = new NetworkUtil();
/* 349:353 */     util.openUrl("www.google.com");
/* 350:    */     
/* 351:355 */     System.in.read();
/* 352:    */     try
/* 353:    */     {
/* 354:360 */       Frame frame = new Frame("Connecting");
/* 355:361 */       NetworkUtil nu = new NetworkUtil();
/* 356:362 */       nu.setBounds(10, 10, 300, 400);
/* 357:363 */       frame.setBounds(10, 10, 300, 400);
/* 358:364 */       frame.add(nu);
/* 359:365 */       nu.getConnection("http://www.cghr.org");
/* 360:    */       
/* 361:367 */       frame.setVisible(true);
/* 362:    */     }
/* 363:    */     catch (Exception e)
/* 364:    */     {
/* 365:370 */       e.printStackTrace();
/* 366:    */     }
/* 367:    */   }
/* 368:    */   
/* 369:    */   public void openUrl(String url)
/* 370:    */     throws URISyntaxException, IOException
/* 371:    */   {
/* 372:375 */     URI uri = new URI(url);
/* 373:    */     
/* 374:377 */     Desktop desk = Desktop.getDesktop();
/* 375:378 */     if (desk.isSupported(Desktop.Action.BROWSE)) {
/* 376:379 */       desk.browse(uri);
/* 377:    */     }
/* 378:    */   }
/* 379:    */   
/* 380:    */   public void mouseClicked(MouseEvent arg0)
/* 381:    */   {
/* 382:385 */     if (arg0.getSource().equals(this.proxyRadioButton)) {
/* 383:386 */       selectProxy(true);
/* 384:387 */     } else if (arg0.getSource().equals(this.noProxyRadioButton)) {
/* 385:388 */       selectProxy(false);
/* 386:    */     }
/* 387:    */   }
/* 388:    */   
/* 389:    */   public void mouseEntered(MouseEvent arg0) {}
/* 390:    */   
/* 391:    */   public void mouseExited(MouseEvent arg0) {}
/* 392:    */   
/* 393:    */   public void mousePressed(MouseEvent arg0) {}
/* 394:    */   
/* 395:    */   public void mouseReleased(MouseEvent arg0) {}
/* 396:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.util.NetworkUtil
 * JD-Core Version:    0.7.0.1
 */