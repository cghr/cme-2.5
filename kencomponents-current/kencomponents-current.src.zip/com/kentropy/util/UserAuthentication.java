/*   1:    */ package com.kentropy.util;
/*   2:    */ 
/*   3:    */ import java.awt.Desktop;
/*   4:    */ import java.awt.Desktop.Action;
/*   5:    */ import java.io.File;
/*   6:    */ import java.io.FileInputStream;
/*   7:    */ import java.io.FileOutputStream;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.InputStream;
/*  10:    */ import java.io.PrintStream;
/*  11:    */ import java.io.UnsupportedEncodingException;
/*  12:    */ import java.net.ConnectException;
/*  13:    */ import java.net.MalformedURLException;
/*  14:    */ import java.net.URI;
/*  15:    */ import java.net.URISyntaxException;
/*  16:    */ import java.net.URL;
/*  17:    */ import java.net.URLConnection;
/*  18:    */ import java.net.URLEncoder;
/*  19:    */ import java.net.UnknownHostException;
/*  20:    */ import java.util.Properties;
/*  21:    */ import javax.swing.JOptionPane;
/*  22:    */ import sun.misc.BASE64Encoder;
/*  23:    */ 
/*  24:    */ public class UserAuthentication
/*  25:    */ {
/*  26:    */   private static String url;
/*  27: 32 */   private static String dest = "resources/teamdata.xml";
/*  28:    */   private static String[] login;
/*  29: 35 */   private File file = new File(dest);
/*  30:    */   
/*  31:    */   static
/*  32:    */   {
/*  33: 38 */     Properties props = new Properties();
/*  34:    */     try
/*  35:    */     {
/*  36: 42 */       FileInputStream is = new FileInputStream("resources/authentication.properties");
/*  37:    */       
/*  38: 44 */       props.load(is);
/*  39: 45 */       url = props.getProperty("URL");
/*  40: 46 */       login = props.getProperty("login").split(",");
/*  41:    */     }
/*  42:    */     catch (Exception e)
/*  43:    */     {
/*  44: 49 */       e.printStackTrace();
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static String[] getLogin()
/*  49:    */   {
/*  50: 54 */     return login;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static void main(String[] args)
/*  54:    */     throws Exception
/*  55:    */   {
/*  56: 62 */     UserAuthentication auth = new UserAuthentication();
/*  57:    */     try
/*  58:    */     {
/*  59: 64 */       auth.authenticate("Physician4", "password1");
/*  60:    */     }
/*  61:    */     catch (Exception e)
/*  62:    */     {
/*  63: 68 */       e.printStackTrace();
/*  64:    */     }
/*  65: 70 */     for (int i = 0; i < 100; i++) {
/*  66: 71 */       auth.authenticate("Physician4", "password");
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean isFirstLogin()
/*  71:    */   {
/*  72:117 */     System.out.println("Verifying First Login");
/*  73:118 */     System.out.println(this.file.getAbsolutePath());
/*  74:    */     
/*  75:120 */     return !this.file.exists();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void authenticate(String username, String password)
/*  79:    */     throws UnsupportedEncodingException, MalformedURLException, ConnectException, UnknownHostException, IOException, InterruptedException
/*  80:    */   {
/*  81:127 */     username = URLEncoder.encode(username, "utf-8");
/*  82:128 */     password = URLEncoder.encode(password, "utf-8");
/*  83:129 */     String credentials = new BASE64Encoder().encode((username + ":" + password).getBytes());
/*  84:    */     
/*  85:    */ 
/*  86:    */ 
/*  87:133 */     String urlString = url + "Transfer?action=authenticate&credentials=" + credentials;
/*  88:134 */     System.out.println(urlString);
/*  89:    */     
/*  90:136 */     URL url = new URL(urlString);
/*  91:137 */     URLConnection urlConnection = url.openConnection();
/*  92:138 */     urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 ( compatible ) ");
/*  93:139 */     urlConnection.setRequestProperty("Accept", "*/*");
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:145 */     InputStream is = urlConnection.getInputStream();
/* 100:    */     
/* 101:147 */     System.out.println("file " + this.file.getAbsolutePath());
/* 102:148 */     FileOutputStream fos = new FileOutputStream(this.file);
/* 103:149 */     byte[] b = new byte[1024];
/* 104:150 */     int n = is.read(b);
/* 105:151 */     while (n > 0)
/* 106:    */     {
/* 107:152 */       fos.write(b, 0, n);
/* 108:153 */       n = is.read(b);
/* 109:    */     }
/* 110:155 */     is.close();
/* 111:156 */     fos.close();
/* 112:157 */     System.out.println("Completed downloading");
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void authenticate1(String username, String password)
/* 116:    */     throws UnsupportedEncodingException, MalformedURLException, ConnectException, UnknownHostException, IOException, InterruptedException
/* 117:    */   {
/* 118:164 */     username = URLEncoder.encode(username, "utf-8");
/* 119:165 */     password = URLEncoder.encode(password, "utf-8");
/* 120:    */     
/* 121:167 */     String urlString = url + "Transfer?action=authenticate&username=" + 
/* 122:168 */       username + "&password=" + password;
/* 123:169 */     System.out.println("urlString:" + urlString);
/* 124:    */     
/* 125:171 */     URL url = new URL(urlString);
/* 126:172 */     URLConnection urlConnection = url.openConnection();
/* 127:173 */     InputStream is = urlConnection.getInputStream();
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void authenticate2(String username, String password)
/* 131:    */     throws UnsupportedEncodingException, MalformedURLException, ConnectException, UnknownHostException, IOException, InterruptedException
/* 132:    */   {
/* 133:    */     try
/* 134:    */     {
/* 135:181 */       username = URLEncoder.encode(username, "utf-8");
/* 136:182 */       password = URLEncoder.encode(password, "utf-8");
/* 137:183 */       byte[] credsArray = (username + ":" + password).getBytes();
/* 138:184 */       BASE64Encoder enc = new BASE64Encoder();
/* 139:185 */       String credsEncode = enc.encode(credsArray);
/* 140:    */       
/* 141:187 */       String urlString = url + "?credentials=" + credsEncode;
/* 142:188 */       System.out.println("urlString:" + urlString);
/* 143:    */       
/* 144:190 */       Desktop desk = Desktop.getDesktop();
/* 145:191 */       if (desk.isSupported(Desktop.Action.BROWSE)) {
/* 146:192 */         desk.browse(new URI(urlString));
/* 147:    */       }
/* 148:    */     }
/* 149:    */     catch (URISyntaxException e)
/* 150:    */     {
/* 151:196 */       e.printStackTrace();
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   static void userDialog(String message)
/* 156:    */   {
/* 157:206 */     JOptionPane.showMessageDialog(null, message, "alert", 
/* 158:207 */       2);
/* 159:    */   }
/* 160:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.util.UserAuthentication
 * JD-Core Version:    0.7.0.1
 */