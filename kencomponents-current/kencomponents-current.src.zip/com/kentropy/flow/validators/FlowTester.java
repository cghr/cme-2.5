/*   1:    */ package com.kentropy.flow.validators;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import com.kentropy.flow.Age;
/*   5:    */ import com.kentropy.flow.QuestionFlowManager;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.io.FileReader;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.nio.CharBuffer;
/*  10:    */ import java.nio.charset.CharacterCodingException;
/*  11:    */ import java.nio.charset.Charset;
/*  12:    */ import java.nio.charset.CharsetEncoder;
/*  13:    */ import java.nio.charset.CodingErrorAction;
/*  14:    */ import java.text.ParseException;
/*  15:    */ import java.text.SimpleDateFormat;
/*  16:    */ import java.util.Date;
/*  17:    */ import java.util.Locale;
/*  18:    */ import net.xoetrope.data.XDataSource;
/*  19:    */ import net.xoetrope.xui.XProject;
/*  20:    */ import net.xoetrope.xui.XProjectManager;
/*  21:    */ import net.xoetrope.xui.XTextHolder;
/*  22:    */ import net.xoetrope.xui.data.XBaseModel;
/*  23:    */ import net.xoetrope.xui.data.XModel;
/*  24:    */ 
/*  25:    */ public class FlowTester
/*  26:    */ {
/*  27:    */   XModel qModel;
/*  28:    */   String value;
/*  29:    */   XModel viewModel;
/*  30:    */   XModel testModel;
/*  31: 41 */   public Object[] viewElements = new Object[3];
/*  32:    */   
/*  33:    */   public boolean rangeCheck()
/*  34:    */   {
/*  35: 46 */     String range = this.qModel.get("@range").toString();
/*  36: 47 */     String[] range1 = range.split("-");
/*  37: 49 */     if (this.qModel.get("@type").equals("age"))
/*  38:    */     {
/*  39: 51 */       if (this.value.toString().split(",").length < 2) {
/*  40: 53 */         return false;
/*  41:    */       }
/*  42: 55 */       Age val = new Age(this.value.toString());
/*  43:    */       
/*  44: 57 */       return (val.compareTo(range1[0]) >= 0) && (val.compareTo(range1[1]) <= 0);
/*  45:    */     }
/*  46: 61 */     if ((this.qModel.get("@inputtype") != null) && (this.qModel.get("@inputtype").equals("numeric")))
/*  47:    */     {
/*  48: 63 */       int lower = Integer.parseInt(range1[0]);
/*  49: 64 */       int upper = Integer.parseInt(range1[1]);
/*  50: 65 */       int val1 = Integer.parseInt(this.value.toString());
/*  51:    */       
/*  52: 67 */       return (val1 >= lower) && (val1 <= upper);
/*  53:    */     }
/*  54: 69 */     if ((this.qModel.get("@inputtype") != null) && (this.qModel.get("@inputtype").equals("date")) && (this.qModel.get("@range") != null)) {
/*  55:    */       try
/*  56:    */       {
/*  57: 72 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
/*  58: 73 */         String format = (String)this.qModel.get("@format");
/*  59: 74 */         format = format == null ? "dd/MM/yyyy" : format;
/*  60:    */         
/*  61: 76 */         SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
/*  62:    */         
/*  63: 78 */         Date lower = sdf.parse(range1[0].equals("Now") ? sdf.format(new Date()) : range1[0]);
/*  64: 79 */         Date upper = sdf.parse(range1[1].equals("Now") ? sdf.format(new Date()) : range1[1]);
/*  65: 80 */         Date val1 = sdf1.parse(this.value.toString());
/*  66:    */         
/*  67: 82 */         return (val1.compareTo(lower) >= 0) && (val1.compareTo(upper) <= 0);
/*  68:    */       }
/*  69:    */       catch (Exception e)
/*  70:    */       {
/*  71: 86 */         e.printStackTrace();
/*  72: 87 */         return true;
/*  73:    */       }
/*  74:    */     }
/*  75: 91 */     return (this.value.toString().compareTo(range1[0]) > 0) && (this.value.toString().compareTo(range1[1]) < 0);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void displayError(String err)
/*  79:    */   {
/*  80: 96 */     System.out.println("Error:" + err);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static boolean isEnglish(String str)
/*  84:    */   {
/*  85:101 */     Charset asciiCharset = Charset.forName("US-ASCII");
/*  86:102 */     CharsetEncoder encoder = asciiCharset.newEncoder();
/*  87:    */     
/*  88:104 */     encoder.onUnmappableCharacter(CodingErrorAction.REPORT);
/*  89:    */     
/*  90:106 */     CharBuffer cb = CharBuffer.wrap(str);
/*  91:    */     try
/*  92:    */     {
/*  93:108 */       encoder.encode(cb);
/*  94:109 */       return true;
/*  95:    */     }
/*  96:    */     catch (CharacterCodingException e)
/*  97:    */     {
/*  98:112 */       System.out.println("Failed");
/*  99:    */     }
/* 100:113 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean checkNumeric(String value1)
/* 104:    */   {
/* 105:118 */     for (int i = 0; i < value1.length(); i++)
/* 106:    */     {
/* 107:120 */       String val = value1.substring(i, i + 1);
/* 108:    */       try
/* 109:    */       {
/* 110:122 */         Integer.parseInt(val);
/* 111:    */       }
/* 112:    */       catch (Exception e)
/* 113:    */       {
/* 114:126 */         e.printStackTrace();
/* 115:127 */         return false;
/* 116:    */       }
/* 117:    */     }
/* 118:132 */     return true;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean checkDate(String value1)
/* 122:    */   {
/* 123:140 */     String format = this.qModel.get("@format") != null ? this.qModel.get("@format").toString() : "dd/MM/yyyy";
/* 124:    */     
/* 125:    */ 
/* 126:143 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/* 127:    */     try
/* 128:    */     {
/* 129:145 */       sdf.setLenient(false);
/* 130:    */       
/* 131:147 */       sdf.parse(this.value.toString());
/* 132:    */     }
/* 133:    */     catch (ParseException e)
/* 134:    */     {
/* 135:150 */       e.printStackTrace();
/* 136:151 */       return false;
/* 137:    */     }
/* 138:158 */     return true;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public String rangeToStr(String range, String type)
/* 142:    */   {
/* 143:    */     try
/* 144:    */     {
/* 145:165 */       Locale locale = Locale.ENGLISH;
/* 146:166 */       if ((type != null) && (type.equals("date")))
/* 147:    */       {
/* 148:168 */         String[] range1 = range.split("-");
/* 149:169 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", locale);
/* 150:170 */         String format = (String)this.qModel.get("@format");
/* 151:171 */         format = format == null ? "dd/MM/yyyy" : format;
/* 152:172 */         SimpleDateFormat sdf1 = new SimpleDateFormat(format, locale);
/* 153:    */         
/* 154:174 */         Date lower = sdf.parse(range1[0].equals("Now") ? sdf.format(new Date()) : range1[0]);
/* 155:175 */         Date upper = sdf.parse(range1[1].equals("Now") ? sdf.format(new Date()) : range1[1]);
/* 156:    */         
/* 157:177 */         return sdf1.format(lower) + "-" + sdf1.format(upper);
/* 158:    */       }
/* 159:180 */       return range;
/* 160:    */     }
/* 161:    */     catch (Exception e)
/* 162:    */     {
/* 163:185 */       e.printStackTrace();
/* 164:    */     }
/* 165:187 */     return range;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void actionPerformed(ActionEvent e)
/* 169:    */   {
/* 170:192 */     System.out.println(" Actuon " + e.getSource() + " " + e.getActionCommand());
/* 171:    */     
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:197 */     e.getActionCommand().equals("GetGPS");
/* 176:    */     
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:203 */     QuestionFlowManager qfm = new QuestionFlowManager();
/* 182:204 */     if (!qfm.crossCheck(this.qModel))
/* 183:    */     {
/* 184:206 */       displayError("Cross check failed!\r\n" + this.qModel.get("@crosscheckmsg"));
/* 185:207 */       return;
/* 186:    */     }
/* 187:220 */     if (this.qModel.get("@type").equals("choice")) {
/* 188:222 */       if ((this.value == null) || (this.value.toString().length() == 0))
/* 189:    */       {
/* 190:224 */         displayError("Please select one of the listed options");
/* 191:225 */         return;
/* 192:    */       }
/* 193:    */     }
/* 194:239 */     if (this.qModel.get("@lang") != null) {
/* 195:241 */       if (!isEnglish(this.value.toString()))
/* 196:    */       {
/* 197:243 */         displayError("Value is not in English ");
/* 198:244 */         return;
/* 199:    */       }
/* 200:    */     }
/* 201:249 */     if (this.qModel.get("@range") != null) {
/* 202:251 */       if (!rangeCheck())
/* 203:    */       {
/* 204:253 */         String inptype = this.qModel.get("@inputtype") == null ? null : (String)this.qModel.get("@inputtype");
/* 205:    */         
/* 206:255 */         displayError("Value out of range (" + rangeToStr(this.qModel.get("@range").toString(), inptype) + ")");
/* 207:256 */         return;
/* 208:    */       }
/* 209:    */     }
/* 210:262 */     if (this.qModel.get("@regex") != null) {
/* 211:264 */       if (!this.value.toString().matches(this.qModel.get("@regex").toString()))
/* 212:    */       {
/* 213:267 */         displayError("Value not in correct format (" + this.qModel.get("@formatstr") + ")");
/* 214:268 */         return;
/* 215:    */       }
/* 216:    */     }
/* 217:274 */     if (this.qModel.get("@minchars") != null)
/* 218:    */     {
/* 219:276 */       System.out.println("Inside michars");
/* 220:277 */       int minchars = Integer.parseInt(this.qModel.get("@minchars").toString());
/* 221:278 */       if (minchars > this.value.length())
/* 222:    */       {
/* 223:280 */         displayError("Please enter at least " + minchars + " characters ");
/* 224:281 */         return;
/* 225:    */       }
/* 226:    */     }
/* 227:284 */     if (this.qModel.get("@inputtype") != null)
/* 228:    */     {
/* 229:286 */       String inputtype = this.qModel.get("@inputtype").toString();
/* 230:287 */       if (inputtype.equals("numeric")) {
/* 231:289 */         if (!checkNumeric(this.value.toString()))
/* 232:    */         {
/* 233:291 */           displayError("Please enter only numbers ");
/* 234:292 */           return;
/* 235:    */         }
/* 236:    */       }
/* 237:295 */       if (inputtype.equals("date")) {
/* 238:297 */         if (!checkDate(this.value.toString()))
/* 239:    */         {
/* 240:299 */           String format = this.qModel.get("@format") == null ? "dd/MM/yyyy" : this.qModel.get("@format").toString();
/* 241:300 */           displayError("Please enter valid date value");
/* 242:301 */           return;
/* 243:    */         }
/* 244:    */       }
/* 245:    */     }
/* 246:306 */     if (this.qModel.get("@maxtext") != null)
/* 247:    */     {
/* 248:308 */       String max = "";
/* 249:309 */       if (this.qModel.get("@maxno") != null) {
/* 250:311 */         max = this.qModel.get("@maxno").toString();
/* 251:    */       } else {
/* 252:315 */         max = ((XTextHolder)((Object[])this.viewElements[1])[1]).getText();
/* 253:    */       }
/* 254:318 */       if ((this.viewModel != null) && (Integer.parseInt(max) > this.viewModel.getNumChildren() - 1))
/* 255:    */       {
/* 256:320 */         displayError("You have not added all the rows");
/* 257:321 */         return;
/* 258:    */       }
/* 259:    */     }
/* 260:    */   }
/* 261:    */   
/* 262:    */   public void runFlow()
/* 263:    */   {
/* 264:334 */     QuestionFlowManager qfm = new QuestionFlowManager();
/* 265:335 */     qfm.setFlowModel(this.qModel);
/* 266:336 */     qfm.dataModel = this.testModel;
/* 267:337 */     XModel context = new XBaseModel();
/* 268:338 */     ((XModel)context.get("va")).set("1315032010008");
/* 269:339 */     qfm.context = context;
/* 270:    */     
/* 271:341 */     XModel qm = qfm.nextQuestion();
/* 272:342 */     System.out.println(" Question " + qm.getId());
/* 273:    */   }
/* 274:    */   
/* 275:    */   public void readFlows(String fileName)
/* 276:    */     throws Exception
/* 277:    */   {
/* 278:346 */     XProject xpm = XProjectManager.getCurrentProject();
/* 279:    */     
/* 280:348 */     XDataSource xd = new XDataSource();
/* 281:349 */     xd.read(new FileReader("e:/workspace_integration/va_integration/resources/adult.xml"));
/* 282:350 */     System.out.println("tytugu:" + xpm.getModel().getNumChildren());
/* 283:    */   }
/* 284:    */   
/* 285:    */   public static void main(String[] args)
/* 286:    */     throws Exception
/* 287:    */   {
/* 288:358 */     XProject xpm = XProjectManager.getCurrentProject();
/* 289:    */     
/* 290:    */ 
/* 291:361 */     XDataSource xd = new XDataSource();
/* 292:    */     
/* 293:363 */     xd.read(new FileReader("e:/workspace_integration/va_integration/resources/datasets.xml"));
/* 294:    */     
/* 295:365 */     System.out.println("tytugu:" + xpm.getModel().get(0).getId() + " " + XProjectManager.getModel().getNumChildren() + " " + xd.toString());
/* 296:366 */     System.out.println(((XModel)XProjectManager.getModel().get("flows")).getNumChildren());
/* 297:367 */     String uniqno = "/va/1315032010008/17";
/* 298:368 */     XModel xm = new XBaseModel();
/* 299:369 */     TestXUIDB.getInstance().getKeyValues(xm, "keyvalue", uniqno);
/* 300:370 */     System.out.println(" data " + xm.getNumChildren());
/* 301:371 */     FlowTester ft = new FlowTester();
/* 302:372 */     ft.qModel = ((XModel)XProjectManager.getModel().get(0).get("va"));
/* 303:373 */     ft.testModel = xm;
/* 304:374 */     ft.runFlow();
/* 305:    */   }
/* 306:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.flow.validators.FlowTester
 * JD-Core Version:    0.7.0.1
 */