/*   1:    */ package com.kentropy.bindings;
/*   2:    */ 
/*   3:    */ import com.kentropy.components.TestComp;
/*   4:    */ import java.io.PrintStream;
/*   5:    */ import net.xoetrope.xml.XmlElement;
/*   6:    */ import net.xoetrope.xui.data.XCustomDataBinding;
/*   7:    */ import net.xoetrope.xui.data.XModel;
/*   8:    */ import net.xoetrope.xui.data.XStateBinding;
/*   9:    */ 
/*  10:    */ public class KenPanelBinding
/*  11:    */   extends XStateBinding
/*  12:    */   implements XCustomDataBinding
/*  13:    */ {
/*  14:    */   public void setup(Object arg0, XmlElement arg1)
/*  15:    */   {
/*  16: 19 */     System.out.println("setup called");
/*  17: 20 */     this.comp = arg0;
/*  18: 21 */     setSourcePath(arg1.getAttribute("source"));
/*  19: 22 */     setOutputPath(arg1.getAttribute("output"));
/*  20: 23 */     System.out.println(arg1.getAttribute("output"));
/*  21:    */   }
/*  22:    */   
/*  23:    */   public KenPanelBinding()
/*  24:    */   {
/*  25: 30 */     System.out.println("1>>");
/*  26:    */   }
/*  27:    */   
/*  28:    */   public KenPanelBinding(Object arg0, String arg1, XModel arg2, String arg3)
/*  29:    */   {
/*  30: 37 */     super(arg0, arg1, arg2, arg3);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public KenPanelBinding(Object arg0, String arg1)
/*  34:    */   {
/*  35: 43 */     super(arg0, arg1);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void get()
/*  39:    */   {
/*  40: 55 */     System.out.println("Get called" + this.comp + " " + getOutputPath() + " " + this.outputModel);
/*  41: 56 */     TestComp tt = (TestComp)this.comp;
/*  42: 57 */     String val = (String)this.outputModel.get();
/*  43: 58 */     System.out.println("Val is " + val);
/*  44: 59 */     tt.setValue(val);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setOutput(XModel arg0, String arg1)
/*  48:    */   {
/*  49: 88 */     System.out.println("Set o1 called");
/*  50:    */     try
/*  51:    */     {
/*  52: 90 */       super.setOutput(arg0, arg1);
/*  53:    */     }
/*  54:    */     catch (Exception localException) {}
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setOutputPath(String arg0)
/*  58:    */   {
/*  59:104 */     System.out.println("Set o2 called");
/*  60:    */     
/*  61:106 */     this.outputPath = arg0;
/*  62:    */     try
/*  63:    */     {
/*  64:108 */       super.setOutputPath(arg0);
/*  65:    */     }
/*  66:    */     catch (Exception localException) {}
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setSource(XModel arg0)
/*  70:    */   {
/*  71:123 */     System.out.println("Set s1 called");
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setSourcePath(String arg0)
/*  75:    */   {
/*  76:134 */     System.out.println("Set s2 called");
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void set()
/*  80:    */   {
/*  81:144 */     System.out.println("Set called");
/*  82:145 */     TestComp tt = (TestComp)this.comp;
/*  83:146 */     String val = tt.getValue();
/*  84:147 */     System.out.println("Val is " + val);
/*  85:    */     
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:163 */     this.outputModel.set(val);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static void main(String[] args) {}
/* 104:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.bindings.KenPanelBinding
 * JD-Core Version:    0.7.0.1
 */