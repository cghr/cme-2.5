/*  1:   */ package com.kentropy.video;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.PrintStream;
/*  7:   */ import java.net.URL;
/*  8:   */ import javax.media.CannotRealizeException;
/*  9:   */ import javax.media.Manager;
/* 10:   */ import javax.media.NoPlayerException;
/* 11:   */ import javax.media.Player;
/* 12:   */ import net.xoetrope.awt.XPanel;
/* 13:   */ 
/* 14:   */ public class MediaPanel
/* 15:   */   extends XPanel
/* 16:   */ {
/* 17:   */   public MediaPanel(URL mediaURL)
/* 18:   */   {
/* 19:21 */     setLayout(new BorderLayout());
/* 20:   */     
/* 21:   */ 
/* 22:24 */     Manager.setHint(3, Boolean.valueOf(true));
/* 23:   */     try
/* 24:   */     {
/* 25:29 */       Player mediaPlayer = Manager.createRealizedPlayer(mediaURL);
/* 26:   */       
/* 27:   */ 
/* 28:32 */       Component video = mediaPlayer.getVisualComponent();
/* 29:   */       
/* 30:34 */       Component controls = mediaPlayer.getControlPanelComponent();
/* 31:36 */       if (video != null) {
/* 32:37 */         add(video, "Center");
/* 33:   */       }
/* 34:39 */       if (controls != null) {
/* 35:40 */         add(controls, "South");
/* 36:   */       }
/* 37:42 */       mediaPlayer.start();
/* 38:   */     }
/* 39:   */     catch (NoPlayerException noPlayerException)
/* 40:   */     {
/* 41:46 */       System.err.println("No media player found");
/* 42:   */     }
/* 43:   */     catch (CannotRealizeException cannotRealizeException)
/* 44:   */     {
/* 45:50 */       System.err.println("Could not realize media player");
/* 46:   */     }
/* 47:   */     catch (IOException iOException)
/* 48:   */     {
/* 49:54 */       System.err.println("Error reading from the source");
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.video.MediaPanel
 * JD-Core Version:    0.7.0.1
 */