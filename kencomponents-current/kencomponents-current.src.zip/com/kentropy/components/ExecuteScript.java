/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ 
/*  5:   */ public class ExecuteScript
/*  6:   */ {
/*  7:   */   public static void main(String[] args)
/*  8:   */   {
/*  9:11 */     String[] command = { "krita", "test.jpg" };
/* 10:   */     try
/* 11:   */     {
/* 12:13 */       if (System.getProperty("os.name").equals("Linux")) {
/* 13:14 */         Process localProcess = Runtime.getRuntime().exec(command);
/* 14:   */       }
/* 15:   */     }
/* 16:   */     catch (IOException e)
/* 17:   */     {
/* 18:18 */       e.printStackTrace();
/* 19:   */     }
/* 20:   */   }
/* 21:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.ExecuteScript
 * JD-Core Version:    0.7.0.1
 */