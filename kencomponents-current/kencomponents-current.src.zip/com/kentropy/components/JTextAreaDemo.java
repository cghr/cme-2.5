/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.Container;
/*  4:   */ import java.awt.Font;
/*  5:   */ import java.awt.GraphicsEnvironment;
/*  6:   */ import java.awt.event.WindowAdapter;
/*  7:   */ import java.awt.event.WindowEvent;
/*  8:   */ import javax.swing.JFrame;
/*  9:   */ import javax.swing.JTextArea;
/* 10:   */ 
/* 11:   */ public class JTextAreaDemo
/* 12:   */   extends JFrame
/* 13:   */ {
/* 14: 9 */   String davidMessage = "David says, \"שלום עולם\" \n";
/* 15:10 */   String andyMessage = "Andy also says, \"שלום עולם\"";
/* 16:   */   
/* 17:   */   public JTextAreaDemo()
/* 18:   */   {
/* 19:13 */     super("Narrative");
/* 20:14 */     setBounds(10, 10, 800, 600);
/* 21:15 */     GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 22:16 */     Font font = new Font("LucidaSans", 0, 40);
/* 23:17 */     JTextArea textArea = new JTextArea(this.davidMessage + this.andyMessage);
/* 24:18 */     textArea.setFont(font);
/* 25:19 */     textArea.setWrapStyleWord(true);
/* 26:20 */     textArea.setLineWrap(true);
/* 27:21 */     getContentPane().setBounds(10, 10, 800, 600);
/* 28:22 */     getContentPane().add(textArea);
/* 29:23 */     textArea.setBounds(10, 10, 800, 600);
/* 30:24 */     textArea.show();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public static void main(String[] args)
/* 34:   */   {
/* 35:28 */     JFrame frame = new JTextAreaDemo();
/* 36:29 */     frame.addWindowListener(new WindowAdapter()
/* 37:   */     {
/* 38:   */       public void windowClosing(WindowEvent e)
/* 39:   */       {
/* 40:30 */         System.exit(0);
/* 41:   */       }
/* 42:33 */     });
/* 43:34 */     frame.setVisible(true);
/* 44:35 */     frame.setSize(800, 600);
/* 45:   */   }
/* 46:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.JTextAreaDemo
 * JD-Core Version:    0.7.0.1
 */