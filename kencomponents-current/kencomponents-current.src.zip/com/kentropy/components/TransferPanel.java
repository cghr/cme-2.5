/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import com.kentropy.transfer.Client;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Font;
/*   7:    */ import java.awt.event.ActionEvent;
/*   8:    */ import java.awt.event.ActionListener;
/*   9:    */ import java.awt.event.ComponentEvent;
/*  10:    */ import java.awt.event.ComponentListener;
/*  11:    */ import java.io.PrintStream;
/*  12:    */ import java.util.Vector;
/*  13:    */ import net.xoetrope.awt.XButton;
/*  14:    */ import net.xoetrope.awt.XLabel;
/*  15:    */ import net.xoetrope.awt.XPanel;
/*  16:    */ import net.xoetrope.awt.XTextArea;
/*  17:    */ import net.xoetrope.xui.data.XModel;
/*  18:    */ 
/*  19:    */ public class TransferPanel
/*  20:    */   extends XPanel
/*  21:    */   implements ActionListener, ComponentListener
/*  22:    */ {
/*  23: 36 */   Thread th = null;
/*  24: 37 */   int codeCount = 0;
/*  25:    */   
/*  26:    */   public class Task
/*  27:    */     implements Runnable
/*  28:    */   {
/*  29:    */     public Task() {}
/*  30:    */     
/*  31:    */     public void upload()
/*  32:    */       throws Exception
/*  33:    */     {
/*  34: 46 */       int changes = TestXUIDB.getInstance().sendLogs(this.currentUser, this.recepients);
/*  35: 47 */       this.tfp.ta.append("\n" + changes + " changes uploaded");
/*  36:    */     }
/*  37:    */     
/*  38:    */     public void download()
/*  39:    */       throws Exception
/*  40:    */     {
/*  41: 57 */       Client cl = new Client();
/*  42: 58 */       cl.participant = this.currentUser;
/*  43: 59 */       cl.run();
/*  44: 60 */       for (int i = 0; i < cl.messages.size(); i++) {
/*  45: 62 */         this.tfp.ta.append("\n" + cl.messages.get(i));
/*  46:    */       }
/*  47:    */     }
/*  48:    */     
/*  49: 69 */     public int codeCount = 0;
/*  50:    */     public String currentUser;
/*  51:    */     public String recepients;
/*  52:    */     
/*  53:    */     public void syncCode()
/*  54:    */       throws Exception
/*  55:    */     {
/*  56: 72 */       Client cl = new Client();
/*  57: 73 */       cl.participant = this.currentUser;
/*  58: 74 */       this.tfp.codeCount = cl.runRepoSync();
/*  59: 75 */       for (int i = 0; i < cl.messages.size(); i++) {
/*  60: 77 */         this.tfp.ta.append("\n" + cl.messages.get(i));
/*  61:    */       }
/*  62:    */     }
/*  63:    */     
/*  64:    */     public void run()
/*  65:    */     {
/*  66:    */       try
/*  67:    */       {
/*  68: 90 */         String curAction = "";
/*  69: 91 */         this.tfp.ta.append("\nChecking connection to server");
/*  70:    */         
/*  71: 93 */         this.tfp.ta.append("\n-------------------");
/*  72: 94 */         this.tfp.ta.append("\nStarting Code Update... It might take some time.");
/*  73: 95 */         curAction = "download";
/*  74: 96 */         syncCode();
/*  75:    */         
/*  76:    */ 
/*  77: 99 */         this.tfp.ta.append("\nStarting Data Synchronization...");
/*  78:    */         
/*  79:101 */         curAction = "upload";
/*  80:102 */         this.tfp.ta.append("\n-------------------");
/*  81:103 */         this.tfp.ta.append("\nStarting Upload...");
/*  82:104 */         upload();
/*  83:    */         
/*  84:106 */         this.tfp.ta.append("\nUpload Completed");
/*  85:    */         
/*  86:    */ 
/*  87:    */ 
/*  88:110 */         this.tfp.ta.append("\n-------------------");
/*  89:111 */         this.tfp.ta.append("\nStarting Download... It might take some time.");
/*  90:112 */         curAction = "download";
/*  91:113 */         download();
/*  92:    */         
/*  93:    */ 
/*  94:    */ 
/*  95:117 */         this.tfp.action.getActionListeners()[0].actionPerformed(new ActionEvent(this.tfp.action, 1, "download"));
/*  96:    */         
/*  97:119 */         this.tfp.ta.append("\nDownload Completed");
/*  98:120 */         this.tfp.ta.append("\nSynchronization Completed");
/*  99:    */       }
/* 100:    */       catch (Exception e)
/* 101:    */       {
/* 102:128 */         this.tfp.ta.append(e.toString());
/* 103:129 */         e.printStackTrace();
/* 104:130 */         this.tfp.action.getActionListeners()[0].actionPerformed(new ActionEvent(this.tfp.action, 1, "abort"));
/* 105:    */       }
/* 106:    */     }
/* 107:    */     
/* 108:136 */     public TransferPanel tfp = null;
/* 109:    */   }
/* 110:    */   
/* 111:141 */   public int columns = 1;
/* 112:142 */   public String heading = "Testing a long heading";
/* 113:143 */   private Color color = Color.blue;
/* 114:147 */   public XModel list = null;
/* 115:148 */   XLabel header = null;
/* 116:149 */   XLabel lbl = null;
/* 117:150 */   XTextArea ta = null;
/* 118:151 */   XButton close = null;
/* 119:152 */   public XButton action = new XButton();
/* 120:    */   
/* 121:    */   public void display(String htext, String msg)
/* 122:    */   {
/* 123:164 */     setBounds(310, 150, 300, 350);
/* 124:165 */     setName("error");
/* 125:166 */     setBackground(new Color(50, 50, 255));
/* 126:    */     
/* 127:    */ 
/* 128:169 */     this.close = new XButton();
/* 129:170 */     this.close.setText("close");
/* 130:171 */     this.close.setForeground(Color.white);
/* 131:172 */     this.close.setBackground(Color.red);
/* 132:173 */     this.close.setBounds(259, 2, 40, 18);
/* 133:174 */     this.close.setFont(new Font("Verdana", 1, 12));
/* 134:    */     
/* 135:176 */     this.close.addActionListener(this);
/* 136:177 */     add(this.close);
/* 137:    */     
/* 138:    */ 
/* 139:180 */     this.action.setName("action");
/* 140:181 */     this.action.setText("");
/* 141:182 */     this.action.setForeground(Color.white);
/* 142:183 */     this.action.setBackground(Color.red);
/* 143:184 */     this.action.setBounds(20, 100, 40, 18);
/* 144:185 */     this.action.setFont(new Font("Verdana", 1, 12));
/* 145:    */     
/* 146:187 */     add(this.action);
/* 147:188 */     this.action.setVisible(false);
/* 148:    */     
/* 149:    */ 
/* 150:    */ 
/* 151:192 */     this.ta = new XTextArea();
/* 152:193 */     this.ta.setName("errorContainer");
/* 153:194 */     this.ta.setBackground(new Color(240, 240, 240));
/* 154:195 */     this.ta.setForeground(Color.black);
/* 155:196 */     this.ta.setBounds(3, 22, 294, 325);
/* 156:197 */     this.ta.setEditable(false);
/* 157:198 */     this.ta.setText(msg);
/* 158:    */     
/* 159:    */ 
/* 160:201 */     this.header = new XLabel();
/* 161:202 */     this.header.setName("errorHeader");
/* 162:203 */     this.header.setBackground(new Color(50, 50, 255));
/* 163:204 */     this.header.setForeground(Color.WHITE);
/* 164:205 */     this.header.setBounds(1, 1, 230, 18);
/* 165:    */     
/* 166:207 */     this.header.setFont(new Font("Verdana", 1, 12));
/* 167:208 */     this.header.setText(htext);
/* 168:    */     
/* 169:210 */     add(this.header);
/* 170:211 */     add(this.ta);
/* 171:    */     
/* 172:213 */     Task task = new Task();
/* 173:214 */     task.currentUser = this.currentUser;
/* 174:215 */     task.recepients = this.recepients;
/* 175:216 */     task.tfp = this;
/* 176:217 */     Thread th = new Thread(task);
/* 177:218 */     th.start();
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setColor(Color color)
/* 181:    */   {
/* 182:230 */     this.color = color;
/* 183:    */   }
/* 184:    */   
/* 185:233 */   public String actionStr = null;
/* 186:234 */   public String currentUser = null;
/* 187:235 */   public String recepients = null;
/* 188:    */   
/* 189:    */   public TransferPanel() {}
/* 190:    */   
/* 191:    */   public TransferPanel(boolean arg0)
/* 192:    */   {
/* 193:245 */     super(arg0);
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void actionPerformed(ActionEvent arg0)
/* 197:    */   {
/* 198:251 */     if (arg0.getActionCommand().equals("close")) {
/* 199:252 */       setVisible(false);
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */   public void componentHidden(ComponentEvent arg0) {}
/* 204:    */   
/* 205:    */   public void componentMoved(ComponentEvent arg0) {}
/* 206:    */   
/* 207:    */   public void componentResized(ComponentEvent arg0) {}
/* 208:    */   
/* 209:    */   public void componentShown(ComponentEvent arg0)
/* 210:    */   {
/* 211:274 */     System.out.println("Component Shown");
/* 212:    */   }
/* 213:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.TransferPanel
 * JD-Core Version:    0.7.0.1
 */