/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Frame;
/*   5:    */ import java.awt.event.WindowEvent;
/*   6:    */ import java.awt.event.WindowStateListener;
/*   7:    */ import java.util.Hashtable;
/*   8:    */ import net.xoetrope.awt.XLabel;
/*   9:    */ import net.xoetrope.awt.XPanel;
/*  10:    */ 
/*  11:    */ public class StatusIndicator
/*  12:    */   extends XPanel
/*  13:    */ {
/*  14:    */   public class StatusControl
/*  15:    */     extends XPanel
/*  16:    */   {
/*  17:    */     String name;
/*  18: 31 */     public String status = "NotStarted";
/*  19:    */     
/*  20:    */     public StatusControl(String name)
/*  21:    */     {
/*  22: 34 */       this.name = name;
/*  23:    */     }
/*  24:    */     
/*  25:    */     public void setStatus(String stat)
/*  26:    */     {
/*  27: 40 */       this.status = stat;
/*  28: 41 */       if (this.status.equals("Processing")) {
/*  29: 43 */         this.indic.setBackground(Color.yellow);
/*  30: 46 */       } else if (this.status.equals("Complete")) {
/*  31: 48 */         this.indic.setBackground(Color.green);
/*  32: 51 */       } else if (this.status.equals("Failed")) {
/*  33: 53 */         this.indic.setBackground(Color.red);
/*  34:    */       } else {
/*  35: 56 */         this.indic.setBackground(Color.gray);
/*  36:    */       }
/*  37: 57 */       this.indic.setText(this.status);
/*  38:    */     }
/*  39:    */     
/*  40: 59 */     XLabel lbl = new XLabel();
/*  41: 60 */     XLabel indic = new XLabel();
/*  42:    */     
/*  43:    */     public void display()
/*  44:    */     {
/*  45: 64 */       this.lbl.setName(this.name + "_lbl");
/*  46: 65 */       this.lbl.setText(this.name);
/*  47: 66 */       this.lbl.setForeground(Color.white);
/*  48: 67 */       this.indic.setName(this.name + "_indic");
/*  49: 68 */       this.indic.setText(this.status);
/*  50: 69 */       this.indic.setBackground(Color.gray);
/*  51: 70 */       this.lbl.setBounds(2, 2, getWidth() - 4, 20);
/*  52: 71 */       this.indic.setBounds(2, 25, getWidth() - 4, 30);
/*  53: 72 */       add(this.lbl);
/*  54: 73 */       add(this.indic);
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58: 82 */   public String[] params = { "Code Sync", "Upload", "Download" };
/*  59: 83 */   Hashtable ht = new Hashtable();
/*  60:    */   
/*  61:    */   public void init()
/*  62:    */   {
/*  63: 87 */     for (int i = 0; i < this.params.length; i++)
/*  64:    */     {
/*  65: 89 */       StatusControl st = new StatusControl(this.params[i]);
/*  66: 90 */       st.setBounds(10 + i * 80, 10, 80, 80);
/*  67: 91 */       add(st);
/*  68: 92 */       st.display();
/*  69: 93 */       this.ht.put(this.params[i], st);
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void setStatus(String name, String status)
/*  74:    */   {
/*  75:102 */     StatusControl sc = (StatusControl)this.ht.get(name);
/*  76:103 */     sc.setStatus(status);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static void main(String[] args)
/*  80:    */     throws Exception
/*  81:    */   {
/*  82:107 */     Frame frm = new Frame("tet");
/*  83:108 */     frm.setBounds(10, 10, 800, 600);
/*  84:109 */     StatusIndicator si = new StatusIndicator();
/*  85:110 */     si.setBounds(10, 10, 600, 400);
/*  86:111 */     si.init();
/*  87:112 */     frm.add(si);
/*  88:113 */     frm.addWindowStateListener(
/*  89:114 */       new WindowStateListener()
/*  90:    */       {
/*  91:    */         public void windowStateChanged(WindowEvent arg0)
/*  92:    */         {
/*  93:119 */           if (arg0.getNewState() == 201) {}
/*  94:    */         }
/*  95:125 */       });
/*  96:126 */     frm.show();
/*  97:127 */     Thread.currentThread();Thread.sleep(1000L);
/*  98:128 */     si.setStatus("Upload", "Processing");
/*  99:129 */     si.setStatus("Code Sync", "Complete");
/* 100:130 */     Thread.currentThread();Thread.sleep(1000L);
/* 101:131 */     si.setStatus("Upload", "Complete");
/* 102:132 */     si.setStatus("Download", "Processing");
/* 103:    */   }
/* 104:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.StatusIndicator
 * JD-Core Version:    0.7.0.1
 */