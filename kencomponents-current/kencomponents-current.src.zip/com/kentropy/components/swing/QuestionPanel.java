/*    1:     */ package com.kentropy.components.swing;
/*    2:     */ 
/*    3:     */ import com.kentropy.components.Narrative;
/*    4:     */ import com.kentropy.components.Scribble;
/*    5:     */ import com.kentropy.data.DataService;
/*    6:     */ import com.kentropy.db.TestXUIDB;
/*    7:     */ import com.kentropy.flow.Age;
/*    8:     */ import com.kentropy.flow.QuestionFlowManager;
/*    9:     */ import com.kentropy.gps.GPStest;
/*   10:     */ import com.kentropy.iterators.Iterator;
/*   11:     */ import com.toedter.calendar.JDateChooser;
/*   12:     */ import java.awt.Component;
/*   13:     */ import java.awt.Container;
/*   14:     */ import java.awt.Dimension;
/*   15:     */ import java.awt.Font;
/*   16:     */ import java.awt.Frame;
/*   17:     */ import java.awt.GridLayout;
/*   18:     */ import java.awt.Point;
/*   19:     */ import java.awt.Rectangle;
/*   20:     */ import java.awt.event.ActionEvent;
/*   21:     */ import java.awt.event.ActionListener;
/*   22:     */ import java.awt.event.FocusEvent;
/*   23:     */ import java.awt.event.FocusListener;
/*   24:     */ import java.awt.event.ItemEvent;
/*   25:     */ import java.awt.event.ItemListener;
/*   26:     */ import java.awt.event.KeyEvent;
/*   27:     */ import java.awt.event.KeyListener;
/*   28:     */ import java.awt.event.MouseEvent;
/*   29:     */ import java.awt.event.MouseListener;
/*   30:     */ import java.awt.event.WindowAdapter;
/*   31:     */ import java.awt.event.WindowEvent;
/*   32:     */ import java.awt.im.InputContext;
/*   33:     */ import java.io.PrintStream;
/*   34:     */ import java.nio.CharBuffer;
/*   35:     */ import java.nio.charset.CharacterCodingException;
/*   36:     */ import java.nio.charset.Charset;
/*   37:     */ import java.nio.charset.CharsetEncoder;
/*   38:     */ import java.nio.charset.CodingErrorAction;
/*   39:     */ import java.text.ParseException;
/*   40:     */ import java.text.SimpleDateFormat;
/*   41:     */ import java.util.Date;
/*   42:     */ import java.util.Enumeration;
/*   43:     */ import java.util.Locale;
/*   44:     */ import java.util.Vector;
/*   45:     */ import javax.swing.AbstractButton;
/*   46:     */ import javax.swing.ButtonGroup;
/*   47:     */ import javax.swing.JComboBox;
/*   48:     */ import net.xoetrope.swing.XButton;
/*   49:     */ import net.xoetrope.swing.XCheckbox;
/*   50:     */ import net.xoetrope.swing.XComboBox;
/*   51:     */ import net.xoetrope.swing.XEdit;
/*   52:     */ import net.xoetrope.swing.XLabel;
/*   53:     */ import net.xoetrope.swing.XMessageBox;
/*   54:     */ import net.xoetrope.swing.XPanel;
/*   55:     */ import net.xoetrope.swing.XTable;
/*   56:     */ import net.xoetrope.swing.XTextArea;
/*   57:     */ import net.xoetrope.xui.PageSupport;
/*   58:     */ import net.xoetrope.xui.XPageManager;
/*   59:     */ import net.xoetrope.xui.XProjectManager;
/*   60:     */ import net.xoetrope.xui.XTextHolder;
/*   61:     */ import net.xoetrope.xui.data.XBaseModel;
/*   62:     */ import net.xoetrope.xui.data.XListBinding;
/*   63:     */ import net.xoetrope.xui.data.XModel;
/*   64:     */ 
/*   65:     */ public class QuestionPanel
/*   66:     */   extends XPanel
/*   67:     */   implements ItemListener, KeyListener, MouseListener, ActionListener, FocusListener
/*   68:     */ {
/*   69:  82 */   XTable view = null;
/*   70:  83 */   XModel viewModel = null;
/*   71:  84 */   XModel rootModel = null;
/*   72:  85 */   String currentContextType = "";
/*   73:  86 */   QuestionFlowManager qfm = null;
/*   74:  87 */   XModel flowparams = null;
/*   75:  89 */   public Component[] gpsComps = new Component[2];
/*   76:  91 */   String qtype = "";
/*   77:  92 */   String label = "";
/*   78:  93 */   String test = "";
/*   79:  94 */   StringBuffer value = new StringBuffer();
/*   80:  95 */   XBaseModel dataM = new XBaseModel();
/*   81:  96 */   XModel xm = new XBaseModel();
/*   82:  97 */   XModel qModel = null;
/*   83:  98 */   Component comp = null;
/*   84:  99 */   String selected = "";
/*   85: 101 */   public XModel context = null;
/*   86: 102 */   public XModel selectedContext = null;
/*   87: 104 */   public Object[] viewElements = new Object[3];
/*   88:     */   
/*   89:     */   public boolean checkNumeric(String value1)
/*   90:     */   {
/*   91: 108 */     for (int i = 0; i < value1.length(); i++)
/*   92:     */     {
/*   93: 110 */       String val = value1.substring(i, i + 1);
/*   94:     */       try
/*   95:     */       {
/*   96: 112 */         Integer.parseInt(val);
/*   97:     */       }
/*   98:     */       catch (Exception e)
/*   99:     */       {
/*  100: 116 */         e.printStackTrace();
/*  101: 117 */         return false;
/*  102:     */       }
/*  103:     */     }
/*  104: 122 */     return true;
/*  105:     */   }
/*  106:     */   
/*  107:     */   public boolean checkDate(String value1)
/*  108:     */   {
/*  109: 130 */     String format = this.qModel.get("@format") != null ? this.qModel.get("@format").toString() : "dd/MM/yyyy";
/*  110:     */     
/*  111:     */ 
/*  112: 133 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*  113:     */     try
/*  114:     */     {
/*  115: 135 */       sdf.setLenient(false);
/*  116:     */       
/*  117: 137 */       sdf.parse(this.value.toString());
/*  118:     */     }
/*  119:     */     catch (ParseException e)
/*  120:     */     {
/*  121: 140 */       e.printStackTrace();
/*  122: 141 */       return false;
/*  123:     */     }
/*  124: 148 */     return true;
/*  125:     */   }
/*  126:     */   
/*  127:     */   public void focusGained(FocusEvent e)
/*  128:     */   {
/*  129: 153 */     System.out.println(" Focus gained " + e);
/*  130: 154 */     ((QuestionFlowPanel)getParent()).setSelectedQp(this);
/*  131:     */   }
/*  132:     */   
/*  133:     */   public void focusLost(FocusEvent e)
/*  134:     */   {
/*  135: 160 */     System.out.println("Focus lost " + e.getSource() + " ");
/*  136:     */   }
/*  137:     */   
/*  138:     */   public void addValue(Object comp)
/*  139:     */   {
/*  140: 165 */     String tmpValue = "";
/*  141: 166 */     if ((comp instanceof XComboBox)) {
/*  142: 168 */       tmpValue = (String)((XComboBox)comp).getSelectedItem();
/*  143:     */     }
/*  144: 170 */     if ((comp instanceof XCheckbox)) {
/*  145: 172 */       if (((XCheckbox)comp).isSelected()) {
/*  146: 173 */         tmpValue = ((XCheckbox)comp).getValue().toString();
/*  147:     */       }
/*  148:     */     }
/*  149: 175 */     if ((comp instanceof XEdit))
/*  150:     */     {
/*  151: 177 */       tmpValue = ((XEdit)comp).getText();
/*  152: 178 */       System.out.println("Comp " + ((Component)comp).getName() + " " + tmpValue);
/*  153:     */     }
/*  154: 180 */     if ((comp instanceof XTextArea)) {
/*  155: 182 */       tmpValue = ((XTextArea)comp).getText();
/*  156:     */     }
/*  157: 184 */     if ((comp instanceof JDateChooser)) {
/*  158: 186 */       if (((JDateChooser)comp).getDate() == null)
/*  159:     */       {
/*  160: 187 */         tmpValue = "";
/*  161:     */       }
/*  162:     */       else
/*  163:     */       {
/*  164: 191 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*  165: 192 */         tmpValue = sdf.format(((JDateChooser)comp).getDate());
/*  166:     */       }
/*  167:     */     }
/*  168: 195 */     if ((tmpValue != null) && (!tmpValue.equals("")))
/*  169:     */     {
/*  170: 197 */       System.out.println(this.value + " " + tmpValue);
/*  171:     */       try
/*  172:     */       {
/*  173: 199 */         tmpValue = TestXUIDB.getInstance().getTranslation1(tmpValue, this.lang);
/*  174:     */       }
/*  175:     */       catch (Exception e)
/*  176:     */       {
/*  177: 202 */         e.printStackTrace();
/*  178:     */       }
/*  179: 204 */       System.out.println(this.value + " Translated " + tmpValue);
/*  180: 205 */       this.value.append((this.value.toString().equals("") ? "" : ",") + tmpValue);
/*  181:     */     }
/*  182:     */   }
/*  183:     */   
/*  184:     */   public boolean rangeCheck()
/*  185:     */   {
/*  186: 211 */     String range = this.qModel.get("@range").toString();
/*  187: 212 */     String[] range1 = range.split("-");
/*  188: 214 */     if (this.qModel.get("@type").equals("age"))
/*  189:     */     {
/*  190: 216 */       if (this.value.toString().split(",").length < 2) {
/*  191: 218 */         return false;
/*  192:     */       }
/*  193: 220 */       Age val = new Age(this.value.toString());
/*  194:     */       
/*  195: 222 */       return (val.compareTo(range1[0]) >= 0) && (val.compareTo(range1[1]) <= 0);
/*  196:     */     }
/*  197: 226 */     if ((this.qModel.get("@inputtype") != null) && (this.qModel.get("@inputtype").equals("numeric")))
/*  198:     */     {
/*  199: 228 */       int lower = Integer.parseInt(range1[0]);
/*  200: 229 */       int upper = Integer.parseInt(range1[1]);
/*  201: 230 */       int val1 = Integer.parseInt(this.value.toString());
/*  202:     */       
/*  203: 232 */       return (val1 >= lower) && (val1 <= upper);
/*  204:     */     }
/*  205: 234 */     if ((this.qModel.get("@inputtype") != null) && (this.qModel.get("@inputtype").equals("date")) && (this.qModel.get("@range") != null)) {
/*  206:     */       try
/*  207:     */       {
/*  208: 237 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
/*  209: 238 */         String format = (String)this.qModel.get("@format");
/*  210: 239 */         format = format == null ? "dd/MM/yyyy" : format;
/*  211:     */         
/*  212: 241 */         SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
/*  213:     */         
/*  214: 243 */         Date lower = sdf.parse(range1[0].equals("Now") ? sdf.format(new Date()) : range1[0]);
/*  215: 244 */         Date upper = sdf.parse(range1[1].equals("Now") ? sdf.format(new Date()) : range1[1]);
/*  216: 245 */         Date val1 = sdf1.parse(this.value.toString());
/*  217:     */         
/*  218: 247 */         return (val1.compareTo(lower) >= 0) && (val1.compareTo(upper) <= 0);
/*  219:     */       }
/*  220:     */       catch (Exception e)
/*  221:     */       {
/*  222: 251 */         e.printStackTrace();
/*  223: 252 */         return true;
/*  224:     */       }
/*  225:     */     }
/*  226: 256 */     return (this.value.toString().compareTo(range1[0]) > 0) && (this.value.toString().compareTo(range1[1]) < 0);
/*  227:     */   }
/*  228:     */   
/*  229:     */   public Locale getLocale()
/*  230:     */   {
/*  231: 261 */     return InputContext.getInstance().getLocale();
/*  232:     */   }
/*  233:     */   
/*  234:     */   public String rangeToStr(String range, String type)
/*  235:     */   {
/*  236:     */     try
/*  237:     */     {
/*  238: 268 */       if ((type != null) && (type.equals("date")))
/*  239:     */       {
/*  240: 270 */         String[] range1 = range.split("-");
/*  241: 271 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd", getLocale());
/*  242: 272 */         String format = (String)this.qModel.get("@format");
/*  243: 273 */         format = format == null ? "dd/MM/yyyy" : format;
/*  244: 274 */         SimpleDateFormat sdf1 = new SimpleDateFormat(format, getLocale());
/*  245:     */         
/*  246: 276 */         Date lower = sdf.parse(range1[0].equals("Now") ? sdf.format(new Date()) : range1[0]);
/*  247: 277 */         Date upper = sdf.parse(range1[1].equals("Now") ? sdf.format(new Date()) : range1[1]);
/*  248:     */         
/*  249: 279 */         return sdf1.format(lower) + "-" + sdf1.format(upper);
/*  250:     */       }
/*  251: 282 */       return range;
/*  252:     */     }
/*  253:     */     catch (Exception e)
/*  254:     */     {
/*  255: 287 */       e.printStackTrace();
/*  256:     */     }
/*  257: 289 */     return range;
/*  258:     */   }
/*  259:     */   
/*  260:     */   public void saveValues()
/*  261:     */   {
/*  262: 294 */     this.value = new StringBuffer();
/*  263: 295 */     for (int i = 0; i < getComponentCount(); i++) {
/*  264: 297 */       addValue(getComponent(i));
/*  265:     */     }
/*  266: 299 */     String qno = this.qModel.get("@qno").toString();
/*  267: 300 */     XModel dataModel = (XModel)this.qfm.dataModel.get(qno);
/*  268: 301 */     dataModel.set(this.value.toString());
/*  269:     */   }
/*  270:     */   
/*  271:     */   public void actionPerformed(ActionEvent e)
/*  272:     */   {
/*  273: 308 */     System.out.println(" Actuon " + e.getSource() + " " + e.getActionCommand());
/*  274: 309 */     if ((e.getSource() instanceof JComboBox)) {
/*  275: 311 */       this.selected = ((JComboBox)e.getSource()).getSelectedItem().toString();
/*  276:     */     }
/*  277: 313 */     if (e.getActionCommand().equals("GetGPS")) {
/*  278: 315 */       getGpsCoordinates1();
/*  279:     */     }
/*  280: 318 */     if (e.getActionCommand().equals("Refresh")) {
/*  281: 320 */       if (this.qModel.get("@type").equals("view")) {
/*  282:     */         try
/*  283:     */         {
/*  284: 324 */           readViewModel();
/*  285:     */         }
/*  286:     */         catch (Exception e1)
/*  287:     */         {
/*  288: 327 */           e1.printStackTrace();
/*  289:     */         }
/*  290:     */       }
/*  291:     */     }
/*  292: 334 */     if (e.getActionCommand().equals("Next"))
/*  293:     */     {
/*  294: 336 */       saveValues();
/*  295: 338 */       if (!this.qfm.crossCheck(this.qModel))
/*  296:     */       {
/*  297: 340 */         displayError("Cross check failed!\r\n" + this.qModel.get("@crosscheckmsg"));
/*  298: 341 */         return;
/*  299:     */       }
/*  300: 354 */       if (this.qModel.get("@type").equals("choice")) {
/*  301: 356 */         if ((this.value == null) || (this.value.toString().length() == 0))
/*  302:     */         {
/*  303: 358 */           displayError("Please select one of the listed options");
/*  304: 359 */           return;
/*  305:     */         }
/*  306:     */       }
/*  307: 363 */       if (this.qModel.get("@type").equals("narrative")) {
/*  308: 365 */         if (!validateNarrative())
/*  309:     */         {
/*  310: 367 */           displayError("Please complete the narrative");
/*  311: 368 */           return;
/*  312:     */         }
/*  313:     */       }
/*  314: 372 */       if (this.qModel.get("@lang") != null) {
/*  315: 374 */         if (!isEnglish(this.value.toString()))
/*  316:     */         {
/*  317: 376 */           displayError("Value is not in English ");
/*  318: 377 */           return;
/*  319:     */         }
/*  320:     */       }
/*  321: 382 */       if (this.qModel.get("@range") != null) {
/*  322: 384 */         if (!rangeCheck())
/*  323:     */         {
/*  324: 386 */           String inptype = this.qModel.get("@inputtype") == null ? null : (String)this.qModel.get("@inputtype");
/*  325:     */           
/*  326: 388 */           displayError("Value out of range (" + rangeToStr(this.qModel.get("@range").toString(), inptype) + ")");
/*  327: 389 */           return;
/*  328:     */         }
/*  329:     */       }
/*  330: 395 */       if (this.qModel.get("@regex") != null) {
/*  331: 397 */         if (!this.value.toString().matches(this.qModel.get("@regex").toString()))
/*  332:     */         {
/*  333: 400 */           displayError("Value not in correct format (" + this.qModel.get("@formatstr") + ")");
/*  334: 401 */           return;
/*  335:     */         }
/*  336:     */       }
/*  337: 407 */       if (this.qModel.get("@minchars") != null)
/*  338:     */       {
/*  339: 409 */         System.out.println("Inside michars");
/*  340: 410 */         int minchars = Integer.parseInt(this.qModel.get("@minchars").toString());
/*  341: 411 */         if (minchars > this.value.length())
/*  342:     */         {
/*  343: 413 */           displayError("Please enter at least " + minchars + " characters ");
/*  344: 414 */           return;
/*  345:     */         }
/*  346:     */       }
/*  347: 417 */       if (this.qModel.get("@inputtype") != null)
/*  348:     */       {
/*  349: 419 */         String inputtype = this.qModel.get("@inputtype").toString();
/*  350: 420 */         if (inputtype.equals("numeric")) {
/*  351: 422 */           if (!checkNumeric(this.value.toString()))
/*  352:     */           {
/*  353: 424 */             displayError("Please enter only numbers ");
/*  354: 425 */             return;
/*  355:     */           }
/*  356:     */         }
/*  357: 428 */         if (inputtype.equals("date")) {
/*  358: 430 */           if (!checkDate(this.value.toString()))
/*  359:     */           {
/*  360: 432 */             String format = this.qModel.get("@format") == null ? "dd/MM/yyyy" : this.qModel.get("@format").toString();
/*  361: 433 */             displayError("Please enter valid date value");
/*  362: 434 */             return;
/*  363:     */           }
/*  364:     */         }
/*  365:     */       }
/*  366: 439 */       if (this.qModel.get("@maxtext") != null)
/*  367:     */       {
/*  368: 441 */         String max = "";
/*  369: 442 */         if (this.qModel.get("@maxno") != null) {
/*  370: 444 */           max = this.qModel.get("@maxno").toString();
/*  371:     */         } else {
/*  372: 448 */           max = ((XTextHolder)((Object[])this.viewElements[1])[1]).getText();
/*  373:     */         }
/*  374: 451 */         if ((this.view.getModel() != null) && (Integer.parseInt(max) > this.view.getModel().getNumChildren() - 1))
/*  375:     */         {
/*  376: 453 */           displayError("You have not added all the rows");
/*  377: 454 */           return;
/*  378:     */         }
/*  379:     */       }
/*  380: 459 */       save();
/*  381:     */       
/*  382: 461 */       ((QuestionFlowPanel)getParent()).actionPerformed(e);
/*  383:     */     }
/*  384: 466 */     if (e.getActionCommand().equals("Add"))
/*  385:     */     {
/*  386:     */       try
/*  387:     */       {
/*  388: 470 */         if (this.qModel.get("@maxtext") != null)
/*  389:     */         {
/*  390: 472 */           String max = "";
/*  391: 473 */           if (this.qModel.get("@maxno") != null) {
/*  392: 475 */             max = this.qModel.get("@maxno").toString();
/*  393:     */           } else {
/*  394: 479 */             max = ((XTextHolder)((Object[])this.viewElements[1])[1]).getText();
/*  395:     */           }
/*  396: 482 */           if ((this.view.getModel() != null) && (Integer.parseInt(max) == this.view.getModel().getNumChildren() - 1))
/*  397:     */           {
/*  398: 484 */             displayError("MAX Rows reached");
/*  399: 485 */             return;
/*  400:     */           }
/*  401:     */         }
/*  402: 489 */         saveValues();
/*  403:     */         
/*  404: 491 */         String subflow = this.qModel.get("@subflow").toString();
/*  405: 492 */         XModel flowM = (XModel)this.rootModel.get("flows/" + subflow);
/*  406: 493 */         String contextType = flowM.get("@context").toString();
/*  407: 494 */         String id = TestXUIDB.getInstance().getMaxId(this.context, contextType);
/*  408: 495 */         System.out.println(" next context " + contextType + " " + id);
/*  409: 496 */         this.selectedContext = new XBaseModel();
/*  410: 497 */         this.selectedContext.setId(contextType);
/*  411: 498 */         this.selectedContext.set(id);
/*  412: 499 */         ((QuestionFlowPanel)getParent()).actionPerformed(e);
/*  413:     */       }
/*  414:     */       catch (Exception e1)
/*  415:     */       {
/*  416: 502 */         e1.printStackTrace();
/*  417:     */       }
/*  418:     */     }
/*  419: 506 */     else if (e.getActionCommand().equals("Edit"))
/*  420:     */     {
/*  421: 508 */       saveValues();
/*  422: 509 */       int row = this.view.getSelectedRow();
/*  423: 510 */       String id = this.view.getModel().get(row + 1).getId();
/*  424: 511 */       System.out.println("id =" + id + " row=" + row);
/*  425:     */       try
/*  426:     */       {
/*  427: 514 */         String subflow = this.qModel.get("@subflow").toString();
/*  428: 515 */         XModel flowM = (XModel)this.rootModel.get("flows/" + subflow);
/*  429: 516 */         String contextType = flowM.get("@context").toString();
/*  430:     */         
/*  431: 518 */         this.selectedContext = new XBaseModel();
/*  432: 519 */         this.selectedContext.setId(contextType);
/*  433: 520 */         this.selectedContext.set(id);
/*  434: 521 */         ((QuestionFlowPanel)getParent()).actionPerformed(e);
/*  435:     */       }
/*  436:     */       catch (Exception e1)
/*  437:     */       {
/*  438: 524 */         e1.printStackTrace();
/*  439:     */       }
/*  440:     */     }
/*  441:     */   }
/*  442:     */   
/*  443:     */   private boolean validateNarrative()
/*  444:     */   {
/*  445: 530 */     XModel areaM = (XModel)this.context.get("area");
/*  446: 531 */     XModel indivM = (XModel)this.context.get("member");
/*  447: 532 */     XModel surveyorM = (XModel)this.context.get("surveyor");
/*  448: 533 */     String savePath = "/va/" + areaM.get() + indivM.get() + "/" + surveyorM.get();
/*  449: 534 */     String val = TestXUIDB.getInstance().getValue("resource", savePath + "/narrative");
/*  450: 535 */     if ((val == null) || (val.length() == 0)) {
/*  451: 536 */       return false;
/*  452:     */     }
/*  453: 537 */     return true;
/*  454:     */   }
/*  455:     */   
/*  456:     */   public void mouseClicked(MouseEvent e)
/*  457:     */   {
/*  458: 542 */     System.out.println(e.getSource());
/*  459:     */   }
/*  460:     */   
/*  461:     */   public void mouseEntered(MouseEvent e) {}
/*  462:     */   
/*  463:     */   public void mouseExited(MouseEvent e) {}
/*  464:     */   
/*  465:     */   public void mousePressed(MouseEvent e) {}
/*  466:     */   
/*  467:     */   public void mouseReleased(MouseEvent e) {}
/*  468:     */   
/*  469:     */   public void getChoiceValues()
/*  470:     */   {
/*  471: 563 */     String fieldStr = (String)this.qModel.get("@fields");
/*  472: 564 */     System.out.println(" Fields =" + fieldStr + " " + this.value);
/*  473: 565 */     if (fieldStr == null) {
/*  474: 566 */       return;
/*  475:     */     }
/*  476:     */     try
/*  477:     */     {
/*  478: 568 */       ((XModel)this.dataM.get(fieldStr)).set(TestXUIDB.getInstance().getTranslation1(this.value.toString(), this.lang));
/*  479:     */     }
/*  480:     */     catch (Exception e)
/*  481:     */     {
/*  482: 571 */       e.printStackTrace();
/*  483:     */     }
/*  484:     */   }
/*  485:     */   
/*  486:     */   public void save()
/*  487:     */   {
/*  488: 578 */     String fieldStr = (String)this.qModel.get("@fields");
/*  489: 579 */     System.out.println(" Fields =" + fieldStr + " " + this.value);
/*  490: 580 */     if (fieldStr == null) {
/*  491: 581 */       return;
/*  492:     */     }
/*  493: 582 */     if (this.qModel.get("@type").equals("choice"))
/*  494:     */     {
/*  495: 584 */       getChoiceValues();
/*  496:     */     }
/*  497:     */     else
/*  498:     */     {
/*  499: 587 */       String[] fields = fieldStr.split(",");
/*  500: 588 */       String[] values = this.value.toString().split(",");
/*  501: 589 */       for (int i = 0; (i < fields.length) && (fields.length == values.length); i++)
/*  502:     */       {
/*  503: 591 */         ((XModel)this.dataM.get(fields[i])).set(values[i]);
/*  504: 592 */         System.out.println(fields[i] + " " + values[i]);
/*  505:     */       }
/*  506:     */     }
/*  507:     */     try
/*  508:     */     {
/*  509: 597 */       TestXUIDB.getInstance().saveEnumData(this.context, this.currentContextType, this.dataM);
/*  510:     */     }
/*  511:     */     catch (Exception e)
/*  512:     */     {
/*  513: 600 */       e.printStackTrace();
/*  514:     */     }
/*  515:     */   }
/*  516:     */   
/*  517:     */   public void clearValues()
/*  518:     */   {
/*  519: 606 */     String fieldStr = (String)this.qModel.get("@fields");
/*  520: 607 */     System.out.println(" Fields =" + fieldStr + " " + this.value);
/*  521: 608 */     if (fieldStr == null) {
/*  522: 609 */       return;
/*  523:     */     }
/*  524: 611 */     String[] fields = fieldStr.split(",");
/*  525: 613 */     for (int i = 0; i < fields.length; i++)
/*  526:     */     {
/*  527: 615 */       ((XModel)this.dataM.get(fields[i])).set("");
/*  528: 616 */       System.out.println(fields[i]);
/*  529:     */     }
/*  530:     */     try
/*  531:     */     {
/*  532: 621 */       TestXUIDB.getInstance().saveEnumData(this.context, this.currentContextType, this.dataM);
/*  533:     */     }
/*  534:     */     catch (Exception e)
/*  535:     */     {
/*  536: 624 */       e.printStackTrace();
/*  537:     */     }
/*  538:     */   }
/*  539:     */   
/*  540:     */   public void getGpsCoordinates1()
/*  541:     */   {
/*  542:     */     try
/*  543:     */     {
/*  544: 631 */       String[] gps = GPStest.getGPS("127.0.0.1");
/*  545:     */       
/*  546: 633 */       ((XEdit)this.gpsComps[0]).setText(gps[0]);
/*  547: 634 */       ((XEdit)this.gpsComps[1]).setText(gps[1]);
/*  548:     */     }
/*  549:     */     catch (Exception e)
/*  550:     */     {
/*  551: 638 */       displayError("GPS is not fixed, do you want to continue without GPS?");
/*  552: 639 */       e.printStackTrace();
/*  553:     */     }
/*  554:     */   }
/*  555:     */   
/*  556:     */   public void read()
/*  557:     */   {
/*  558: 645 */     String fieldStr = (String)this.qModel.get("@fields");
/*  559: 646 */     System.out.println(" Fields =" + fieldStr + " " + this.value);
/*  560: 647 */     if (fieldStr == null) {
/*  561: 648 */       return;
/*  562:     */     }
/*  563:     */     try
/*  564:     */     {
/*  565: 653 */       XModel dataM = TestXUIDB.getInstance().getEnumData(this.context, this.currentContextType, fieldStr);
/*  566: 654 */       System.out.println("No of values read" + dataM.getNumChildren());
/*  567: 655 */       if (dataM.getNumChildren() > 0) {
/*  568: 656 */         if (this.qModel.get("@type").equals("choice"))
/*  569:     */         {
/*  570: 658 */           readCheckBoxes(dataM);
/*  571:     */         }
/*  572:     */         else
/*  573:     */         {
/*  574:     */           String value1;
/*  575: 661 */           if (this.qModel.get("@type").equals("date"))
/*  576:     */           {
/*  577: 663 */             value1 = (String)dataM.get(0).get(0).get();
/*  578:     */           }
/*  579:     */           else
/*  580:     */           {
/*  581: 672 */             int index = 0;
/*  582: 673 */             System.out.println("No of fields read" + dataM.get(0).getNumChildren());
/*  583: 674 */             for (int i = 0; i < dataM.get(0).getNumChildren(); i++)
/*  584:     */             {
/*  585: 676 */               String value1 = (String)dataM.get(0).get(i).get();
/*  586: 677 */               System.out.println("Value " + value1);
/*  587: 678 */               index = setNextValue(index + 1, TestXUIDB.getInstance().getTranslation(value1, this.lang));
/*  588:     */             }
/*  589:     */           }
/*  590:     */         }
/*  591:     */       }
/*  592:     */     }
/*  593:     */     catch (Exception e)
/*  594:     */     {
/*  595: 684 */       e.printStackTrace();
/*  596:     */     }
/*  597:     */   }
/*  598:     */   
/*  599:     */   private void readCheckBoxes(XModel dataM2)
/*  600:     */   {
/*  601: 689 */     String vals = (String)dataM2.get(0).get(0).get();
/*  602: 690 */     String[] values = (String[])null;
/*  603: 691 */     if (vals != null) {
/*  604: 692 */       if (vals.indexOf(",") != -1)
/*  605:     */       {
/*  606: 694 */         values = vals.toString().split(",");
/*  607:     */       }
/*  608:     */       else
/*  609:     */       {
/*  610: 698 */         values = new String[1];
/*  611: 699 */         values[0] = vals;
/*  612:     */       }
/*  613:     */     }
/*  614: 701 */     for (int i = 0; (values != null) && (i < this.cbs.size()); i++)
/*  615:     */     {
/*  616: 703 */       XCheckbox cb = (XCheckbox)this.cbs.get(i);
/*  617: 704 */       for (int j = 0; (values != null) && (j < values.length); j++)
/*  618:     */       {
/*  619: 706 */         System.out.println(" cb " + values[j] + " " + cb.getValue());
/*  620: 707 */         if (values[j].equals(cb.getValue()))
/*  621:     */         {
/*  622: 709 */           cb.setSelected(true);
/*  623: 710 */           break;
/*  624:     */         }
/*  625:     */       }
/*  626:     */     }
/*  627:     */   }
/*  628:     */   
/*  629:     */   public int setNextValue(int index, String value)
/*  630:     */   {
/*  631: 719 */     Component[] comps = getComponents();
/*  632: 721 */     for (int i = index; i < comps.length; i++)
/*  633:     */     {
/*  634: 723 */       boolean flg = setValue(comps[i], value);
/*  635: 724 */       if (flg) {
/*  636: 725 */         return i;
/*  637:     */       }
/*  638:     */     }
/*  639: 728 */     return index;
/*  640:     */   }
/*  641:     */   
/*  642:     */   public boolean setValue(Object comp, String value)
/*  643:     */   {
/*  644: 733 */     boolean set = false;
/*  645: 734 */     if (value == null) {
/*  646: 735 */       return false;
/*  647:     */     }
/*  648: 736 */     System.out.println("In set value");
/*  649: 738 */     if ((comp instanceof XComboBox))
/*  650:     */     {
/*  651: 740 */       ((XComboBox)comp).select(value);
/*  652: 741 */       set = true;
/*  653:     */     }
/*  654: 744 */     if ((comp instanceof XEdit))
/*  655:     */     {
/*  656: 746 */       ((XEdit)comp).setText(value);
/*  657: 747 */       set = true;
/*  658:     */     }
/*  659: 749 */     if ((comp instanceof XTextArea))
/*  660:     */     {
/*  661: 751 */       ((XTextArea)comp).setText(value);
/*  662: 752 */       set = true;
/*  663:     */     }
/*  664: 754 */     if ((comp instanceof JDateChooser))
/*  665:     */     {
/*  666: 756 */       System.out.println("In set value 1");
/*  667: 757 */       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*  668:     */       try
/*  669:     */       {
/*  670: 759 */         ((JDateChooser)comp).setDate(sdf.parse(value));
/*  671: 760 */         set = true;
/*  672:     */       }
/*  673:     */       catch (Exception e)
/*  674:     */       {
/*  675: 762 */         set = false;
/*  676:     */         
/*  677: 764 */         e.printStackTrace();
/*  678: 765 */         System.out.println("In exception");
/*  679:     */       }
/*  680:     */     }
/*  681: 770 */     return set;
/*  682:     */   }
/*  683:     */   
/*  684:     */   public void createQuestion() {}
/*  685:     */   
/*  686:     */   public void setQuestionModel(XModel xm)
/*  687:     */   {
/*  688: 789 */     this.qModel = xm;
/*  689: 790 */     String formatStr = (String)xm.get("@formatstr");
/*  690: 791 */     formatStr = formatStr != null ? "(" + formatStr + ")" : "";
/*  691: 792 */     String label = TestXUIDB.getInstance().getTranslation(((XModel)xm.get("text")).get().toString(), this.lang);
/*  692: 793 */     String controltype = xm.get("@type").toString();
/*  693: 794 */     String qno = xm.get("@qno").toString();
/*  694: 795 */     XLabel qLabel = new XLabel();
/*  695: 796 */     qLabel.setText(qno + " " + label);
/*  696: 797 */     qLabel.setName(qno + "Lbl");
/*  697: 798 */     qLabel.setBounds(10, 10, qLabel.getText().length() * 8, 30);
/*  698:     */     
/*  699: 800 */     Font font1 = new Font("Arial Unicode MS", 0, 14);
/*  700:     */     
/*  701: 802 */     qLabel.setFont(font1);
/*  702: 803 */     add(qLabel);
/*  703: 804 */     Object readonly = xm.get("@readonly");
/*  704: 805 */     if ((readonly != null) && (!controltype.equals("view")))
/*  705:     */     {
/*  706: 807 */       XLabel vLabel = new XLabel();
/*  707: 808 */       if (xm.get("@value") != null) {
/*  708: 809 */         vLabel.setText(xm.get("@value").toString());
/*  709:     */       } else {
/*  710: 811 */         vLabel.setText("");
/*  711:     */       }
/*  712: 812 */       vLabel.setBounds(10, 50, 100, 30);
/*  713: 813 */       add(vLabel);
/*  714: 814 */       return;
/*  715:     */     }
/*  716: 817 */     if (controltype.equals("context"))
/*  717:     */     {
/*  718: 818 */       String val = "";
/*  719: 819 */       for (int i = 0; i < this.context.getNumChildren(); i++)
/*  720:     */       {
/*  721: 821 */         String id = this.context.get(i).getId();
/*  722: 822 */         Object tmpVal = (String)this.context.get(i).get();
/*  723: 823 */         val = val + (tmpVal != null ? " " + id + ":" + tmpVal : "");
/*  724:     */       }
/*  725: 825 */       val = val + " Language :" + this.lang;
/*  726: 826 */       XLabel vLabel = new XLabel();
/*  727: 827 */       vLabel.setText(val);
/*  728: 828 */       vLabel.setBounds(10, 50, getWidth(), 30);
/*  729: 829 */       Font font = new Font("Arial Unicode MS", 2, 14);
/*  730:     */       
/*  731: 831 */       vLabel.setFont(font);
/*  732:     */       
/*  733: 833 */       add(vLabel);
/*  734: 834 */       System.out.println("Font " + vLabel.getFont());
/*  735: 835 */       return;
/*  736:     */     }
/*  737: 838 */     if (controltype.equals("choice"))
/*  738:     */     {
/*  739: 840 */       XModel choices = (XModel)xm.get("options");
/*  740: 841 */       if (choices.get("@lookupfunc") != null)
/*  741:     */       {
/*  742: 843 */         Object test = XProjectManager.getPageManager().getCurrentPage(null).evaluateAttribute(choices.get("@lookupfunc").toString());
/*  743: 845 */         if (test != null)
/*  744:     */         {
/*  745: 847 */           choices = (XModel)test;
/*  746: 848 */           System.out.println(" Lookup " + test + " " + choices.getNumChildren());
/*  747:     */         }
/*  748:     */       }
/*  749: 851 */       if (choices.get("@uri") != null)
/*  750:     */       {
/*  751: 853 */         String uri = DataService.translate(this.context, choices.get("@uri").toString());
/*  752: 854 */         String[] cols = choices.get("@cols").toString().split(",");
/*  753: 855 */         XModel test = null;
/*  754:     */         try
/*  755:     */         {
/*  756: 857 */           test = DataService.get(uri);
/*  757:     */         }
/*  758:     */         catch (Exception e)
/*  759:     */         {
/*  760: 860 */           e.printStackTrace();
/*  761:     */         }
/*  762: 863 */         if (test != null)
/*  763:     */         {
/*  764: 865 */           for (int i = 0; i < test.getNumChildren(); i++)
/*  765:     */           {
/*  766: 867 */             XModel choice = new XBaseModel();
/*  767: 868 */             choice.setId(((XModel)test.get(i).get(cols[0])).get().toString());
/*  768: 869 */             choice.set(((XModel)test.get(i).get(cols[1])).get().toString() + "-" + choice.getId().toString());
/*  769: 870 */             choices.append(choice);
/*  770:     */           }
/*  771: 873 */           System.out.println(" URI " + uri + " " + choices.getNumChildren());
/*  772:     */         }
/*  773:     */       }
/*  774: 877 */       this.xm = choices;
/*  775: 878 */       XComboBox combo = new XComboBox();
/*  776:     */       
/*  777: 880 */       System.out.println("Locales " + Locale.getISOCountries());
/*  778:     */       
/*  779:     */ 
/*  780:     */ 
/*  781: 884 */       int w = 100;
/*  782: 885 */       if (this.qModel.get("@width") != null) {
/*  783: 886 */         w = Integer.parseInt(this.qModel.get("@width").toString());
/*  784:     */       }
/*  785: 887 */       combo.setName(qno);
/*  786:     */       
/*  787:     */ 
/*  788:     */ 
/*  789: 891 */       combo.setBounds(10, 50, w, 30);
/*  790:     */       
/*  791:     */ 
/*  792:     */ 
/*  793: 895 */       XListBinding xl = new XListBinding();
/*  794: 897 */       for (int i = 0; i < choices.getNumChildren(); i++)
/*  795:     */       {
/*  796: 899 */         String item = choices.get(i).get().toString();
/*  797:     */         
/*  798:     */ 
/*  799:     */ 
/*  800: 903 */         combo.addItem(TestXUIDB.getInstance().getTranslation(item, this.lang));
/*  801:     */       }
/*  802: 905 */       combo.addKeyListener(this);
/*  803: 906 */       if (xm.get("@value") != null) {
/*  804: 907 */         combo.select(xm.get("@value"));
/*  805:     */       }
/*  806: 908 */       combo.addFocusListener(this);
/*  807:     */       
/*  808:     */ 
/*  809:     */ 
/*  810:     */ 
/*  811:     */ 
/*  812:     */ 
/*  813:     */ 
/*  814: 916 */       boolean single = this.qModel.get("@multiple") == null;
/*  815: 917 */       displayCheckbox(choices, single, (String)xm.get("@value"));
/*  816:     */       
/*  817: 919 */       validate();
/*  818:     */       
/*  819: 921 */       transferFocus();
/*  820:     */     }
/*  821: 925 */     else if (controltype.equals("view"))
/*  822:     */     {
/*  823: 927 */       displayView(xm);
/*  824:     */     }
/*  825: 929 */     else if (controltype.equals("gps"))
/*  826:     */     {
/*  827: 931 */       displayGPS(xm);
/*  828:     */     }
/*  829: 933 */     else if (controltype.equals("age"))
/*  830:     */     {
/*  831: 935 */       displayAge(xm);
/*  832:     */     }
/*  833: 937 */     else if (controltype.equals("date"))
/*  834:     */     {
/*  835: 939 */       displayDate(xm);
/*  836:     */     }
/*  837: 941 */     else if (controltype.equals("narrative"))
/*  838:     */     {
/*  839: 943 */       displayNarrative(xm);
/*  840:     */     }
/*  841: 945 */     else if ((controltype == null) || (controltype.equals("text")))
/*  842:     */     {
/*  843: 947 */       String inputtype = (String)xm.get("@inputtype");
/*  844: 949 */       if ((inputtype != null) && (inputtype.equals("date")))
/*  845:     */       {
/*  846: 951 */         displayDate(xm);
/*  847: 952 */         transferFocus();
/*  848:     */       }
/*  849:     */       else
/*  850:     */       {
/*  851: 955 */         XEdit edit = new XEdit();
/*  852: 956 */         int width = 100;
/*  853: 957 */         if (this.qModel.get("@width") != null) {
/*  854: 959 */           width = Integer.parseInt(this.qModel.get("@width").toString());
/*  855:     */         }
/*  856: 961 */         edit.setBounds(10, 50, width, 30);
/*  857: 962 */         edit.addFocusListener(this);
/*  858: 963 */         edit.addKeyListener(this);
/*  859: 964 */         edit.setName(qno);
/*  860: 965 */         add(edit);
/*  861:     */         
/*  862: 967 */         transferFocus();
/*  863:     */       }
/*  864:     */     }
/*  865: 970 */     else if (controltype.equals("textarea"))
/*  866:     */     {
/*  867: 972 */       XTextArea edit = new XTextArea();
/*  868: 973 */       int width = 100;
/*  869: 974 */       if (this.qModel.get("@width") != null) {
/*  870: 976 */         width = Integer.parseInt(this.qModel.get("@width").toString());
/*  871:     */       }
/*  872: 978 */       edit.setBounds(10, 50, 400, 90);
/*  873: 979 */       edit.addFocusListener(this);
/*  874: 980 */       edit.addKeyListener(this);
/*  875: 981 */       edit.setName(qno);
/*  876: 982 */       add(edit);
/*  877: 983 */       XButton xb2 = new XButton();
/*  878: 984 */       xb2.setLabel("Next");
/*  879: 985 */       xb2.setBounds(380, getHeight() - 40, 100, 20);
/*  880: 986 */       add(xb2);
/*  881: 987 */       xb2.addActionListener(this);
/*  882:     */       
/*  883: 989 */       transferFocus();
/*  884:     */     }
/*  885: 992 */     repaint();
/*  886:     */   }
/*  887:     */   
/*  888: 997 */   ButtonGroup cb = null;
/*  889: 998 */   Vector cbs = null;
/*  890: 999 */   public String lang = "en";
/*  891:1000 */   public String inlineflow = null;
/*  892:     */   
/*  893:     */   public void displayCheckbox(XModel options, boolean single, String vals)
/*  894:     */   {
/*  895:1003 */     System.out.println(" Vals " + vals + " " + this.value);
/*  896:1004 */     Vector pnemonics = new Vector();
/*  897:1006 */     if (single) {
/*  898:1007 */       this.cb = new ButtonGroup();
/*  899:     */     }
/*  900:1008 */     this.cbs = new Vector();
/*  901:     */     
/*  902:1010 */     XPanel xp = new XPanel();
/*  903:1011 */     xp.setLayout(new GridLayout(3, 2));
/*  904:1012 */     xp.setBounds(10, 30, getWidth() - 20, 100);
/*  905:     */     
/*  906:     */ 
/*  907:1015 */     int rows = (getHeight() - 40) / 25;
/*  908:1016 */     int cols = options.getNumChildren() / rows + 1;
/*  909:1017 */     int colcount = 0;
/*  910:1018 */     int rowcount = 0;
/*  911:1019 */     int width = (getWidth() - 20) / cols;
/*  912:1020 */     for (int i = 0; i < options.getNumChildren(); i++)
/*  913:     */     {
/*  914:1022 */       String id = options.get(i).getId();
/*  915:1023 */       String value = options.get(i).get().toString();
/*  916:1024 */       XCheckbox xcb = new XCheckbox();
/*  917:1025 */       if (single) {
/*  918:1026 */         this.cb.add(xcb);
/*  919:     */       }
/*  920:1027 */       this.cbs.add(xcb);
/*  921:1028 */       xcb.setValue(value);
/*  922:1029 */       String txt1 = TestXUIDB.getInstance().getTranslation(value, this.lang);
/*  923:1030 */       xcb.setLabel(txt1);
/*  924:1031 */       if (!pnemonics.contains(Character.valueOf(txt1.charAt(0))))
/*  925:     */       {
/*  926:1033 */         xcb.setMnemonic(txt1.charAt(0));
/*  927:1034 */         pnemonics.add(Character.valueOf(txt1.charAt(0)));
/*  928:     */       }
/*  929:1037 */       else if (!pnemonics.contains(Character.valueOf(txt1.charAt(1))))
/*  930:     */       {
/*  931:1039 */         xcb.setMnemonic(txt1.charAt(1));
/*  932:1040 */         pnemonics.add(Character.valueOf(txt1.charAt(1)));
/*  933:     */       }
/*  934:1044 */       xcb.setBounds(colcount * (width + 5) + 10, 30 + rowcount * 25, width, 20);
/*  935:1045 */       xcb.addItemListener(this);
/*  936:1046 */       xcb.addKeyListener(this);
/*  937:1047 */       add(xcb);
/*  938:1048 */       rowcount++;
/*  939:1049 */       if (rowcount >= rows)
/*  940:     */       {
/*  941:1051 */         colcount++;
/*  942:1052 */         rowcount = 0;
/*  943:     */       }
/*  944:     */     }
/*  945:     */   }
/*  946:     */   
/*  947:     */   public void displayAge(XModel m)
/*  948:     */   {
/*  949:1068 */     int y = 40;
/*  950:1069 */     XLabel ageLbl = new XLabel();
/*  951:1070 */     ageLbl.setText("age");
/*  952:1071 */     ageLbl.setBounds(10, y, 50, 20);
/*  953:1072 */     add(ageLbl);
/*  954:     */     
/*  955:1074 */     XEdit age = new XEdit();
/*  956:1075 */     age.setName("age");
/*  957:1076 */     age.setBounds(70, y, 50, 20);
/*  958:1077 */     add(age);
/*  959:1078 */     XLabel ageUnitLbl = new XLabel();
/*  960:1079 */     ageUnitLbl.setText("unit");
/*  961:1080 */     ageUnitLbl.setBounds(130, y, 50, 20);
/*  962:1081 */     add(ageUnitLbl);
/*  963:1082 */     XComboBox ageUnit = new XComboBox();
/*  964:1083 */     if (this.qModel.get("@units") != null)
/*  965:     */     {
/*  966:1085 */       String[] units1 = this.qModel.get("@units").toString().split(",");
/*  967:1087 */       for (int i = 0; i < units1.length; i++) {
/*  968:1089 */         ageUnit.addItem(units1[i]);
/*  969:     */       }
/*  970:     */     }
/*  971:     */     else
/*  972:     */     {
/*  973:1094 */       ageUnit.addItem("Y");
/*  974:1095 */       ageUnit.addItem("M");
/*  975:1096 */       ageUnit.addItem("D");
/*  976:     */     }
/*  977:1099 */     ageUnit.setName("ageUnit");
/*  978:1100 */     ageUnit.setBounds(190, y, 100, 20);
/*  979:1101 */     add(ageUnit);
/*  980:     */     
/*  981:1103 */     XButton xb2 = new XButton();
/*  982:1104 */     xb2.setLabel("Next");
/*  983:1105 */     xb2.setBounds(310, y, 100, 20);
/*  984:1106 */     add(xb2);
/*  985:1107 */     xb2.addActionListener(this);
/*  986:1108 */     validate();
/*  987:1109 */     transferFocus();
/*  988:     */   }
/*  989:     */   
/*  990:     */   public void checkLocale()
/*  991:     */   {
/*  992:1113 */     if (!InputContext.getInstance().getLocale().getLanguage().equals(this.lang))
/*  993:     */     {
/*  994:1115 */       displayError(" Language keyboard selected is " + InputContext.getInstance().getLocale().getLanguage() + " Please switch to " + this.lang);
/*  995:1116 */       repaint();
/*  996:     */     }
/*  997:     */   }
/*  998:     */   
/*  999:     */   public void displayDate(XModel m)
/* 1000:     */   {
/* 1001:1131 */     System.out.println(" Inside Date");
/* 1002:1132 */     setLayout(null);
/* 1003:1133 */     JDateChooser df = new JDateChooser();
/* 1004:1134 */     df.setBounds(10, 40, 200, 30);
/* 1005:     */     
/* 1006:     */ 
/* 1007:     */ 
/* 1008:     */ 
/* 1009:     */ 
/* 1010:     */ 
/* 1011:     */ 
/* 1012:1142 */     add(df);
/* 1013:1143 */     validate();
/* 1014:1144 */     XButton xb2 = new XButton();
/* 1015:1145 */     xb2.setLabel("Next");
/* 1016:1146 */     xb2.setBounds(260, 40, 100, 20);
/* 1017:1147 */     add(xb2);
/* 1018:1148 */     xb2.addActionListener(this);
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   public static boolean isEnglish(String str)
/* 1022:     */   {
/* 1023:1153 */     Charset asciiCharset = Charset.forName("US-ASCII");
/* 1024:1154 */     CharsetEncoder encoder = asciiCharset.newEncoder();
/* 1025:     */     
/* 1026:1156 */     encoder.onUnmappableCharacter(CodingErrorAction.REPORT);
/* 1027:     */     
/* 1028:1158 */     CharBuffer cb = CharBuffer.wrap(str);
/* 1029:     */     try
/* 1030:     */     {
/* 1031:1160 */       encoder.encode(cb);
/* 1032:1161 */       return true;
/* 1033:     */     }
/* 1034:     */     catch (CharacterCodingException e)
/* 1035:     */     {
/* 1036:1164 */       System.out.println("Failed");
/* 1037:     */     }
/* 1038:1165 */     return false;
/* 1039:     */   }
/* 1040:     */   
/* 1041:     */   public void displayNarrative(XModel m)
/* 1042:     */   {
/* 1043:1175 */     XEdit e1 = new XEdit();
/* 1044:1176 */     e1.setBounds(1, 1, 1, 1);
/* 1045:1177 */     add(e1);
/* 1046:     */     
/* 1047:1179 */     XButton xb1 = new XButton();
/* 1048:1180 */     xb1.setLabel("Open Text Narrative");
/* 1049:1181 */     xb1.setBounds(10, 30, 150, 20);
/* 1050:1182 */     add(xb1);
/* 1051:1183 */     xb1.addActionListener(new ActionListener()
/* 1052:     */     {
/* 1053:     */       public void actionPerformed(ActionEvent e)
/* 1054:     */       {
/* 1055:1188 */         openNarrative();
/* 1056:     */       }
/* 1057:     */       
/* 1058:     */       public boolean checkNarrativeLocale(String savePath)
/* 1059:     */       {
/* 1060:1192 */         String inplang = InputContext.getInstance().getLocale().getLanguage();
/* 1061:1193 */         String savedLang = TestXUIDB.getInstance().getValue("resource", savePath + "/language");
/* 1062:1194 */         if (!inplang.equals(QuestionPanel.this.lang))
/* 1063:     */         {
/* 1064:1196 */           QuestionPanel.this.displayError(" Language keyboard selected is " + InputContext.getInstance().getLocale().getLanguage() + " Please switch to " + QuestionPanel.this.lang);
/* 1065:1197 */           return false;
/* 1066:     */         }
/* 1067:1199 */         if ((savedLang != null) && (!savedLang.equals("")) && (!savedLang.equals(QuestionPanel.this.lang)))
/* 1068:     */         {
/* 1069:1201 */           QuestionPanel.this.displayError(" Narrative was saved in " + savedLang + " Please restart application with " + savedLang);
/* 1070:1202 */           return false;
/* 1071:     */         }
/* 1072:1204 */         return true;
/* 1073:     */       }
/* 1074:     */       
/* 1075:1206 */       String savePath = "";
/* 1076:     */       
/* 1077:     */       public void openNarrative()
/* 1078:     */       {
/* 1079:1209 */         XModel areaM = (XModel)QuestionPanel.this.context.get("area");
/* 1080:1210 */         XModel indivM = (XModel)QuestionPanel.this.context.get("member");
/* 1081:1211 */         XModel surveyorM = (XModel)QuestionPanel.this.context.get("surveyor");
/* 1082:1212 */         this.savePath = ("/va/" + areaM.get() + indivM.get() + "/" + surveyorM.get());
/* 1083:1214 */         if (!checkNarrativeLocale(this.savePath)) {
/* 1084:1215 */           return;
/* 1085:     */         }
/* 1086:1216 */         Frame frame = new Frame("Narrative");
/* 1087:     */         
/* 1088:1218 */         frame.addWindowListener(new WindowAdapter()
/* 1089:     */         {
/* 1090:     */           public void windowClosing(WindowEvent arg0)
/* 1091:     */           {
/* 1092:1222 */             Frame frame = (Frame)arg0.getSource();
/* 1093:1223 */             frame.dispose();
/* 1094:     */           }
/* 1095:1230 */         });
/* 1096:1231 */         frame.setSize(1000, 600);
/* 1097:1232 */         Narrative narrative = new Narrative();
/* 1098:1233 */         narrative.savePath = ("/va/" + areaM.get() + indivM.get() + "/" + surveyorM.get());
/* 1099:1234 */         narrative.rootModel = QuestionPanel.this.rootModel;
/* 1100:1235 */         narrative.lang = QuestionPanel.this.lang;
/* 1101:1236 */         frame.add(narrative);
/* 1102:1237 */         frame.setVisible(true);
/* 1103:     */         
/* 1104:1239 */         narrative.type = QuestionPanel.this.inlineflow.toLowerCase();
/* 1105:1240 */         narrative.init();
/* 1106:     */       }
/* 1107:1248 */     });
/* 1108:1249 */     XButton xb11 = new XButton();
/* 1109:1250 */     xb11.setLabel("Open Image Narrative");
/* 1110:1251 */     xb11.setBounds(250, 30, 160, 20);
/* 1111:     */     
/* 1112:1253 */     xb11.addActionListener(new ActionListener()
/* 1113:     */     {
/* 1114:     */       public void actionPerformed(ActionEvent e)
/* 1115:     */       {
/* 1116:1258 */         openNarrative();
/* 1117:     */       }
/* 1118:     */       
/* 1119:     */       public void openNarrative()
/* 1120:     */       {
/* 1121:1263 */         new Scribble("test");
/* 1122:     */       }
/* 1123:1269 */     });
/* 1124:1270 */     XButton xb2 = new XButton();
/* 1125:1271 */     xb2.setLabel("Next");
/* 1126:1272 */     xb2.setBounds(380, getHeight() - 40, 100, 20);
/* 1127:1273 */     add(xb2);
/* 1128:1274 */     xb2.addActionListener(this);
/* 1129:1275 */     transferFocus();
/* 1130:     */   }
/* 1131:     */   
/* 1132:     */   public void catchAllFocusEvents(Container cont)
/* 1133:     */   {
/* 1134:1281 */     Component[] comps = cont.getComponents();
/* 1135:1282 */     System.out.println(" Catch " + comps.length);
/* 1136:1283 */     for (int i = 0; i < comps.length; i++)
/* 1137:     */     {
/* 1138:1285 */       System.out.println(" Catch " + comps[i] + " " + (comps[i] instanceof Container));
/* 1139:     */       
/* 1140:     */ 
/* 1141:     */ 
/* 1142:     */ 
/* 1143:1290 */       comps[i].addFocusListener(this);
/* 1144:1293 */       if ((comps[i] instanceof Container)) {
/* 1145:1294 */         catchAllFocusEvents((Container)comps[i]);
/* 1146:     */       }
/* 1147:     */     }
/* 1148:     */   }
/* 1149:     */   
/* 1150:     */   public void displayGPS(XModel m)
/* 1151:     */   {
/* 1152:1301 */     int y = 40;
/* 1153:1302 */     XLabel latLbl = new XLabel();
/* 1154:1303 */     latLbl.setText("lat");
/* 1155:1304 */     latLbl.setBounds(10, y, 50, 20);
/* 1156:1305 */     add(latLbl);
/* 1157:     */     
/* 1158:1307 */     XEdit lat = new XEdit();
/* 1159:1308 */     lat.setName("lat");
/* 1160:1309 */     lat.setBounds(70, y, 50, 20);
/* 1161:1310 */     add(lat);
/* 1162:1311 */     this.gpsComps[0] = lat;
/* 1163:1312 */     XLabel longLbl = new XLabel();
/* 1164:1313 */     longLbl.setText("long");
/* 1165:1314 */     longLbl.setBounds(120, y, 50, 20);
/* 1166:1315 */     add(longLbl);
/* 1167:1316 */     XEdit longi = new XEdit();
/* 1168:1317 */     longi.setName("long");
/* 1169:1318 */     longi.setBounds(190, y, 50, 20);
/* 1170:1319 */     add(longi);
/* 1171:1320 */     this.gpsComps[1] = longi;
/* 1172:1321 */     XButton xb1 = new XButton();
/* 1173:1322 */     xb1.setLabel("GetGPS");
/* 1174:1323 */     xb1.setBounds(250, y, 100, 20);
/* 1175:1324 */     xb1.addActionListener(this);
/* 1176:1325 */     add(xb1);
/* 1177:1326 */     XButton xb2 = new XButton();
/* 1178:1327 */     xb2.setLabel("Next");
/* 1179:1328 */     xb2.setBounds(370, y, 100, 20);
/* 1180:1329 */     add(xb2);
/* 1181:1330 */     xb2.addActionListener(this);
/* 1182:     */   }
/* 1183:     */   
/* 1184:     */   public void setAttribute1(String arg0, Object arg1)
/* 1185:     */   {
/* 1186:1335 */     arg0.equals("question");
/* 1187:     */   }
/* 1188:     */   
/* 1189:     */   public void readViewModel()
/* 1190:     */     throws Exception
/* 1191:     */   {
/* 1192:1343 */     String iterator = this.qModel.get("@iterator").toString();
/* 1193:1344 */     Iterator itera = (Iterator)Class.forName(iterator).newInstance();
/* 1194:1345 */     itera.setContext(this.context);
/* 1195:1346 */     if (this.qModel.get("@cols") != null)
/* 1196:     */     {
/* 1197:1348 */       String cols = this.qModel.get("@cols").toString();
/* 1198:1349 */       itera.setFields(cols);
/* 1199:     */     }
/* 1200:1351 */     String subflow = this.qModel.get("@subflow").toString();
/* 1201:1352 */     XModel flowM = (XModel)this.rootModel.get("flows/" + subflow);
/* 1202:1353 */     String contextType = flowM.get("@context").toString();
/* 1203:1354 */     itera.setNextContextType(contextType);
/* 1204:1355 */     String constraints = (String)this.qModel.get("@constraints");
/* 1205:     */     
/* 1206:1357 */     itera.setConstraints(constraints);
/* 1207:1358 */     if (this.qModel.get("@autoupdate") != null) {
/* 1208:1359 */       itera.setAutoUpdate(true);
/* 1209:     */     }
/* 1210:1360 */     itera.init();
/* 1211:     */     
/* 1212:1362 */     XModel tbModel = new XBaseModel();
/* 1213:1363 */     tbModel.setTagName("table");
/* 1214:     */     
/* 1215:1365 */     XModel headers = itera.getHeaders();
/* 1216:1366 */     if (headers != null) {
/* 1217:1367 */       tbModel.append(headers);
/* 1218:     */     }
/* 1219:1368 */     itera.first();
/* 1220:1369 */     XModel xm1 = itera.getData();
/* 1221:1371 */     if (xm1 != null)
/* 1222:     */     {
/* 1223:1372 */       tbModel.append(xm1);
/* 1224:1373 */       while (itera.next())
/* 1225:     */       {
/* 1226:1375 */         xm1 = itera.getData();
/* 1227:1376 */         if (xm1 == null) {
/* 1228:     */           break;
/* 1229:     */         }
/* 1230:1378 */         tbModel.append(xm1);
/* 1231:     */       }
/* 1232:1381 */       if (tbModel.getNumChildren() > 0)
/* 1233:     */       {
/* 1234:1383 */         this.view.setModel(tbModel);
/* 1235:1384 */         if (this.qModel.get("@colwidths") != null)
/* 1236:     */         {
/* 1237:1386 */           String[] colWidths = this.qModel.get("@colwidths").toString().split(",");
/* 1238:1387 */           for (int i = 0; i < colWidths.length; i++)
/* 1239:     */           {
/* 1240:1388 */             System.out.println(" col width " + i + " " + colWidths[i]);
/* 1241:1389 */             this.view.setColWidth(i, Integer.parseInt(colWidths[i]));
/* 1242:     */           }
/* 1243:     */         }
/* 1244:     */       }
/* 1245:     */     }
/* 1246:     */   }
/* 1247:     */   
/* 1248:     */   public void displayView(XModel xm)
/* 1249:     */   {
/* 1250:1398 */     int y = 40;
/* 1251:1400 */     if (this.qModel.get("@selector") != null)
/* 1252:     */     {
/* 1253:1402 */       XLabel selectorLbl = new XLabel();
/* 1254:1403 */       System.out.println(this.qModel.get("@selector"));
/* 1255:1404 */       System.out.println(this.qModel.get("@selectortext"));
/* 1256:1405 */       selectorLbl.setText(this.qModel.get("@selectortext").toString());
/* 1257:1406 */       selectorLbl.setBounds(10, y, 250, 30);
/* 1258:1407 */       add(selectorLbl);
/* 1259:1408 */       XComboBox selector = new XComboBox();
/* 1260:     */       
/* 1261:1410 */       selector.setName("selectorno");
/* 1262:1411 */       selector.setBounds(260, y, 150, 30);
/* 1263:1412 */       selector.addItem(" Choose Any One");
/* 1264:1413 */       selector.addItem("Yes");
/* 1265:1414 */       selector.addItem("No");
/* 1266:1415 */       add(selector);
/* 1267:1416 */       Object[] tt = { selectorLbl, selector };
/* 1268:1417 */       this.viewElements[0] = tt;
/* 1269:1418 */       selector.addKeyListener(this);
/* 1270:1419 */       selector.addFocusListener(this);
/* 1271:1420 */       y += 40;
/* 1272:     */     }
/* 1273:1423 */     String qno = xm.get("@qno").toString();
/* 1274:     */     try
/* 1275:     */     {
/* 1276:1426 */       if (this.qModel.get("@maxtext") != null)
/* 1277:     */       {
/* 1278:1428 */         XLabel maxnoLbl = new XLabel();
/* 1279:1429 */         maxnoLbl.setText(this.qModel.get("@maxtext").toString());
/* 1280:1430 */         maxnoLbl.setBounds(10, y, 100, 30);
/* 1281:1431 */         add(maxnoLbl);
/* 1282:1433 */         if (this.qModel.get("@maxrows") != null)
/* 1283:     */         {
/* 1284:1435 */           XLabel maxno = new XLabel();
/* 1285:1436 */           maxno.setText(this.qModel.get("@maxrows").toString());
/* 1286:1437 */           maxno.setName("maxno");
/* 1287:1438 */           maxno.setBounds(110, y, 50, 30);
/* 1288:1439 */           add(maxno);
/* 1289:1440 */           maxno.addKeyListener(this);
/* 1290:1441 */           Object[] tt = { maxnoLbl, maxno };
/* 1291:1442 */           this.viewElements[1] = tt;
/* 1292:     */           
/* 1293:1444 */           y += 40;
/* 1294:     */         }
/* 1295:     */         else
/* 1296:     */         {
/* 1297:1448 */           XEdit maxno = new XEdit();
/* 1298:     */           
/* 1299:1450 */           maxno.setBounds(110, y, 50, 20);
/* 1300:1451 */           maxno.setName("maxno");
/* 1301:1452 */           add(maxno);
/* 1302:1453 */           maxno.addKeyListener(this);
/* 1303:1454 */           Object[] tt = { maxnoLbl, maxno };
/* 1304:1455 */           this.viewElements[1] = tt;
/* 1305:1456 */           y += 40;
/* 1306:     */         }
/* 1307:     */       }
/* 1308:1461 */       XTable table = new XTable();
/* 1309:1462 */       int h = 200;
/* 1310:1463 */       if (this.qModel.get("@viewheight") != null) {
/* 1311:1465 */         h = Integer.parseInt(this.qModel.get("@viewheight").toString());
/* 1312:     */       }
/* 1313:1467 */       table.setBounds(10, y, getWidth() - 30, h);
/* 1314:1468 */       table.setInteractiveTable(true);
/* 1315:1469 */       table.setSelectedStyle("selectedRow");
/* 1316:1470 */       table.setName(qno);
/* 1317:1471 */       table.addItemListener(this);
/* 1318:     */       
/* 1319:     */ 
/* 1320:1474 */       y = y + h + 10;
/* 1321:1475 */       XButton xb = new XButton();
/* 1322:1476 */       xb.setLabel("Add");
/* 1323:1477 */       xb.setBounds(10, y, 100, 20);
/* 1324:1478 */       xb.addActionListener(this);
/* 1325:1479 */       if (this.qModel.get("@add") != null) {
/* 1326:1480 */         add(xb);
/* 1327:     */       }
/* 1328:1482 */       XButton xb1 = new XButton();
/* 1329:1483 */       xb1.setLabel("Edit");
/* 1330:1484 */       xb1.setBounds(110, y, 100, 20);
/* 1331:1485 */       xb1.addActionListener(this);
/* 1332:1486 */       add(xb1);
/* 1333:     */       
/* 1334:1488 */       XButton xb2 = new XButton();
/* 1335:1489 */       xb2.setLabel("Next");
/* 1336:1490 */       xb2.setBounds(220, y, 100, 20);
/* 1337:1491 */       xb2.addActionListener(this);
/* 1338:1492 */       add(xb2);
/* 1339:1493 */       XButton xb3 = new XButton();
/* 1340:1494 */       xb3.setLabel("Refresh");
/* 1341:1495 */       xb3.setBounds(340, y, 100, 20);
/* 1342:1496 */       xb3.addActionListener(this);
/* 1343:1497 */       add(xb3);
/* 1344:     */       
/* 1345:1499 */       add(table);
/* 1346:1500 */       this.view = table;
/* 1347:1501 */       readViewModel();
/* 1348:1502 */       table.addItemListener(this);
/* 1349:1503 */       table.addKeyListener(this);
/* 1350:1504 */       if (this.qModel.get("@add") != null)
/* 1351:     */       {
/* 1352:1506 */         Object[] tt = { xb, xb1, xb2, xb3 };
/* 1353:1507 */         this.viewElements[2] = tt;
/* 1354:     */       }
/* 1355:     */       else
/* 1356:     */       {
/* 1357:1511 */         Object[] tt = { xb1, xb2, xb3 };
/* 1358:1512 */         this.viewElements[2] = tt;
/* 1359:     */       }
/* 1360:1514 */       if (this.qModel.get("@selector") != null)
/* 1361:     */       {
/* 1362:1516 */         hideViewElements(1, false);
/* 1363:1517 */         hideViewElements(2, false);
/* 1364:1518 */         this.view.setVisible(false);
/* 1365:     */       }
/* 1366:1524 */       transferFocus();
/* 1367:     */     }
/* 1368:     */     catch (InstantiationException e)
/* 1369:     */     {
/* 1370:1528 */       e.printStackTrace();
/* 1371:     */     }
/* 1372:     */     catch (IllegalAccessException e)
/* 1373:     */     {
/* 1374:1531 */       e.printStackTrace();
/* 1375:     */     }
/* 1376:     */     catch (ClassNotFoundException e)
/* 1377:     */     {
/* 1378:1534 */       e.printStackTrace();
/* 1379:     */     }
/* 1380:     */     catch (Exception e)
/* 1381:     */     {
/* 1382:1537 */       e.printStackTrace();
/* 1383:     */     }
/* 1384:     */   }
/* 1385:     */   
/* 1386:     */   public void hideViewElements(int index, boolean flg)
/* 1387:     */   {
/* 1388:1543 */     Object[] elementsToHide = (Object[])this.viewElements[index];
/* 1389:1544 */     if (elementsToHide == null) {
/* 1390:1545 */       return;
/* 1391:     */     }
/* 1392:1546 */     System.out.println("Elements to hide =" + elementsToHide.length);
/* 1393:1547 */     for (int i = 0; i < elementsToHide.length; i++) {
/* 1394:1549 */       ((Component)elementsToHide[i]).setVisible(flg);
/* 1395:     */     }
/* 1396:     */   }
/* 1397:     */   
/* 1398:     */   public void itemStateChanged(ItemEvent e)
/* 1399:     */   {
/* 1400:1555 */     System.out.println(e.getID() + " " + e.getItem());
/* 1401:1556 */     this.selected = e.getItem().toString();
/* 1402:     */   }
/* 1403:     */   
/* 1404:     */   public void keyPressed(KeyEvent e)
/* 1405:     */   {
/* 1406:1561 */     if ((e.getComponent() instanceof XComboBox)) {
/* 1407:1563 */       for (int i = 0; i < this.xm.getNumChildren(); i++)
/* 1408:     */       {
/* 1409:1565 */         System.out.println(" item pressed" + this.xm.get(i).getId());
/* 1410:1566 */         if ((this.xm.get(i).get().toString().startsWith(e.getKeyChar())) || (this.xm.get(i).getId().equals(e.getKeyChar()))) {
/* 1411:1568 */           ((XComboBox)e.getComponent()).select(this.xm.get(i).get().toString());
/* 1412:     */         }
/* 1413:     */       }
/* 1414:     */     }
/* 1415:1571 */     if ((e.getComponent() instanceof XCheckbox))
/* 1416:     */     {
/* 1417:1573 */       Enumeration e1 = this.cbs.elements();
/* 1418:1574 */       for (int i = 0; i < this.xm.getNumChildren(); i++)
/* 1419:     */       {
/* 1420:1576 */         System.out.println(" item pressed" + this.xm.get(i).getId());
/* 1421:1577 */         AbstractButton b = (AbstractButton)e1.nextElement();
/* 1422:1578 */         String key1 = e.getKeyChar();
/* 1423:     */         try
/* 1424:     */         {
/* 1425:1580 */           key1 = TestXUIDB.getInstance().getTranslation1(e.getKeyChar(), this.lang);
/* 1426:     */         }
/* 1427:     */         catch (Exception e2)
/* 1428:     */         {
/* 1429:1583 */           e2.printStackTrace();
/* 1430:     */         }
/* 1431:1585 */         if ((this.xm.get(i).get().toString().startsWith(key1)) || (this.xm.get(i).getId().equals(key1))) {
/* 1432:1588 */           b.setSelected(true);
/* 1433:     */         }
/* 1434:     */       }
/* 1435:     */     }
/* 1436:1593 */     if ((e.getComponent() instanceof JComboBox)) {
/* 1437:1595 */       for (int i = 0; i < this.xm.getNumChildren(); i++)
/* 1438:     */       {
/* 1439:1597 */         System.out.println(" item pressed" + this.xm.get(i).getId() + " " + e.getKeyChar());
/* 1440:1598 */         if ((this.xm.get(i).get().toString().startsWith(e.getKeyChar())) || (this.xm.get(i).getId().equals(e.getKeyChar()))) {
/* 1441:1600 */           ((JComboBox)e.getComponent()).setSelectedIndex(i);
/* 1442:     */         }
/* 1443:     */       }
/* 1444:     */     }
/* 1445:     */   }
/* 1446:     */   
/* 1447:     */   public void viewExit(Component c)
/* 1448:     */     throws Exception
/* 1449:     */   {
/* 1450:1609 */     System.out.println(" View Exit" + c);
/* 1451:1610 */     if ((c instanceof XEdit))
/* 1452:     */     {
/* 1453:1612 */       String value = ((XEdit)c).getText();
/* 1454:     */       try
/* 1455:     */       {
/* 1456:1614 */         Integer.parseInt(value);
/* 1457:     */       }
/* 1458:     */       catch (Exception e)
/* 1459:     */       {
/* 1460:1618 */         e.printStackTrace();
/* 1461:1619 */         displayError("You have to enter a number ");
/* 1462:1620 */         hideViewElements(2, false);
/* 1463:1621 */         return;
/* 1464:     */       }
/* 1465:1624 */       if ((this.view.getModel() != null) && (Integer.parseInt(value) < this.view.getModel().getNumChildren() - 1))
/* 1466:     */       {
/* 1467:1626 */         displayError("Cannot make the value lesser than the number of rows ");
/* 1468:1627 */         hideViewElements(2, false);
/* 1469:     */       }
/* 1470:     */       else
/* 1471:     */       {
/* 1472:1631 */         hideViewElements(2, true);
/* 1473:1632 */         ((XEdit)c).transferFocus();
/* 1474:     */       }
/* 1475:     */     }
/* 1476:1636 */     else if ((c instanceof XComboBox))
/* 1477:     */     {
/* 1478:1638 */       String value = ((XComboBox)c).getSelectedItem().toString();
/* 1479:1639 */       if (value.equals("No"))
/* 1480:     */       {
/* 1481:1641 */         if (!((XEdit)((Object[])this.viewElements[1])[1]).getText().equals(""))
/* 1482:     */         {
/* 1483:1643 */           displayError("Cannot change to No because you have already added a few rows");
/* 1484:1644 */           ((XComboBox)c).select("Yes");
/* 1485:     */         }
/* 1486:     */         else
/* 1487:     */         {
/* 1488:1648 */           hideViewElements(1, false);
/* 1489:1649 */           hideViewElements(2, false);
/* 1490:1650 */           ActionEvent e1 = new ActionEvent(c, 0, "Next");
/* 1491:1651 */           Rectangle r = getBounds();
/* 1492:     */           
/* 1493:1653 */           setBounds(r.x, r.y, r.width, 200);
/* 1494:1654 */           getParent().doLayout();
/* 1495:1655 */           actionPerformed(e1);
/* 1496:     */         }
/* 1497:     */       }
/* 1498:1659 */       else if (((XComboBox)c).getSelectedItem().equals(" Choose Any One"))
/* 1499:     */       {
/* 1500:1660 */         displayError("Please select a value");
/* 1501:     */       }
/* 1502:1662 */       else if (((XComboBox)c).getSelectedItem().equals("Yes"))
/* 1503:     */       {
/* 1504:1664 */         hideViewElements(1, true);
/* 1505:1665 */         this.view.setVisible(true);
/* 1506:     */         
/* 1507:1667 */         ((XComboBox)c).transferFocus();
/* 1508:     */       }
/* 1509:     */     }
/* 1510:     */   }
/* 1511:     */   
/* 1512:     */   public void displayError(String err)
/* 1513:     */   {
/* 1514:1674 */     XMessageBox mbox = new XMessageBox();
/* 1515:1675 */     Dimension size = getSize();
/* 1516:1676 */     Point location = getLocationOnScreen();
/* 1517:1677 */     size = new Dimension(size.width + 2 * location.x, size.height + 2 * location.y);
/* 1518:     */     
/* 1519:1679 */     mbox.setup("Error", err, size, this);
/* 1520:     */   }
/* 1521:     */   
/* 1522:     */   public void keyReleased(KeyEvent e)
/* 1523:     */   {
/* 1524:1684 */     System.out.println(" Key released" + e.getKeyChar() + " " + e.getComponent().getName() + " " + e.isConsumed());
/* 1525:1685 */     if ((e.getKeyCode() == 10) && (!e.isConsumed())) {
/* 1526:     */       try
/* 1527:     */       {
/* 1528:1688 */         System.out.println("Enter released");
/* 1529:1690 */         if (this.qModel.get("@type").equals("view"))
/* 1530:     */         {
/* 1531:1692 */           viewExit((Component)e.getSource());
/* 1532:1693 */           e.consume();
/* 1533:1694 */           return;
/* 1534:     */         }
/* 1535:1696 */         if (this.qModel.get("@type").equals("textarea")) {
/* 1536:1699 */           return;
/* 1537:     */         }
/* 1538:1701 */         if (this.qModel.get("@type").equals("age")) {
/* 1539:1704 */           System.out.println(" Enter pressed on age");
/* 1540:     */         }
/* 1541:1707 */         if (this.qModel.get("@type").equals("narrative"))
/* 1542:     */         {
/* 1543:1710 */           System.out.println(" Enter pressed on narrative");
/* 1544:1711 */           e.consume();
/* 1545:1712 */           return;
/* 1546:     */         }
/* 1547:1714 */         ActionEvent e1 = new ActionEvent(e.getSource(), 0, "Next");
/* 1548:     */         
/* 1549:1716 */         actionPerformed(e1);
/* 1550:1717 */         e.consume();
/* 1551:1718 */         return;
/* 1552:     */       }
/* 1553:     */       catch (Exception e1)
/* 1554:     */       {
/* 1555:1722 */         e.consume();
/* 1556:     */       }
/* 1557:     */     }
/* 1558:     */   }
/* 1559:     */   
/* 1560:1725 */   String keyBuf = "";
/* 1561:     */   
/* 1562:     */   public void keyTyped(KeyEvent e)
/* 1563:     */   {
/* 1564:1729 */     System.out.println(" Key typed" + e.getKeyChar() + " " + e.getComponent().getName() + " " + e.isConsumed());
/* 1565:1730 */     if ((e.getComponent() instanceof XCheckbox))
/* 1566:     */     {
/* 1567:1732 */       Enumeration e1 = this.cbs.elements();
/* 1568:1734 */       for (int i = 0; i < this.xm.getNumChildren(); i++)
/* 1569:     */       {
/* 1570:1736 */         System.out.println(" item pressed" + this.xm.get(i).getId());
/* 1571:1737 */         AbstractButton b = (AbstractButton)e1.nextElement();
/* 1572:1738 */         String key1 = e.getKeyChar();
/* 1573:1739 */         String key2 = e.getKeyChar();
/* 1574:     */         try
/* 1575:     */         {
/* 1576:1742 */           key1 = TestXUIDB.getInstance().getTranslation1(e.getKeyChar(), this.lang);
/* 1577:     */         }
/* 1578:     */         catch (Exception e2)
/* 1579:     */         {
/* 1580:1745 */           e2.printStackTrace();
/* 1581:     */         }
/* 1582:1748 */         if ((b.getText().startsWith(key2)) || (this.xm.get(i).get().toString().toLowerCase().startsWith(key1.toLowerCase())) || (this.xm.get(i).getId().equals(key1)) || (this.xm.get(i).getId().equals(this.keyBuf + key1)))
/* 1583:     */         {
/* 1584:1752 */           b.setSelected(true);
/* 1585:1753 */           this.keyBuf = "";
/* 1586:1754 */           return;
/* 1587:     */         }
/* 1588:1757 */         if (this.xm.get(i).getId().startsWith(key1)) {
/* 1589:1759 */           this.keyBuf += key1;
/* 1590:     */         } else {
/* 1591:1763 */           this.keyBuf = "";
/* 1592:     */         }
/* 1593:     */       }
/* 1594:     */     }
/* 1595:     */   }
/* 1596:     */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.swing.QuestionPanel
 * JD-Core Version:    0.7.0.1
 */