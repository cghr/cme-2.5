/*   1:    */ package com.kentropy.components.swing;
/*   2:    */ 
/*   3:    */ import com.kentropy.components.TransferPanel1;
/*   4:    */ import com.kentropy.transfer.Discovery;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Frame;
/*   7:    */ import java.awt.Image;
/*   8:    */ import java.awt.PopupMenu;
/*   9:    */ import java.awt.SystemTray;
/*  10:    */ import java.awt.Toolkit;
/*  11:    */ import java.awt.TrayIcon;
/*  12:    */ import java.awt.event.ActionEvent;
/*  13:    */ import java.awt.event.ActionListener;
/*  14:    */ import java.awt.event.WindowEvent;
/*  15:    */ import java.awt.event.WindowStateListener;
/*  16:    */ import java.io.PrintStream;
/*  17:    */ import java.util.ArrayDeque;
/*  18:    */ import java.util.Observable;
/*  19:    */ import java.util.Observer;
/*  20:    */ import java.util.Vector;
/*  21:    */ import net.xoetrope.swing.XButton;
/*  22:    */ import net.xoetrope.swing.XLabel;
/*  23:    */ import net.xoetrope.swing.XPanel;
/*  24:    */ 
/*  25:    */ public class NetworkPanel
/*  26:    */   extends XPanel
/*  27:    */   implements Observer, ActionListener
/*  28:    */ {
/*  29: 49 */   int[] counters = null;
/*  30: 50 */   ArrayDeque<String> q = new ArrayDeque();
/*  31: 51 */   String username = null;
/*  32: 52 */   String passwd = null;
/*  33: 53 */   String recepients = null;
/*  34: 54 */   String id = null;
/*  35: 55 */   public static int sleepTime = 10000;
/*  36: 56 */   public static int noOfCycles = 20;
/*  37:    */   
/*  38:    */   public NetworkPanel(String uname, String p, String r, String id1)
/*  39:    */   {
/*  40: 59 */     this.username = uname;
/*  41: 60 */     this.passwd = p;
/*  42: 61 */     this.recepients = r;
/*  43: 62 */     this.id = id1;
/*  44:    */   }
/*  45:    */   
/*  46: 65 */   public TransferPanel1 tfp = new TransferPanel1();
/*  47:    */   
/*  48:    */   public void sync(String node)
/*  49:    */   {
/*  50:    */     try
/*  51:    */     {
/*  52: 76 */       this.tfp.actionStr = "upload";
/*  53: 77 */       this.tfp.currentUser = this.id;
/*  54: 78 */       this.tfp.recepients = this.recepients;
/*  55: 79 */       this.tfp.run();
/*  56:    */     }
/*  57:    */     catch (Exception e)
/*  58:    */     {
/*  59: 84 */       e.printStackTrace();
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void init()
/*  64:    */   {
/*  65: 91 */     Vector networks = Discovery.network;
/*  66: 92 */     this.counters = new int[networks.size()];
/*  67: 93 */     for (int i = 0; i < networks.size(); i++)
/*  68:    */     {
/*  69: 95 */       XLabel label = new XLabel();
/*  70: 96 */       label.setBounds(10, 10 + i * 30, 350, 20);
/*  71: 97 */       label.setText(networks.get(i).toString());
/*  72: 98 */       add(label);
/*  73: 99 */       XButton btn = new XButton();
/*  74:100 */       btn.setBounds(360, 10 + i * 30, 150, 20);
/*  75:101 */       String[] tt = networks.get(i).toString().split(",");
/*  76:102 */       if (tt[2].equals("server")) {
/*  77:103 */         btn.setLabel("Get and Send");
/*  78:    */       } else {
/*  79:105 */         btn.setLabel("Send");
/*  80:    */       }
/*  81:106 */       btn.setEnabled(false);
/*  82:107 */       btn.addActionListener(this);
/*  83:108 */       add(btn);
/*  84:109 */       this.counters[i] = 0;
/*  85:    */     }
/*  86:113 */     XButton btn = new XButton();
/*  87:114 */     btn.setBounds(360, 300, 150, 20);
/*  88:    */     
/*  89:116 */     btn.setLabel("Close");
/*  90:    */     
/*  91:118 */     btn.addActionListener(this);
/*  92:119 */     add(btn);
/*  93:120 */     add(this.tfp, 0);
/*  94:121 */     this.tfp.display("Upload", "Starting upload ");
/*  95:122 */     this.tfp.setVisible(true);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static void main(String[] args)
/*  99:    */     throws Exception
/* 100:    */   {
/* 101:140 */     Frame frm = new Frame("tet");
/* 102:141 */     frm.setBounds(10, 10, 800, 600);
/* 103:142 */     Image img = Toolkit.getDefaultToolkit().createImage("resources/cghr_logo1.gif");
/* 104:143 */     TrayIcon t = new TrayIcon(img);
/* 105:144 */     t.setToolTip("Hello world");
/* 106:145 */     PopupMenu p = new PopupMenu();
/* 107:146 */     p.add("Maximize");
/* 108:147 */     p.add("Minimize");
/* 109:148 */     p.add("Close");
/* 110:149 */     p.addActionListener(new ActionListener()
/* 111:    */     {
/* 112:    */       public void actionPerformed(ActionEvent arg0)
/* 113:    */       {
/* 114:154 */         System.out.println(arg0.getActionCommand());
/* 115:155 */         if (arg0.getActionCommand().equals("Maximize"))
/* 116:    */         {
/* 117:156 */           NetworkPanel.this.setState(0);
/* 118:    */         }
/* 119:158 */         else if (arg0.getActionCommand().equals("Minimize"))
/* 120:    */         {
/* 121:159 */           NetworkPanel.this.setState(1);
/* 122:    */         }
/* 123:    */         else
/* 124:    */         {
/* 125:162 */           NetworkPanel.this.dispose();
/* 126:163 */           System.exit(0);
/* 127:    */         }
/* 128:    */       }
/* 129:172 */     });
/* 130:173 */     t.setPopupMenu(p);
/* 131:    */     
/* 132:    */ 
/* 133:176 */     SystemTray.getSystemTray().add(t);
/* 134:177 */     frm.setState(1);
/* 135:    */     
/* 136:    */ 
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:187 */     NetworkPanel np = new NetworkPanel("test", "test", "admin", "9");
/* 145:188 */     np.setBounds(10, 10, 600, 400);
/* 146:189 */     np.init();
/* 147:190 */     frm.add(np);
/* 148:    */     
/* 149:192 */     frm.addWindowStateListener(
/* 150:193 */       new WindowStateListener()
/* 151:    */       {
/* 152:    */         public void windowStateChanged(WindowEvent arg0)
/* 153:    */         {
/* 154:198 */           if (arg0.getNewState() == 201) {
/* 155:199 */             SystemTray.getSystemTray().remove(SystemTray.getSystemTray().getTrayIcons()[0]);
/* 156:    */           }
/* 157:    */         }
/* 158:203 */       });
/* 159:204 */     frm.show();
/* 160:    */     
/* 161:206 */     Thread th = new Thread(new Discovery(np));
/* 162:207 */     th.start();
/* 163:208 */     np.stop();
/* 164:209 */     Thread.currentThread();Thread.sleep(sleepTime);
/* 165:210 */     np.start();
/* 166:    */   }
/* 167:    */   
/* 168:214 */   int counter = 0;
/* 169:    */   
/* 170:    */   public void update(Observable arg0, Object arg1)
/* 171:    */   {
/* 172:218 */     System.out.println(" Status is " + this.status);
/* 173:219 */     if (this.status.equals("NotStarted")) {
/* 174:220 */       return;
/* 175:    */     }
/* 176:221 */     this.counter += 1;
/* 177:222 */     System.out.println(" Counter is " + this.counter);
/* 178:223 */     for (int i = 0; i < getComponentCount(); i++) {
/* 179:225 */       if ((getComponent(i) instanceof XLabel))
/* 180:    */       {
/* 181:226 */         XLabel label = (XLabel)getComponent(i);
/* 182:227 */         String[] tt = arg1.toString().split(" ");
/* 183:228 */         String[] tt1 = label.getText().split(" ");
/* 184:229 */         if (tt[0].trim().equals(tt1[0]))
/* 185:    */         {
/* 186:231 */           label.setText(arg1.toString());
/* 187:232 */           if (tt[1].equals("alive"))
/* 188:    */           {
/* 189:234 */             getComponent(i + 1).setEnabled(true);
/* 190:237 */             if (!this.q.contains(arg1.toString()))
/* 191:    */             {
/* 192:239 */               System.out.println("Adding to queue " + this.q.size());
/* 193:    */               
/* 194:241 */               this.q.push(arg1.toString());
/* 195:    */             }
/* 196:    */           }
/* 197:    */           else
/* 198:    */           {
/* 199:246 */             getComponent(i + 1).setEnabled(false);
/* 200:    */           }
/* 201:    */         }
/* 202:    */       }
/* 203:    */     }
/* 204:252 */     if (this.counter > noOfCycles)
/* 205:    */     {
/* 206:254 */       processQueue();
/* 207:255 */       this.counter = 0;
/* 208:    */     }
/* 209:    */   }
/* 210:    */   
/* 211:259 */   String status = "Started";
/* 212:    */   
/* 213:    */   public void stop()
/* 214:    */   {
/* 215:262 */     System.out.println(" Stopping ");
/* 216:263 */     this.status = "NotStarted";
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void start()
/* 220:    */   {
/* 221:267 */     System.out.println(" Starting ");
/* 222:268 */     this.status = "Started";
/* 223:    */   }
/* 224:    */   
/* 225:    */   public void start(int counter1)
/* 226:    */   {
/* 227:273 */     System.out.println(" Starting ");
/* 228:274 */     this.status = "Started";
/* 229:275 */     this.counter = counter1;
/* 230:    */   }
/* 231:    */   
/* 232:    */   private synchronized void processQueue()
/* 233:    */   {
/* 234:281 */     while (!this.q.isEmpty()) {
/* 235:282 */       sync((String)this.q.pop());
/* 236:    */     }
/* 237:    */   }
/* 238:    */   
/* 239:    */   public void actionPerformed(ActionEvent arg0)
/* 240:    */   {
/* 241:289 */     if (arg0.getActionCommand().equals("Close"))
/* 242:    */     {
/* 243:291 */       setVisible(false);
/* 244:    */     }
/* 245:    */     else
/* 246:    */     {
/* 247:296 */       this.q.add("");
/* 248:297 */       processQueue();
/* 249:298 */       this.counter = 0;
/* 250:    */     }
/* 251:    */   }
/* 252:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.swing.NetworkPanel
 * JD-Core Version:    0.7.0.1
 */