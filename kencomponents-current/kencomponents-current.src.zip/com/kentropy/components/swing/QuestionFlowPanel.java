/*   1:    */ package com.kentropy.components.swing;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import com.kentropy.flow.QuestionFlowManager;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.Point;
/*   9:    */ import java.awt.Rectangle;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.event.ActionListener;
/*  12:    */ import java.awt.event.ItemEvent;
/*  13:    */ import java.awt.event.ItemListener;
/*  14:    */ import java.awt.event.KeyEvent;
/*  15:    */ import java.awt.event.KeyListener;
/*  16:    */ import java.awt.event.MouseEvent;
/*  17:    */ import java.awt.event.MouseListener;
/*  18:    */ import java.io.PrintStream;
/*  19:    */ import java.text.SimpleDateFormat;
/*  20:    */ import java.util.Date;
/*  21:    */ import java.util.Vector;
/*  22:    */ import javax.swing.JViewport;
/*  23:    */ import net.xoetrope.swing.XMessageBox;
/*  24:    */ import net.xoetrope.swing.XPanel;
/*  25:    */ import net.xoetrope.xui.data.XBaseModel;
/*  26:    */ import net.xoetrope.xui.data.XModel;
/*  27:    */ 
/*  28:    */ public class QuestionFlowPanel
/*  29:    */   extends XPanel
/*  30:    */   implements ItemListener, KeyListener, MouseListener, ActionListener
/*  31:    */ {
/*  32: 38 */   public QuestionPanel selectedQp = null;
/*  33: 39 */   public QuestionFlowManager qfm = new QuestionFlowManager();
/*  34: 40 */   public Vector qps = new Vector();
/*  35: 41 */   public XModel rootModel = null;
/*  36: 42 */   public QuestionFlowPanel parent = null;
/*  37: 43 */   public XModel context = null;
/*  38: 44 */   public String lang = "en";
/*  39: 46 */   String qtype = "";
/*  40: 47 */   String label = "";
/*  41: 48 */   String test = "";
/*  42: 49 */   String value = "";
/*  43: 50 */   XModel xm = new XBaseModel();
/*  44: 51 */   XModel qModel = null;
/*  45: 52 */   Component comp = null;
/*  46: 53 */   String selected = "";
/*  47: 55 */   int count = 0;
/*  48: 56 */   public String currentContextType = "";
/*  49:    */   
/*  50:    */   public void save()
/*  51:    */   {
/*  52: 60 */     String table = this.qfm.flowModel.get("@table").toString();
/*  53: 61 */     String where = "";
/*  54: 62 */     for (int i = 0; i < this.context.getNumChildren(); i++)
/*  55:    */     {
/*  56: 64 */       String key = this.context.get(i).getId();
/*  57: 65 */       String value = this.context.get(i).get().toString();
/*  58: 66 */       String tablekey = this.qfm.flowModel.get("@" + key + "Fld").toString();
/*  59: 67 */       where = where + (i == 0 ? "" : " and ") + tablekey + "'" + value + "'";
/*  60:    */     }
/*  61: 70 */     for (int i = 0; i < this.qps.size(); i++)
/*  62:    */     {
/*  63: 72 */       QuestionPanel qp = (QuestionPanel)this.qps.get(i);
/*  64: 73 */       String field = qp.qModel.get("@field").toString();
/*  65: 74 */       ((XModel)this.xm.get(field)).set(qp.value);
/*  66: 75 */       System.out.println(qp.getName() + " " + qp.value);
/*  67:    */     }
/*  68:    */     try
/*  69:    */     {
/*  70: 80 */       TestXUIDB.getInstance().saveDataM(table, where, this.xm);
/*  71:    */     }
/*  72:    */     catch (Exception e)
/*  73:    */     {
/*  74: 83 */       e.printStackTrace();
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void read()
/*  79:    */   {
/*  80: 89 */     XModel xm = new XBaseModel();
/*  81: 90 */     String table = this.qfm.flowModel.get("@table").toString();
/*  82: 91 */     String where = "";
/*  83: 92 */     for (int i = 0; i < this.context.getNumChildren(); i++)
/*  84:    */     {
/*  85: 94 */       String key = this.context.get(i).getId();
/*  86: 95 */       String value = this.context.get(i).get().toString();
/*  87: 96 */       String tablekey = this.qfm.flowModel.get("@" + key + "Fld").toString();
/*  88: 97 */       where = where + (i == 0 ? "" : " and ") + tablekey + "'" + value + "'";
/*  89:    */     }
/*  90:    */     try
/*  91:    */     {
/*  92:102 */       xm = TestXUIDB.getInstance().getDataM1(table, where);
/*  93:103 */       this.qfm.dataModel = xm;
/*  94:    */     }
/*  95:    */     catch (Exception e)
/*  96:    */     {
/*  97:106 */       e.printStackTrace();
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:110 */   Date qStartTime = null;
/* 102:111 */   Date qEndTime = null;
/* 103:    */   
/* 104:    */   public void displayQuestion(XModel xm)
/* 105:    */   {
/* 106:114 */     System.out.println(" Displa q" + xm);
/* 107:115 */     if (xm != null)
/* 108:    */     {
/* 109:117 */       QuestionPanel qp = new QuestionPanel();
/* 110:118 */       this.qStartTime = new Date();
/* 111:119 */       qp.lang = this.lang;
/* 112:120 */       qp.qfm = this.qfm;
/* 113:121 */       qp.flowparams = this.qfm.getFlowParams();
/* 114:    */       
/* 115:123 */       qp.inlineflow = this.qfm.inlineflow;
/* 116:    */       
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:128 */       qp.setLayout(null);
/* 121:129 */       qp.context = this.context;
/* 122:130 */       qp.setAttribute("border", "1");
/* 123:131 */       qp.currentContextType = this.currentContextType;
/* 124:132 */       QuestionPanel lastqp = this.qps.size() > 0 ? (QuestionPanel)this.qps.get(this.qps.size() - 1) : null;
/* 125:133 */       int x = 10;
/* 126:134 */       int y = lastqp == null ? 30 : lastqp.getHeight() + lastqp.getY() + 10;
/* 127:135 */       int w = getWidth() - 30;
/* 128:136 */       int h = xm.get("@type").equals("textarea") ? 200 : xm.get("@type").equals("view") ? 400 : 100;
/* 129:137 */       if (xm.get("@height") != null) {
/* 130:139 */         h = Integer.parseInt(xm.get("@height").toString());
/* 131:    */       }
/* 132:141 */       System.out.println(x + " " + y + " " + w + " " + h);
/* 133:142 */       qp.setBounds(x, y, w, h);
/* 134:143 */       qp.rootModel = this.rootModel;
/* 135:144 */       add(qp);
/* 136:145 */       qp.setQuestionModel(xm);
/* 137:146 */       qp.setName(xm.getId());
/* 138:147 */       qp.read();
/* 139:148 */       this.qps.add(qp);
/* 140:149 */       this.selectedQp = qp;
/* 141:    */       
/* 142:    */ 
/* 143:152 */       ((JViewport)getParent()).setViewPosition(new Point(x, y - 100));
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void setSelectedQp(QuestionPanel qp)
/* 148:    */   {
/* 149:160 */     int i = this.qps.indexOf(qp) + 1;
/* 150:161 */     this.qfm.goTo(i - 2);
/* 151:162 */     System.out.println(" Current  " + this.qfm.current);
/* 152:164 */     while (this.qps.size() > i)
/* 153:    */     {
/* 154:166 */       QuestionPanel qp1 = (QuestionPanel)this.qps.get(i);
/* 155:    */       
/* 156:168 */       qp1.setVisible(false);
/* 157:169 */       remove(qp1);
/* 158:170 */       this.qps.remove(qp1);
/* 159:    */     }
/* 160:173 */     validate();
/* 161:174 */     repaint();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void scrollToCurrent()
/* 165:    */   {
/* 166:181 */     ((JViewport)getParent()).setViewPosition(new Point(10, this.selectedQp.getY() - 100));
/* 167:    */   }
/* 168:    */   
/* 169:    */   public void displayContext(XModel xm)
/* 170:    */   {
/* 171:185 */     System.out.println(" Displa q" + xm);
/* 172:186 */     if (xm != null)
/* 173:    */     {
/* 174:188 */       QuestionPanel qp = new QuestionPanel();
/* 175:189 */       qp.lang = this.lang;
/* 176:190 */       int x = 10;
/* 177:191 */       int y = 30;
/* 178:192 */       int w = getWidth() - 30;
/* 179:193 */       int h = 100;
/* 180:194 */       System.out.println(x + " " + y + " " + w + " " + h);
/* 181:195 */       qp.context = this.context;
/* 182:196 */       qp.setBounds(x, y, w, h);
/* 183:197 */       add(qp);
/* 184:198 */       qp.setQuestionModel(xm);
/* 185:199 */       qp.setName(xm.getId());
/* 186:    */       
/* 187:201 */       this.qps.add(qp);
/* 188:    */       
/* 189:    */ 
/* 190:204 */       ((JViewport)getParent()).setViewPosition(new Point(x, y - 100));
/* 191:    */     }
/* 192:    */   }
/* 193:    */   
/* 194:    */   public void displaySubFlow(XModel xm)
/* 195:    */   {
/* 196:209 */     System.out.println(" Displa q" + xm);
/* 197:210 */     if (xm != null)
/* 198:    */     {
/* 199:212 */       QuestionFlowPanel qfp = new QuestionFlowPanel();
/* 200:213 */       qfp.lang = this.lang;
/* 201:214 */       qfp.rootModel = this.rootModel;
/* 202:    */       
/* 203:216 */       XModel newContext = new XBaseModel();
/* 204:218 */       for (int i = 0; i < this.context.getNumChildren(); i++) {
/* 205:220 */         newContext.append(this.context.get(i));
/* 206:    */       }
/* 207:223 */       newContext.append(this.selectedQp.selectedContext);
/* 208:224 */       ((XModel)this.rootModel.get("currentContext")).removeChildren();
/* 209:225 */       ((XModel)this.rootModel.get("currentContext")).append(this.context);
/* 210:    */       
/* 211:227 */       qfp.setBounds(getX(), getY(), getWidth(), getHeight());
/* 212:228 */       qfp.setPreferredSize(new Dimension(getWidth(), getHeight()));
/* 213:    */       
/* 214:    */ 
/* 215:    */ 
/* 216:232 */       ((JViewport)getParent()).setView(qfp);
/* 217:    */       
/* 218:234 */       qfp.setName(xm.getId());
/* 219:235 */       this.rootModel.set("currentPanel", xm.getId());
/* 220:    */       
/* 221:237 */       qfp.parent = this;
/* 222:238 */       qfp.context = newContext;
/* 223:239 */       qfp.currentContextType = this.selectedQp.selectedContext.getId();
/* 224:240 */       XModel flowParams = new XBaseModel();
/* 225:    */       try
/* 226:    */       {
/* 227:242 */         flowParams = TestXUIDB.getInstance().getFlowParameters(newContext, qfp.currentContextType);
/* 228:    */       }
/* 229:    */       catch (Exception e)
/* 230:    */       {
/* 231:245 */         e.printStackTrace();
/* 232:    */       }
/* 233:247 */       qfp.setQuestionFlowModel(xm, flowParams);
/* 234:    */     }
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void displayInlineFlow(XModel xm)
/* 238:    */   {
/* 239:251 */     System.out.println(" Displa q" + xm);
/* 240:252 */     if (xm != null)
/* 241:    */     {
/* 242:254 */       QuestionFlowPanel qfp = new QuestionFlowPanel();
/* 243:255 */       qfp.rootModel = this.rootModel;
/* 244:    */       
/* 245:257 */       XModel newContext = new XBaseModel();
/* 246:259 */       for (int i = 0; i < this.context.getNumChildren(); i++) {
/* 247:261 */         newContext.append(this.context.get(i));
/* 248:    */       }
/* 249:268 */       qfp.setBounds(getX(), getY(), getWidth(), getHeight());
/* 250:    */       
/* 251:270 */       getParent().add(qfp);
/* 252:271 */       qfp.setName(xm.getId());
/* 253:272 */       this.rootModel.set("currentPanel", xm.getId());
/* 254:    */       
/* 255:274 */       qfp.parent = this;
/* 256:275 */       qfp.context = newContext;
/* 257:276 */       qfp.currentContextType = this.selectedQp.selectedContext.getId();
/* 258:    */       
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:284 */       qfp.setQuestionFlowModel(xm, this.qfm.flowParams);
/* 266:    */     }
/* 267:    */   }
/* 268:    */   
/* 269:    */   public void actionPerformed(ActionEvent e)
/* 270:    */   {
/* 271:289 */     System.out.println(e.getSource() + " " + e.getActionCommand());
/* 272:290 */     if (e.getActionCommand().equals("Next"))
/* 273:    */     {
/* 274:292 */       QuestionPanel qp = (QuestionPanel)this.qps.get(this.qps.size() - 1);
/* 275:293 */       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
/* 276:    */       try
/* 277:    */       {
/* 278:295 */         TestXUIDB.getInstance().saveFlowQuestion(this.id, this.flow, (String)((XModel)this.context.get("surveyor")).get(), (String)qp.qModel.get("@qno"), sdf.format(this.qStartTime), sdf.format(new Date()));
/* 279:    */       }
/* 280:    */       catch (Exception e1)
/* 281:    */       {
/* 282:298 */         e1.printStackTrace();
/* 283:    */       }
/* 284:300 */       String field = (String)qp.qModel.get("@field");
/* 285:301 */       String value1 = qp.value.toString();
/* 286:302 */       if (field != null) {
/* 287:304 */         this.qfm.dataModel.set("@" + field, this.value);
/* 288:    */       }
/* 289:306 */       XModel nextQuestion = this.qfm.nextQuestion();
/* 290:307 */       if (nextQuestion != null)
/* 291:    */       {
/* 292:309 */         qp.catchAllFocusEvents(qp);
/* 293:    */         
/* 294:311 */         displayQuestion(nextQuestion);
/* 295:    */       }
/* 296:    */       else
/* 297:    */       {
/* 298:314 */         displayMsg("Flow completed.Press the Close Button");
/* 299:315 */         this.status = "Complete";
/* 300:    */       }
/* 301:    */     }
/* 302:320 */     if (e.getActionCommand().equals("Add"))
/* 303:    */     {
/* 304:322 */       QuestionPanel qp = (QuestionPanel)((Component)e.getSource()).getParent();
/* 305:323 */       displaySubFlow((XModel)this.rootModel.get("flows/" + qp.qModel.get("@subflow")));
/* 306:    */     }
/* 307:327 */     if (e.getActionCommand().equals("Edit"))
/* 308:    */     {
/* 309:329 */       QuestionPanel qp = (QuestionPanel)((Component)e.getSource()).getParent();
/* 310:330 */       displaySubFlow((XModel)this.rootModel.get("flows/" + qp.qModel.get("@subflow")));
/* 311:    */     }
/* 312:    */   }
/* 313:    */   
/* 314:335 */   public String id = "";
/* 315:    */   
/* 316:    */   public void close()
/* 317:    */   {
/* 318:338 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
/* 319:    */     try
/* 320:    */     {
/* 321:342 */       TestXUIDB.getInstance().saveFlow(this.id, this.flow, getContextStr(), (String)((XModel)this.context.get("surveyor")).get(), this.status, sdf.format(this.startTime), sdf.format(new Date()));
/* 322:    */     }
/* 323:    */     catch (Exception e1)
/* 324:    */     {
/* 325:345 */       e1.printStackTrace();
/* 326:    */     }
/* 327:    */   }
/* 328:    */   
/* 329:351 */   public String status = "In Process";
/* 330:352 */   public String ilineflow = null;
/* 331:    */   private Date startTime;
/* 332:    */   private String flow;
/* 333:    */   
/* 334:    */   public void mouseClicked(MouseEvent e)
/* 335:    */   {
/* 336:357 */     System.out.println(e.getSource());
/* 337:    */   }
/* 338:    */   
/* 339:    */   public void mouseEntered(MouseEvent e) {}
/* 340:    */   
/* 341:    */   public void mouseExited(MouseEvent e) {}
/* 342:    */   
/* 343:    */   public void mousePressed(MouseEvent e) {}
/* 344:    */   
/* 345:    */   public void mouseReleased(MouseEvent e) {}
/* 346:    */   
/* 347:    */   public QuestionFlowPanel()
/* 348:    */   {
/* 349:378 */     setAutoscrolls(true);
/* 350:    */   }
/* 351:    */   
/* 352:    */   public QuestionFlowPanel(boolean arg0) {}
/* 353:    */   
/* 354:    */   public void createQuestion() {}
/* 355:    */   
/* 356:    */   public String getContextStr()
/* 357:    */   {
/* 358:393 */     String val = "";
/* 359:394 */     for (int i = 0; i < this.context.getNumChildren(); i++)
/* 360:    */     {
/* 361:396 */       String id = this.context.get(i).getId();
/* 362:397 */       Object tmpVal = (String)this.context.get(i).get();
/* 363:398 */       val = val + (tmpVal != null ? " " + id + ":" + tmpVal : "");
/* 364:    */     }
/* 365:400 */     val = val + " Language :" + this.lang;
/* 366:401 */     return val;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public void setQuestionFlowModel(XModel xm, XModel params)
/* 370:    */   {
/* 371:405 */     if (this.count == 0)
/* 372:    */     {
/* 373:407 */       this.startTime = new Date();
/* 374:408 */       this.flow = xm.getId();
/* 375:409 */       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
/* 376:410 */       this.id = ("/va/" + TestXUIDB.getInstance().getCurrentUser() + sdf.format(new Date()));
/* 377:    */       
/* 378:412 */       XModel xm1 = new XBaseModel();
/* 379:413 */       xm1.setId("context");
/* 380:414 */       xm1.set("@type", "context");
/* 381:415 */       xm1.set("@qno", "");
/* 382:416 */       ((XModel)xm1.get("text")).set("context");
/* 383:    */       
/* 384:418 */       displayContext(xm1);
/* 385:419 */       this.count += 1;
/* 386:420 */       this.currentContextType = xm.get("@context").toString();
/* 387:    */     }
/* 388:422 */     this.qfm.setFlowModel(xm);
/* 389:423 */     this.qfm.setFlowParams(params);
/* 390:424 */     this.qfm.context = this.context;
/* 391:425 */     this.qfm.currentContextType = this.currentContextType;
/* 392:426 */     XModel next = this.qfm.nextQuestion();
/* 393:    */     
/* 394:428 */     displayQuestion(next);
/* 395:    */   }
/* 396:    */   
/* 397:    */   public void displayMsg(String msg)
/* 398:    */   {
/* 399:434 */     XMessageBox mbox = new XMessageBox();
/* 400:435 */     Dimension size = getSize();
/* 401:436 */     Point location = getLocationOnScreen();
/* 402:437 */     size = new Dimension(size.width + 2 * location.x, size.height + 2 * location.y);
/* 403:    */     
/* 404:439 */     mbox.setup("Message", msg, size, this);
/* 405:    */   }
/* 406:    */   
/* 407:    */   public void setAttribute(String arg0, Object arg1)
/* 408:    */   {
/* 409:444 */     arg0.equals("question");
/* 410:    */     
/* 411:446 */     super.setAttribute(arg0, arg1);
/* 412:    */   }
/* 413:    */   
/* 414:    */   public void itemStateChanged(ItemEvent e)
/* 415:    */   {
/* 416:451 */     System.out.println(e.getID() + " " + e.getItem());
/* 417:452 */     this.selected = e.getItem().toString();
/* 418:    */   }
/* 419:    */   
/* 420:    */   public void keyPressed(KeyEvent e)
/* 421:    */   {
/* 422:457 */     System.out.println("QFP Key pressed" + e.getKeyChar());
/* 423:    */   }
/* 424:    */   
/* 425:    */   public void keyReleased(KeyEvent e) {}
/* 426:    */   
/* 427:    */   public void keyTyped(KeyEvent e) {}
/* 428:    */   
/* 429:    */   public Dimension getPreferredScrollableViewportSize()
/* 430:    */   {
/* 431:470 */     Dimension d = new Dimension();
/* 432:471 */     d.setSize(800, 10000);
/* 433:472 */     return getPreferredSize();
/* 434:    */   }
/* 435:    */   
/* 436:    */   public int getScrollableBlockIncrement(Rectangle arg0, int arg1, int arg2)
/* 437:    */   {
/* 438:476 */     return 10;
/* 439:    */   }
/* 440:    */   
/* 441:    */   public boolean getScrollableTracksViewportHeight()
/* 442:    */   {
/* 443:480 */     return false;
/* 444:    */   }
/* 445:    */   
/* 446:    */   public boolean getScrollableTracksViewportWidth()
/* 447:    */   {
/* 448:484 */     return false;
/* 449:    */   }
/* 450:    */   
/* 451:    */   public int getScrollableUnitIncrement(Rectangle arg0, int arg1, int arg2)
/* 452:    */   {
/* 453:488 */     return 10;
/* 454:    */   }
/* 455:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.swing.QuestionFlowPanel
 * JD-Core Version:    0.7.0.1
 */