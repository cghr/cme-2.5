/*    1:     */ package com.kentropy.components;
/*    2:     */ 
/*    3:     */ import com.inet.jortho.SpellChecker;
/*    4:     */ import com.kentropy.db.TestXUIDB;
/*    5:     */ import java.awt.Color;
/*    6:     */ import java.awt.Component;
/*    7:     */ import java.awt.Container;
/*    8:     */ import java.awt.FlowLayout;
/*    9:     */ import java.awt.Font;
/*   10:     */ import java.awt.Frame;
/*   11:     */ import java.awt.Point;
/*   12:     */ import java.awt.event.ActionEvent;
/*   13:     */ import java.awt.event.ActionListener;
/*   14:     */ import java.awt.event.FocusEvent;
/*   15:     */ import java.awt.event.FocusListener;
/*   16:     */ import java.awt.event.ItemEvent;
/*   17:     */ import java.awt.event.ItemListener;
/*   18:     */ import java.awt.event.MouseEvent;
/*   19:     */ import java.awt.event.MouseListener;
/*   20:     */ import java.awt.event.WindowAdapter;
/*   21:     */ import java.awt.event.WindowEvent;
/*   22:     */ import java.io.PrintStream;
/*   23:     */ import java.util.Vector;
/*   24:     */ import javax.swing.JPanel;
/*   25:     */ import javax.swing.JTextArea;
/*   26:     */ import net.xoetrope.awt.XButton;
/*   27:     */ import net.xoetrope.awt.XComboBox;
/*   28:     */ import net.xoetrope.awt.XLabel;
/*   29:     */ import net.xoetrope.awt.XPanel;
/*   30:     */ import net.xoetrope.awt.XScrollPane;
/*   31:     */ import net.xoetrope.awt.XToolTip;
/*   32:     */ import net.xoetrope.xui.XPage;
/*   33:     */ import net.xoetrope.xui.XProject;
/*   34:     */ import net.xoetrope.xui.XProjectManager;
/*   35:     */ import net.xoetrope.xui.data.XBaseModel;
/*   36:     */ import net.xoetrope.xui.data.XModel;
/*   37:     */ 
/*   38:     */ public class KeywordPanel1
/*   39:     */   extends JPanel
/*   40:     */   implements MouseListener, ActionListener, FocusListener, ItemListener
/*   41:     */ {
/*   42:  42 */   KeywordPanel kp = null;
/*   43:  44 */   Vector physicians = new Vector();
/*   44:     */   
/*   45:     */   public Vector getPhysicians()
/*   46:     */   {
/*   47:  47 */     return this.physicians;
/*   48:     */   }
/*   49:     */   
/*   50:     */   public void setPhysicians(Vector physicians)
/*   51:     */   {
/*   52:  51 */     this.physicians = physicians;
/*   53:     */   }
/*   54:     */   
/*   55:     */   public KeywordPanel1(XPanel mainPanel, JTextArea commentArea, XButton[] xb)
/*   56:     */   {
/*   57:  55 */     this.editPanel = mainPanel;
/*   58:  56 */     this.commentArea = commentArea;
/*   59:  57 */     this.saveButton = null;
/*   60:  58 */     this.editButton = null;
/*   61:  59 */     this.closeButton = null;
/*   62:  60 */     this.cancelButton = null;
/*   63:  61 */     this.deleteButton = null;
/*   64:     */   }
/*   65:     */   
/*   66:  64 */   CommentBox cb = null;
/*   67:     */   
/*   68:     */   public KeywordPanel1(CommentBox cb)
/*   69:     */   {
/*   70:  67 */     this.cb = cb;
/*   71:     */   }
/*   72:     */   
/*   73:  75 */   XPage page = null;
/*   74:  77 */   Container parent = null;
/*   75:  79 */   private static int BUTTON_WIDTH = 50;
/*   76:  80 */   private static int BUTTON_HEIGHT = 20;
/*   77:  82 */   int currentSelected = -1;
/*   78:  83 */   XScrollPane scr = new XScrollPane();
/*   79:  84 */   public XPanel mainPanel = null;
/*   80:  85 */   XPanel listPanel = null;
/*   81:  86 */   public XPanel editPanel = null;
/*   82:     */   private static final int ROWS = 1;
/*   83:     */   private static final int COLUMNS = 8;
/*   84:  89 */   private String deleteFunc = null;
/*   85:  90 */   private String saveFunc = null;
/*   86:  91 */   private String cancelFunc = null;
/*   87:  92 */   private String closeFunc = null;
/*   88:  93 */   private String selectFunc = null;
/*   89:  94 */   private String currentPhysician = null;
/*   90:  95 */   private String report = null;
/*   91:  96 */   private String stage = null;
/*   92:  97 */   private JTextArea commentArea = null;
/*   93:  98 */   private XLabel heading = null;
/*   94:  99 */   private XButton closeMpButton = null;
/*   95: 103 */   private XButton saveButton = null;
/*   96: 104 */   private XButton editButton = null;
/*   97: 105 */   private XButton closeButton = null;
/*   98: 106 */   private XButton cancelButton = null;
/*   99: 107 */   private XButton deleteButton = null;
/*  100: 110 */   public String keywordPhysician = null;
/*  101:     */   
/*  102:     */   public KeywordPanel1() {}
/*  103:     */   
/*  104:     */   public String getKeywordPhysician()
/*  105:     */   {
/*  106: 113 */     return this.keywordPhysician;
/*  107:     */   }
/*  108:     */   
/*  109:     */   public void remove()
/*  110:     */   {
/*  111:     */     try
/*  112:     */     {
/*  113: 119 */       if (this.mainPanel.getParent() != null) {
/*  114: 120 */         this.mainPanel.getParent().remove(this.mainPanel);
/*  115:     */       }
/*  116:     */     }
/*  117:     */     catch (Exception e)
/*  118:     */     {
/*  119: 124 */       e.printStackTrace();
/*  120:     */     }
/*  121:     */     try
/*  122:     */     {
/*  123: 127 */       if (this.editPanel.getParent() != null) {
/*  124: 128 */         this.editPanel.getParent().remove(this.editPanel);
/*  125:     */       }
/*  126:     */     }
/*  127:     */     catch (Exception e)
/*  128:     */     {
/*  129: 132 */       e.printStackTrace();
/*  130:     */     }
/*  131:     */   }
/*  132:     */   
/*  133:     */   public void setKeywordPhysician(String keywordPhysician)
/*  134:     */   {
/*  135: 137 */     System.out.println("setting physician:" + keywordPhysician);
/*  136: 138 */     this.keywordPhysician = keywordPhysician;
/*  137: 139 */     String str = "";
/*  138: 140 */     if (keywordPhysician.equals(this.currentPhysician)) {
/*  139: 141 */       str = "Your Keywords";
/*  140:     */     } else {
/*  141: 143 */       str = "Others Keywords";
/*  142:     */     }
/*  143:     */   }
/*  144:     */   
/*  145:     */   public void setParent(Container parent)
/*  146:     */   {
/*  147: 151 */     this.parent = parent;
/*  148:     */   }
/*  149:     */   
/*  150:     */   public void setCurrentPhysician(String currentPhysician)
/*  151:     */   {
/*  152: 155 */     System.out.println("Setting current physician:" + currentPhysician);
/*  153: 156 */     this.currentPhysician = currentPhysician;
/*  154:     */   }
/*  155:     */   
/*  156:     */   public String getCurrentPhysician()
/*  157:     */   {
/*  158: 160 */     return this.currentPhysician;
/*  159:     */   }
/*  160:     */   
/*  161:     */   public void setReport(String report)
/*  162:     */   {
/*  163: 164 */     this.report = report;
/*  164:     */   }
/*  165:     */   
/*  166:     */   public String getReport()
/*  167:     */   {
/*  168: 168 */     return this.report;
/*  169:     */   }
/*  170:     */   
/*  171:     */   public void setStage(String stage)
/*  172:     */   {
/*  173: 172 */     this.stage = stage;
/*  174:     */   }
/*  175:     */   
/*  176:     */   public String getStage()
/*  177:     */   {
/*  178: 176 */     return this.stage;
/*  179:     */   }
/*  180:     */   
/*  181: 179 */   String[] keywords = { "Key1", "Lorem Ipsium", 
/*  182: 180 */     "This is a multiline keyword that spans a paragraph", 
/*  183: 181 */     "Lots of Keywords", "Even More Keywords", "Comments gone crazy" };
/*  184:     */   XModel cm;
/*  185:     */   
/*  186:     */   public void setPage(XPage page)
/*  187:     */   {
/*  188: 186 */     this.page = page;
/*  189:     */   }
/*  190:     */   
/*  191:     */   private Color getRowColor(int i)
/*  192:     */   {
/*  193: 190 */     if (i % 2 == 0) {
/*  194: 191 */       return new Color(220, 220, 220);
/*  195:     */     }
/*  196: 193 */     return Color.WHITE;
/*  197:     */   }
/*  198:     */   
/*  199:     */   public void setModel(XModel cm)
/*  200:     */   {
/*  201: 198 */     clearKeywords();
/*  202: 199 */     int currentY = 10;
/*  203: 200 */     for (int i = 0; i < cm.getNumChildren(); i++)
/*  204:     */     {
/*  205: 201 */       System.out.println(">>kp " + cm.get(i).getId());
/*  206: 202 */       JTextArea keywordArea = new JTextArea();
/*  207: 203 */       keywordArea.setLineWrap(true);
/*  208: 204 */       keywordArea.setWrapStyleWord(true);
/*  209: 205 */       String text = ((XModel)cm.get(i).get("text")).get().toString();
/*  210:     */       
/*  211:     */ 
/*  212: 208 */       keywordArea.setBounds(1, currentY, 125, 
/*  213: 209 */         (text.length() / 20 + 1) * 16);
/*  214: 210 */       currentY += (text.length() / 20 + 1) * 16;
/*  215: 211 */       keywordArea.setText(text);
/*  216:     */       
/*  217:     */ 
/*  218:     */ 
/*  219: 215 */       keywordArea.setName(cm.get(i).getId());
/*  220: 216 */       keywordArea.addMouseListener(this);
/*  221:     */       
/*  222:     */ 
/*  223:     */ 
/*  224:     */ 
/*  225: 221 */       keywordArea.setBackground(getRowColor(i));
/*  226:     */       
/*  227: 223 */       keywordArea.setEditable(false);
/*  228:     */       
/*  229: 225 */       this.listPanel.add(keywordArea);
/*  230:     */     }
/*  231: 232 */     this.scr.doLayout();
/*  232: 233 */     this.listPanel.repaint();
/*  233:     */   }
/*  234:     */   
/*  235:     */   public void setCommentModel(XModel cm)
/*  236:     */   {
/*  237: 237 */     this.cm = cm;
/*  238: 238 */     display();
/*  239:     */   }
/*  240:     */   
/*  241:     */   public void display()
/*  242:     */   {
/*  243: 252 */     setModel(this.cm);
/*  244:     */   }
/*  245:     */   
/*  246: 255 */   String changePhyFunc = null;
/*  247: 256 */   String confirmDelete = null;
/*  248: 257 */   String changeKeywordPrompt = null;
/*  249:     */   
/*  250:     */   public void setCallback(String action, String function)
/*  251:     */   {
/*  252: 261 */     if (action.equals("Delete")) {
/*  253: 262 */       this.deleteFunc = function;
/*  254:     */     }
/*  255: 265 */     if (action.equals("Save")) {
/*  256: 266 */       this.saveFunc = function;
/*  257:     */     }
/*  258: 269 */     if (action.equals("Cancel")) {
/*  259: 270 */       this.cancelFunc = function;
/*  260:     */     }
/*  261: 273 */     if (action.equals("Select")) {
/*  262: 274 */       this.selectFunc = function;
/*  263:     */     }
/*  264: 277 */     if (action.equals("Close")) {
/*  265: 278 */       this.closeFunc = function;
/*  266:     */     }
/*  267: 281 */     if (action.equals("ChangePhy")) {
/*  268: 282 */       this.changePhyFunc = function;
/*  269:     */     }
/*  270: 284 */     if (action.equals("ConfirmDelete")) {
/*  271: 285 */       this.confirmDelete = function;
/*  272:     */     }
/*  273: 287 */     if (action.equals("ChangeKeywordPrompt")) {
/*  274: 288 */       this.changeKeywordPrompt = function;
/*  275:     */     }
/*  276:     */   }
/*  277:     */   
/*  278:     */   public void clearKeywords()
/*  279:     */   {
/*  280: 293 */     if (this.listPanel != null)
/*  281:     */     {
/*  282: 294 */       Component[] components = this.listPanel.getComponents();
/*  283: 296 */       for (Component c : components) {
/*  284: 297 */         if (((c instanceof JTextArea)) && 
/*  285: 298 */           (!((JTextArea)c).getName().equals("commentArea"))) {
/*  286: 299 */           this.listPanel.remove(c);
/*  287:     */         }
/*  288:     */       }
/*  289:     */     }
/*  290:     */   }
/*  291:     */   
/*  292: 305 */   Vector items = new Vector();
/*  293:     */   
/*  294:     */   public void init2()
/*  295:     */   {
/*  296: 308 */     Font buttonFont = new Font("SANS_SERIF", 1, 12);
/*  297: 309 */     Color buttonColor = new Color(215, 25, 32);
/*  298: 310 */     this.listPanel = new XPanel();
/*  299:     */     
/*  300: 312 */     setLayout(new FlowLayout());
/*  301:     */     
/*  302:     */ 
/*  303:     */ 
/*  304: 316 */     this.editPanel.setBackground(new Color(220, 220, 220));
/*  305: 317 */     this.editPanel.setBounds(560, 150, 250, 200);
/*  306:     */     
/*  307:     */ 
/*  308:     */ 
/*  309:     */ 
/*  310: 322 */     this.commentArea.setOpaque(true);
/*  311: 323 */     this.commentArea.setLineWrap(true);
/*  312: 324 */     this.commentArea.setWrapStyleWord(true);
/*  313:     */     
/*  314: 326 */     SpellChecker.registerDictionaries(null, "en");
/*  315: 327 */     SpellChecker.register(this.commentArea);
/*  316:     */     
/*  317:     */ 
/*  318: 330 */     XLabel commentLabel = new XLabel();
/*  319: 331 */     commentLabel.setText("Keywords:");
/*  320: 332 */     commentLabel.setFont(buttonFont);
/*  321: 333 */     commentLabel.setBounds(3, 3, 150, 20);
/*  322: 334 */     commentLabel.setForeground(Color.BLACK);
/*  323:     */     
/*  324: 336 */     this.commentArea.setName("commentArea");
/*  325: 337 */     this.commentArea.setBounds(5, 25, this.editPanel.getWidth() - 10, 140);
/*  326:     */     
/*  327:     */ 
/*  328: 340 */     this.commentArea.setBackground(Color.WHITE);
/*  329: 341 */     this.commentArea.setForeground(Color.BLACK);
/*  330:     */     
/*  331: 343 */     this.saveButton.setName("Save");
/*  332: 344 */     this.saveButton.setLabel("Save");
/*  333: 345 */     this.saveButton.setBounds(this.commentArea.getLocation().x, this.commentArea.getY() + 
/*  334: 346 */       this.commentArea.getHeight() + 10, BUTTON_WIDTH, BUTTON_HEIGHT);
/*  335: 347 */     this.editButton.setName("Edit");
/*  336: 348 */     this.editButton.setLabel("Edit");
/*  337: 349 */     this.editButton.setBounds(this.commentArea.getLocation().x, this.commentArea.getY() + 
/*  338: 350 */       this.commentArea.getHeight() + 10, BUTTON_WIDTH, BUTTON_HEIGHT);
/*  339: 351 */     this.deleteButton.setName("Delete");
/*  340: 352 */     this.deleteButton.setLabel("Delete");
/*  341: 353 */     this.deleteButton.setBounds(this.saveButton.getX() + this.saveButton.getWidth() + 20, 
/*  342: 354 */       this.saveButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/*  343: 355 */     this.closeButton.setName("Close");
/*  344: 356 */     this.closeButton.setLabel("Close");
/*  345: 357 */     this.closeButton.setBounds(this.deleteButton.getX() + this.deleteButton.getWidth() + 
/*  346: 358 */       20, this.deleteButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/*  347: 359 */     this.cancelButton.setName("Cancel");
/*  348: 360 */     this.cancelButton.setLabel("Cancel");
/*  349: 361 */     this.cancelButton.setBounds(this.deleteButton.getX() + this.deleteButton.getWidth() + 
/*  350: 362 */       20, this.deleteButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/*  351: 363 */     this.cancelButton.setVisible(false);
/*  352:     */     
/*  353: 365 */     this.saveButton.setBackground(buttonColor);
/*  354: 366 */     this.saveButton.setForeground(Color.WHITE);
/*  355: 367 */     this.saveButton.setFont(buttonFont);
/*  356: 368 */     new XToolTip("Click to Save changes", this.saveButton);
/*  357: 369 */     this.editButton.setBackground(buttonColor);
/*  358: 370 */     this.editButton.setForeground(Color.WHITE);
/*  359: 371 */     this.editButton.setFont(buttonFont);
/*  360: 372 */     new XToolTip("Click to Edit this comment", this.editButton);
/*  361: 373 */     this.deleteButton.setBackground(buttonColor);
/*  362: 374 */     this.deleteButton.setForeground(Color.WHITE);
/*  363: 375 */     this.deleteButton.setFont(buttonFont);
/*  364: 376 */     new XToolTip("Click to Delete this comment", this.deleteButton);
/*  365: 377 */     this.closeButton.setBackground(buttonColor);
/*  366: 378 */     this.closeButton.setForeground(Color.WHITE);
/*  367: 379 */     this.closeButton.setFont(buttonFont);
/*  368: 380 */     new XToolTip("Close Comment Box", this.closeButton);
/*  369: 381 */     this.cancelButton.setBackground(buttonColor);
/*  370: 382 */     this.cancelButton.setForeground(Color.WHITE);
/*  371: 383 */     this.cancelButton.setFont(buttonFont);
/*  372: 384 */     new XToolTip("Cancel Changes", this.cancelButton);
/*  373:     */     
/*  374:     */ 
/*  375:     */ 
/*  376:     */ 
/*  377:     */ 
/*  378:     */ 
/*  379:     */ 
/*  380:     */ 
/*  381:     */ 
/*  382:     */ 
/*  383:     */ 
/*  384:     */ 
/*  385:     */ 
/*  386:     */ 
/*  387:     */ 
/*  388:     */ 
/*  389:     */ 
/*  390:     */ 
/*  391:     */ 
/*  392:     */ 
/*  393:     */ 
/*  394:     */ 
/*  395:     */ 
/*  396: 408 */     this.saveButton.addActionListener(this);
/*  397: 409 */     this.editButton.addActionListener(this);
/*  398: 410 */     this.deleteButton.addActionListener(this);
/*  399: 411 */     this.closeButton.addActionListener(this);
/*  400: 412 */     this.cancelButton.addActionListener(this);
/*  401:     */     
/*  402:     */ 
/*  403: 415 */     this.scr.setBounds(0, 20, 150, 180);
/*  404: 416 */     this.listPanel = new XPanel();
/*  405:     */     
/*  406: 418 */     this.listPanel.setBounds(2, 2, 170, 1000);
/*  407:     */     
/*  408: 420 */     FlowLayout flow = new FlowLayout();
/*  409:     */     
/*  410:     */ 
/*  411: 423 */     this.scr.add(this.listPanel);
/*  412:     */     
/*  413: 425 */     this.editPanel.add(this.saveButton);
/*  414: 426 */     this.editPanel.add(this.editButton);
/*  415: 427 */     this.editPanel.add(this.deleteButton);
/*  416: 428 */     this.editPanel.add(this.closeButton);
/*  417: 429 */     this.editPanel.add(this.cancelButton);
/*  418: 430 */     this.editPanel.add(this.commentArea);
/*  419: 431 */     this.editPanel.add(commentLabel);
/*  420:     */     
/*  421:     */ 
/*  422:     */ 
/*  423:     */ 
/*  424:     */ 
/*  425:     */ 
/*  426:     */ 
/*  427: 439 */     this.heading = new XLabel();
/*  428:     */     
/*  429: 441 */     this.heading.setFont(new Font("SansSerif", 1, 12));
/*  430:     */     
/*  431: 443 */     this.heading.setForeground(Color.BLACK);
/*  432:     */     
/*  433:     */ 
/*  434: 446 */     this.heading.setBounds(0, 0, 150, 20);
/*  435: 447 */     this.heading.setBackground(new Color(220, 220, 220));
/*  436:     */     
/*  437:     */ 
/*  438:     */ 
/*  439:     */ 
/*  440:     */ 
/*  441:     */ 
/*  442:     */ 
/*  443:     */ 
/*  444:     */ 
/*  445:     */ 
/*  446:     */ 
/*  447:     */ 
/*  448:     */ 
/*  449:     */ 
/*  450:     */ 
/*  451: 463 */     this.mainPanel = new XPanel();
/*  452:     */     
/*  453: 465 */     this.mainPanel.add(this.scr);
/*  454: 466 */     this.mainPanel.add(this.heading);
/*  455:     */     
/*  456:     */ 
/*  457:     */ 
/*  458: 470 */     this.mainPanel.setBounds(810, 90, 145, 500);
/*  459:     */     
/*  460:     */ 
/*  461:     */ 
/*  462: 474 */     System.out.println(" parent=" + getParent());
/*  463:     */   }
/*  464:     */   
/*  465:     */   public void init()
/*  466:     */   {
/*  467: 483 */     Font buttonFont = new Font("SANS_SERIF", 1, 12);
/*  468: 484 */     Color buttonColor = new Color(215, 25, 32);
/*  469: 485 */     this.listPanel = new XPanel();
/*  470:     */     
/*  471: 487 */     setLayout(new FlowLayout());
/*  472:     */     
/*  473: 489 */     this.scr.setBounds(0, 20, 150, 180);
/*  474: 490 */     this.listPanel = new XPanel();
/*  475:     */     
/*  476: 492 */     this.listPanel.setBounds(2, 2, 170, 1000);
/*  477:     */     
/*  478: 494 */     FlowLayout flow = new FlowLayout();
/*  479:     */     
/*  480:     */ 
/*  481: 497 */     this.scr.add(this.listPanel);
/*  482:     */     
/*  483: 499 */     this.heading = new XLabel();
/*  484:     */     
/*  485: 501 */     this.heading.setFont(new Font("SansSerif", 1, 12));
/*  486:     */     
/*  487: 503 */     this.heading.setForeground(Color.BLACK);
/*  488:     */     
/*  489:     */ 
/*  490: 506 */     this.heading.setBounds(0, 0, 130, 20);
/*  491: 507 */     this.heading.setBackground(new Color(220, 220, 220));
/*  492:     */     
/*  493: 509 */     this.closeMpButton = new XButton();
/*  494: 510 */     this.closeMpButton.setText("X");
/*  495: 511 */     this.closeMpButton.setLabel("X");
/*  496: 512 */     this.closeMpButton.setBounds(130, 0, 20, 20);
/*  497: 513 */     this.closeMpButton.setBackground(buttonColor);
/*  498: 514 */     this.closeMpButton.setForeground(Color.WHITE);
/*  499: 515 */     this.closeMpButton.setFont(buttonFont);
/*  500: 516 */     this.closeMpButton.addActionListener(this);
/*  501:     */     
/*  502:     */ 
/*  503: 519 */     this.mainPanel = new XPanel();
/*  504:     */     
/*  505: 521 */     this.mainPanel.add(this.scr);
/*  506: 522 */     this.mainPanel.add(this.heading);
/*  507: 523 */     this.mainPanel.add(this.closeMpButton);
/*  508:     */     
/*  509:     */ 
/*  510:     */ 
/*  511: 527 */     this.mainPanel.setBounds(810, 90, 145, 500);
/*  512:     */     
/*  513:     */ 
/*  514:     */ 
/*  515: 531 */     System.out.println(" parent=" + getParent());
/*  516:     */   }
/*  517:     */   
/*  518:     */   public XPanel getMainPanel()
/*  519:     */   {
/*  520: 540 */     return this.mainPanel;
/*  521:     */   }
/*  522:     */   
/*  523:     */   public XPanel getEditPanel()
/*  524:     */   {
/*  525: 544 */     return this.editPanel;
/*  526:     */   }
/*  527:     */   
/*  528:     */   public static void main(String[] args)
/*  529:     */   {
/*  530: 548 */     String[] strArray = { "Hello! This is a very long comment", 
/*  531: 549 */       "This is another comment" };
/*  532:     */     
/*  533:     */ 
/*  534: 552 */     Frame frame = new Frame("KeywordPanel1");
/*  535:     */     
/*  536: 554 */     XProjectManager.getCurrentProject().setAppFrame(frame);
/*  537:     */     
/*  538: 556 */     XProjectManager.getCurrentProject().initialise("startup.properties");
/*  539: 557 */     frame.setBounds(10, 10, 800, 600);
/*  540:     */     
/*  541: 559 */     KeywordPanel1 kp = new KeywordPanel1(new XPanel(), new JTextArea(), null);
/*  542: 560 */     kp.setBounds(0, 0, 100, 500);
/*  543:     */     
/*  544: 562 */     XModel xm = new XBaseModel();
/*  545: 563 */     String parentPath = "/cme/01200001_01_02/Coding/Comments/9";
/*  546: 564 */     kp.setCurrentPhysician("9");
/*  547: 565 */     kp.setReport("01200001_01_02");
/*  548: 566 */     TestXUIDB.getInstance().getKeyValues(xm, "keyvalue", parentPath);
/*  549:     */     
/*  550: 568 */     kp.setParent(frame);
/*  551: 569 */     kp.init();
/*  552: 570 */     kp.setCommentModel(xm);
/*  553: 571 */     kp.display();
/*  554:     */     
/*  555:     */ 
/*  556:     */ 
/*  557:     */ 
/*  558:     */ 
/*  559:     */ 
/*  560:     */ 
/*  561:     */ 
/*  562:     */ 
/*  563:     */ 
/*  564:     */ 
/*  565:     */ 
/*  566: 584 */     frame.add(kp);
/*  567: 585 */     frame.repaint();
/*  568:     */     
/*  569: 587 */     frame.addWindowListener(new WindowAdapter()
/*  570:     */     {
/*  571:     */       public void windowClosing(WindowEvent w)
/*  572:     */       {
/*  573: 589 */         System.exit(0);
/*  574:     */       }
/*  575: 591 */     });
/*  576: 592 */     frame.setVisible(true);
/*  577:     */   }
/*  578:     */   
/*  579:     */   public void mouseClicked(MouseEvent arg0) {}
/*  580:     */   
/*  581:     */   public void setMode(String mode)
/*  582:     */   {
/*  583: 625 */     this.cb.setMode("New");
/*  584: 626 */     showCommentPanel(true);
/*  585:     */   }
/*  586:     */   
/*  587:     */   public int getLastComment()
/*  588:     */   {
/*  589: 646 */     String maxId = "";
/*  590: 647 */     for (int i = 0; i < this.cm.getNumChildren(); i++) {
/*  591: 649 */       if (this.cm.get(i).getId().compareTo(maxId) > 0) {
/*  592: 650 */         maxId = this.cm.get(i).getId();
/*  593:     */       }
/*  594:     */     }
/*  595: 653 */     if (maxId.equals("")) {
/*  596: 654 */       return 0;
/*  597:     */     }
/*  598: 656 */     return Integer.parseInt(maxId.substring("comments".length()));
/*  599:     */   }
/*  600:     */   
/*  601: 659 */   private Color color = Color.YELLOW;
/*  602: 660 */   private Color foregroundColor = Color.BLACK;
/*  603:     */   
/*  604:     */   public void setSelectionColor(Color c)
/*  605:     */   {
/*  606: 663 */     this.color = c;
/*  607:     */   }
/*  608:     */   
/*  609:     */   public void setSelectionForegroundColor(Color c)
/*  610:     */   {
/*  611: 667 */     this.foregroundColor = c;
/*  612:     */   }
/*  613:     */   
/*  614: 670 */   String mode = "Edit";
/*  615:     */   
/*  616:     */   public void selectComment(String comment)
/*  617:     */   {
/*  618: 673 */     System.out.println("CurrentSelected::" + this.currentSelected);
/*  619: 674 */     if ((this.currentSelected != -1) && 
/*  620: 675 */       (this.listPanel.getComponents().length > this.currentSelected))
/*  621:     */     {
/*  622: 676 */       this.listPanel.getComponent(this.currentSelected).setBackground(
/*  623: 677 */         getRowColor(this.currentSelected));
/*  624: 678 */       this.listPanel.getComponent(this.currentSelected).setForeground(
/*  625: 679 */         Color.BLACK);
/*  626:     */     }
/*  627: 681 */     setEditable(false);
/*  628: 682 */     for (int i = 0; i < this.cm.getNumChildren(); i++) {
/*  629: 683 */       if (this.cm.get(i).getId().equals(comment))
/*  630:     */       {
/*  631: 685 */         this.currentSelected = i;
/*  632:     */         
/*  633:     */ 
/*  634: 688 */         showCommentPanel(true);
/*  635: 689 */         this.cb.setComment(this.cm.get(i));
/*  636: 690 */         this.cb.setKeywordPhysician(getKeywordPhysician());
/*  637: 691 */         this.cb.displayComment(((XModel)this.cm.get(i).get("text")).get()
/*  638: 692 */           .toString());
/*  639:     */         
/*  640:     */ 
/*  641: 695 */         this.listPanel.getComponent(i).setBackground(this.color);
/*  642: 696 */         this.listPanel.getComponent(i).setForeground(this.foregroundColor);
/*  643: 697 */         System.out.println("currPhy:" + this.currentPhysician + 
/*  644: 698 */           " keywordPhy::" + this.keywordPhysician);
/*  645: 699 */         this.page.evaluateAttribute("${" + this.selectFunc + "(" + this.stage + 
/*  646: 700 */           "-" + this.keywordPhysician + "-" + comment + ")}");
/*  647:     */         
/*  648:     */ 
/*  649:     */ 
/*  650:     */ 
/*  651:     */ 
/*  652:     */ 
/*  653:     */ 
/*  654:     */ 
/*  655:     */ 
/*  656:     */ 
/*  657:     */ 
/*  658:     */ 
/*  659:     */ 
/*  660:     */ 
/*  661:     */ 
/*  662:     */ 
/*  663: 717 */         break;
/*  664:     */       }
/*  665:     */     }
/*  666:     */   }
/*  667:     */   
/*  668:     */   public void addComment(XModel cm1)
/*  669:     */   {
/*  670: 725 */     String commId = getLastComment() + 1;
/*  671: 726 */     cm1.setId("comments" + commId);
/*  672: 727 */     this.cm.append(cm1);
/*  673: 728 */     display();
/*  674: 729 */     selectComment("comments" + commId);
/*  675: 730 */     showCommentPanel(true);
/*  676: 731 */     this.cb.setEditable(true);
/*  677: 732 */     this.newComment = true;
/*  678:     */   }
/*  679:     */   
/*  680:     */   public void changeKeywordPrompt()
/*  681:     */   {
/*  682: 738 */     this.mp.setAction("OK", "DeleteOK");
/*  683: 739 */     this.mp.okButton.addActionListener(this);
/*  684: 740 */     this.mp.setTitle("Enter Keyword");
/*  685: 741 */     this.mp.setMessage("Please enter a keyword to continue");
/*  686: 742 */     this.mp.setBounds(600, 200, 300, 100);
/*  687: 743 */     this.mp.init();
/*  688: 744 */     this.mp.remove(this.mp.cancelButton);
/*  689: 745 */     this.mp.okButton.setBounds((this.mp.getWidth() - 80) / 2, this.mp.getHeight() - 3 * 3 - 20, 80, 20);
/*  690:     */     
/*  691:     */ 
/*  692:     */ 
/*  693: 749 */     this.mp.setVisible(true);
/*  694:     */   }
/*  695:     */   
/*  696:     */   public boolean saveComment()
/*  697:     */     throws Exception
/*  698:     */   {
/*  699: 755 */     System.out.println("Inside KeywordPanel1.saveComment()");
/*  700:     */     
/*  701: 757 */     String path = "/cme/" + this.report + "/Coding/Comments/" + this.currentPhysician;
/*  702:     */     
/*  703: 759 */     String text = this.cb.getText();
/*  704: 761 */     if (text.trim().equals(""))
/*  705:     */     {
/*  706: 762 */       System.out.println("Keyword is empty");
/*  707: 763 */       this.page.evaluateAttribute("${" + this.changeKeywordPrompt + "()}");
/*  708: 764 */       return false;
/*  709:     */     }
/*  710: 766 */     System.out.println("Keyword is not empty");
/*  711:     */     
/*  712: 768 */     text = text.replaceAll("[^A-Z^a-z^0-9^\\s]", " ");
/*  713: 769 */     ((XModel)getSelectedComment().get("text")).set(text);
/*  714: 770 */     System.out.println("Text::" + text);
/*  715:     */     
/*  716: 772 */     TestXUIDB.getInstance().saveTree(getSelectedComment(), "keyvalue", 
/*  717: 773 */       path);
/*  718: 774 */     if (this.saveFunc != null) {
/*  719: 775 */       this.page.evaluateAttribute("${" + this.saveFunc + "()}");
/*  720:     */     }
/*  721: 777 */     showCommentPanel(false);
/*  722: 778 */     display();
/*  723: 779 */     this.disableSelect = false;
/*  724: 780 */     setEditable(false);
/*  725:     */     
/*  726:     */ 
/*  727: 783 */     return true;
/*  728:     */   }
/*  729:     */   
/*  730:     */   public void mouseEntered(MouseEvent arg0) {}
/*  731:     */   
/*  732:     */   public void mouseExited(MouseEvent arg0) {}
/*  733:     */   
/*  734:     */   public void mousePressed(MouseEvent arg0)
/*  735:     */   {
/*  736: 795 */     if (this.disableSelect) {
/*  737: 796 */       return;
/*  738:     */     }
/*  739: 802 */     System.out.println("TextArea::" + 
/*  740: 803 */       ((JTextArea)arg0.getSource()).getName());
/*  741: 804 */     selectComment(((JTextArea)arg0.getSource()).getName());
/*  742:     */   }
/*  743:     */   
/*  744:     */   public void mouseReleased(MouseEvent arg0) {}
/*  745:     */   
/*  746:     */   public void setEditable(boolean status)
/*  747:     */   {
/*  748: 815 */     System.out.println("KeywordPanel.setEditable(" + status + ")");
/*  749: 816 */     this.disableSelect = status;
/*  750:     */     
/*  751:     */ 
/*  752:     */ 
/*  753:     */ 
/*  754:     */ 
/*  755:     */ 
/*  756:     */ 
/*  757:     */ 
/*  758:     */ 
/*  759:     */ 
/*  760:     */ 
/*  761:     */ 
/*  762:     */ 
/*  763:     */ 
/*  764:     */ 
/*  765:     */ 
/*  766:     */ 
/*  767:     */ 
/*  768:     */ 
/*  769:     */ 
/*  770:     */ 
/*  771:     */ 
/*  772:     */ 
/*  773:     */ 
/*  774:     */ 
/*  775:     */ 
/*  776:     */ 
/*  777:     */ 
/*  778: 845 */     System.out.println(this.currentPhysician + " " + this.keywordPhysician);
/*  779: 846 */     this.currentPhysician.equals(this.keywordPhysician);
/*  780:     */   }
/*  781:     */   
/*  782:     */   public void showMainPanel()
/*  783:     */   {
/*  784: 858 */     this.mainPanel.setBounds(315, 90, 150, 209);
/*  785:     */     
/*  786:     */ 
/*  787:     */ 
/*  788:     */ 
/*  789:     */ 
/*  790:     */ 
/*  791:     */ 
/*  792: 866 */     System.out.println(" Hiding 1");
/*  793:     */     
/*  794: 868 */     System.out.println(" Hiding 2");
/*  795:     */   }
/*  796:     */   
/*  797:     */   public void hideMainPanel()
/*  798:     */   {
/*  799: 879 */     this.mainPanel.setVisible(false);
/*  800:     */     
/*  801:     */ 
/*  802:     */ 
/*  803:     */ 
/*  804:     */ 
/*  805:     */ 
/*  806:     */ 
/*  807:     */ 
/*  808:     */ 
/*  809: 889 */     System.out.println(" Hiding 1");
/*  810:     */     
/*  811: 891 */     System.out.println(" Hiding 2");
/*  812:     */     
/*  813:     */ 
/*  814: 894 */     this.mainPanel.doLayout();
/*  815:     */   }
/*  816:     */   
/*  817:     */   public void removeMainPanel()
/*  818:     */   {
/*  819: 900 */     this.parent.remove(this.mainPanel);
/*  820:     */   }
/*  821:     */   
/*  822:     */   public void addMainPanel()
/*  823:     */   {
/*  824: 904 */     this.parent.add(this.mainPanel, 0);
/*  825:     */   }
/*  826:     */   
/*  827: 907 */   public MessagePanel mp = new MessagePanel();
/*  828:     */   
/*  829:     */   public void confirmDelete()
/*  830:     */   {
/*  831: 910 */     this.mp = new MessagePanel();
/*  832:     */     
/*  833: 912 */     this.mp.setAction("OK", "DeleteOK");
/*  834: 913 */     this.mp.okButton.addActionListener(this);
/*  835: 914 */     this.mp.setTitle("Delete Keyword");
/*  836: 915 */     this.mp.setMessage("Are you sure you want to delete this comment?");
/*  837: 916 */     this.mp.init();
/*  838: 917 */     this.mp.repaint();
/*  839:     */     
/*  840:     */ 
/*  841:     */ 
/*  842:     */ 
/*  843: 922 */     this.mp.repaint();
/*  844:     */   }
/*  845:     */   
/*  846:     */   public XModel getSelectedComment()
/*  847:     */   {
/*  848: 927 */     return this.cm.get(this.currentSelected);
/*  849:     */   }
/*  850:     */   
/*  851: 930 */   boolean disableSelect = false;
/*  852:     */   
/*  853:     */   public void deleteComment1()
/*  854:     */   {
/*  855: 934 */     String path = "/cme/" + this.report + "/Coding/Comments/" + 
/*  856: 935 */       this.currentPhysician + "/" + getSelectedComment().getId();
/*  857:     */     try
/*  858:     */     {
/*  859: 937 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/text");
/*  860: 938 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/x");
/*  861: 939 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/y");
/*  862: 940 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/endx");
/*  863: 941 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/endy");
/*  864: 942 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/stage");
/*  865: 944 */       if (this.deleteFunc != null) {
/*  866: 945 */         this.page.evaluateAttribute("${" + this.deleteFunc + "()}");
/*  867:     */       }
/*  868: 947 */       ((XBaseModel)this.cm).removeChild(getSelectedComment().getId());
/*  869:     */       
/*  870: 949 */       display();
/*  871: 950 */       setEditable(false);
/*  872:     */       
/*  873:     */ 
/*  874:     */ 
/*  875: 954 */       this.disableSelect = false;
/*  876: 955 */       showCommentPanel(false);
/*  877:     */     }
/*  878:     */     catch (Exception e)
/*  879:     */     {
/*  880: 957 */       e.printStackTrace();
/*  881:     */     }
/*  882:     */   }
/*  883:     */   
/*  884:     */   public void showCommentPanel(boolean b)
/*  885:     */   {
/*  886: 962 */     this.cb.setVisible(b);
/*  887: 963 */     if (b) {
/*  888: 964 */       this.cb.kp = this;
/*  889:     */     }
/*  890:     */   }
/*  891:     */   
/*  892: 994 */   private boolean newComment = false;
/*  893:     */   
/*  894:     */   public void actionPerformed(ActionEvent arg0)
/*  895:     */   {
/*  896: 998 */     if (arg0.getActionCommand().equals("Save"))
/*  897:     */     {
/*  898:     */       try
/*  899:     */       {
/*  900:1000 */         if (!saveComment()) {
/*  901:     */           return;
/*  902:     */         }
/*  903:1001 */         this.newComment = false;
/*  904:1002 */         setEditable(false);
/*  905:     */       }
/*  906:     */       catch (Exception e)
/*  907:     */       {
/*  908:1006 */         e.printStackTrace();
/*  909:     */       }
/*  910:     */     }
/*  911:1009 */     else if (arg0.getActionCommand().equals("Edit"))
/*  912:     */     {
/*  913:1010 */       setEditable(true);
/*  914:     */     }
/*  915:1011 */     else if (arg0.getActionCommand().equals("Close"))
/*  916:     */     {
/*  917:1012 */       this.disableSelect = false;
/*  918:1013 */       this.page.evaluateAttribute("${" + this.closeFunc + "()}");
/*  919:     */       
/*  920:1015 */       showCommentPanel(false);
/*  921:     */     }
/*  922:1016 */     else if (arg0.getActionCommand().equals("Delete"))
/*  923:     */     {
/*  924:1017 */       System.out.println("Confirm");
/*  925:1018 */       this.page.evaluateAttribute("${" + this.confirmDelete + "()}");
/*  926:     */     }
/*  927:1020 */     else if (arg0.getActionCommand().equals("DeleteOK"))
/*  928:     */     {
/*  929:1021 */       System.out.println("Deleting Comment");
/*  930:     */       try
/*  931:     */       {
/*  932:1023 */         deleteComment1();
/*  933:     */       }
/*  934:     */       catch (NullPointerException e)
/*  935:     */       {
/*  936:1025 */         e.printStackTrace();
/*  937:     */       }
/*  938:     */     }
/*  939:1028 */     else if (arg0.getActionCommand().equals("Cancel"))
/*  940:     */     {
/*  941:1029 */       if (this.newComment) {
/*  942:1032 */         ((XBaseModel)this.cm).removeChild(getSelectedComment().getId());
/*  943:     */       }
/*  944:1034 */       this.disableSelect = false;
/*  945:1035 */       this.editPanel.setVisible(false);
/*  946:1036 */       this.page.evaluateAttribute("${" + this.cancelFunc + "()}");
/*  947:1037 */       display();
/*  948:1038 */       this.newComment = false;
/*  949:     */     }
/*  950:1039 */     else if (arg0.getActionCommand().equals("hide"))
/*  951:     */     {
/*  952:1040 */       hideMainPanel();
/*  953:     */     }
/*  954:1042 */     else if (arg0.getActionCommand().equals("show"))
/*  955:     */     {
/*  956:1043 */       showMainPanel();
/*  957:     */     }
/*  958:1044 */     else if (arg0.getActionCommand().equals("ChangePhy"))
/*  959:     */     {
/*  960:1045 */       String phy = null;
/*  961:1046 */       if (this.keywordPhysician.equals(this.physicians.get(0))) {
/*  962:1047 */         phy = (String)this.physicians.get(1);
/*  963:1048 */       } else if (this.keywordPhysician.equals(this.physicians.get(1))) {
/*  964:1049 */         phy = (String)this.physicians.get(0);
/*  965:     */       }
/*  966:1051 */       System.out.println("changePhyFunc::${" + this.changePhyFunc + "(" + 
/*  967:1052 */         phy + ")}");
/*  968:1053 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + phy + ")}");
/*  969:     */     }
/*  970:1054 */     else if (arg0.getActionCommand().equals("X"))
/*  971:     */     {
/*  972:1055 */       hideMainPanel();
/*  973:     */     }
/*  974:     */   }
/*  975:     */   
/*  976:     */   public void focusGained(FocusEvent arg0) {}
/*  977:     */   
/*  978:     */   public void focusLost(FocusEvent arg0)
/*  979:     */   {
/*  980:1066 */     System.out.println(" Focus Lost 111");
/*  981:     */   }
/*  982:     */   
/*  983:     */   public void reset()
/*  984:     */   {
/*  985:1071 */     hideMainPanel();
/*  986:     */   }
/*  987:     */   
/*  988:     */   public void itemStateChanged(ItemEvent arg0)
/*  989:     */   {
/*  990:1075 */     XComboBox xc = (XComboBox)arg0.getSource();
/*  991:1076 */     System.out.println("Item::" + arg0.getItem());
/*  992:1077 */     String otherPhysician = this.physicians.get(0).equals(this.currentPhysician) ? this.physicians
/*  993:1078 */       .get(1).toString() : this.physicians.get(0).toString();
/*  994:1079 */     if (getStage().equals("Adjudication"))
/*  995:     */     {
/*  996:1080 */       if (arg0.getItem().equals("First Physician")) {
/*  997:1081 */         this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/*  998:1082 */           this.physicians.get(0) + ")}");
/*  999:1083 */       } else if (arg0.getItem().equals("Second Physician")) {
/* 1000:1084 */         this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 1001:1085 */           this.physicians.get(1) + ")}");
/* 1002:     */       }
/* 1003:     */     }
/* 1004:1088 */     else if (arg0.getItem().equals("Your Keywords")) {
/* 1005:1089 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 1006:1090 */         this.currentPhysician + ")}");
/* 1007:1091 */     } else if (arg0.getItem().equals("Others Keywords")) {
/* 1008:1092 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 1009:1093 */         otherPhysician + ")}");
/* 1010:     */     }
/* 1011:     */   }
/* 1012:     */   
/* 1013:     */   public void setTitle(String title)
/* 1014:     */   {
/* 1015:1099 */     this.heading.setText(title);
/* 1016:1100 */     repaint();
/* 1017:     */   }
/* 1018:     */   
/* 1019:     */   public void setKeywordStage(String stage)
/* 1020:     */   {
/* 1021:1104 */     this.cb.setKeywordStage(stage);
/* 1022:     */   }
/* 1023:     */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.KeywordPanel1
 * JD-Core Version:    0.7.0.1
 */