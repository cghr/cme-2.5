/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import com.kentropy.flow.QuestionFlowManager;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.Point;
/*   9:    */ import java.awt.event.ActionEvent;
/*  10:    */ import java.awt.event.ActionListener;
/*  11:    */ import java.awt.event.ItemEvent;
/*  12:    */ import java.awt.event.ItemListener;
/*  13:    */ import java.awt.event.KeyEvent;
/*  14:    */ import java.awt.event.KeyListener;
/*  15:    */ import java.awt.event.MouseEvent;
/*  16:    */ import java.awt.event.MouseListener;
/*  17:    */ import java.io.PrintStream;
/*  18:    */ import java.util.Vector;
/*  19:    */ import net.xoetrope.awt.XMessageBox;
/*  20:    */ import net.xoetrope.awt.XPanel;
/*  21:    */ import net.xoetrope.awt.XScrollPane;
/*  22:    */ import net.xoetrope.xui.data.XBaseModel;
/*  23:    */ import net.xoetrope.xui.data.XModel;
/*  24:    */ 
/*  25:    */ public class QuestionFlowPanel
/*  26:    */   extends XPanel
/*  27:    */   implements ItemListener, KeyListener, MouseListener, ActionListener
/*  28:    */ {
/*  29: 28 */   public QuestionPanel selectedQp = null;
/*  30: 29 */   public QuestionFlowManager qfm = new QuestionFlowManager();
/*  31: 30 */   public Vector qps = new Vector();
/*  32: 31 */   public XModel rootModel = null;
/*  33: 32 */   public QuestionFlowPanel parent = null;
/*  34: 33 */   public XModel context = null;
/*  35: 36 */   String qtype = "";
/*  36: 37 */   String label = "";
/*  37: 38 */   String test = "";
/*  38: 39 */   String value = "";
/*  39: 40 */   XModel xm = new XBaseModel();
/*  40: 41 */   XModel qModel = null;
/*  41: 42 */   Component comp = null;
/*  42: 43 */   String selected = "";
/*  43: 45 */   int count = 0;
/*  44: 46 */   public String currentContextType = "";
/*  45:    */   
/*  46:    */   public void save()
/*  47:    */   {
/*  48: 50 */     String table = this.qfm.flowModel.get("@table").toString();
/*  49: 51 */     String where = "";
/*  50: 52 */     for (int i = 0; i < this.context.getNumChildren(); i++)
/*  51:    */     {
/*  52: 54 */       String key = this.context.get(i).getId();
/*  53: 55 */       String value = this.context.get(i).get().toString();
/*  54: 56 */       String tablekey = this.qfm.flowModel.get("@" + key + "Fld").toString();
/*  55: 57 */       where = where + (i == 0 ? "" : " and ") + tablekey + "'" + value + "'";
/*  56:    */     }
/*  57: 60 */     for (int i = 0; i < this.qps.size(); i++)
/*  58:    */     {
/*  59: 62 */       QuestionPanel qp = (QuestionPanel)this.qps.get(i);
/*  60: 63 */       String field = qp.qModel.get("@field").toString();
/*  61: 64 */       ((XModel)this.xm.get(field)).set(qp.value);
/*  62: 65 */       System.out.println(qp.getName() + " " + qp.value);
/*  63:    */     }
/*  64:    */     try
/*  65:    */     {
/*  66: 70 */       TestXUIDB.getInstance().saveDataM(table, where, this.xm);
/*  67:    */     }
/*  68:    */     catch (Exception e)
/*  69:    */     {
/*  70: 73 */       e.printStackTrace();
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void read()
/*  75:    */   {
/*  76: 79 */     XModel xm = new XBaseModel();
/*  77: 80 */     String table = this.qfm.flowModel.get("@table").toString();
/*  78: 81 */     String where = "";
/*  79: 82 */     for (int i = 0; i < this.context.getNumChildren(); i++)
/*  80:    */     {
/*  81: 84 */       String key = this.context.get(i).getId();
/*  82: 85 */       String value = this.context.get(i).get().toString();
/*  83: 86 */       String tablekey = this.qfm.flowModel.get("@" + key + "Fld").toString();
/*  84: 87 */       where = where + (i == 0 ? "" : " and ") + tablekey + "'" + value + "'";
/*  85:    */     }
/*  86:    */     try
/*  87:    */     {
/*  88: 92 */       xm = TestXUIDB.getInstance().getDataM1(table, where);
/*  89: 93 */       this.qfm.dataModel = xm;
/*  90:    */     }
/*  91:    */     catch (Exception e)
/*  92:    */     {
/*  93: 96 */       e.printStackTrace();
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void displayQuestion(XModel xm)
/*  98:    */   {
/*  99:101 */     System.out.println(" Displa q" + xm);
/* 100:102 */     if (xm != null)
/* 101:    */     {
/* 102:104 */       QuestionPanel qp = new QuestionPanel();
/* 103:105 */       qp.context = this.context;
/* 104:106 */       qp.currentContextType = this.currentContextType;
/* 105:107 */       QuestionPanel lastqp = this.qps.size() > 0 ? (QuestionPanel)this.qps.get(this.qps.size() - 1) : null;
/* 106:108 */       int x = 10;
/* 107:109 */       int y = lastqp == null ? 30 : lastqp.getHeight() + lastqp.getY() + 10;
/* 108:110 */       int w = getWidth() - 30;
/* 109:111 */       int h = xm.get("@type").equals("view") ? 400 : 100;
/* 110:112 */       System.out.println(x + " " + y + " " + w + " " + h);
/* 111:113 */       qp.setBounds(x, y, w, h);
/* 112:114 */       qp.rootModel = this.rootModel;
/* 113:115 */       add(qp);
/* 114:116 */       qp.setQuestionModel(xm);
/* 115:117 */       qp.setName(xm.getId());
/* 116:118 */       qp.read();
/* 117:119 */       this.qps.add(qp);
/* 118:120 */       this.selectedQp = qp;
/* 119:121 */       ((XScrollPane)getParent()).setScrollPosition(x, y - 100);
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void scrollToCurrent()
/* 124:    */   {
/* 125:126 */     ((XScrollPane)getParent()).setScrollPosition(10, this.selectedQp.getY());
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void displayContext(XModel xm)
/* 129:    */   {
/* 130:130 */     System.out.println(" Displa q" + xm);
/* 131:131 */     if (xm != null)
/* 132:    */     {
/* 133:133 */       QuestionPanel qp = new QuestionPanel();
/* 134:    */       
/* 135:135 */       int x = 10;
/* 136:136 */       int y = 30;
/* 137:137 */       int w = getWidth() - 30;
/* 138:138 */       int h = 100;
/* 139:139 */       System.out.println(x + " " + y + " " + w + " " + h);
/* 140:140 */       qp.context = this.context;
/* 141:141 */       qp.setBounds(x, y, w, h);
/* 142:142 */       add(qp);
/* 143:143 */       qp.setQuestionModel(xm);
/* 144:144 */       qp.setName(xm.getId());
/* 145:    */       
/* 146:146 */       this.qps.add(qp);
/* 147:147 */       ((XScrollPane)getParent()).setScrollPosition(x, y - 100);
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void displaySubFlow(XModel xm)
/* 152:    */   {
/* 153:152 */     System.out.println(" Displa q" + xm);
/* 154:153 */     if (xm != null)
/* 155:    */     {
/* 156:155 */       QuestionFlowPanel qfp = new QuestionFlowPanel();
/* 157:156 */       qfp.rootModel = this.rootModel;
/* 158:    */       
/* 159:158 */       XModel newContext = new XBaseModel();
/* 160:160 */       for (int i = 0; i < this.context.getNumChildren(); i++) {
/* 161:162 */         newContext.append(this.context.get(i));
/* 162:    */       }
/* 163:165 */       newContext.append(this.selectedQp.selectedContext);
/* 164:166 */       ((XModel)this.rootModel.get("currentContext")).removeChildren();
/* 165:167 */       ((XModel)this.rootModel.get("currentContext")).append(this.context);
/* 166:    */       
/* 167:169 */       qfp.setBounds(getX(), getY(), getWidth(), getHeight());
/* 168:    */       
/* 169:171 */       getParent().add(qfp);
/* 170:172 */       qfp.setName(xm.getId());
/* 171:173 */       this.rootModel.set("currentPanel", xm.getId());
/* 172:    */       
/* 173:175 */       qfp.parent = this;
/* 174:176 */       qfp.context = newContext;
/* 175:177 */       qfp.currentContextType = this.selectedQp.selectedContext.getId();
/* 176:178 */       XModel flowParams = new XBaseModel();
/* 177:    */       try
/* 178:    */       {
/* 179:180 */         flowParams = TestXUIDB.getInstance().getFlowParameters(newContext, qfp.currentContextType);
/* 180:    */       }
/* 181:    */       catch (Exception e)
/* 182:    */       {
/* 183:183 */         e.printStackTrace();
/* 184:    */       }
/* 185:185 */       qfp.setQuestionFlowModel(xm, flowParams);
/* 186:    */     }
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void displayInlineFlow(XModel xm)
/* 190:    */   {
/* 191:189 */     System.out.println(" Displa q" + xm);
/* 192:190 */     if (xm != null)
/* 193:    */     {
/* 194:192 */       QuestionFlowPanel qfp = new QuestionFlowPanel();
/* 195:193 */       qfp.rootModel = this.rootModel;
/* 196:    */       
/* 197:195 */       XModel newContext = new XBaseModel();
/* 198:197 */       for (int i = 0; i < this.context.getNumChildren(); i++) {
/* 199:199 */         newContext.append(this.context.get(i));
/* 200:    */       }
/* 201:206 */       qfp.setBounds(getX(), getY(), getWidth(), getHeight());
/* 202:    */       
/* 203:208 */       getParent().add(qfp);
/* 204:209 */       qfp.setName(xm.getId());
/* 205:210 */       this.rootModel.set("currentPanel", xm.getId());
/* 206:    */       
/* 207:212 */       qfp.parent = this;
/* 208:213 */       qfp.context = newContext;
/* 209:214 */       qfp.currentContextType = this.selectedQp.selectedContext.getId();
/* 210:    */       
/* 211:    */ 
/* 212:    */ 
/* 213:    */ 
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:222 */       qfp.setQuestionFlowModel(xm, this.qfm.flowParams);
/* 218:    */     }
/* 219:    */   }
/* 220:    */   
/* 221:    */   public void actionPerformed(ActionEvent e)
/* 222:    */   {
/* 223:227 */     System.out.println(e.getSource() + " " + e.getActionCommand());
/* 224:228 */     if (e.getActionCommand().equals("Next"))
/* 225:    */     {
/* 226:230 */       QuestionPanel qp = (QuestionPanel)this.qps.get(this.qps.size() - 1);
/* 227:231 */       String field = (String)qp.qModel.get("@field");
/* 228:232 */       String value1 = qp.value.toString();
/* 229:233 */       if (field != null) {
/* 230:235 */         this.qfm.dataModel.set("@" + field, this.value);
/* 231:    */       }
/* 232:237 */       XModel nextQuestion = this.qfm.nextQuestion();
/* 233:238 */       if (nextQuestion != null) {
/* 234:239 */         displayQuestion(nextQuestion);
/* 235:    */       } else {
/* 236:241 */         displayMsg("Flow completed.Press the Close Button");
/* 237:    */       }
/* 238:    */     }
/* 239:245 */     if (e.getActionCommand().equals("Add"))
/* 240:    */     {
/* 241:247 */       QuestionPanel qp = (QuestionPanel)((Component)e.getSource()).getParent();
/* 242:248 */       displaySubFlow((XModel)this.rootModel.get("flows/" + qp.qModel.get("@subflow")));
/* 243:    */     }
/* 244:251 */     if (e.getActionCommand().equals("Edit"))
/* 245:    */     {
/* 246:253 */       QuestionPanel qp = (QuestionPanel)((Component)e.getSource()).getParent();
/* 247:254 */       displaySubFlow((XModel)this.rootModel.get("flows/" + qp.qModel.get("@subflow")));
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   public void mouseClicked(MouseEvent e)
/* 252:    */   {
/* 253:260 */     System.out.println(e.getSource());
/* 254:    */   }
/* 255:    */   
/* 256:    */   public void mouseEntered(MouseEvent e) {}
/* 257:    */   
/* 258:    */   public void mouseExited(MouseEvent e) {}
/* 259:    */   
/* 260:    */   public void mousePressed(MouseEvent e) {}
/* 261:    */   
/* 262:    */   public void mouseReleased(MouseEvent e) {}
/* 263:    */   
/* 264:    */   public QuestionFlowPanel() {}
/* 265:    */   
/* 266:    */   public QuestionFlowPanel(boolean arg0)
/* 267:    */   {
/* 268:285 */     super(arg0);
/* 269:    */   }
/* 270:    */   
/* 271:    */   public void createQuestion() {}
/* 272:    */   
/* 273:    */   public void setQuestionFlowModel(XModel xm, XModel params)
/* 274:    */   {
/* 275:294 */     if (this.count == 0)
/* 276:    */     {
/* 277:296 */       XModel xm1 = new XBaseModel();
/* 278:297 */       xm1.setId("context");
/* 279:298 */       xm1.set("@type", "context");
/* 280:299 */       xm1.set("@qno", "");
/* 281:300 */       ((XModel)xm1.get("text")).set("context");
/* 282:    */       
/* 283:302 */       displayContext(xm1);
/* 284:303 */       this.count += 1;
/* 285:304 */       this.currentContextType = xm.get("@context").toString();
/* 286:    */     }
/* 287:306 */     this.qfm.setFlowModel(xm);
/* 288:307 */     this.qfm.setFlowParams(params);
/* 289:308 */     XModel next = this.qfm.nextQuestion();
/* 290:    */     
/* 291:310 */     displayQuestion(next);
/* 292:    */   }
/* 293:    */   
/* 294:    */   public void displayMsg(String msg)
/* 295:    */   {
/* 296:315 */     XMessageBox mbox = new XMessageBox();
/* 297:316 */     Dimension size = getSize();
/* 298:317 */     Point location = getLocationOnScreen();
/* 299:318 */     size = new Dimension(size.width + 2 * location.x, size.height + 2 * location.y);
/* 300:    */     
/* 301:320 */     mbox.setup("Message", msg, size, this);
/* 302:    */   }
/* 303:    */   
/* 304:    */   public void setAttribute(String arg0, Object arg1)
/* 305:    */   {
/* 306:325 */     arg0.equals("question");
/* 307:    */     
/* 308:327 */     super.setAttribute(arg0, arg1);
/* 309:    */   }
/* 310:    */   
/* 311:    */   public void itemStateChanged(ItemEvent e)
/* 312:    */   {
/* 313:332 */     System.out.println(e.getID() + " " + e.getItem());
/* 314:333 */     this.selected = e.getItem().toString();
/* 315:    */   }
/* 316:    */   
/* 317:    */   public void keyPressed(KeyEvent e)
/* 318:    */   {
/* 319:338 */     System.out.println("QFP Key pressed" + e.getKeyChar());
/* 320:    */   }
/* 321:    */   
/* 322:    */   public void keyReleased(KeyEvent e) {}
/* 323:    */   
/* 324:    */   public void keyTyped(KeyEvent e) {}
/* 325:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.QuestionFlowPanel
 * JD-Core Version:    0.7.0.1
 */