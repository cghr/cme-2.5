/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import com.toedter.calendar.JDateChooser;
/*  4:   */ import java.awt.Color;
/*  5:   */ import java.awt.Frame;
/*  6:   */ import java.awt.event.WindowAdapter;
/*  7:   */ import java.awt.event.WindowEvent;
/*  8:   */ import java.awt.im.InputContext;
/*  9:   */ import java.io.PrintStream;
/* 10:   */ import java.text.ParseException;
/* 11:   */ import java.text.SimpleDateFormat;
/* 12:   */ import java.util.Locale;
/* 13:   */ import net.xoetrope.swing.XPanel;
/* 14:   */ 
/* 15:   */ public final class TestDateField
/* 16:   */ {
/* 17:   */   public static void main(String[] args)
/* 18:   */     throws ParseException
/* 19:   */   {
/* 20:34 */     Frame frm = new Frame("Test Date Field");
/* 21:35 */     frm.setBounds(0, 0, 800, 600);
/* 22:36 */     frm.addWindowListener(new WindowAdapter()
/* 23:   */     {
/* 24:   */       public void windowClosing(WindowEvent arg0)
/* 25:   */       {
/* 26:44 */         super.windowClosing(arg0);
/* 27:45 */         System.exit(0);
/* 28:   */       }
/* 29:49 */     });
/* 30:50 */     Locale locale = new Locale("mr", "IN");
/* 31:   */     
/* 32:52 */     InputContext.getInstance().selectInputMethod(locale);
/* 33:   */     
/* 34:54 */     JDateChooser df = new JDateChooser();
/* 35:55 */     df.setDate(new SimpleDateFormat("yyyy-MM-dd").parse("2004-01-01"));
/* 36:56 */     df.setSize(400, 100);
/* 37:   */     
/* 38:58 */     frm.setLayout(null);
/* 39:59 */     XPanel jp0 = new XPanel();
/* 40:60 */     jp0.setBounds(10, 10, 500, 100);
/* 41:61 */     jp0.setAttribute("border", "1");
/* 42:62 */     frm.add(jp0);
/* 43:63 */     XPanel jp = new XPanel();
/* 44:64 */     jp.setBounds(10, 210, 500, 200);
/* 45:65 */     jp.setAttribute("border", "1");
/* 46:66 */     jp.setBackground(Color.red);
/* 47:   */     
/* 48:68 */     df.setBounds(10, 60, 200, 30);
/* 49:69 */     jp.add(df);
/* 50:   */     
/* 51:71 */     frm.add(jp);
/* 52:   */     
/* 53:73 */     frm.setVisible(true);
/* 54:74 */     System.out.println(InputContext.getInstance().getLocale());
/* 55:   */   }
/* 56:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.TestDateField
 * JD-Core Version:    0.7.0.1
 */