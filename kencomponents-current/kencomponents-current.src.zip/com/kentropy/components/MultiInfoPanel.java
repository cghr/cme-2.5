/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Font;
/*   7:    */ import java.io.PrintStream;
/*   8:    */ import net.xoetrope.awt.XLabel;
/*   9:    */ import net.xoetrope.awt.XPanel;
/*  10:    */ import net.xoetrope.xui.data.XBaseModel;
/*  11:    */ import net.xoetrope.xui.data.XModel;
/*  12:    */ 
/*  13:    */ public class MultiInfoPanel
/*  14:    */   extends XPanel
/*  15:    */ {
/*  16: 17 */   public int columns = 1;
/*  17: 18 */   public String heading = "";
/*  18: 19 */   private Color color = Color.BLACK;
/*  19: 20 */   private String style = "head123";
/*  20:    */   
/*  21:    */   public void setStyle(String style)
/*  22:    */   {
/*  23: 22 */     this.style = style;
/*  24:    */   }
/*  25:    */   
/*  26: 28 */   public XModel list = null;
/*  27:    */   
/*  28:    */   public void setList(XModel list1)
/*  29:    */   {
/*  30: 32 */     Component[] comps = getComponents();
/*  31: 33 */     for (int i = 0; i < comps.length; i++) {
/*  32: 35 */       remove(comps[i]);
/*  33:    */     }
/*  34: 37 */     this.list = list1;
/*  35: 38 */     System.out.println("---" + this.list.getNumChildren());
/*  36: 39 */     int rowcount = 0;
/*  37: 40 */     XLabel item = new XLabel();
/*  38:    */     
/*  39: 42 */     int w = getWidth() - 10;
/*  40: 43 */     item.setBounds(5, 10, w, 15);
/*  41: 44 */     item.setText(this.heading);
/*  42:    */     
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46: 49 */     Font font = new Font("Arial", 1, 12);
/*  47: 50 */     item.setForeground(this.color);
/*  48:    */     
/*  49: 52 */     item.setFont(font);
/*  50: 53 */     add(item);
/*  51: 54 */     item.setVisible(true);
/*  52: 55 */     Font font1 = new Font("SANS_SERIF", 1, 10);
/*  53: 57 */     for (int i = 0; i < this.list.getNumChildren();)
/*  54:    */     {
/*  55: 59 */       for (int j = 0; j < this.columns; j++)
/*  56:    */       {
/*  57: 61 */         String key = this.list.get(i).getId();
/*  58: 62 */         key = key.substring(key.indexOf(" ") + 1);
/*  59: 63 */         String value = (String)this.list.get(i).get();
/*  60: 64 */         item = new XLabel();
/*  61: 65 */         item.setFont(font1);
/*  62: 66 */         w = (getWidth() - 10) / this.columns;
/*  63: 67 */         System.out.println("---" + key + " " + value + " " + this.columns + " " + w);
/*  64: 68 */         item.setBounds(5 + j * w, 25 + rowcount * 12, w, 15);
/*  65: 69 */         if ((key.length() > 20) && (key.contains("Pregnancy"))) {
/*  66: 70 */           key = key.replace("Pregnancy", "Preg.");
/*  67:    */         }
/*  68: 72 */         item.setText((key.length() > 20 ? key.substring(0, 20) : key) + ": " + value);
/*  69: 73 */         item.setAttribute("style", "Table/SmallHeader2");
/*  70:    */         
/*  71:    */ 
/*  72: 76 */         item.setFont(font1);
/*  73: 77 */         add(item);
/*  74: 78 */         item.setVisible(true);
/*  75: 79 */         i++;
/*  76: 80 */         if (i == this.list.getNumChildren()) {
/*  77: 81 */           return;
/*  78:    */         }
/*  79:    */       }
/*  80: 83 */       rowcount++;
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84: 88 */   Font headingFont = new Font("Arial", 1, 12);
/*  85: 89 */   Font textFont = new Font("Arial", 0, 12);
/*  86:    */   
/*  87:    */   public void displayItem(String text, String style, int row)
/*  88:    */   {
/*  89: 93 */     XLabel item = new XLabel();
/*  90: 94 */     if (style.equals("h2")) {
/*  91: 95 */       item.setFont(this.headingFont);
/*  92:    */     } else {
/*  93: 97 */       item.setFont(this.textFont);
/*  94:    */     }
/*  95:100 */     if (style.equals("p")) {
/*  96:101 */       text = text.substring(text.indexOf(' ') + 1);
/*  97:    */     }
/*  98:103 */     item.setText(text);
/*  99:    */     
/* 100:105 */     int w = getWidth() - 10;
/* 101:106 */     item.setBounds(5, 5 + 15 * (row - 1), w, 15);
/* 102:    */     
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:111 */     item.setForeground(this.color);
/* 107:    */     
/* 108:    */ 
/* 109:114 */     add(item);
/* 110:115 */     item.setVisible(true);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setList1(XModel list1, String report)
/* 114:    */   {
/* 115:120 */     System.out.println("---Children");
/* 116:    */     
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:126 */     this.list = list1;
/* 122:127 */     System.out.println("Children---" + list1.getNumChildren());
/* 123:128 */     int rowcount = 0;
/* 124:129 */     for (int i = 0; i < list1.getNumChildren(); i++)
/* 125:    */     {
/* 126:131 */       for (int j = 0; j < list1.get(i).getNumChildren(); j++)
/* 127:    */       {
/* 128:133 */         XModel itemM = list1.get(i).get(j);
/* 129:    */         
/* 130:135 */         String style = itemM.getTagName();
/* 131:136 */         String src = (String)itemM.get("@src");
/* 132:137 */         String value = (String)itemM.get();
/* 133:138 */         String text = null;
/* 134:139 */         if (src != null)
/* 135:    */         {
/* 136:141 */           if (src.contains("*"))
/* 137:    */           {
/* 138:143 */             XModel itemsM = new XBaseModel();
/* 139:144 */             TestXUIDB.getInstance().getKeyValues(itemsM, "keyvalue", "/va/" + report + "/" + src.substring(0, src.indexOf("*") - 1));
/* 140:145 */             System.out.println("Path11: va/" + report + "/" + src.substring(0, src.indexOf("*") - 1));
/* 141:146 */             for (int k = 0; k < itemsM.getNumChildren(); k++)
/* 142:    */             {
/* 143:148 */               text = itemsM.get(k).getId() + ": " + itemsM.get(k).get().toString();
/* 144:149 */               rowcount++;
/* 145:150 */               displayItem(text, style, rowcount);
/* 146:    */             }
/* 147:    */           }
/* 148:    */           else
/* 149:    */           {
/* 150:155 */             text = TestXUIDB.getInstance().getValue("keyvalue", "/va/" + report + "/" + src);
/* 151:156 */             System.out.println("Path11: va/" + report + "/" + src + " " + text);
/* 152:157 */             rowcount++;
/* 153:158 */             displayItem(text, style, rowcount);
/* 154:    */           }
/* 155:    */         }
/* 156:    */         else
/* 157:    */         {
/* 158:164 */           text = value;
/* 159:165 */           rowcount++;
/* 160:166 */           displayItem(text, style, rowcount);
/* 161:    */         }
/* 162:    */       }
/* 163:172 */       rowcount++;
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void setColor(Color color)
/* 168:    */   {
/* 169:181 */     this.color = color;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public XModel getList()
/* 173:    */   {
/* 174:186 */     return this.list;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public MultiInfoPanel() {}
/* 178:    */   
/* 179:    */   public MultiInfoPanel(boolean arg0)
/* 180:    */   {
/* 181:195 */     super(arg0);
/* 182:    */   }
/* 183:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.MultiInfoPanel
 * JD-Core Version:    0.7.0.1
 */