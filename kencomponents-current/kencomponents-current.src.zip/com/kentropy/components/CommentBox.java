/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.inet.jortho.SpellChecker;
/*   4:    */ import com.kentropy.db.TestXUIDB;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.FlowLayout;
/*   8:    */ import java.awt.Font;
/*   9:    */ import java.awt.Frame;
/*  10:    */ import java.awt.Point;
/*  11:    */ import java.awt.event.ActionEvent;
/*  12:    */ import java.awt.event.ActionListener;
/*  13:    */ import java.awt.event.FocusEvent;
/*  14:    */ import java.awt.event.FocusListener;
/*  15:    */ import java.awt.event.ItemEvent;
/*  16:    */ import java.awt.event.ItemListener;
/*  17:    */ import java.awt.event.MouseEvent;
/*  18:    */ import java.awt.event.MouseListener;
/*  19:    */ import java.awt.event.WindowAdapter;
/*  20:    */ import java.awt.event.WindowEvent;
/*  21:    */ import java.io.PrintStream;
/*  22:    */ import java.util.Vector;
/*  23:    */ import javax.swing.JTextArea;
/*  24:    */ import net.xoetrope.awt.XButton;
/*  25:    */ import net.xoetrope.awt.XLabel;
/*  26:    */ import net.xoetrope.awt.XPanel;
/*  27:    */ import net.xoetrope.awt.XScrollPane;
/*  28:    */ import net.xoetrope.awt.XToolTip;
/*  29:    */ import net.xoetrope.xui.XPage;
/*  30:    */ import net.xoetrope.xui.XProject;
/*  31:    */ import net.xoetrope.xui.XProjectManager;
/*  32:    */ import net.xoetrope.xui.data.XBaseModel;
/*  33:    */ import net.xoetrope.xui.data.XModel;
/*  34:    */ 
/*  35:    */ public class CommentBox
/*  36:    */   extends XPanel
/*  37:    */   implements MouseListener, ActionListener, FocusListener, ItemListener
/*  38:    */ {
/*  39: 42 */   public KeywordPanel1 kp = null;
/*  40: 44 */   Vector physicians = new Vector();
/*  41:    */   
/*  42:    */   public Vector getPhysicians()
/*  43:    */   {
/*  44: 47 */     return this.physicians;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setPhysicians(Vector physicians)
/*  48:    */   {
/*  49: 51 */     this.physicians = physicians;
/*  50:    */   }
/*  51:    */   
/*  52: 63 */   XPage page = null;
/*  53: 65 */   Container parent = null;
/*  54: 67 */   private static int BUTTON_WIDTH = 50;
/*  55: 68 */   private static int BUTTON_HEIGHT = 20;
/*  56: 70 */   int currentSelected = -1;
/*  57: 71 */   XScrollPane scr = new XScrollPane();
/*  58:    */   private static final int ROWS = 1;
/*  59:    */   private static final int COLUMNS = 8;
/*  60: 77 */   private String deleteFunc = null;
/*  61: 78 */   private String saveFunc = null;
/*  62: 79 */   private String cancelFunc = null;
/*  63: 80 */   private String closeFunc = null;
/*  64: 81 */   private String selectFunc = null;
/*  65: 82 */   private String currentPhysician = null;
/*  66: 83 */   private String report = null;
/*  67: 84 */   private String currentStage = null;
/*  68: 85 */   private String keywordStage = null;
/*  69:    */   
/*  70:    */   public CommentBox(XPanel mainPanel, JTextArea commentArea, XButton[] xb) {}
/*  71:    */   
/*  72:    */   public CommentBox() {}
/*  73:    */   
/*  74:    */   public String getKeywordStage()
/*  75:    */   {
/*  76: 87 */     return this.keywordStage;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setKeywordStage(String keywordStage)
/*  80:    */   {
/*  81: 91 */     this.keywordStage = keywordStage;
/*  82:    */   }
/*  83:    */   
/*  84: 94 */   private JTextArea commentArea = null;
/*  85: 99 */   private XButton saveButton = new XButton();
/*  86:100 */   private XButton editButton = new XButton();
/*  87:101 */   private XButton closeButton = new XButton();
/*  88:102 */   private XButton cancelButton = new XButton();
/*  89:103 */   private XButton deleteButton = new XButton();
/*  90:106 */   public String keywordPhysician = null;
/*  91:    */   
/*  92:    */   public String getKeywordPhysician()
/*  93:    */   {
/*  94:109 */     return this.keywordPhysician;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void remove()
/*  98:    */   {
/*  99:    */     try
/* 100:    */     {
/* 101:115 */       if (getParent() != null) {
/* 102:116 */         getParent().remove(this);
/* 103:    */       }
/* 104:    */     }
/* 105:    */     catch (Exception e)
/* 106:    */     {
/* 107:120 */       e.printStackTrace();
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setKeywordPhysician(String keywordPhysician)
/* 112:    */   {
/* 113:125 */     System.out.println("setting physician:" + keywordPhysician);
/* 114:126 */     this.keywordPhysician = keywordPhysician;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void setParent(Container parent)
/* 118:    */   {
/* 119:139 */     this.parent = parent;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setCurrentPhysician(String currentPhysician)
/* 123:    */   {
/* 124:143 */     System.out.println("Setting current physician:" + currentPhysician);
/* 125:144 */     this.currentPhysician = currentPhysician;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public String getCurrentPhysician()
/* 129:    */   {
/* 130:148 */     return this.currentPhysician;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setReport(String report)
/* 134:    */   {
/* 135:152 */     this.report = report;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public String getReport()
/* 139:    */   {
/* 140:156 */     return this.report;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void setCurrentStage(String currentStage)
/* 144:    */   {
/* 145:160 */     this.currentStage = currentStage;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public String getCurrentStage()
/* 149:    */   {
/* 150:164 */     return this.currentStage;
/* 151:    */   }
/* 152:    */   
/* 153:167 */   String[] keywords = { "Key1", "Lorem Ipsium", 
/* 154:168 */     "This is a multiline keyword that spans a paragraph", 
/* 155:169 */     "Lots of Keywords", "Even More Keywords", "Comments gone crazy" };
/* 156:    */   XModel cm;
/* 157:    */   
/* 158:    */   public void setPage(XPage page)
/* 159:    */   {
/* 160:174 */     this.page = page;
/* 161:    */   }
/* 162:    */   
/* 163:    */   private Color getRowColor(int i)
/* 164:    */   {
/* 165:178 */     if (i % 2 == 0) {
/* 166:179 */       return new Color(220, 220, 220);
/* 167:    */     }
/* 168:181 */     return Color.WHITE;
/* 169:    */   }
/* 170:    */   
/* 171:191 */   String changePhyFunc = null;
/* 172:192 */   String confirmDelete = null;
/* 173:193 */   String changeKeywordPrompt = null;
/* 174:    */   
/* 175:    */   public void setCallback(String action, String function)
/* 176:    */   {
/* 177:197 */     if (action.equals("Delete")) {
/* 178:198 */       this.deleteFunc = function;
/* 179:    */     }
/* 180:201 */     if (action.equals("Save")) {
/* 181:202 */       this.saveFunc = function;
/* 182:    */     }
/* 183:205 */     if (action.equals("Cancel")) {
/* 184:206 */       this.cancelFunc = function;
/* 185:    */     }
/* 186:209 */     if (action.equals("Select")) {
/* 187:210 */       this.selectFunc = function;
/* 188:    */     }
/* 189:213 */     if (action.equals("Close")) {
/* 190:214 */       this.closeFunc = function;
/* 191:    */     }
/* 192:217 */     if (action.equals("ChangePhy")) {
/* 193:218 */       this.changePhyFunc = function;
/* 194:    */     }
/* 195:220 */     if (action.equals("ConfirmDelete")) {
/* 196:221 */       this.confirmDelete = function;
/* 197:    */     }
/* 198:223 */     if (action.equals("ChangeKeywordPrompt")) {
/* 199:224 */       this.changeKeywordPrompt = function;
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:230 */   Vector items = new Vector();
/* 204:    */   
/* 205:    */   public void init()
/* 206:    */   {
/* 207:233 */     Font buttonFont = new Font("SANS_SERIF", 1, 12);
/* 208:234 */     Color buttonColor = new Color(215, 25, 32);
/* 209:    */     
/* 210:    */ 
/* 211:237 */     setLayout(null);
/* 212:    */     
/* 213:    */ 
/* 214:    */ 
/* 215:241 */     setBackground(new Color(220, 220, 220));
/* 216:242 */     setBounds(560, 150, 250, 200);
/* 217:    */     
/* 218:    */ 
/* 219:    */ 
/* 220:246 */     this.commentArea = new JTextArea();
/* 221:247 */     this.commentArea.setOpaque(true);
/* 222:248 */     this.commentArea.setLineWrap(true);
/* 223:249 */     this.commentArea.setWrapStyleWord(true);
/* 224:    */     
/* 225:251 */     SpellChecker.registerDictionaries(null, "en");
/* 226:252 */     SpellChecker.register(this.commentArea);
/* 227:    */     
/* 228:    */ 
/* 229:255 */     XLabel commentLabel = new XLabel();
/* 230:256 */     commentLabel.setText("Keywords:");
/* 231:257 */     commentLabel.setFont(buttonFont);
/* 232:258 */     commentLabel.setBounds(3, 3, 150, 20);
/* 233:259 */     commentLabel.setForeground(Color.BLACK);
/* 234:    */     
/* 235:261 */     this.commentArea.setName("commentArea");
/* 236:262 */     this.commentArea.setBounds(5, 25, getWidth() - 10, 140);
/* 237:    */     
/* 238:    */ 
/* 239:265 */     this.commentArea.setBackground(Color.WHITE);
/* 240:266 */     this.commentArea.setForeground(Color.BLACK);
/* 241:    */     
/* 242:268 */     this.saveButton.setName("Save");
/* 243:269 */     this.saveButton.setLabel("Save");
/* 244:270 */     this.saveButton.setBounds(this.commentArea.getLocation().x, this.commentArea.getY() + 
/* 245:271 */       this.commentArea.getHeight() + 10, BUTTON_WIDTH, BUTTON_HEIGHT);
/* 246:272 */     this.editButton.setName("Edit");
/* 247:273 */     this.editButton.setLabel("Edit");
/* 248:274 */     this.editButton.setBounds(this.commentArea.getLocation().x, this.commentArea.getY() + 
/* 249:275 */       this.commentArea.getHeight() + 10, BUTTON_WIDTH, BUTTON_HEIGHT);
/* 250:276 */     this.deleteButton.setName("Delete");
/* 251:277 */     this.deleteButton.setLabel("Delete");
/* 252:278 */     this.deleteButton.setBounds(this.saveButton.getX() + this.saveButton.getWidth() + 20, 
/* 253:279 */       this.saveButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/* 254:280 */     this.closeButton.setName("Close");
/* 255:281 */     this.closeButton.setLabel("Close");
/* 256:282 */     this.closeButton.setBounds(this.deleteButton.getX() + this.deleteButton.getWidth() + 
/* 257:283 */       20, this.deleteButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/* 258:284 */     this.cancelButton.setName("Cancel");
/* 259:285 */     this.cancelButton.setLabel("Cancel");
/* 260:286 */     this.cancelButton.setBounds(this.deleteButton.getX() + this.deleteButton.getWidth() + 
/* 261:287 */       20, this.deleteButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/* 262:288 */     this.cancelButton.setVisible(false);
/* 263:    */     
/* 264:290 */     this.saveButton.setBackground(buttonColor);
/* 265:291 */     this.saveButton.setForeground(Color.WHITE);
/* 266:292 */     this.saveButton.setFont(buttonFont);
/* 267:293 */     new XToolTip("Click to Save changes", this.saveButton);
/* 268:294 */     this.editButton.setBackground(buttonColor);
/* 269:295 */     this.editButton.setForeground(Color.WHITE);
/* 270:296 */     this.editButton.setFont(buttonFont);
/* 271:297 */     new XToolTip("Click to Edit this comment", this.editButton);
/* 272:298 */     this.deleteButton.setBackground(buttonColor);
/* 273:299 */     this.deleteButton.setForeground(Color.WHITE);
/* 274:300 */     this.deleteButton.setFont(buttonFont);
/* 275:301 */     new XToolTip("Click to Delete this comment", this.deleteButton);
/* 276:302 */     this.closeButton.setBackground(buttonColor);
/* 277:303 */     this.closeButton.setForeground(Color.WHITE);
/* 278:304 */     this.closeButton.setFont(buttonFont);
/* 279:305 */     new XToolTip("Close Comment Box", this.closeButton);
/* 280:306 */     this.cancelButton.setBackground(buttonColor);
/* 281:307 */     this.cancelButton.setForeground(Color.WHITE);
/* 282:308 */     this.cancelButton.setFont(buttonFont);
/* 283:309 */     new XToolTip("Cancel Changes", this.cancelButton);
/* 284:    */     
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:    */ 
/* 305:    */ 
/* 306:    */ 
/* 307:333 */     this.saveButton.addActionListener(this);
/* 308:334 */     this.editButton.addActionListener(this);
/* 309:335 */     this.deleteButton.addActionListener(this);
/* 310:336 */     this.closeButton.addActionListener(this);
/* 311:337 */     this.cancelButton.addActionListener(this);
/* 312:    */     
/* 313:    */ 
/* 314:340 */     this.scr.setBounds(0, 20, 150, 180);
/* 315:    */     
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:345 */     FlowLayout flow = new FlowLayout();
/* 320:    */     
/* 321:    */ 
/* 322:    */ 
/* 323:    */ 
/* 324:350 */     add(this.saveButton);
/* 325:351 */     add(this.editButton);
/* 326:352 */     add(this.deleteButton);
/* 327:353 */     add(this.closeButton);
/* 328:354 */     add(this.cancelButton);
/* 329:355 */     add(this.commentArea);
/* 330:356 */     add(commentLabel);
/* 331:    */     
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:    */ 
/* 348:    */ 
/* 349:    */ 
/* 350:    */ 
/* 351:    */ 
/* 352:    */ 
/* 353:    */ 
/* 354:    */ 
/* 355:    */ 
/* 356:    */ 
/* 357:    */ 
/* 358:384 */     System.out.println(" parent=" + getParent());
/* 359:    */   }
/* 360:    */   
/* 361:    */   public void displayComment(String comment)
/* 362:    */   {
/* 363:396 */     this.commentArea.setText(comment);
/* 364:397 */     if ((this.currentPhysician.equals(this.keywordPhysician)) && (this.currentStage.equals(this.keywordStage))) {
/* 365:398 */       setMode("showEditable");
/* 366:    */     } else {
/* 367:400 */       setMode("showUnEditable");
/* 368:    */     }
/* 369:    */   }
/* 370:    */   
/* 371:    */   public void displayComment(String comment, String phy) {}
/* 372:    */   
/* 373:    */   public static void main(String[] args)
/* 374:    */   {
/* 375:412 */     String[] strArray = { "Hello! This is a very long comment", 
/* 376:413 */       "This is another comment" };
/* 377:    */     
/* 378:    */ 
/* 379:416 */     Frame frame = new Frame("KeywordPanel1");
/* 380:    */     
/* 381:418 */     XProjectManager.getCurrentProject().setAppFrame(frame);
/* 382:    */     
/* 383:420 */     XProjectManager.getCurrentProject().initialise("startup.properties");
/* 384:421 */     frame.setBounds(10, 10, 800, 600);
/* 385:    */     
/* 386:423 */     CommentBox kp = new CommentBox();
/* 387:424 */     kp.setBounds(0, 0, 100, 500);
/* 388:    */     
/* 389:426 */     XModel xm = new XBaseModel();
/* 390:427 */     String parentPath = "/cme/01200001_01_02/Coding/Comments/9";
/* 391:428 */     kp.setCurrentPhysician("9");
/* 392:429 */     kp.setReport("01200001_01_02");
/* 393:    */     
/* 394:    */ 
/* 395:432 */     kp.setParent(frame);
/* 396:433 */     kp.init();
/* 397:    */     
/* 398:    */ 
/* 399:    */ 
/* 400:    */ 
/* 401:    */ 
/* 402:    */ 
/* 403:    */ 
/* 404:    */ 
/* 405:    */ 
/* 406:    */ 
/* 407:    */ 
/* 408:    */ 
/* 409:    */ 
/* 410:    */ 
/* 411:448 */     frame.add(kp);
/* 412:449 */     frame.repaint();
/* 413:    */     
/* 414:451 */     frame.addWindowListener(new WindowAdapter()
/* 415:    */     {
/* 416:    */       public void windowClosing(WindowEvent w)
/* 417:    */       {
/* 418:453 */         System.exit(0);
/* 419:    */       }
/* 420:455 */     });
/* 421:456 */     frame.setVisible(true);
/* 422:    */   }
/* 423:    */   
/* 424:    */   public void mouseClicked(MouseEvent arg0) {}
/* 425:    */   
/* 426:    */   public String getText()
/* 427:    */   {
/* 428:489 */     return this.commentArea.getText();
/* 429:    */   }
/* 430:    */   
/* 431:    */   public void setMode(String mode)
/* 432:    */   {
/* 433:493 */     System.out.println("KeywordPanel1.setMode(" + mode + ")");
/* 434:494 */     if (mode.equals("New"))
/* 435:    */     {
/* 436:495 */       setEditable(true);
/* 437:496 */       this.deleteButton.setVisible(false);
/* 438:    */     }
/* 439:497 */     else if (mode.equals("Edit"))
/* 440:    */     {
/* 441:498 */       setEditable(true);
/* 442:    */     }
/* 443:499 */     else if (mode.equals("showEditable"))
/* 444:    */     {
/* 445:500 */       setEditable(false);
/* 446:    */     }
/* 447:501 */     else if (mode.equals("showUnEditable"))
/* 448:    */     {
/* 449:502 */       setEditable(false);
/* 450:503 */       this.deleteButton.setVisible(false);
/* 451:504 */       this.editButton.setVisible(false);
/* 452:    */     }
/* 453:506 */     showCommentPanel(true);
/* 454:    */   }
/* 455:    */   
/* 456:    */   public int getLastComment()
/* 457:    */   {
/* 458:510 */     String maxId = "";
/* 459:511 */     for (int i = 0; i < this.cm.getNumChildren(); i++) {
/* 460:513 */       if (this.cm.get(i).getId().compareTo(maxId) > 0) {
/* 461:514 */         maxId = this.cm.get(i).getId();
/* 462:    */       }
/* 463:    */     }
/* 464:517 */     if (maxId.equals("")) {
/* 465:518 */       return 0;
/* 466:    */     }
/* 467:520 */     return Integer.parseInt(maxId.substring("comments".length()));
/* 468:    */   }
/* 469:    */   
/* 470:523 */   String mode = "Edit";
/* 471:    */   
/* 472:    */   public void changeKeywordPrompt()
/* 473:    */   {
/* 474:530 */     this.mp.setAction("OK", "DeleteOK");
/* 475:531 */     this.mp.okButton.addActionListener(this);
/* 476:532 */     this.mp.setTitle("Enter Keyword");
/* 477:533 */     this.mp.setMessage("Please enter a keyword to continue");
/* 478:534 */     this.mp.setBounds(600, 200, 300, 100);
/* 479:535 */     this.mp.init();
/* 480:536 */     this.mp.remove(this.mp.cancelButton);
/* 481:537 */     this.mp.okButton.setBounds((this.mp.getWidth() - 80) / 2, this.mp.getHeight() - 3 * 3 - 20, 80, 20);
/* 482:    */     
/* 483:    */ 
/* 484:    */ 
/* 485:541 */     this.mp.setVisible(true);
/* 486:    */   }
/* 487:    */   
/* 488:546 */   XModel comment = null;
/* 489:    */   
/* 490:    */   public void setComment(XModel comment)
/* 491:    */   {
/* 492:549 */     this.comment = comment;
/* 493:550 */     this.commentArea.setText(((XModel)comment.get("text")).get().toString());
/* 494:551 */     this.keywordStage = ((XModel)comment.get("stage")).get().toString();
/* 495:    */   }
/* 496:    */   
/* 497:    */   public XModel getComment()
/* 498:    */   {
/* 499:555 */     return this.comment;
/* 500:    */   }
/* 501:    */   
/* 502:    */   public boolean saveComment()
/* 503:    */     throws Exception
/* 504:    */   {
/* 505:561 */     System.out.println("Inside KeywordPanel1.saveComment()");
/* 506:    */     
/* 507:563 */     String path = "/cme/" + this.report + "/Coding/Comments/" + this.currentPhysician;
/* 508:564 */     System.out.println("report::" + this.report);
/* 509:    */     
/* 510:566 */     String text = this.commentArea.getText();
/* 511:568 */     if (text.trim().equals(""))
/* 512:    */     {
/* 513:569 */       System.out.println("Keyword is empty");
/* 514:570 */       this.page.evaluateAttribute("${" + this.changeKeywordPrompt + "()}");
/* 515:571 */       return false;
/* 516:    */     }
/* 517:573 */     System.out.println("Keyword is not empty");
/* 518:    */     
/* 519:575 */     text = text.replaceAll("[^A-Z^a-z^0-9^\\s]", " ");
/* 520:576 */     ((XModel)getComment().get("text")).set(text);
/* 521:577 */     System.out.println("Text::" + text);
/* 522:    */     
/* 523:579 */     TestXUIDB.getInstance().saveTree(getSelectedComment(), "keyvalue", 
/* 524:580 */       path);
/* 525:581 */     if (this.saveFunc != null) {
/* 526:582 */       this.page.evaluateAttribute("${" + this.saveFunc + "()}");
/* 527:    */     }
/* 528:584 */     showCommentPanel(false);
/* 529:    */     
/* 530:586 */     this.disableSelect = false;
/* 531:587 */     setEditable(false);
/* 532:    */     
/* 533:    */ 
/* 534:590 */     return true;
/* 535:    */   }
/* 536:    */   
/* 537:    */   public void mouseEntered(MouseEvent arg0) {}
/* 538:    */   
/* 539:    */   public void mouseExited(MouseEvent arg0) {}
/* 540:    */   
/* 541:    */   public void mousePressed(MouseEvent arg0) {}
/* 542:    */   
/* 543:    */   public void mouseReleased(MouseEvent arg0) {}
/* 544:    */   
/* 545:    */   public void setEditable(boolean status)
/* 546:    */   {
/* 547:610 */     System.out.println("KeywordPanel.setEditable(" + status + ")");
/* 548:611 */     this.disableSelect = status;
/* 549:612 */     this.saveButton.setVisible(status);
/* 550:613 */     this.editButton.setVisible(!status);
/* 551:614 */     this.deleteButton.setVisible(!status);
/* 552:615 */     this.commentArea.setEditable(status);
/* 553:616 */     this.closeButton.setVisible(!status);
/* 554:617 */     this.cancelButton.setVisible(status);
/* 555:    */     
/* 556:    */ 
/* 557:    */ 
/* 558:    */ 
/* 559:    */ 
/* 560:    */ 
/* 561:    */ 
/* 562:    */ 
/* 563:    */ 
/* 564:    */ 
/* 565:    */ 
/* 566:    */ 
/* 567:    */ 
/* 568:    */ 
/* 569:    */ 
/* 570:    */ 
/* 571:    */ 
/* 572:    */ 
/* 573:    */ 
/* 574:    */ 
/* 575:    */ 
/* 576:    */ 
/* 577:    */ 
/* 578:    */ 
/* 579:    */ 
/* 580:    */ 
/* 581:    */ 
/* 582:645 */     System.out.println(this.currentPhysician + " " + this.keywordPhysician);
/* 583:646 */     if (!this.currentPhysician.equals(this.keywordPhysician))
/* 584:    */     {
/* 585:650 */       this.editButton.setVisible(false);
/* 586:651 */       this.deleteButton.setVisible(false);
/* 587:    */     }
/* 588:653 */     repaint();
/* 589:    */   }
/* 590:    */   
/* 591:660 */   public MessagePanel mp = new MessagePanel();
/* 592:    */   
/* 593:    */   public void confirmDelete()
/* 594:    */   {
/* 595:663 */     this.mp = new MessagePanel();
/* 596:    */     
/* 597:665 */     this.mp.setAction("OK", "DeleteOK");
/* 598:666 */     this.mp.okButton.addActionListener(this);
/* 599:667 */     this.mp.setTitle("Delete Keyword");
/* 600:668 */     this.mp.setMessage("Are you sure you want to delete this comment?");
/* 601:669 */     this.mp.init();
/* 602:670 */     this.mp.repaint();
/* 603:    */     
/* 604:    */ 
/* 605:    */ 
/* 606:    */ 
/* 607:675 */     this.mp.repaint();
/* 608:    */   }
/* 609:    */   
/* 610:    */   public XModel getSelectedComment()
/* 611:    */   {
/* 612:681 */     return this.comment;
/* 613:    */   }
/* 614:    */   
/* 615:684 */   boolean disableSelect = false;
/* 616:    */   
/* 617:    */   public void deleteComment1()
/* 618:    */   {
/* 619:688 */     String path = "/cme/" + this.report + "/Coding/Comments/" + 
/* 620:689 */       this.currentPhysician + "/" + getSelectedComment().getId();
/* 621:    */     try
/* 622:    */     {
/* 623:691 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/text");
/* 624:692 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/x");
/* 625:693 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/y");
/* 626:694 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/endx");
/* 627:695 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/endy");
/* 628:696 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/stage");
/* 629:698 */       if (this.deleteFunc != null) {
/* 630:699 */         this.page.evaluateAttribute("${" + this.deleteFunc + "()}");
/* 631:    */       }
/* 632:701 */       ((XBaseModel)this.cm).removeChild(getSelectedComment().getId());
/* 633:    */       
/* 634:    */ 
/* 635:704 */       setEditable(false);
/* 636:    */       
/* 637:    */ 
/* 638:    */ 
/* 639:708 */       this.disableSelect = false;
/* 640:709 */       showCommentPanel(false);
/* 641:    */     }
/* 642:    */     catch (Exception e)
/* 643:    */     {
/* 644:711 */       e.printStackTrace();
/* 645:    */     }
/* 646:    */   }
/* 647:    */   
/* 648:    */   public void showCommentPanel(boolean b)
/* 649:    */   {
/* 650:716 */     repaint();
/* 651:717 */     setVisible(b);
/* 652:    */   }
/* 653:    */   
/* 654:745 */   private boolean newComment = false;
/* 655:    */   
/* 656:    */   public void actionPerformed(ActionEvent arg0)
/* 657:    */   {
/* 658:749 */     if (arg0.getActionCommand().equals("Save"))
/* 659:    */     {
/* 660:    */       try
/* 661:    */       {
/* 662:751 */         if (!this.kp.saveComment()) {
/* 663:    */           return;
/* 664:    */         }
/* 665:752 */         this.newComment = false;
/* 666:753 */         setEditable(false);
/* 667:    */       }
/* 668:    */       catch (Exception e)
/* 669:    */       {
/* 670:757 */         e.printStackTrace();
/* 671:    */       }
/* 672:    */     }
/* 673:760 */     else if (arg0.getActionCommand().equals("Edit"))
/* 674:    */     {
/* 675:761 */       setEditable(true);
/* 676:    */     }
/* 677:762 */     else if (arg0.getActionCommand().equals("Close"))
/* 678:    */     {
/* 679:763 */       this.disableSelect = false;
/* 680:764 */       this.page.evaluateAttribute("${" + this.closeFunc + "()}");
/* 681:    */       
/* 682:766 */       showCommentPanel(false);
/* 683:    */     }
/* 684:767 */     else if (arg0.getActionCommand().equals("Delete"))
/* 685:    */     {
/* 686:768 */       System.out.println("Confirm");
/* 687:769 */       this.page.evaluateAttribute("${" + this.confirmDelete + "()}");
/* 688:    */     }
/* 689:771 */     else if (arg0.getActionCommand().equals("DeleteOK"))
/* 690:    */     {
/* 691:772 */       System.out.println("Deleting Comment");
/* 692:    */       try
/* 693:    */       {
/* 694:774 */         deleteComment1();
/* 695:    */       }
/* 696:    */       catch (NullPointerException e)
/* 697:    */       {
/* 698:776 */         e.printStackTrace();
/* 699:    */       }
/* 700:    */     }
/* 701:779 */     else if (arg0.getActionCommand().equals("Cancel"))
/* 702:    */     {
/* 703:780 */       if (this.newComment) {
/* 704:783 */         ((XBaseModel)this.cm).removeChild(getSelectedComment().getId());
/* 705:    */       }
/* 706:785 */       this.disableSelect = false;
/* 707:786 */       setVisible(false);
/* 708:787 */       this.page.evaluateAttribute("${" + this.cancelFunc + "()}");
/* 709:    */       
/* 710:789 */       this.newComment = false;
/* 711:    */     }
/* 712:790 */     else if (!arg0.getActionCommand().equals("hide"))
/* 713:    */     {
/* 714:793 */       if (!arg0.getActionCommand().equals("show")) {
/* 715:795 */         if (arg0.getActionCommand().equals("ChangePhy"))
/* 716:    */         {
/* 717:796 */           String phy = null;
/* 718:797 */           if (this.keywordPhysician.equals(this.physicians.get(0))) {
/* 719:798 */             phy = (String)this.physicians.get(1);
/* 720:799 */           } else if (this.keywordPhysician.equals(this.physicians.get(1))) {
/* 721:800 */             phy = (String)this.physicians.get(0);
/* 722:    */           }
/* 723:802 */           System.out.println("changePhyFunc::${" + this.changePhyFunc + "(" + 
/* 724:803 */             phy + ")}");
/* 725:804 */           this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + phy + ")}");
/* 726:    */         }
/* 727:    */       }
/* 728:    */     }
/* 729:    */   }
/* 730:    */   
/* 731:    */   public void focusGained(FocusEvent arg0) {}
/* 732:    */   
/* 733:    */   public void focusLost(FocusEvent arg0)
/* 734:    */   {
/* 735:815 */     System.out.println(" Focus Lost 111");
/* 736:    */   }
/* 737:    */   
/* 738:    */   public void reset() {}
/* 739:    */   
/* 740:    */   public void itemStateChanged(ItemEvent arg0) {}
/* 741:    */   
/* 742:    */   public void setTitle(String title) {}
/* 743:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.CommentBox
 * JD-Core Version:    0.7.0.1
 */