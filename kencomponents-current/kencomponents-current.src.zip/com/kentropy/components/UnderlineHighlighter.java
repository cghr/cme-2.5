/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.FontMetrics;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.Rectangle;
/*   7:    */ import java.awt.Shape;
/*   8:    */ import javax.swing.text.BadLocationException;
/*   9:    */ import javax.swing.text.DefaultHighlighter;
/*  10:    */ import javax.swing.text.Highlighter.HighlightPainter;
/*  11:    */ import javax.swing.text.JTextComponent;
/*  12:    */ import javax.swing.text.LayeredHighlighter.LayerPainter;
/*  13:    */ import javax.swing.text.Position.Bias;
/*  14:    */ import javax.swing.text.View;
/*  15:    */ 
/*  16:    */ class UnderlineHighlighter
/*  17:    */   extends DefaultHighlighter
/*  18:    */ {
/*  19:    */   public UnderlineHighlighter(Color c)
/*  20:    */   {
/*  21:167 */     this.painter = (c == null ? sharedPainter : new UnderlineHighlightPainter(c));
/*  22:    */   }
/*  23:    */   
/*  24:    */   public Object addHighlight(int p0, int p1)
/*  25:    */     throws BadLocationException
/*  26:    */   {
/*  27:173 */     return addHighlight(p0, p1, this.painter);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void setDrawsLayeredHighlights(boolean newValue)
/*  31:    */   {
/*  32:178 */     if (!newValue) {
/*  33:179 */       throw new IllegalArgumentException(
/*  34:180 */         "UnderlineHighlighter only draws layered highlights");
/*  35:    */     }
/*  36:182 */     super.setDrawsLayeredHighlights(true);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static class UnderlineHighlightPainter
/*  40:    */     extends LayeredHighlighter.LayerPainter
/*  41:    */   {
/*  42:    */     protected Color color;
/*  43:    */     
/*  44:    */     public UnderlineHighlightPainter(Color c)
/*  45:    */     {
/*  46:189 */       this.color = c;
/*  47:    */     }
/*  48:    */     
/*  49:    */     public void paint(Graphics g, int offs0, int offs1, Shape bounds, JTextComponent c) {}
/*  50:    */     
/*  51:    */     public Shape paintLayer(Graphics g, int offs0, int offs1, Shape bounds, JTextComponent c, View view)
/*  52:    */     {
/*  53:199 */       g.setColor(this.color == null ? c.getSelectionColor() : this.color);
/*  54:    */       
/*  55:201 */       Rectangle alloc = null;
/*  56:202 */       if ((offs0 == view.getStartOffset()) && (offs1 == view.getEndOffset()))
/*  57:    */       {
/*  58:203 */         if ((bounds instanceof Rectangle)) {
/*  59:204 */           alloc = (Rectangle)bounds;
/*  60:    */         } else {
/*  61:206 */           alloc = bounds.getBounds();
/*  62:    */         }
/*  63:    */       }
/*  64:    */       else {
/*  65:    */         try
/*  66:    */         {
/*  67:210 */           Shape shape = view.modelToView(offs0, 
/*  68:211 */             Position.Bias.Forward, offs1, 
/*  69:212 */             Position.Bias.Backward, bounds);
/*  70:213 */           alloc = (shape instanceof Rectangle) ? (Rectangle)shape : 
/*  71:214 */             shape.getBounds();
/*  72:    */         }
/*  73:    */         catch (BadLocationException e)
/*  74:    */         {
/*  75:216 */           return null;
/*  76:    */         }
/*  77:    */       }
/*  78:220 */       FontMetrics fm = c.getFontMetrics(c.getFont());
/*  79:221 */       int baseline = alloc.y + alloc.height - fm.getDescent() + 1;
/*  80:222 */       g.drawLine(alloc.x, baseline, alloc.x + alloc.width, baseline);
/*  81:223 */       g.drawLine(alloc.x, baseline + 1, alloc.x + alloc.width, 
/*  82:224 */         baseline + 1);
/*  83:    */       
/*  84:226 */       return alloc;
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:233 */   protected static final Highlighter.HighlightPainter sharedPainter = new UnderlineHighlightPainter(
/*  89:234 */     null);
/*  90:    */   protected Highlighter.HighlightPainter painter;
/*  91:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.UnderlineHighlighter
 * JD-Core Version:    0.7.0.1
 */