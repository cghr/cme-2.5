/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import java.awt.Checkbox;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.Dimension;
/*   8:    */ import java.awt.FlowLayout;
/*   9:    */ import java.awt.Font;
/*  10:    */ import java.awt.Frame;
/*  11:    */ import java.awt.event.ActionEvent;
/*  12:    */ import java.awt.event.ActionListener;
/*  13:    */ import java.awt.event.KeyEvent;
/*  14:    */ import java.awt.event.KeyListener;
/*  15:    */ import java.awt.event.MouseEvent;
/*  16:    */ import java.awt.event.MouseListener;
/*  17:    */ import java.awt.event.WindowAdapter;
/*  18:    */ import java.awt.event.WindowEvent;
/*  19:    */ import java.io.FileReader;
/*  20:    */ import java.io.PrintStream;
/*  21:    */ import java.util.Vector;
/*  22:    */ import java.util.regex.Matcher;
/*  23:    */ import java.util.regex.Pattern;
/*  24:    */ import javax.swing.Box;
/*  25:    */ import javax.swing.JCheckBox;
/*  26:    */ import javax.swing.JLabel;
/*  27:    */ import javax.swing.JOptionPane;
/*  28:    */ import javax.swing.JPanel;
/*  29:    */ import javax.swing.JScrollPane;
/*  30:    */ import javax.swing.JTextPane;
/*  31:    */ import javax.swing.event.HyperlinkEvent;
/*  32:    */ import javax.swing.event.HyperlinkListener;
/*  33:    */ import javax.swing.text.BadLocationException;
/*  34:    */ import javax.swing.text.Document;
/*  35:    */ import net.xoetrope.data.XDataSource;
/*  36:    */ import net.xoetrope.swing.XButton;
/*  37:    */ import net.xoetrope.swing.XComboBox;
/*  38:    */ import net.xoetrope.swing.XLabel;
/*  39:    */ import net.xoetrope.swing.XPanel;
/*  40:    */ import net.xoetrope.xui.XProject;
/*  41:    */ import net.xoetrope.xui.XProjectManager;
/*  42:    */ import net.xoetrope.xui.data.XBaseModel;
/*  43:    */ import net.xoetrope.xui.data.XModel;
/*  44:    */ 
/*  45:    */ public class Narrative
/*  46:    */   extends XPanel
/*  47:    */   implements ActionListener, KeyListener, HyperlinkListener, MouseListener
/*  48:    */ {
/*  49: 57 */   public String lang = "en";
/*  50: 58 */   public String type = "adult";
/*  51: 59 */   public String savePath = "";
/*  52: 60 */   public XModel rootModel = null;
/*  53: 61 */   JCheckBox[] checkboxArray = null;
/*  54: 62 */   JCheckBox[] selectedCheckbox = null;
/*  55: 63 */   Box symptomCheckList = Box.createVerticalBox();
/*  56: 64 */   JPanel selectionPanel = new JPanel();
/*  57: 65 */   JPanel selectedPanel = new JPanel();
/*  58: 66 */   XPanel listPanel = new XPanel();
/*  59: 67 */   JTextPane narrativeArea = new JTextPane();
/*  60: 68 */   JTextPane noteArea = new JTextPane();
/*  61: 69 */   JLabel guidelinesLabel = new JLabel();
/*  62: 70 */   XLabel narrativePanelHeading = new XLabel();
/*  63: 71 */   XLabel noteHeading = new XLabel();
/*  64: 72 */   XPanel displayPanel = new XPanel();
/*  65: 73 */   XButton nextButton = new XButton();
/*  66: 74 */   XComboBox languageBox = new XComboBox();
/*  67: 75 */   XButton languageButton = new XButton();
/*  68: 76 */   XButton finishButton = new XButton();
/*  69: 77 */   String text1 = "";
/*  70: 78 */   public XModel filterM = new XBaseModel();
/*  71: 79 */   public Vector positive = new Vector();
/*  72: 80 */   public Vector covered = new Vector();
/*  73: 81 */   private static int PANEL_WIDTH = 1000;
/*  74: 82 */   private static int PANEL_HEIGHT = 570;
/*  75: 83 */   XPanel lang1 = new XPanel();
/*  76:    */   
/*  77:    */   public void init()
/*  78:    */   {
/*  79: 88 */     setBounds(0, 0, PANEL_WIDTH, PANEL_HEIGHT);
/*  80: 89 */     setLayout(null);
/*  81: 90 */     this.lang1.setBounds(0, 0, 250, 100);
/*  82: 91 */     this.lang1.setBackground(Color.red);
/*  83:    */     
/*  84: 93 */     this.selectionPanel.setBounds(0, 0, 220, PANEL_HEIGHT - 50);
/*  85: 94 */     this.selectionPanel.setBackground(Color.pink);
/*  86:    */     
/*  87: 96 */     add(this.selectionPanel);
/*  88:    */     
/*  89: 98 */     loadFilters();
/*  90: 99 */     loadSymptoms();
/*  91:    */     
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:107 */     createLayout();
/*  99:    */     
/* 100:109 */     initLanguageSelector();
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void initLanguageSelector() {}
/* 104:    */   
/* 105:    */   public void listPanelInit()
/* 106:    */   {
/* 107:130 */     this.listPanel.setBounds(0, 0, 350, PANEL_HEIGHT);
/* 108:131 */     this.listPanel.setLayout(new FlowLayout());
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void loadFilters()
/* 112:    */   {
/* 113:138 */     this.filterM = ((XModel)this.rootModel.get("symptomlist_" + this.type));
/* 114:139 */     System.out.println(" No of nodes " + this.filterM.getNumChildren());
/* 115:    */   }
/* 116:    */   
/* 117:144 */   Box symptomBox = null;
/* 118:    */   
/* 119:    */   public void initSelectionPanel()
/* 120:    */   {
/* 121:148 */     this.selectionPanel.setBackground(Color.LIGHT_GRAY);
/* 122:    */     
/* 123:150 */     this.selectionPanel.setLayout(new FlowLayout());
/* 124:151 */     XLabel selectionPanelHeading = new XLabel();
/* 125:152 */     selectionPanelHeading.setText("Positive symptoms");
/* 126:153 */     selectionPanelHeading.setFont(new Font("SansSerif", 1, 12));
/* 127:154 */     selectionPanelHeading.setForeground(Color.white);
/* 128:155 */     this.selectionPanel.repaint();
/* 129:    */     
/* 130:157 */     this.symptomBox = Box.createVerticalBox();
/* 131:158 */     this.symptomBox.setBounds(0, 0, 240, 500);
/* 132:159 */     this.symptomBox.setBackground(Color.white);
/* 133:    */     
/* 134:    */ 
/* 135:162 */     this.selectionPanel.add(selectionPanelHeading);
/* 136:164 */     for (int i = 0; i < this.checkboxArray.length; i++) {
/* 137:167 */       this.selectionPanel.add(this.checkboxArray[i]);
/* 138:    */     }
/* 139:169 */     this.nextButton.setLabel("Next");
/* 140:170 */     this.nextButton.addActionListener(this);
/* 141:    */     
/* 142:172 */     this.selectionPanel.add(this.nextButton);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void initSelectionPanel1()
/* 146:    */   {
/* 147:180 */     this.selectionPanel.setLayout(null);
/* 148:181 */     this.selectionPanel.setBackground(new Color(176, 19, 58));
/* 149:    */     
/* 150:    */ 
/* 151:184 */     XLabel selectionPanelHeading = new XLabel();
/* 152:185 */     selectionPanelHeading.setText("Positive symptoms");
/* 153:186 */     selectionPanelHeading.setFont(new Font("SansSerif", 1, 12));
/* 154:187 */     selectionPanelHeading.setBounds(0, 0, 150, 20);
/* 155:188 */     selectionPanelHeading.setForeground(Color.white);
/* 156:    */     
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:194 */     this.selectionPanel.add(selectionPanelHeading);
/* 162:    */     
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:222 */     this.nextButton.setLabel("Next");
/* 190:223 */     this.nextButton.addActionListener(this);
/* 191:    */     
/* 192:225 */     this.nextButton.setBounds(0, 500, 100, 20);
/* 193:226 */     this.selectionPanel.add(this.nextButton);
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void initListPanel()
/* 197:    */   {
/* 198:233 */     this.listPanel.setBounds(0, 0, 250, 600);
/* 199:234 */     this.listPanel.setLayout(null);
/* 200:    */     
/* 201:236 */     XLabel listPanelHeading = new XLabel();
/* 202:237 */     listPanelHeading.setText("Positive symptoms");
/* 203:238 */     listPanelHeading.setFont(new Font("SansSerif", 1, 12));
/* 204:239 */     listPanelHeading.setSize(this.listPanel.getWidth(), 15);
/* 205:240 */     this.listPanel.add(listPanelHeading);
/* 206:    */     
/* 207:    */ 
/* 208:243 */     this.listPanel.setVisible(false);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void save()
/* 212:    */   {
/* 213:    */     try
/* 214:    */     {
/* 215:248 */       System.out.println(this.narrativeArea.getDocument().getText(0, this.narrativeArea.getDocument().getLength()));
/* 216:249 */       TestXUIDB.getInstance().saveKeyValue("resource", this.savePath + "/narrative", this.narrativeArea.getDocument().getText(0, this.narrativeArea.getDocument().getLength()));
/* 217:250 */       TestXUIDB.getInstance().saveKeyValue("resource", this.savePath + "/notes", this.noteArea.getDocument().getText(0, this.noteArea.getDocument().getLength()));
/* 218:251 */       TestXUIDB.getInstance().saveKeyValue("resource", this.savePath + "/symptoms", getValues());
/* 219:252 */       TestXUIDB.getInstance().saveKeyValue("resource", this.savePath + "/language", this.lang);
/* 220:    */     }
/* 221:    */     catch (Exception e)
/* 222:    */     {
/* 223:256 */       e.printStackTrace();
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   private String getValues()
/* 228:    */   {
/* 229:265 */     String str = "";
/* 230:266 */     int count = 0;
/* 231:267 */     for (int i = 0; i < this.checkboxArray.length; i++) {
/* 232:269 */       if (this.checkboxArray[i].isSelected())
/* 233:    */       {
/* 234:271 */         str = str + (count == 0 ? "" : ",") + this.checkboxArray[i].getName();
/* 235:272 */         count++;
/* 236:    */       }
/* 237:    */     }
/* 238:275 */     return str;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void read() {}
/* 242:    */   
/* 243:    */   public void initGuidelinesArea()
/* 244:    */   {
/* 245:287 */     this.guidelinesLabel.setBounds(0, 0, 290, PANEL_HEIGHT + 100);
/* 246:288 */     this.guidelinesLabel.setPreferredSize(new Dimension(290, PANEL_HEIGHT + 100));
/* 247:289 */     this.guidelinesLabel.setVisible(false);
/* 248:290 */     this.guidelinesLabel.setVerticalAlignment(1);
/* 249:291 */     JScrollPane scroll = new JScrollPane(this.guidelinesLabel, 22, 31);
/* 250:292 */     scroll.setBounds(PANEL_WIDTH - 300, 10, 290, PANEL_HEIGHT - 100);
/* 251:    */     
/* 252:294 */     add(scroll, "East");
/* 253:    */   }
/* 254:    */   
/* 255:296 */   JScrollPane narrativeScrollPane = null;
/* 256:    */   
/* 257:    */   public void initNarrativePanel()
/* 258:    */   {
/* 259:298 */     this.noteArea.setBounds(230, 30, 450, PANEL_HEIGHT - 430);
/* 260:299 */     this.noteArea.getDocument().putProperty(
/* 261:300 */       "__EndOfLine__", "<br />");
/* 262:301 */     this.noteArea.addHyperlinkListener(this);
/* 263:    */     
/* 264:303 */     this.noteArea.setVisible(false);
/* 265:304 */     this.noteArea.setContentType("text/html");
/* 266:    */     
/* 267:306 */     this.noteArea.addKeyListener(this);
/* 268:307 */     this.noteArea.setBackground(new Color(245, 245, 245));
/* 269:308 */     add(this.noteArea);
/* 270:    */     
/* 271:    */ 
/* 272:311 */     this.noteHeading.setText("Notes");
/* 273:312 */     this.noteHeading.setFont(new Font("SansSerif", 1, 12));
/* 274:313 */     this.noteHeading.setBounds(260, 0, 480, 20);
/* 275:314 */     this.noteHeading.setVisible(false);
/* 276:315 */     add(this.noteHeading);
/* 277:316 */     this.narrativeScrollPane = new JScrollPane(this.narrativeArea, 22, 31);
/* 278:317 */     this.narrativeScrollPane.setBounds(230, 230, 450, PANEL_HEIGHT - 300);
/* 279:    */     
/* 280:    */ 
/* 281:320 */     this.narrativeArea.getDocument().putProperty(
/* 282:321 */       "__EndOfLine__", "<br />");
/* 283:322 */     this.narrativeArea.addHyperlinkListener(this);
/* 284:323 */     this.narrativeScrollPane.setVisible(false);
/* 285:324 */     this.narrativeArea.setVisible(false);
/* 286:325 */     this.narrativeArea.setContentType("text/html");
/* 287:    */     
/* 288:327 */     this.narrativeArea.addKeyListener(this);
/* 289:328 */     this.narrativeArea.setBackground(new Color(245, 245, 245));
/* 290:    */     
/* 291:330 */     this.narrativePanelHeading
/* 292:331 */       .setText("Type the narrative in chronological sequence:");
/* 293:332 */     this.narrativePanelHeading.setFont(new Font("SansSerif", 1, 12));
/* 294:    */     
/* 295:    */ 
/* 296:335 */     this.narrativePanelHeading.setBounds(260, 200, 480, 20);
/* 297:336 */     this.narrativePanelHeading.setVisible(false);
/* 298:337 */     add(this.narrativePanelHeading);
/* 299:    */     
/* 300:    */ 
/* 301:    */ 
/* 302:    */ 
/* 303:    */ 
/* 304:343 */     add(this.narrativeScrollPane);
/* 305:344 */     String narrStr = TestXUIDB.getInstance().getValue("resource", this.savePath + "/narrative");
/* 306:345 */     if (narrStr != null) {
/* 307:347 */       this.narrativeArea.setText(narrStr);
/* 308:    */     }
/* 309:350 */     String noteStr = TestXUIDB.getInstance().getValue("resource", this.savePath + "/notes");
/* 310:351 */     if (noteStr != null) {
/* 311:353 */       this.noteArea.setText(noteStr);
/* 312:    */     }
/* 313:357 */     this.finishButton.setBounds(550, 0, 100, 20);
/* 314:    */     
/* 315:    */ 
/* 316:360 */     this.finishButton.setText("Save");
/* 317:361 */     this.finishButton.setVisible(false);
/* 318:362 */     this.finishButton.addActionListener(this);
/* 319:    */     
/* 320:    */ 
/* 321:365 */     add(this.finishButton);
/* 322:366 */     validate();
/* 323:    */   }
/* 324:    */   
/* 325:    */   public void createLayout()
/* 326:    */   {
/* 327:370 */     initSelectionPanel1();
/* 328:    */     
/* 329:372 */     initGuidelinesArea();
/* 330:373 */     initNarrativePanel();
/* 331:    */   }
/* 332:    */   
/* 333:    */   public void loadSymptoms()
/* 334:    */   {
/* 335:380 */     String sympStr = TestXUIDB.getInstance().getValue("resource", this.savePath + "/symptoms");
/* 336:381 */     Vector v = new Vector();
/* 337:382 */     if (sympStr != null)
/* 338:    */     {
/* 339:384 */       String[] symps = sympStr.split(",");
/* 340:386 */       for (int i = 0; i < symps.length; i++) {
/* 341:388 */         v.add(symps[i]);
/* 342:    */       }
/* 343:    */     }
/* 344:392 */     this.checkboxArray = new JCheckBox[this.filterM.getNumChildren() - 1];
/* 345:393 */     System.out.println("filterM Children:" + this.filterM.getNumChildren());
/* 346:394 */     int count = 0;
/* 347:395 */     for (int i = 0; i < this.filterM.getNumChildren(); i++) {
/* 348:396 */       if (!this.filterM.get(i).getId().equals("keywords"))
/* 349:    */       {
/* 350:400 */         System.out.println("filterM " + this.filterM.get(i).getId());
/* 351:401 */         System.out.println(this.filterM.get(i).getId() + "  " + TestXUIDB.getInstance().getTranslation(this.filterM.get(i).getId(), this.lang));
/* 352:402 */         this.checkboxArray[count] = new JCheckBox();
/* 353:403 */         this.checkboxArray[count].setName(this.filterM.get(i).getId());
/* 354:404 */         if (v.contains(this.filterM.get(i).getId())) {
/* 355:406 */           this.checkboxArray[count].setSelected(true);
/* 356:    */         }
/* 357:408 */         this.checkboxArray[count].setText(TestXUIDB.getInstance().getTranslation(this.filterM.get(i).getId(), this.lang));
/* 358:    */         
/* 359:410 */         this.checkboxArray[count].addMouseListener(this);
/* 360:    */         
/* 361:412 */         this.checkboxArray[count].setBounds(10, 20 * count + 40, 200, 20);
/* 362:413 */         this.selectionPanel.add(this.checkboxArray[count]);
/* 363:414 */         count++;
/* 364:    */       }
/* 365:    */     }
/* 366:419 */     this.selectionPanel.setVisible(true);
/* 367:420 */     this.selectionPanel.repaint();
/* 368:    */   }
/* 369:    */   
/* 370:    */   public void addSymptoms(JCheckBox[] checkboxArray)
/* 371:    */   {
/* 372:425 */     int count = 0;
/* 373:426 */     this.selectionPanel.removeAll();
/* 374:427 */     for (int i = 0; i < checkboxArray.length; i++) {
/* 375:428 */       if (checkboxArray[i].isSelected())
/* 376:    */       {
/* 377:429 */         checkboxArray[i].setBounds(10, 20 * count + 40, 200, 20);
/* 378:430 */         this.selectionPanel.add(checkboxArray[i]);
/* 379:431 */         count++;
/* 380:    */       }
/* 381:    */     }
/* 382:435 */     for (int i = 0; i < checkboxArray.length; i++) {
/* 383:436 */       if (!checkboxArray[i].isSelected())
/* 384:    */       {
/* 385:437 */         checkboxArray[i].setBounds(10, 20 * count + 40, 200, 20);
/* 386:438 */         this.selectionPanel.add(checkboxArray[i]);
/* 387:439 */         count++;
/* 388:    */       }
/* 389:    */     }
/* 390:442 */     this.selectionPanel.repaint();
/* 391:443 */     this.selectionPanel.validate();
/* 392:    */   }
/* 393:    */   
/* 394:    */   public void actionPerformed(ActionEvent ae)
/* 395:    */   {
/* 396:449 */     if (ae.getSource() == this.nextButton)
/* 397:    */     {
/* 398:450 */       this.nextButton.setVisible(false);
/* 399:460 */       for (int i = 0; i < this.checkboxArray.length; i++) {
/* 400:461 */         if (this.checkboxArray[i].isSelected()) {
/* 401:465 */           this.checkboxArray[i].setForeground(new Color(176, 19, 58));
/* 402:    */         } else {
/* 403:470 */           this.checkboxArray[i].setEnabled(true);
/* 404:    */         }
/* 405:    */       }
/* 406:475 */       addSymptoms(this.checkboxArray);
/* 407:    */       
/* 408:    */ 
/* 409:    */ 
/* 410:    */ 
/* 411:480 */       this.guidelinesLabel.setVisible(true);
/* 412:481 */       showNarrativePanel();
/* 413:    */     }
/* 414:482 */     else if (ae.getSource() == this.finishButton)
/* 415:    */     {
/* 416:483 */       if (!validateFinish())
/* 417:    */       {
/* 418:484 */         JOptionPane.showMessageDialog((Frame)getParent(), 
/* 419:485 */           "Narrative does not cover all the symptoms.", "Error", 
/* 420:486 */           0);
/* 421:    */       }
/* 422:    */       else
/* 423:    */       {
/* 424:488 */         save();
/* 425:489 */         setVisible(false);
/* 426:490 */         ((Frame)getParent()).dispose();
/* 427:    */       }
/* 428:    */     }
/* 429:493 */     else if (ae.getSource() == this.languageButton)
/* 430:    */     {
/* 431:496 */       this.language = ((String)this.languageBox.getSelectedItem());
/* 432:    */       
/* 433:    */ 
/* 434:499 */       loadFilters();
/* 435:500 */       loadSymptoms();
/* 436:    */       
/* 437:    */ 
/* 438:503 */       this.lang1.setVisible(false);
/* 439:504 */       this.nextButton.setVisible(true);
/* 440:    */       
/* 441:    */ 
/* 442:    */ 
/* 443:508 */       System.out.println("child comps:" + 
/* 444:509 */         this.selectionPanel.getComponentCount());
/* 445:    */     }
/* 446:    */   }
/* 447:    */   
/* 448:514 */   public String language = "";
/* 449:    */   
/* 450:    */   public void showNarrativePanel()
/* 451:    */   {
/* 452:517 */     this.noteArea.setVisible(true);
/* 453:518 */     this.noteHeading.setVisible(true);
/* 454:519 */     this.narrativeScrollPane.setVisible(true);
/* 455:520 */     this.narrativeArea.setVisible(true);
/* 456:521 */     this.narrativePanelHeading.setVisible(true);
/* 457:522 */     this.finishButton.setVisible(true);
/* 458:523 */     replace(this.noteArea);
/* 459:524 */     replace(this.narrativeArea);
/* 460:525 */     validate();
/* 461:    */   }
/* 462:    */   
/* 463:    */   public boolean validateFinish()
/* 464:    */   {
/* 465:529 */     Component[] cArray = this.symptomCheckList.getComponents();
/* 466:530 */     for (int i = 0; i < cArray.length; i++) {
/* 467:531 */       if (((cArray[i] instanceof Checkbox)) && 
/* 468:532 */         (!((Checkbox)cArray[i]).getState())) {
/* 469:533 */         return false;
/* 470:    */       }
/* 471:    */     }
/* 472:538 */     return true;
/* 473:    */   }
/* 474:    */   
/* 475:    */   public static void main(String[] args)
/* 476:    */     throws Exception
/* 477:    */   {
/* 478:546 */     Frame frame = new Frame("Narrative");
/* 479:    */     
/* 480:548 */     frame.addWindowListener(new WindowAdapter()
/* 481:    */     {
/* 482:    */       public void windowClosing(WindowEvent arg0)
/* 483:    */       {
/* 484:552 */         Frame frame = (Frame)arg0.getSource();
/* 485:553 */         frame.dispose();
/* 486:    */       }
/* 487:555 */     });
/* 488:556 */     XDataSource ds = new XDataSource();
/* 489:557 */     ds.read(new FileReader("datasets.xml"));
/* 490:    */     
/* 491:559 */     XModel xm = XProjectManager.getModel();
/* 492:    */     
/* 493:561 */     XProjectManager.getCurrentProject().setAppFrame(frame);
/* 494:    */     
/* 495:563 */     Narrative narrative = new Narrative();
/* 496:564 */     narrative.setAutoscrolls(true);
/* 497:565 */     narrative.rootModel = xm;
/* 498:566 */     narrative.lang = args[0];
/* 499:    */     
/* 500:    */ 
/* 501:569 */     narrative.setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
/* 502:    */     
/* 503:    */ 
/* 504:    */ 
/* 505:573 */     frame.add(narrative);
/* 506:574 */     narrative.type = "adult";
/* 507:575 */     frame.setVisible(true);
/* 508:576 */     narrative.init();
/* 509:577 */     frame.setSize(1000, 600);
/* 510:578 */     frame.validate();
/* 511:    */   }
/* 512:    */   
/* 513:    */   public void keyPressed(KeyEvent arg0)
/* 514:    */   {
/* 515:582 */     System.out.println(arg0);
/* 516:583 */     if ((arg0.getKeyCode() == 27) || (arg0.getKeyCode() == 112))
/* 517:    */     {
/* 518:584 */       this.narrativeArea.setEditable(false);
/* 519:585 */       replace(this.narrativeArea);
/* 520:586 */       this.noteArea.setEditable(false);
/* 521:587 */       replace(this.noteArea);
/* 522:588 */       System.out.println("Escape pressed");
/* 523:    */     }
/* 524:    */     else
/* 525:    */     {
/* 526:601 */       System.out.println("Enter pressed");
/* 527:602 */       if (!this.narrativeArea.isEditable()) {
/* 528:603 */         this.narrativeArea.setEditable(true);
/* 529:    */       }
/* 530:605 */       if (!this.noteArea.isEditable()) {
/* 531:606 */         this.noteArea.setEditable(true);
/* 532:    */       }
/* 533:    */     }
/* 534:    */   }
/* 535:    */   
/* 536:    */   public void keyReleased(KeyEvent arg0) {}
/* 537:    */   
/* 538:    */   public void replace(JTextPane narrativeArea)
/* 539:    */   {
/* 540:619 */     String text = "";
/* 541:    */     try
/* 542:    */     {
/* 543:622 */       text = narrativeArea.getDocument().getText(0, 
/* 544:623 */         narrativeArea.getDocument().getLength());
/* 545:    */     }
/* 546:    */     catch (BadLocationException e)
/* 547:    */     {
/* 548:625 */       e.printStackTrace();
/* 549:    */     }
/* 550:627 */     System.out.println(text);
/* 551:628 */     String highlightText = "test";
/* 552:629 */     XModel keyM = (XModel)this.filterM.get("keywords");
/* 553:    */     
/* 554:    */ 
/* 555:    */ 
/* 556:    */ 
/* 557:    */ 
/* 558:    */ 
/* 559:    */ 
/* 560:    */ 
/* 561:    */ 
/* 562:    */ 
/* 563:    */ 
/* 564:    */ 
/* 565:    */ 
/* 566:643 */     System.out.println(" ----" + text + "---");
/* 567:645 */     for (int i = 0; i < keyM.getNumChildren(); i++)
/* 568:    */     {
/* 569:646 */       highlightText = keyM.get(i).getId();
/* 570:647 */       highlightText = TestXUIDB.getInstance().getTranslation(highlightText, this.lang);
/* 571:648 */       System.out.println(" HIlight " + highlightText);
/* 572:649 */       int guideline = Integer.parseInt(keyM.get(i).get("@guideline").toString());
/* 573:650 */       System.out.println(" Guideline " + guideline);
/* 574:651 */       if (text.toLowerCase().contains(highlightText))
/* 575:    */       {
/* 576:655 */         this.checkboxArray[guideline].setSelected(true);
/* 577:656 */         System.out.println("match found");
/* 578:657 */         text = text.replaceAll("(?i)" + highlightText, 
/* 579:658 */           "<a href=\"" + keyM.get(i).getAttribValue(2) + "\">" + 
/* 580:659 */           highlightText.toUpperCase() + "</a>");
/* 581:    */       }
/* 582:    */     }
/* 583:662 */     text = text.trim();
/* 584:663 */     text = text.replace("-", "<br/>-");
/* 585:664 */     text = text.replace("\n", "<br/>-");
/* 586:665 */     narrativeArea.setText(text);
/* 587:    */     
/* 588:667 */     addSymptoms(this.checkboxArray);
/* 589:    */   }
/* 590:    */   
/* 591:    */   public void clearSelection()
/* 592:    */   {
/* 593:671 */     Component[] cArray = this.checkboxArray;
/* 594:672 */     for (int i = 0; i < cArray.length; i++) {
/* 595:673 */       if (((cArray[i] instanceof Checkbox)) && 
/* 596:674 */         (cArray[i].getForeground().equals(new Color(176, 19, 58)))) {
/* 597:675 */         ((Checkbox)cArray[i]).setState(false);
/* 598:    */       }
/* 599:    */     }
/* 600:    */   }
/* 601:    */   
/* 602:    */   public void addSymptom(String symptom)
/* 603:    */   {
/* 604:711 */     System.out.println(" Symtom to add " + symptom);
/* 605:712 */     for (int j = 0; j < this.checkboxArray.length; j++)
/* 606:    */     {
/* 607:713 */       System.out.println(" Name " + j + " " + this.checkboxArray[j].getName());
/* 608:714 */       if (this.checkboxArray[j].getName().equals(symptom))
/* 609:    */       {
/* 610:716 */         this.checkboxArray[j].setSelected(true);
/* 611:    */         
/* 612:    */ 
/* 613:    */ 
/* 614:720 */         break;
/* 615:    */       }
/* 616:    */     }
/* 617:    */   }
/* 618:    */   
/* 619:    */   public void keyTyped(KeyEvent arg0) {}
/* 620:    */   
/* 621:    */   public void keyTyped1(KeyEvent arg0)
/* 622:    */   {
/* 623:730 */     String text = this.narrativeArea.getText();
/* 624:731 */     String highlightText = "test";
/* 625:733 */     if (text.contains(highlightText))
/* 626:    */     {
/* 627:734 */       System.out.println("Match found");
/* 628:735 */       Pattern p = Pattern.compile("<a href.+" + highlightText + "</a>");
/* 629:736 */       Pattern p1 = Pattern.compile(highlightText);
/* 630:737 */       Matcher m = p.matcher(text);
/* 631:738 */       text = m.replaceAll(highlightText);
/* 632:    */       
/* 633:740 */       Matcher m1 = p.matcher(text);
/* 634:741 */       System.out.println("Match:" + m1.matches());
/* 635:742 */       text = m1.replaceAll("<a href=\"" + highlightText + "\">" + 
/* 636:743 */         highlightText + "</a>");
/* 637:744 */       System.out.println(text);
/* 638:745 */       this.narrativeArea.setText(text);
/* 639:    */     }
/* 640:    */   }
/* 641:    */   
/* 642:    */   public void showGuidelines(XModel guidelineModel)
/* 643:    */   {
/* 644:750 */     this.guidelinesLabel.setText("");
/* 645:    */     
/* 646:752 */     System.out.println("Childern::" + guidelineModel.getNumChildren());
/* 647:753 */     StringBuffer strBuf = new StringBuffer();
/* 648:754 */     strBuf.append("<html><body>");
/* 649:755 */     strBuf.append("<h2>" + TestXUIDB.getInstance().getTranslation(guidelineModel.getId(), this.lang) + "</h2>");
/* 650:756 */     strBuf.append("<ul>");
/* 651:757 */     for (int i = 0; i < guidelineModel.getNumChildren(); i++)
/* 652:    */     {
/* 653:758 */       String q = guidelineModel.get(i).get("@question").toString();
/* 654:759 */       q = TestXUIDB.getInstance().getTranslation(q, this.lang);
/* 655:760 */       strBuf.append("<li>" + 
/* 656:761 */         q + 
/* 657:762 */         "</li>");
/* 658:    */     }
/* 659:764 */     strBuf.append("</ul></body></html>");
/* 660:765 */     this.guidelinesLabel.setText(strBuf.toString());
/* 661:    */   }
/* 662:    */   
/* 663:    */   public void hyperlinkUpdate(HyperlinkEvent arg0)
/* 664:    */   {
/* 665:773 */     XModel guidelineModel = this.filterM.get(Integer.parseInt(arg0
/* 666:774 */       .getDescription()));
/* 667:775 */     showGuidelines(guidelineModel);
/* 668:    */   }
/* 669:    */   
/* 670:    */   public void mouseClicked(MouseEvent arg0)
/* 671:    */   {
/* 672:781 */     arg0.consume();
/* 673:    */   }
/* 674:    */   
/* 675:    */   public void mouseEntered(MouseEvent arg0)
/* 676:    */   {
/* 677:785 */     System.out.println("Mouse entered");
/* 678:786 */     if ((arg0.getSource() instanceof JCheckBox))
/* 679:    */     {
/* 680:787 */       String symptom = ((JCheckBox)arg0.getSource()).getName();
/* 681:    */       try
/* 682:    */       {
/* 683:790 */         XModel guidelineModel = (XModel)this.filterM.get(symptom);
/* 684:791 */         showGuidelines(guidelineModel);
/* 685:    */       }
/* 686:    */       catch (Exception e)
/* 687:    */       {
/* 688:794 */         e.printStackTrace();
/* 689:    */       }
/* 690:    */     }
/* 691:    */   }
/* 692:    */   
/* 693:    */   public void mouseExited(MouseEvent arg0) {}
/* 694:    */   
/* 695:    */   public void mousePressed(MouseEvent arg0) {}
/* 696:    */   
/* 697:    */   public void mouseReleased(MouseEvent arg0) {}
/* 698:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.Narrative
 * JD-Core Version:    0.7.0.1
 */