/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Frame;
/*  5:   */ import java.awt.event.WindowAdapter;
/*  6:   */ import java.awt.event.WindowEvent;
/*  7:   */ 
/*  8:   */ public class PaintDemo
/*  9:   */ {
/* 10:   */   public static void main(String[] args)
/* 11:   */   {
/* 12:14 */     Frame f = new Frame("Have a nice day!");
/* 13:15 */     f.addWindowListener(new WindowAdapter()
/* 14:   */     {
/* 15:   */       public void windowClosing(WindowEvent e)
/* 16:   */       {
/* 17:17 */         System.exit(0);
/* 18:   */       }
/* 19:19 */     });
/* 20:20 */     f.add(new SmileyCanvas(Color.yellow), "Center");
/* 21:21 */     f.pack();
/* 22:22 */     f.show();
/* 23:   */   }
/* 24:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.PaintDemo
 * JD-Core Version:    0.7.0.1
 */