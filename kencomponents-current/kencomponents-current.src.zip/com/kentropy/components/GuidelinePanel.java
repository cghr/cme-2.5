/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.Font;
/*  4:   */ import java.io.PrintStream;
/*  5:   */ import javax.swing.JLabel;
/*  6:   */ import net.xoetrope.awt.XPanel;
/*  7:   */ 
/*  8:   */ public class GuidelinePanel
/*  9:   */   extends XPanel
/* 10:   */ {
/* 11:   */   public GuidelinePanel()
/* 12:   */   {
/* 13:15 */     this.guideLabel.setVerticalAlignment(1);
/* 14:16 */     add(this.guideLabel);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public GuidelinePanel(boolean arg0)
/* 18:   */   {
/* 19:20 */     super(arg0);
/* 20:   */   }
/* 21:   */   
/* 22:24 */   String guide = null;
/* 23:25 */   String g = null;
/* 24:26 */   JLabel guideLabel = new JLabel();
/* 25:   */   
/* 26:   */   public void addText(String guidelines, boolean stage)
/* 27:   */   {
/* 28:30 */     System.out.println("Mult info panel method called");
/* 29:31 */     System.out.println("Guideline::::" + guidelines);
/* 30:32 */     int w = getWidth() - 10;
/* 31:33 */     int h = getHeight() - 10;
/* 32:34 */     this.guideLabel.setBounds(getX() + 5, getY(), w, h);
/* 33:35 */     if ((this.guide != null) && (stage))
/* 34:   */     {
/* 35:36 */       this.guide = (this.g + "\n" + guidelines);
/* 36:37 */       System.out.println("Second guide***********" + this.guide);
/* 37:   */     }
/* 38:   */     else
/* 39:   */     {
/* 40:39 */       this.guide = guidelines;
/* 41:40 */       this.g = guidelines;
/* 42:41 */       System.out.println("First guide***********" + this.guide);
/* 43:   */     }
/* 44:43 */     this.guideLabel.setText("<html>" + this.guide + "</html>");
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setFont(Font font)
/* 48:   */   {
/* 49:48 */     this.guideLabel.setFont(font);
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void clearGuide()
/* 53:   */   {
/* 54:52 */     System.out.println("Entered clear guide");
/* 55:53 */     this.guideLabel.setText("");
/* 56:   */   }
/* 57:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.GuidelinePanel
 * JD-Core Version:    0.7.0.1
 */