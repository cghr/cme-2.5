/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import com.kentropy.transfer.Client;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.Font;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.ActionListener;
/*  10:    */ import java.awt.event.ComponentEvent;
/*  11:    */ import java.awt.event.ComponentListener;
/*  12:    */ import java.io.PrintStream;
/*  13:    */ import java.util.Vector;
/*  14:    */ import net.xoetrope.awt.XButton;
/*  15:    */ import net.xoetrope.awt.XLabel;
/*  16:    */ import net.xoetrope.awt.XPanel;
/*  17:    */ import net.xoetrope.awt.XTextArea;
/*  18:    */ import net.xoetrope.xui.data.XModel;
/*  19:    */ 
/*  20:    */ public class TransferPanel1
/*  21:    */   extends XPanel
/*  22:    */   implements ActionListener, ComponentListener
/*  23:    */ {
/*  24: 36 */   Thread th = null;
/*  25:    */   
/*  26:    */   public class Task
/*  27:    */     implements Runnable
/*  28:    */   {
/*  29:    */     public Task() {}
/*  30:    */     
/*  31:    */     public void upload()
/*  32:    */       throws Exception
/*  33:    */     {
/*  34: 45 */       int changes = TestXUIDB.getInstance().sendLogs(this.currentUser, this.recepients);
/*  35: 46 */       this.tfp.ta.append("\n" + changes + " changes uploaded");
/*  36:    */     }
/*  37:    */     
/*  38:    */     public void download()
/*  39:    */       throws Exception
/*  40:    */     {
/*  41: 56 */       Client cl = new Client();
/*  42: 57 */       cl.participant = this.currentUser;
/*  43: 58 */       cl.run();
/*  44: 59 */       for (int i = 0; i < cl.messages.size(); i++) {
/*  45: 61 */         this.tfp.ta.append("\n" + cl.messages.get(i));
/*  46:    */       }
/*  47:    */     }
/*  48:    */     
/*  49:    */     public void syncCode()
/*  50:    */       throws Exception
/*  51:    */     {
/*  52: 68 */       Client cl = new Client();
/*  53: 69 */       cl.participant = this.currentUser;
/*  54: 70 */       cl.runRepoSync();
/*  55: 71 */       for (int i = 0; i < cl.messages.size(); i++) {
/*  56: 73 */         this.tfp.ta.append("\n" + cl.messages.get(i));
/*  57:    */       }
/*  58:    */     }
/*  59:    */     
/*  60: 82 */     String task = "";
/*  61:    */     public String currentUser;
/*  62:    */     public String recepients;
/*  63:    */     
/*  64:    */     public void run()
/*  65:    */     {
/*  66: 85 */       String curAction = "";
/*  67:    */       try
/*  68:    */       {
/*  69: 87 */         TransferPanel1.this.si.setStatus("Code Sync", "NotStarted");
/*  70: 88 */         TransferPanel1.this.si.setStatus("Upload", "NotStarted");
/*  71: 89 */         TransferPanel1.this.si.setStatus("Download", "NotStarted");
/*  72: 90 */         this.tfp.ta.append("\nChecking connection to server");
/*  73:    */         
/*  74: 92 */         this.tfp.ta.append("\n-------------------");
/*  75: 93 */         this.tfp.ta.append("\nStarting Code Update... It might take some time.");
/*  76: 94 */         curAction = "Code Sync";
/*  77:    */         
/*  78: 96 */         this.tfp.si.setStatus("Code Sync", "Processing");
/*  79: 97 */         syncCode();
/*  80:    */         
/*  81: 99 */         this.tfp.si.setStatus("Code Sync", "Complete");
/*  82:100 */         this.tfp.ta.append("\nStarting Data Synchronization...");
/*  83:101 */         this.tfp.si.setStatus("Upload", "Processing");
/*  84:102 */         curAction = "Upload";
/*  85:103 */         this.tfp.ta.append("\n-------------------");
/*  86:104 */         this.tfp.ta.append("\nStarting Upload...");
/*  87:105 */         upload();
/*  88:106 */         this.tfp.si.setStatus("Upload", "Complete");
/*  89:107 */         this.tfp.ta.append("\nUpload Completed");
/*  90:108 */         this.tfp.si.setStatus("Download", "Processing");
/*  91:    */         
/*  92:    */ 
/*  93:    */ 
/*  94:112 */         this.tfp.ta.append("\n-------------------");
/*  95:113 */         this.tfp.ta.append("\nStarting Download... It might take some time.");
/*  96:114 */         curAction = "Download";
/*  97:115 */         download();
/*  98:    */         
/*  99:117 */         this.tfp.si.setStatus("Download", "Complete");
/* 100:    */         
/* 101:119 */         this.tfp.action.getActionListeners()[0].actionPerformed(new ActionEvent(this.tfp.action, 1, "download"));
/* 102:    */         
/* 103:121 */         this.tfp.ta.append("\nDownload Completed");
/* 104:122 */         this.tfp.ta.append("\nSynchronization Completed");
/* 105:    */       }
/* 106:    */       catch (Exception e)
/* 107:    */       {
/* 108:129 */         this.tfp.si.setStatus(curAction, "Failed");
/* 109:130 */         this.tfp.ta.append(e.toString());
/* 110:131 */         e.printStackTrace();
/* 111:132 */         this.tfp.action.getActionListeners()[0].actionPerformed(new ActionEvent(this.tfp.action, 1, "abort"));
/* 112:    */       }
/* 113:    */     }
/* 114:    */     
/* 115:138 */     public TransferPanel1 tfp = null;
/* 116:    */   }
/* 117:    */   
/* 118:142 */   public int columns = 1;
/* 119:143 */   public String heading = "Testing a long heading";
/* 120:144 */   private Color color = Color.blue;
/* 121:148 */   public XModel list = null;
/* 122:149 */   XLabel header = null;
/* 123:150 */   XLabel lbl = null;
/* 124:151 */   XTextArea ta = null;
/* 125:152 */   XButton close = null;
/* 126:153 */   public XButton action = new XButton();
/* 127:154 */   public StatusIndicator si = new StatusIndicator();
/* 128:    */   
/* 129:    */   public void display(String htext, String msg)
/* 130:    */   {
/* 131:166 */     setBounds(10, 50, getParent().getWidth() - 20, getParent().getHeight() - 20);
/* 132:167 */     setName("error");
/* 133:168 */     setBackground(new Color(50, 50, 255));
/* 134:    */     
/* 135:    */ 
/* 136:171 */     this.close = new XButton();
/* 137:172 */     this.close.setText("close");
/* 138:173 */     this.close.setForeground(Color.white);
/* 139:174 */     this.close.setBackground(Color.red);
/* 140:175 */     this.close.setBounds(259, 2, 40, 18);
/* 141:176 */     this.close.setFont(new Font("Verdana", 1, 12));
/* 142:    */     
/* 143:178 */     this.close.addActionListener(this);
/* 144:    */     
/* 145:    */ 
/* 146:    */ 
/* 147:182 */     this.action.setName("action");
/* 148:183 */     this.action.setText("");
/* 149:184 */     this.action.setForeground(Color.white);
/* 150:185 */     this.action.setBackground(Color.red);
/* 151:186 */     this.action.setBounds(20, 100, 40, 18);
/* 152:187 */     this.action.setFont(new Font("Verdana", 1, 12));
/* 153:    */     
/* 154:189 */     add(this.action);
/* 155:190 */     this.action.setVisible(false);
/* 156:    */     
/* 157:    */ 
/* 158:    */ 
/* 159:194 */     this.ta = new XTextArea();
/* 160:195 */     this.ta.setName("errorContainer");
/* 161:196 */     this.ta.setBackground(new Color(240, 240, 240));
/* 162:197 */     this.ta.setForeground(Color.black);
/* 163:198 */     this.ta.setBounds(3, 3, getWidth() - 6, getHeight() / 2 - 6);
/* 164:199 */     this.ta.setEditable(false);
/* 165:200 */     this.ta.setText(msg);
/* 166:    */     
/* 167:    */ 
/* 168:203 */     this.si.setBounds(3, getHeight() / 2, getWidth() - 6, getHeight() / 2 - 6);
/* 169:204 */     this.si.init();
/* 170:205 */     add(this.si);
/* 171:    */     
/* 172:207 */     this.header = new XLabel();
/* 173:208 */     this.header.setName("errorHeader");
/* 174:209 */     this.header.setBackground(new Color(50, 50, 255));
/* 175:210 */     this.header.setForeground(Color.WHITE);
/* 176:211 */     this.header.setBounds(1, 1, 230, 18);
/* 177:    */     
/* 178:213 */     this.header.setFont(new Font("Verdana", 1, 12));
/* 179:214 */     this.header.setText(htext);
/* 180:    */     
/* 181:    */ 
/* 182:217 */     add(this.ta);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void run()
/* 186:    */   {
/* 187:223 */     Task task = new Task();
/* 188:224 */     task.currentUser = this.currentUser;
/* 189:225 */     task.recepients = this.recepients;
/* 190:226 */     task.tfp = this;
/* 191:227 */     Thread th = new Thread(task);
/* 192:228 */     th.start();
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void setColor(Color color)
/* 196:    */   {
/* 197:237 */     this.color = color;
/* 198:    */   }
/* 199:    */   
/* 200:240 */   public String actionStr = null;
/* 201:241 */   public String currentUser = null;
/* 202:242 */   public String recepients = null;
/* 203:    */   
/* 204:    */   public TransferPanel1() {}
/* 205:    */   
/* 206:    */   public TransferPanel1(boolean arg0)
/* 207:    */   {
/* 208:252 */     super(arg0);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void actionPerformed(ActionEvent arg0)
/* 212:    */   {
/* 213:258 */     if (arg0.getActionCommand().equals("close")) {
/* 214:259 */       setVisible(false);
/* 215:    */     }
/* 216:    */   }
/* 217:    */   
/* 218:    */   public void componentHidden(ComponentEvent arg0) {}
/* 219:    */   
/* 220:    */   public void componentMoved(ComponentEvent arg0) {}
/* 221:    */   
/* 222:    */   public void componentResized(ComponentEvent arg0) {}
/* 223:    */   
/* 224:    */   public void componentShown(ComponentEvent arg0)
/* 225:    */   {
/* 226:281 */     System.out.println("Component Shown");
/* 227:    */   }
/* 228:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.TransferPanel1
 * JD-Core Version:    0.7.0.1
 */