/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Toolkit;
/*   5:    */ import java.awt.event.KeyEvent;
/*   6:    */ import java.awt.event.KeyListener;
/*   7:    */ import java.io.PrintStream;
/*   8:    */ import java.util.StringTokenizer;
/*   9:    */ import net.xoetrope.awt.XEdit;
/*  10:    */ import net.xoetrope.awt.XLabel;
/*  11:    */ import net.xoetrope.awt.XPanel;
/*  12:    */ import net.xoetrope.xui.XPageManager;
/*  13:    */ import net.xoetrope.xui.XProject;
/*  14:    */ import net.xoetrope.xui.XProjectManager;
/*  15:    */ 
/*  16:    */ public class TestComp
/*  17:    */   extends XPanel
/*  18:    */   implements KeyListener
/*  19:    */ {
/*  20:    */   public void keyPressed(KeyEvent arg0)
/*  21:    */   {
/*  22: 23 */     restrictDigits2(arg0);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void keyReleased(KeyEvent arg0) {}
/*  26:    */   
/*  27:    */   public String getValue()
/*  28:    */   {
/*  29: 34 */     System.out.println("Set called");
/*  30:    */     
/*  31: 36 */     String val = "";
/*  32: 37 */     System.out.println("Val is " + val);
/*  33:    */     
/*  34:    */ 
/*  35: 40 */     Component[] test = getComponents();
/*  36: 41 */     int count = 0;
/*  37: 42 */     for (int i = 0; i < test.length; i++) {
/*  38: 44 */       if ((test[i] instanceof XEdit))
/*  39:    */       {
/*  40: 47 */         System.out.println("comp called" + test[i].getName());
/*  41:    */         
/*  42:    */ 
/*  43: 50 */         val = val + (count == 0 ? "" : ":") + ((XEdit)test[i]).getText();
/*  44:    */         
/*  45: 52 */         count++;
/*  46:    */       }
/*  47:    */     }
/*  48: 56 */     return val;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setValue(String val)
/*  52:    */   {
/*  53: 68 */     System.out.println("Val is " + val);
/*  54: 69 */     StringTokenizer valTok = null;
/*  55: 70 */     if (val != null) {
/*  56: 71 */       valTok = new StringTokenizer(val, ":");
/*  57:    */     }
/*  58: 72 */     Component[] test = getComponents();
/*  59: 73 */     for (int i = 0; i < test.length; i++) {
/*  60: 75 */       if ((test[i] instanceof XEdit))
/*  61:    */       {
/*  62: 78 */         System.out.println("comp called" + test[i].getName());
/*  63: 79 */         if ((valTok != null) && (valTok.hasMoreTokens())) {
/*  64: 81 */           ((XEdit)test[i]).setText(valTok.nextToken());
/*  65:    */         } else {
/*  66: 84 */           ((XEdit)test[i]).setText("00");
/*  67:    */         }
/*  68:    */       }
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void restrictDigits2(KeyEvent evt)
/*  73:    */   {
/*  74: 91 */     System.out.println("restrict digits2");
/*  75: 92 */     String digitsToRestrictStr = "2";
/*  76: 93 */     if (evt.getID() == 401)
/*  77:    */     {
/*  78: 95 */       Component source1 = (Component)evt.getSource();
/*  79: 96 */       if ((source1 instanceof KenEdit))
/*  80:    */       {
/*  81: 97 */         KenEdit source = (KenEdit)source1;
/*  82: 98 */         digitsToRestrictStr = source.restrictDigit;
/*  83: 99 */         if (source.getText() != null) {
/*  84:100 */           switch (evt.getKeyCode())
/*  85:    */           {
/*  86:    */           case 8: 
/*  87:    */           case 9: 
/*  88:    */           case 37: 
/*  89:    */           case 39: 
/*  90:    */           case 127: 
/*  91:    */             break;
/*  92:    */           default: 
/*  93:108 */             int level = 0;
/*  94:110 */             if (digitsToRestrictStr != null) {
/*  95:    */               try
/*  96:    */               {
/*  97:112 */                 int digitsToRestrict = 
/*  98:113 */                   Integer.parseInt(digitsToRestrictStr);
/*  99:115 */                 if (source.getSelectedText().length() == digitsToRestrict) {
/* 100:116 */                   source.setText("");
/* 101:    */                 }
/* 102:118 */                 if (source.getText().length() >= digitsToRestrict)
/* 103:    */                 {
/* 104:119 */                   evt.consume();
/* 105:120 */                   Toolkit.getDefaultToolkit().beep();
/* 106:    */                 }
/* 107:    */               }
/* 108:    */               catch (Exception e)
/* 109:    */               {
/* 110:124 */                 e.printStackTrace();
/* 111:    */               }
/* 112:    */             }
/* 113:    */             break;
/* 114:    */           }
/* 115:    */         }
/* 116:    */       }
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:141 */   String fields = "";
/* 121:142 */   String labels = "";
/* 122:    */   
/* 123:    */   public void keyTyped(KeyEvent arg0) {}
/* 124:    */   
/* 125:    */   public TestComp() {}
/* 126:    */   
/* 127:    */   public void setAttribute(String arg0, Object arg1)
/* 128:    */   {
/* 129:154 */     System.out.println("Set attribute called");
/* 130:155 */     if (arg0.equals("fields"))
/* 131:    */     {
/* 132:157 */       this.fields = ((String)arg1);
/* 133:158 */       System.out.println("fields " + arg1);
/* 134:159 */       StringTokenizer st = new StringTokenizer(this.fields, ",");
/* 135:160 */       int count = 0;
/* 136:161 */       while (st.hasMoreTokens())
/* 137:    */       {
/* 138:163 */         String fld = st.nextToken();
/* 139:164 */         StringTokenizer st1 = new StringTokenizer(fld, ":");
/* 140:165 */         String lbl1 = st1.nextToken();
/* 141:166 */         XLabel lbl = new XLabel();
/* 142:167 */         lbl.setBounds(10 + count * 55, 2, 50, 20);
/* 143:    */         
/* 144:169 */         lbl.setText(lbl1);
/* 145:170 */         add(lbl);
/* 146:171 */         String fld1 = st1.nextToken();
/* 147:172 */         KenEdit ed = new KenEdit();
/* 148:173 */         ed.addKeyListener(this);
/* 149:174 */         ed.setAttribute("restrictDigit", "2");
/* 150:    */         
/* 151:    */ 
/* 152:177 */         ed.setBounds(10 + count * 55, 22, 30, 20);
/* 153:178 */         ed.setName(fld1);
/* 154:179 */         ed.restrictDigit = st1.nextToken();
/* 155:180 */         add(ed);
/* 156:181 */         XPageManager pm = XProjectManager.getCurrentProject().getPageManager();
/* 157:182 */         System.out.println("Targets=" + pm.getNumTargets() + " " + pm.getTarget(0));
/* 158:    */         
/* 159:    */ 
/* 160:185 */         System.out.println("Adding " + ed.getName());
/* 161:186 */         count++;
/* 162:    */       }
/* 163:    */     }
/* 164:    */     else
/* 165:    */     {
/* 166:207 */       super.setAttribute(arg0, arg1);
/* 167:    */     }
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void doLayout()
/* 171:    */   {
/* 172:217 */     super.doLayout();
/* 173:    */   }
/* 174:    */   
/* 175:    */   public TestComp(boolean arg0)
/* 176:    */   {
/* 177:221 */     super(arg0);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setup() {}
/* 181:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.TestComp
 * JD-Core Version:    0.7.0.1
 */