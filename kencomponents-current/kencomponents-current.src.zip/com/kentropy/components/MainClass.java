/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import java.awt.Container;
/*  5:   */ import javax.swing.Action;
/*  6:   */ import javax.swing.JFrame;
/*  7:   */ import javax.swing.JMenu;
/*  8:   */ import javax.swing.JMenuBar;
/*  9:   */ import javax.swing.JPanel;
/* 10:   */ import javax.swing.JScrollPane;
/* 11:   */ import javax.swing.JTextPane;
/* 12:   */ 
/* 13:   */ public class MainClass
/* 14:   */ {
/* 15:   */   public MainClass()
/* 16:   */   {
/* 17:35 */     JFrame frame = new JFrame();
/* 18:36 */     JTextPane textPane = new JTextPane();
/* 19:37 */     JScrollPane scrollPane = new JScrollPane(textPane);
/* 20:   */     
/* 21:39 */     JPanel north = new JPanel();
/* 22:   */     
/* 23:41 */     JMenuBar menu = new JMenuBar();
/* 24:42 */     JMenu styleMenu = new JMenu();
/* 25:43 */     styleMenu.setText("Style");
/* 26:   */     
/* 27:45 */     Action boldAction = new BoldAction();
/* 28:46 */     boldAction.putValue("Name", "Bold");
/* 29:47 */     styleMenu.add(boldAction);
/* 30:   */     
/* 31:49 */     Action italicAction = new ItalicAction();
/* 32:50 */     italicAction.putValue("Name", "Italic");
/* 33:51 */     styleMenu.add(italicAction);
/* 34:   */     
/* 35:53 */     Action foregroundAction = new ForegroundAction();
/* 36:54 */     foregroundAction.putValue("Name", "Color");
/* 37:55 */     styleMenu.add(foregroundAction);
/* 38:   */     
/* 39:57 */     Action formatTextAction = new FontAndSizeAction();
/* 40:58 */     formatTextAction.putValue("Name", "Font and Size");
/* 41:59 */     styleMenu.add(formatTextAction);
/* 42:   */     
/* 43:61 */     menu.add(styleMenu);
/* 44:   */     
/* 45:63 */     north.add(menu);
/* 46:64 */     frame.getContentPane().setLayout(new BorderLayout());
/* 47:65 */     frame.getContentPane().add(north, "North");
/* 48:66 */     frame.getContentPane().add(scrollPane, "Center");
/* 49:67 */     frame.setSize(800, 500);
/* 50:68 */     frame.setDefaultCloseOperation(3);
/* 51:69 */     frame.setVisible(true);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static void main(String[] args)
/* 55:   */   {
/* 56:73 */     new MainClass();
/* 57:   */   }
/* 58:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.MainClass
 * JD-Core Version:    0.7.0.1
 */