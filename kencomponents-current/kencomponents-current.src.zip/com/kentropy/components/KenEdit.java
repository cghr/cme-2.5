/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.event.KeyEvent;
/*  4:   */ import java.awt.event.KeyListener;
/*  5:   */ import net.xoetrope.awt.XEdit;
/*  6:   */ import net.xoetrope.xui.XAttributedComponent;
/*  7:   */ 
/*  8:   */ public class KenEdit
/*  9:   */   extends XEdit
/* 10:   */   implements XAttributedComponent, KeyListener
/* 11:   */ {
/* 12:33 */   String restrictDigit = "";
/* 13:   */   
/* 14:   */   public void keyPressed(KeyEvent arg0) {}
/* 15:   */   
/* 16:   */   public void keyReleased(KeyEvent arg0) {}
/* 17:   */   
/* 18:   */   public void keyTyped(KeyEvent arg0) {}
/* 19:   */   
/* 20:   */   public void setAttribute(String arg0, Object arg1)
/* 21:   */   {
/* 22:36 */     if (arg0.equals("restrictDigit")) {
/* 23:38 */       this.restrictDigit = ((String)arg1);
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Object getAttribute(String arg0)
/* 28:   */   {
/* 29:46 */     if (arg0.equals("restrictDigit")) {
/* 30:48 */       return this.restrictDigit;
/* 31:   */     }
/* 32:51 */     return "";
/* 33:   */   }
/* 34:   */   
/* 35:   */   public static void main(String[] args) {}
/* 36:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.KenEdit
 * JD-Core Version:    0.7.0.1
 */