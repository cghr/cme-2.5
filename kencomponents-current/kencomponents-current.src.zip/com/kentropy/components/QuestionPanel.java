/*    1:     */ package com.kentropy.components;
/*    2:     */ 
/*    3:     */ import com.kentropy.db.TestXUIDB;
/*    4:     */ import com.kentropy.flow.Age;
/*    5:     */ import com.kentropy.flow.QuestionFlowManager;
/*    6:     */ import com.kentropy.gps.GPStest;
/*    7:     */ import com.kentropy.iterators.Iterator;
/*    8:     */ import com.theotherbell.ui.DateField;
/*    9:     */ import java.awt.Component;
/*   10:     */ import java.awt.Container;
/*   11:     */ import java.awt.Dimension;
/*   12:     */ import java.awt.Point;
/*   13:     */ import java.awt.Rectangle;
/*   14:     */ import java.awt.event.ActionEvent;
/*   15:     */ import java.awt.event.ActionListener;
/*   16:     */ import java.awt.event.FocusEvent;
/*   17:     */ import java.awt.event.FocusListener;
/*   18:     */ import java.awt.event.ItemEvent;
/*   19:     */ import java.awt.event.ItemListener;
/*   20:     */ import java.awt.event.KeyEvent;
/*   21:     */ import java.awt.event.KeyListener;
/*   22:     */ import java.awt.event.MouseEvent;
/*   23:     */ import java.awt.event.MouseListener;
/*   24:     */ import java.awt.event.WindowAdapter;
/*   25:     */ import java.awt.event.WindowEvent;
/*   26:     */ import java.io.PrintStream;
/*   27:     */ import java.text.ParseException;
/*   28:     */ import java.text.SimpleDateFormat;
/*   29:     */ import java.util.Date;
/*   30:     */ import javax.swing.JFrame;
/*   31:     */ import net.xoetrope.awt.XButton;
/*   32:     */ import net.xoetrope.awt.XComboBox;
/*   33:     */ import net.xoetrope.awt.XEdit;
/*   34:     */ import net.xoetrope.awt.XLabel;
/*   35:     */ import net.xoetrope.awt.XMessageBox;
/*   36:     */ import net.xoetrope.awt.XPanel;
/*   37:     */ import net.xoetrope.awt.XTable;
/*   38:     */ import net.xoetrope.awt.XTextArea;
/*   39:     */ import net.xoetrope.xui.PageSupport;
/*   40:     */ import net.xoetrope.xui.XPageManager;
/*   41:     */ import net.xoetrope.xui.XProjectManager;
/*   42:     */ import net.xoetrope.xui.XTextHolder;
/*   43:     */ import net.xoetrope.xui.data.XBaseModel;
/*   44:     */ import net.xoetrope.xui.data.XListBinding;
/*   45:     */ import net.xoetrope.xui.data.XModel;
/*   46:     */ 
/*   47:     */ public class QuestionPanel
/*   48:     */   extends XPanel
/*   49:     */   implements ItemListener, KeyListener, MouseListener, ActionListener, FocusListener
/*   50:     */ {
/*   51:  54 */   XTable view = null;
/*   52:  55 */   XModel viewModel = null;
/*   53:  56 */   XModel rootModel = null;
/*   54:  57 */   String currentContextType = "";
/*   55:  59 */   public Component[] gpsComps = new Component[2];
/*   56:  61 */   String qtype = "";
/*   57:  62 */   String label = "";
/*   58:  63 */   String test = "";
/*   59:  64 */   StringBuffer value = new StringBuffer();
/*   60:  65 */   XBaseModel dataM = new XBaseModel();
/*   61:  66 */   XModel xm = new XBaseModel();
/*   62:  67 */   XModel qModel = null;
/*   63:  68 */   Component comp = null;
/*   64:  69 */   String selected = "";
/*   65:  71 */   public XModel context = null;
/*   66:  72 */   public XModel selectedContext = null;
/*   67:  74 */   public Object[] viewElements = new Object[3];
/*   68:     */   
/*   69:     */   public boolean checkNumeric(String value1)
/*   70:     */   {
/*   71:  78 */     for (int i = 0; i < value1.length(); i++)
/*   72:     */     {
/*   73:  80 */       String val = value1.substring(i, i + 1);
/*   74:     */       try
/*   75:     */       {
/*   76:  82 */         Integer.parseInt(val);
/*   77:     */       }
/*   78:     */       catch (Exception e)
/*   79:     */       {
/*   80:  86 */         e.printStackTrace();
/*   81:  87 */         return false;
/*   82:     */       }
/*   83:     */     }
/*   84:  92 */     return true;
/*   85:     */   }
/*   86:     */   
/*   87:     */   public boolean checkDate(String value1)
/*   88:     */   {
/*   89: 100 */     String format = this.qModel.get("@format") != null ? this.qModel.get("@format").toString() : "dd/MM/yyyy";
/*   90: 101 */     SimpleDateFormat sdf = new SimpleDateFormat(format);
/*   91:     */     try
/*   92:     */     {
/*   93: 103 */       sdf.setLenient(false);
/*   94:     */       
/*   95: 105 */       sdf.parse(this.value.toString());
/*   96:     */     }
/*   97:     */     catch (ParseException e)
/*   98:     */     {
/*   99: 108 */       e.printStackTrace();
/*  100: 109 */       return false;
/*  101:     */     }
/*  102: 116 */     return true;
/*  103:     */   }
/*  104:     */   
/*  105:     */   public void focusGained(FocusEvent e) {}
/*  106:     */   
/*  107:     */   public void focusLost(FocusEvent e)
/*  108:     */   {
/*  109: 125 */     System.out.println("Focus " + e.getSource() + " ");
/*  110:     */   }
/*  111:     */   
/*  112:     */   public void addValue(Object comp)
/*  113:     */   {
/*  114: 130 */     String tmpValue = "";
/*  115: 131 */     if ((comp instanceof XComboBox)) {
/*  116: 133 */       tmpValue = ((XComboBox)comp).getSelectedItem();
/*  117:     */     }
/*  118: 135 */     if ((comp instanceof XEdit))
/*  119:     */     {
/*  120: 137 */       tmpValue = ((XEdit)comp).getText();
/*  121: 138 */       System.out.println("Comp " + ((Component)comp).getName() + " " + tmpValue);
/*  122:     */     }
/*  123: 140 */     if ((comp instanceof XTextArea)) {
/*  124: 142 */       tmpValue = ((XTextArea)comp).getText();
/*  125:     */     }
/*  126: 144 */     if ((comp instanceof DateField)) {
/*  127: 146 */       tmpValue = ((DateField)comp).getDate().toString();
/*  128:     */     }
/*  129: 148 */     if (!tmpValue.equals(""))
/*  130:     */     {
/*  131: 150 */       System.out.println(this.value + " " + tmpValue);
/*  132: 151 */       this.value.append((this.value.toString().equals("") ? "" : ",") + tmpValue);
/*  133:     */     }
/*  134:     */   }
/*  135:     */   
/*  136:     */   public boolean rangeCheck()
/*  137:     */   {
/*  138: 157 */     String range = this.qModel.get("@range").toString();
/*  139: 158 */     String[] range1 = range.split("-");
/*  140: 160 */     if (this.qModel.get("@type").equals("age"))
/*  141:     */     {
/*  142: 162 */       if (this.value.toString().split(",").length < 2) {
/*  143: 164 */         return false;
/*  144:     */       }
/*  145: 166 */       Age val = new Age(this.value.toString());
/*  146:     */       
/*  147: 168 */       return (val.compareTo(range1[0]) >= 0) && (val.compareTo(range1[1]) <= 0);
/*  148:     */     }
/*  149: 172 */     if ((this.qModel.get("@inputtype") != null) && (this.qModel.get("@inputtype").equals("numeric")))
/*  150:     */     {
/*  151: 174 */       int lower = Integer.parseInt(range1[0]);
/*  152: 175 */       int upper = Integer.parseInt(range1[1]);
/*  153: 176 */       int val1 = Integer.parseInt(this.value.toString());
/*  154:     */       
/*  155: 178 */       return (val1 >= lower) && (val1 <= upper);
/*  156:     */     }
/*  157: 180 */     if ((this.qModel.get("@inputtype") != null) && (this.qModel.get("@inputtype").equals("date"))) {
/*  158:     */       try
/*  159:     */       {
/*  160: 183 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
/*  161: 184 */         String format = (String)this.qModel.get("@format");
/*  162: 185 */         format = format == null ? "dd/MM/yyyy" : format;
/*  163: 186 */         SimpleDateFormat sdf1 = new SimpleDateFormat(format);
/*  164:     */         
/*  165: 188 */         Date lower = sdf.parse(range1[0].equals("Now") ? sdf.format(new Date()) : range1[0]);
/*  166: 189 */         Date upper = sdf.parse(range1[1].equals("Now") ? sdf.format(new Date()) : range1[1]);
/*  167: 190 */         Date val1 = sdf1.parse(this.value.toString());
/*  168:     */         
/*  169: 192 */         return (val1.compareTo(lower) >= 0) && (val1.compareTo(upper) <= 0);
/*  170:     */       }
/*  171:     */       catch (Exception e)
/*  172:     */       {
/*  173: 196 */         e.printStackTrace();
/*  174: 197 */         return true;
/*  175:     */       }
/*  176:     */     }
/*  177: 201 */     return (this.value.toString().compareTo(range1[0]) > 0) && (this.value.toString().compareTo(range1[1]) < 0);
/*  178:     */   }
/*  179:     */   
/*  180:     */   public String rangeToStr(String range, String type)
/*  181:     */   {
/*  182:     */     try
/*  183:     */     {
/*  184: 208 */       if ((type != null) && (type.equals("date")))
/*  185:     */       {
/*  186: 210 */         String[] range1 = range.split("-");
/*  187: 211 */         SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
/*  188: 212 */         String format = (String)this.qModel.get("@format");
/*  189: 213 */         format = format == null ? "dd/MM/yyyy" : format;
/*  190: 214 */         SimpleDateFormat sdf1 = new SimpleDateFormat(format);
/*  191:     */         
/*  192: 216 */         Date lower = sdf.parse(range1[0].equals("Now") ? sdf.format(new Date()) : range1[0]);
/*  193: 217 */         Date upper = sdf.parse(range1[1].equals("Now") ? sdf.format(new Date()) : range1[1]);
/*  194:     */         
/*  195: 219 */         return sdf1.format(lower) + "-" + sdf1.format(upper);
/*  196:     */       }
/*  197: 222 */       return range;
/*  198:     */     }
/*  199:     */     catch (Exception e)
/*  200:     */     {
/*  201: 227 */       e.printStackTrace();
/*  202:     */     }
/*  203: 229 */     return range;
/*  204:     */   }
/*  205:     */   
/*  206:     */   public void saveValues()
/*  207:     */   {
/*  208: 233 */     this.value = new StringBuffer();
/*  209: 234 */     for (int i = 0; i < getComponentCount(); i++) {
/*  210: 236 */       addValue(getComponent(i));
/*  211:     */     }
/*  212: 238 */     XModel dataModel = (XModel)((QuestionFlowPanel)getParent()).qfm.dataModel.get(this.qModel.get("@qno").toString());
/*  213: 239 */     dataModel.set(this.value.toString());
/*  214:     */   }
/*  215:     */   
/*  216:     */   public void actionPerformed(ActionEvent e)
/*  217:     */   {
/*  218: 244 */     System.out.println(" Actuon " + e.getSource() + " " + e.getActionCommand());
/*  219: 245 */     if (e.getActionCommand().equals("GetGPS")) {
/*  220: 247 */       getGpsCoordinates1();
/*  221:     */     }
/*  222: 250 */     if (e.getActionCommand().equals("Refresh")) {
/*  223: 252 */       if (this.qModel.get("@type").equals("view")) {
/*  224:     */         try
/*  225:     */         {
/*  226: 256 */           readViewModel();
/*  227:     */         }
/*  228:     */         catch (Exception e1)
/*  229:     */         {
/*  230: 259 */           e1.printStackTrace();
/*  231:     */         }
/*  232:     */       }
/*  233:     */     }
/*  234: 266 */     if (e.getActionCommand().equals("Next"))
/*  235:     */     {
/*  236: 268 */       saveValues();
/*  237: 269 */       if (this.qModel.get("@range") != null) {
/*  238: 271 */         if (!rangeCheck())
/*  239:     */         {
/*  240: 273 */           displayError("Value out of range (" + rangeToStr(this.qModel.get("@range").toString(), this.qModel.get("@inputtype").toString()) + ")");
/*  241: 274 */           return;
/*  242:     */         }
/*  243:     */       }
/*  244: 280 */       if (this.qModel.get("@regex") != null) {
/*  245: 282 */         if (!this.value.toString().matches(this.qModel.get("@regex").toString()))
/*  246:     */         {
/*  247: 285 */           displayError("Value not in correct format (" + this.qModel.get("@formatstr") + ")");
/*  248: 286 */           return;
/*  249:     */         }
/*  250:     */       }
/*  251: 292 */       if (this.qModel.get("@minchars") != null)
/*  252:     */       {
/*  253: 294 */         int minchars = Integer.parseInt(this.qModel.get("@minchars").toString());
/*  254: 295 */         if (minchars > this.value.length())
/*  255:     */         {
/*  256: 297 */           displayError("Please enter at least " + minchars + " characters ");
/*  257: 298 */           return;
/*  258:     */         }
/*  259:     */       }
/*  260: 301 */       if (this.qModel.get("@inputtype") != null)
/*  261:     */       {
/*  262: 303 */         String inputtype = this.qModel.get("@inputtype").toString();
/*  263: 304 */         if (inputtype.equals("numeric")) {
/*  264: 306 */           if (!checkNumeric(this.value.toString()))
/*  265:     */           {
/*  266: 308 */             displayError("Please enter only numbers ");
/*  267: 309 */             return;
/*  268:     */           }
/*  269:     */         }
/*  270: 312 */         if (inputtype.equals("date")) {
/*  271: 314 */           if (!checkDate(this.value.toString()))
/*  272:     */           {
/*  273: 316 */             String format = this.qModel.get("@format") == null ? "dd/MM/yyyy" : this.qModel.get("@format").toString();
/*  274: 317 */             displayError("Please enter valid date value  (" + format + ")");
/*  275: 318 */             return;
/*  276:     */           }
/*  277:     */         }
/*  278:     */       }
/*  279: 323 */       if (this.qModel.get("@maxtext") != null)
/*  280:     */       {
/*  281: 325 */         String max = "";
/*  282: 326 */         if (this.qModel.get("@maxno") != null) {
/*  283: 328 */           max = this.qModel.get("@maxno").toString();
/*  284:     */         } else {
/*  285: 332 */           max = ((XTextHolder)((Object[])this.viewElements[1])[1]).getText();
/*  286:     */         }
/*  287: 335 */         if ((this.view.getModel() != null) && (Integer.parseInt(max) > this.view.getModel().getNumChildren() - 1))
/*  288:     */         {
/*  289: 337 */           displayError("You have not added all the rows");
/*  290: 338 */           return;
/*  291:     */         }
/*  292:     */       }
/*  293: 343 */       save();
/*  294:     */       
/*  295: 345 */       ((QuestionFlowPanel)getParent()).actionPerformed(e);
/*  296:     */     }
/*  297: 350 */     if (e.getActionCommand().equals("Add"))
/*  298:     */     {
/*  299:     */       try
/*  300:     */       {
/*  301: 354 */         if (this.qModel.get("@maxtext") != null)
/*  302:     */         {
/*  303: 356 */           String max = "";
/*  304: 357 */           if (this.qModel.get("@maxno") != null) {
/*  305: 359 */             max = this.qModel.get("@maxno").toString();
/*  306:     */           } else {
/*  307: 363 */             max = ((XTextHolder)((Object[])this.viewElements[1])[1]).getText();
/*  308:     */           }
/*  309: 366 */           if ((this.view.getModel() != null) && (Integer.parseInt(max) == this.view.getModel().getNumChildren() - 1))
/*  310:     */           {
/*  311: 368 */             displayError("MAX Rows reached");
/*  312: 369 */             return;
/*  313:     */           }
/*  314:     */         }
/*  315: 373 */         saveValues();
/*  316:     */         
/*  317: 375 */         String subflow = this.qModel.get("@subflow").toString();
/*  318: 376 */         XModel flowM = (XModel)this.rootModel.get("flows/" + subflow);
/*  319: 377 */         String contextType = flowM.get("@context").toString();
/*  320: 378 */         String id = TestXUIDB.getInstance().getMaxId(this.context, contextType);
/*  321: 379 */         System.out.println(" next context " + contextType + " " + id);
/*  322: 380 */         this.selectedContext = new XBaseModel();
/*  323: 381 */         this.selectedContext.setId(contextType);
/*  324: 382 */         this.selectedContext.set(id);
/*  325: 383 */         ((QuestionFlowPanel)getParent()).actionPerformed(e);
/*  326:     */       }
/*  327:     */       catch (Exception e1)
/*  328:     */       {
/*  329: 386 */         e1.printStackTrace();
/*  330:     */       }
/*  331:     */     }
/*  332: 390 */     else if (e.getActionCommand().equals("Edit"))
/*  333:     */     {
/*  334: 392 */       saveValues();
/*  335: 393 */       int row = this.view.getSelectedRow();
/*  336: 394 */       String id = this.view.getModel().get(row + 1).getId();
/*  337: 395 */       System.out.println("id =" + id + " row=" + row);
/*  338:     */       try
/*  339:     */       {
/*  340: 398 */         String subflow = this.qModel.get("@subflow").toString();
/*  341: 399 */         XModel flowM = (XModel)this.rootModel.get("flows/" + subflow);
/*  342: 400 */         String contextType = flowM.get("@context").toString();
/*  343:     */         
/*  344: 402 */         this.selectedContext = new XBaseModel();
/*  345: 403 */         this.selectedContext.setId(contextType);
/*  346: 404 */         this.selectedContext.set(id);
/*  347: 405 */         ((QuestionFlowPanel)getParent()).actionPerformed(e);
/*  348:     */       }
/*  349:     */       catch (Exception e1)
/*  350:     */       {
/*  351: 408 */         e1.printStackTrace();
/*  352:     */       }
/*  353:     */     }
/*  354:     */   }
/*  355:     */   
/*  356:     */   public void mouseClicked(MouseEvent e)
/*  357:     */   {
/*  358: 415 */     System.out.println(e.getSource());
/*  359:     */   }
/*  360:     */   
/*  361:     */   public void mouseEntered(MouseEvent e) {}
/*  362:     */   
/*  363:     */   public void mouseExited(MouseEvent e) {}
/*  364:     */   
/*  365:     */   public void mousePressed(MouseEvent e) {}
/*  366:     */   
/*  367:     */   public void mouseReleased(MouseEvent e) {}
/*  368:     */   
/*  369:     */   public void save()
/*  370:     */   {
/*  371: 436 */     String fieldStr = (String)this.qModel.get("@fields");
/*  372: 437 */     System.out.println(" Fields =" + fieldStr + " " + this.value);
/*  373: 438 */     if (fieldStr == null) {
/*  374: 439 */       return;
/*  375:     */     }
/*  376: 440 */     String[] fields = fieldStr.split(",");
/*  377: 441 */     String[] values = this.value.toString().split(",");
/*  378: 442 */     for (int i = 0; (i < fields.length) && (fields.length == values.length); i++)
/*  379:     */     {
/*  380: 444 */       ((XModel)this.dataM.get(fields[i])).set(values[i]);
/*  381: 445 */       System.out.println(fields[i] + " " + values[i]);
/*  382:     */     }
/*  383:     */     try
/*  384:     */     {
/*  385: 449 */       TestXUIDB.getInstance().saveEnumData(this.context, this.currentContextType, this.dataM);
/*  386:     */     }
/*  387:     */     catch (Exception e)
/*  388:     */     {
/*  389: 452 */       e.printStackTrace();
/*  390:     */     }
/*  391:     */   }
/*  392:     */   
/*  393:     */   public void getGpsCoordinates1()
/*  394:     */   {
/*  395:     */     try
/*  396:     */     {
/*  397: 460 */       String[] gps = GPStest.getGPS("127.0.0.1");
/*  398:     */       
/*  399: 462 */       ((XEdit)this.gpsComps[0]).setText(gps[0]);
/*  400: 463 */       ((XEdit)this.gpsComps[1]).setText(gps[1]);
/*  401:     */     }
/*  402:     */     catch (Exception e)
/*  403:     */     {
/*  404: 467 */       displayError("GPS is not fixed, do you want to continue without GPS?");
/*  405: 468 */       e.printStackTrace();
/*  406:     */     }
/*  407:     */   }
/*  408:     */   
/*  409:     */   public void read()
/*  410:     */   {
/*  411: 474 */     String fieldStr = (String)this.qModel.get("@fields");
/*  412: 475 */     System.out.println(" Fields =" + fieldStr + " " + this.value);
/*  413: 476 */     if (fieldStr == null) {
/*  414: 477 */       return;
/*  415:     */     }
/*  416:     */     try
/*  417:     */     {
/*  418: 482 */       XModel dataM = TestXUIDB.getInstance().getEnumData(this.context, this.currentContextType, fieldStr);
/*  419: 483 */       System.out.println("No of values read" + dataM.getNumChildren());
/*  420: 484 */       if (dataM.getNumChildren() > 0)
/*  421:     */       {
/*  422: 485 */         int index = 0;
/*  423: 486 */         System.out.println("No of fields read" + dataM.get(0).getNumChildren());
/*  424: 487 */         for (int i = 0; i < dataM.get(0).getNumChildren(); i++)
/*  425:     */         {
/*  426: 489 */           String value1 = dataM.get(0).get(i).get().toString();
/*  427: 490 */           System.out.println("Value " + value1);
/*  428: 491 */           index = setNextValue(index + 1, value1);
/*  429:     */         }
/*  430:     */       }
/*  431:     */     }
/*  432:     */     catch (Exception e)
/*  433:     */     {
/*  434: 496 */       e.printStackTrace();
/*  435:     */     }
/*  436:     */   }
/*  437:     */   
/*  438:     */   public int setNextValue(int index, String value)
/*  439:     */   {
/*  440: 502 */     Component[] comps = getComponents();
/*  441: 504 */     for (int i = index; i < comps.length; i++)
/*  442:     */     {
/*  443: 506 */       boolean flg = setValue(comps[i], value);
/*  444: 507 */       if (flg) {
/*  445: 508 */         return i;
/*  446:     */       }
/*  447:     */     }
/*  448: 511 */     return index;
/*  449:     */   }
/*  450:     */   
/*  451:     */   public boolean setValue(Object comp, String value)
/*  452:     */   {
/*  453: 516 */     boolean set = false;
/*  454: 518 */     if ((comp instanceof XComboBox))
/*  455:     */     {
/*  456: 520 */       ((XComboBox)comp).select(value);
/*  457: 521 */       set = true;
/*  458:     */     }
/*  459: 523 */     if ((comp instanceof XEdit))
/*  460:     */     {
/*  461: 525 */       ((XEdit)comp).setText(value);
/*  462: 526 */       set = true;
/*  463:     */     }
/*  464: 528 */     if ((comp instanceof XTextArea))
/*  465:     */     {
/*  466: 530 */       ((XTextArea)comp).setText(value);
/*  467: 531 */       set = true;
/*  468:     */     }
/*  469: 534 */     return set;
/*  470:     */   }
/*  471:     */   
/*  472:     */   public QuestionPanel() {}
/*  473:     */   
/*  474:     */   public QuestionPanel(boolean arg0)
/*  475:     */   {
/*  476: 543 */     super(arg0);
/*  477:     */   }
/*  478:     */   
/*  479:     */   public void createQuestion() {}
/*  480:     */   
/*  481:     */   public void setQuestionModel(XModel xm)
/*  482:     */   {
/*  483: 552 */     this.qModel = xm;
/*  484: 553 */     String formatStr = (String)xm.get("@formatstr");
/*  485: 554 */     formatStr = formatStr != null ? "(" + formatStr + ")" : "";
/*  486: 555 */     String label = ((XModel)xm.get("text")).get().toString() + " " + formatStr;
/*  487: 556 */     String controltype = xm.get("@type").toString();
/*  488: 557 */     String qno = xm.get("@qno").toString();
/*  489: 558 */     XLabel qLabel = new XLabel();
/*  490: 559 */     qLabel.setText(label);
/*  491: 560 */     qLabel.setName(qno + "Lbl");
/*  492: 561 */     qLabel.setBounds(10, 10, label.length() * 8, 30);
/*  493: 562 */     qLabel.setAttribute("style", "Panel/Caption");
/*  494: 563 */     add(qLabel);
/*  495: 564 */     Object readonly = xm.get("@readonly");
/*  496: 565 */     if ((readonly != null) && (!controltype.equals("view")))
/*  497:     */     {
/*  498: 567 */       XLabel vLabel = new XLabel();
/*  499: 568 */       vLabel.setText(xm.get("@value").toString());
/*  500: 569 */       vLabel.setBounds(10, 50, 100, 30);
/*  501: 570 */       add(vLabel);
/*  502: 571 */       return;
/*  503:     */     }
/*  504: 574 */     if (controltype.equals("context"))
/*  505:     */     {
/*  506: 575 */       String val = "";
/*  507: 576 */       for (int i = 0; i < this.context.getNumChildren(); i++)
/*  508:     */       {
/*  509: 578 */         String id = this.context.get(i).getId();
/*  510: 579 */         Object tmpVal = (String)this.context.get(i).get();
/*  511: 580 */         val = val + (tmpVal != null ? " " + id + ":" + tmpVal : "");
/*  512:     */       }
/*  513: 583 */       XLabel vLabel = new XLabel();
/*  514: 584 */       vLabel.setText(val);
/*  515: 585 */       vLabel.setBounds(10, 50, getWidth(), 30);
/*  516: 586 */       add(vLabel);
/*  517: 587 */       return;
/*  518:     */     }
/*  519: 590 */     if (controltype.equals("choice"))
/*  520:     */     {
/*  521: 592 */       XModel choices = (XModel)xm.get("options");
/*  522: 593 */       if (choices.get("@lookupfunc") != null)
/*  523:     */       {
/*  524: 595 */         Object test = XProjectManager.getPageManager().getCurrentPage(null).evaluateAttribute(choices.get("@lookupfunc").toString());
/*  525: 597 */         if (test != null)
/*  526:     */         {
/*  527: 599 */           choices = (XModel)test;
/*  528: 600 */           System.out.println(" Lookup " + test + " " + choices.getNumChildren());
/*  529:     */         }
/*  530:     */       }
/*  531: 604 */       this.xm = choices;
/*  532: 605 */       XComboBox combo = new XComboBox();
/*  533: 606 */       int w = 100;
/*  534: 607 */       if (this.qModel.get("@width") != null) {
/*  535: 608 */         w = Integer.parseInt(this.qModel.get("@width").toString());
/*  536:     */       }
/*  537: 609 */       combo.setName(qno);
/*  538: 610 */       combo.setBounds(10, 50, w, 30);
/*  539: 611 */       XListBinding xl = new XListBinding();
/*  540: 613 */       for (int i = 0; i < choices.getNumChildren(); i++)
/*  541:     */       {
/*  542: 615 */         String item = choices.get(i).get().toString();
/*  543:     */         
/*  544: 617 */         combo.add(item);
/*  545:     */       }
/*  546: 619 */       combo.addKeyListener(this);
/*  547: 620 */       combo.select(xm.get("@value"));
/*  548: 621 */       combo.addFocusListener(this);
/*  549:     */       
/*  550: 623 */       add(combo);
/*  551: 624 */       transferFocus();
/*  552:     */     }
/*  553: 626 */     else if (controltype.equals("view"))
/*  554:     */     {
/*  555: 628 */       displayView(xm);
/*  556:     */     }
/*  557: 630 */     else if (controltype.equals("gps"))
/*  558:     */     {
/*  559: 632 */       displayGPS(xm);
/*  560:     */     }
/*  561: 634 */     else if (controltype.equals("age"))
/*  562:     */     {
/*  563: 636 */       displayAge(xm);
/*  564:     */     }
/*  565: 638 */     else if (controltype.equals("date"))
/*  566:     */     {
/*  567: 640 */       displayDate(xm);
/*  568:     */     }
/*  569: 642 */     else if (controltype.equals("narrative"))
/*  570:     */     {
/*  571: 644 */       displayNarrative(xm);
/*  572:     */     }
/*  573: 646 */     else if ((controltype == null) || (controltype.equals("text")))
/*  574:     */     {
/*  575: 648 */       XEdit edit = new XEdit();
/*  576: 649 */       int width = 100;
/*  577: 650 */       if (this.qModel.get("@width") != null) {
/*  578: 652 */         width = Integer.parseInt(this.qModel.get("@width").toString());
/*  579:     */       }
/*  580: 654 */       edit.setBounds(10, 50, width, 30);
/*  581: 655 */       edit.addFocusListener(this);
/*  582: 656 */       edit.addKeyListener(this);
/*  583: 657 */       edit.setName(qno);
/*  584: 658 */       add(edit);
/*  585: 659 */       transferFocus();
/*  586:     */     }
/*  587: 661 */     else if (controltype.equals("textarea"))
/*  588:     */     {
/*  589: 663 */       XTextArea edit = new XTextArea();
/*  590: 664 */       int width = 100;
/*  591: 665 */       if (this.qModel.get("@width") != null) {
/*  592: 667 */         width = Integer.parseInt(this.qModel.get("@width").toString());
/*  593:     */       }
/*  594: 669 */       edit.setBounds(10, 50, width, 80);
/*  595: 670 */       edit.addFocusListener(this);
/*  596: 671 */       edit.addKeyListener(this);
/*  597: 672 */       edit.setName(qno);
/*  598: 673 */       add(edit);
/*  599: 674 */       transferFocus();
/*  600:     */     }
/*  601:     */   }
/*  602:     */   
/*  603:     */   public void displayAge(XModel m)
/*  604:     */   {
/*  605: 681 */     int y = 40;
/*  606: 682 */     XLabel ageLbl = new XLabel();
/*  607: 683 */     ageLbl.setText("age");
/*  608: 684 */     ageLbl.setBounds(10, y, 50, 20);
/*  609: 685 */     add(ageLbl);
/*  610:     */     
/*  611: 687 */     XEdit age = new XEdit();
/*  612: 688 */     age.setName("age");
/*  613: 689 */     age.setBounds(70, y, 50, 20);
/*  614: 690 */     add(age);
/*  615: 691 */     XLabel ageUnitLbl = new XLabel();
/*  616: 692 */     ageUnitLbl.setText("unit");
/*  617: 693 */     ageUnitLbl.setBounds(130, y, 50, 20);
/*  618: 694 */     add(ageUnitLbl);
/*  619: 695 */     XComboBox ageUnit = new XComboBox();
/*  620: 696 */     if (this.qModel.get("@units") != null)
/*  621:     */     {
/*  622: 698 */       String[] units1 = this.qModel.get("@units").toString().split(",");
/*  623: 699 */       for (int i = 0; i < units1.length; i++) {
/*  624: 701 */         ageUnit.add(units1[i]);
/*  625:     */       }
/*  626:     */     }
/*  627:     */     else
/*  628:     */     {
/*  629: 706 */       ageUnit.add("Y");
/*  630: 707 */       ageUnit.add("M");
/*  631: 708 */       ageUnit.add("D");
/*  632: 709 */       ageUnit.setName("ageUnit");
/*  633:     */     }
/*  634: 712 */     ageUnit.setBounds(190, y, 50, 20);
/*  635: 713 */     add(ageUnit);
/*  636:     */     
/*  637: 715 */     XButton xb2 = new XButton();
/*  638: 716 */     xb2.setLabel("Next");
/*  639: 717 */     xb2.setBounds(310, y, 50, 20);
/*  640: 718 */     add(xb2);
/*  641: 719 */     xb2.addActionListener(this);
/*  642:     */   }
/*  643:     */   
/*  644:     */   public void displayDate(XModel m)
/*  645:     */   {
/*  646: 726 */     XEdit df = new XEdit();
/*  647: 727 */     df.setBounds(50, 10, 200, 40);
/*  648: 728 */     df.setName(m.getId() + "_dt");
/*  649: 729 */     df.setVisible(true);
/*  650:     */     
/*  651:     */ 
/*  652:     */ 
/*  653: 733 */     add(df);
/*  654: 734 */     XButton xb2 = new XButton();
/*  655: 735 */     xb2.setLabel("Next");
/*  656: 736 */     xb2.setBounds(260, 10, 50, 20);
/*  657: 737 */     add(xb2);
/*  658: 738 */     xb2.addActionListener(this);
/*  659:     */   }
/*  660:     */   
/*  661:     */   public void displayNarrative(XModel m)
/*  662:     */   {
/*  663: 749 */     XButton xb1 = new XButton();
/*  664: 750 */     xb1.setLabel("Open Text Narrative");
/*  665: 751 */     xb1.setBounds(50, 10, 150, 20);
/*  666: 752 */     add(xb1);
/*  667: 753 */     xb1.addActionListener(new ActionListener()
/*  668:     */     {
/*  669:     */       public void actionPerformed(ActionEvent e)
/*  670:     */       {
/*  671: 758 */         openNarrative();
/*  672:     */       }
/*  673:     */       
/*  674:     */       public void openNarrative()
/*  675:     */       {
/*  676: 762 */         JFrame frame = new JTextAreaDemo();
/*  677: 763 */         frame.addWindowListener(new WindowAdapter()
/*  678:     */         {
/*  679:     */           public void windowClosing(WindowEvent e)
/*  680:     */           {
/*  681: 764 */             System.exit(0);
/*  682:     */           }
/*  683: 766 */         });
/*  684: 767 */         frame.pack();
/*  685: 768 */         frame.setVisible(true);
/*  686: 769 */         frame.setSize(800, 600);
/*  687:     */       }
/*  688: 774 */     });
/*  689: 775 */     XButton xb11 = new XButton();
/*  690: 776 */     xb11.setLabel("Open Image Narrative");
/*  691: 777 */     xb11.setBounds(150, 10, 250, 20);
/*  692: 778 */     add(xb11);
/*  693: 779 */     xb11.addActionListener(new ActionListener()
/*  694:     */     {
/*  695:     */       public void actionPerformed(ActionEvent e)
/*  696:     */       {
/*  697: 784 */         openNarrative();
/*  698:     */       }
/*  699:     */       
/*  700:     */       public void openNarrative()
/*  701:     */       {
/*  702: 789 */         new Scribble("test");
/*  703:     */       }
/*  704: 794 */     });
/*  705: 795 */     XButton xb2 = new XButton();
/*  706: 796 */     xb2.setLabel("Next");
/*  707: 797 */     xb2.setBounds(260, 10, 50, 20);
/*  708: 798 */     add(xb2);
/*  709: 799 */     xb2.addActionListener(this);
/*  710:     */   }
/*  711:     */   
/*  712:     */   public void displayGPS(XModel m)
/*  713:     */   {
/*  714: 806 */     int y = 40;
/*  715: 807 */     XLabel latLbl = new XLabel();
/*  716: 808 */     latLbl.setText("lat");
/*  717: 809 */     latLbl.setBounds(10, y, 50, 20);
/*  718: 810 */     add(latLbl);
/*  719:     */     
/*  720: 812 */     XEdit lat = new XEdit();
/*  721: 813 */     lat.setName("lat");
/*  722: 814 */     lat.setBounds(70, y, 50, 20);
/*  723: 815 */     add(lat);
/*  724: 816 */     this.gpsComps[0] = lat;
/*  725: 817 */     XLabel longLbl = new XLabel();
/*  726: 818 */     longLbl.setText("long");
/*  727: 819 */     longLbl.setBounds(130, y, 50, 20);
/*  728: 820 */     add(longLbl);
/*  729: 821 */     XEdit longi = new XEdit();
/*  730: 822 */     longi.setName("long");
/*  731: 823 */     longi.setBounds(190, y, 50, 20);
/*  732: 824 */     add(longi);
/*  733: 825 */     this.gpsComps[1] = longi;
/*  734: 826 */     XButton xb1 = new XButton();
/*  735: 827 */     xb1.setLabel("GetGPS");
/*  736: 828 */     xb1.setBounds(250, y, 50, 20);
/*  737: 829 */     xb1.addActionListener(this);
/*  738: 830 */     add(xb1);
/*  739: 831 */     XButton xb2 = new XButton();
/*  740: 832 */     xb2.setLabel("Next");
/*  741: 833 */     xb2.setBounds(310, y, 50, 20);
/*  742: 834 */     add(xb2);
/*  743: 835 */     xb2.addActionListener(this);
/*  744:     */   }
/*  745:     */   
/*  746:     */   public void setAttribute(String arg0, Object arg1)
/*  747:     */   {
/*  748: 840 */     arg0.equals("question");
/*  749:     */     
/*  750: 842 */     super.setAttribute(arg0, arg1);
/*  751:     */   }
/*  752:     */   
/*  753:     */   public void readViewModel()
/*  754:     */     throws Exception
/*  755:     */   {
/*  756: 848 */     String iterator = this.qModel.get("@iterator").toString();
/*  757: 849 */     Iterator itera = (Iterator)Class.forName(iterator).newInstance();
/*  758: 850 */     itera.setContext(this.context);
/*  759: 851 */     if (this.qModel.get("@cols") != null)
/*  760:     */     {
/*  761: 853 */       String cols = this.qModel.get("@cols").toString();
/*  762: 854 */       itera.setFields(cols);
/*  763:     */     }
/*  764: 856 */     String subflow = this.qModel.get("@subflow").toString();
/*  765: 857 */     XModel flowM = (XModel)this.rootModel.get("flows/" + subflow);
/*  766: 858 */     String contextType = flowM.get("@context").toString();
/*  767: 859 */     itera.setNextContextType(contextType);
/*  768: 860 */     String constraints = (String)this.qModel.get("@constraints");
/*  769:     */     
/*  770: 862 */     itera.setConstraints(constraints);
/*  771: 863 */     if (this.qModel.get("@autoupdate") != null) {
/*  772: 864 */       itera.setAutoUpdate(true);
/*  773:     */     }
/*  774: 865 */     itera.init();
/*  775:     */     
/*  776: 867 */     XModel tbModel = new XBaseModel();
/*  777: 868 */     tbModel.setTagName("table");
/*  778:     */     
/*  779: 870 */     XModel headers = itera.getHeaders();
/*  780: 871 */     if (headers != null) {
/*  781: 872 */       tbModel.append(headers);
/*  782:     */     }
/*  783: 873 */     itera.first();
/*  784: 874 */     XModel xm1 = itera.getData();
/*  785: 876 */     if (xm1 != null)
/*  786:     */     {
/*  787: 877 */       tbModel.append(xm1);
/*  788: 878 */       while (itera.next())
/*  789:     */       {
/*  790: 880 */         xm1 = itera.getData();
/*  791: 881 */         if (xm1 == null) {
/*  792:     */           break;
/*  793:     */         }
/*  794: 883 */         tbModel.append(xm1);
/*  795:     */       }
/*  796: 886 */       if (tbModel.getNumChildren() > 0)
/*  797:     */       {
/*  798: 888 */         this.view.setModel(tbModel);
/*  799: 889 */         if (this.qModel.get("@colwidths") != null)
/*  800:     */         {
/*  801: 891 */           String[] colWidths = this.qModel.get("@colwidths").toString().split(",");
/*  802: 892 */           for (int i = 0; i < colWidths.length; i++)
/*  803:     */           {
/*  804: 893 */             System.out.println(" col width " + i + " " + colWidths[i]);
/*  805: 894 */             this.view.setColWidth(i, Integer.parseInt(colWidths[i]));
/*  806:     */           }
/*  807:     */         }
/*  808:     */       }
/*  809:     */     }
/*  810:     */   }
/*  811:     */   
/*  812:     */   public void displayView(XModel xm)
/*  813:     */   {
/*  814: 903 */     int y = 40;
/*  815: 905 */     if (this.qModel.get("@selector") != null)
/*  816:     */     {
/*  817: 907 */       XLabel selectorLbl = new XLabel();
/*  818: 908 */       System.out.println(this.qModel.get("@selector"));
/*  819: 909 */       System.out.println(this.qModel.get("@selectortext"));
/*  820: 910 */       selectorLbl.setText(this.qModel.get("@selectortext").toString());
/*  821: 911 */       selectorLbl.setBounds(10, y, 250, 30);
/*  822: 912 */       add(selectorLbl);
/*  823: 913 */       XComboBox selector = new XComboBox();
/*  824:     */       
/*  825: 915 */       selector.setName("selectorno");
/*  826: 916 */       selector.setBounds(260, y, 150, 30);
/*  827: 917 */       selector.addItem(" Choose Any One");
/*  828: 918 */       selector.addItem("Yes");
/*  829: 919 */       selector.addItem("No");
/*  830: 920 */       add(selector);
/*  831: 921 */       Object[] tt = { selectorLbl, selector };
/*  832: 922 */       this.viewElements[0] = tt;
/*  833: 923 */       selector.addKeyListener(this);
/*  834: 924 */       selector.addFocusListener(this);
/*  835: 925 */       y += 40;
/*  836:     */     }
/*  837: 928 */     String qno = xm.get("@qno").toString();
/*  838:     */     try
/*  839:     */     {
/*  840: 931 */       if (this.qModel.get("@maxtext") != null)
/*  841:     */       {
/*  842: 933 */         XLabel maxnoLbl = new XLabel();
/*  843: 934 */         maxnoLbl.setText(this.qModel.get("@maxtext").toString());
/*  844: 935 */         maxnoLbl.setBounds(10, y, 100, 30);
/*  845: 936 */         add(maxnoLbl);
/*  846: 938 */         if (this.qModel.get("@maxrows") != null)
/*  847:     */         {
/*  848: 940 */           XLabel maxno = new XLabel();
/*  849: 941 */           maxno.setText(this.qModel.get("@maxrows").toString());
/*  850: 942 */           maxno.setName("maxno");
/*  851: 943 */           maxno.setBounds(110, y, 50, 30);
/*  852: 944 */           add(maxno);
/*  853: 945 */           maxno.addKeyListener(this);
/*  854: 946 */           Object[] tt = { maxnoLbl, maxno };
/*  855: 947 */           this.viewElements[1] = tt;
/*  856:     */           
/*  857: 949 */           y += 40;
/*  858:     */         }
/*  859:     */         else
/*  860:     */         {
/*  861: 953 */           XEdit maxno = new XEdit();
/*  862:     */           
/*  863: 955 */           maxno.setBounds(110, y, 50, 20);
/*  864: 956 */           maxno.setName("maxno");
/*  865: 957 */           add(maxno);
/*  866: 958 */           maxno.addKeyListener(this);
/*  867: 959 */           Object[] tt = { maxnoLbl, maxno };
/*  868: 960 */           this.viewElements[1] = tt;
/*  869: 961 */           y += 40;
/*  870:     */         }
/*  871:     */       }
/*  872: 966 */       XTable table = new XTable();
/*  873: 967 */       int h = 200;
/*  874: 968 */       if (this.qModel.get("@viewheight") != null) {
/*  875: 970 */         h = Integer.parseInt(this.qModel.get("@viewheight").toString());
/*  876:     */       }
/*  877: 972 */       table.setBounds(10, y, getWidth() - 30, h);
/*  878: 973 */       table.setInteractiveTable(true);
/*  879: 974 */       table.setSelectedStyle("selectedRow");
/*  880: 975 */       table.setName(qno);
/*  881: 976 */       table.addItemListener(this);
/*  882:     */       
/*  883: 978 */       y = y + h + 10;
/*  884: 979 */       XButton xb = new XButton();
/*  885: 980 */       xb.setLabel("Add");
/*  886: 981 */       xb.setBounds(10, y, 50, 20);
/*  887: 982 */       xb.addActionListener(this);
/*  888: 983 */       if (this.qModel.get("@add") != null) {
/*  889: 984 */         add(xb);
/*  890:     */       }
/*  891: 986 */       XButton xb1 = new XButton();
/*  892: 987 */       xb1.setLabel("Edit");
/*  893: 988 */       xb1.setBounds(70, y, 50, 20);
/*  894: 989 */       xb1.addActionListener(this);
/*  895: 990 */       add(xb1);
/*  896:     */       
/*  897: 992 */       XButton xb2 = new XButton();
/*  898: 993 */       xb2.setLabel("Next");
/*  899: 994 */       xb2.setBounds(120, y, 50, 20);
/*  900: 995 */       xb2.addActionListener(this);
/*  901: 996 */       add(xb2);
/*  902: 997 */       XButton xb3 = new XButton();
/*  903: 998 */       xb3.setLabel("Refresh");
/*  904: 999 */       xb3.setBounds(190, y, 50, 20);
/*  905:1000 */       xb3.addActionListener(this);
/*  906:1001 */       add(xb3);
/*  907:     */       
/*  908:1003 */       add(table);
/*  909:1004 */       this.view = table;
/*  910:1005 */       readViewModel();
/*  911:1006 */       table.addItemListener(this);
/*  912:1007 */       table.addKeyListener(this);
/*  913:1008 */       if (this.qModel.get("@add") != null)
/*  914:     */       {
/*  915:1010 */         Object[] tt = { xb, xb1, xb2, xb3 };
/*  916:1011 */         this.viewElements[2] = tt;
/*  917:     */       }
/*  918:     */       else
/*  919:     */       {
/*  920:1015 */         Object[] tt = { xb1, xb2, xb3 };
/*  921:1016 */         this.viewElements[2] = tt;
/*  922:     */       }
/*  923:1018 */       if (this.qModel.get("@selector") != null)
/*  924:     */       {
/*  925:1020 */         hideViewElements(1, false);
/*  926:1021 */         hideViewElements(2, false);
/*  927:1022 */         this.view.setVisible(false);
/*  928:     */       }
/*  929:1025 */       transferFocus();
/*  930:     */     }
/*  931:     */     catch (InstantiationException e)
/*  932:     */     {
/*  933:1029 */       e.printStackTrace();
/*  934:     */     }
/*  935:     */     catch (IllegalAccessException e)
/*  936:     */     {
/*  937:1032 */       e.printStackTrace();
/*  938:     */     }
/*  939:     */     catch (ClassNotFoundException e)
/*  940:     */     {
/*  941:1035 */       e.printStackTrace();
/*  942:     */     }
/*  943:     */     catch (Exception e)
/*  944:     */     {
/*  945:1038 */       e.printStackTrace();
/*  946:     */     }
/*  947:     */   }
/*  948:     */   
/*  949:     */   public void hideViewElements(int index, boolean flg)
/*  950:     */   {
/*  951:1044 */     Object[] elementsToHide = (Object[])this.viewElements[index];
/*  952:1045 */     if (elementsToHide == null) {
/*  953:1046 */       return;
/*  954:     */     }
/*  955:1047 */     System.out.println("Elements to hide =" + elementsToHide.length);
/*  956:1048 */     for (int i = 0; i < elementsToHide.length; i++) {
/*  957:1050 */       ((Component)elementsToHide[i]).setVisible(flg);
/*  958:     */     }
/*  959:     */   }
/*  960:     */   
/*  961:     */   public void itemStateChanged(ItemEvent e)
/*  962:     */   {
/*  963:1056 */     System.out.println(e.getID() + " " + e.getItem());
/*  964:1057 */     this.selected = e.getItem().toString();
/*  965:     */   }
/*  966:     */   
/*  967:     */   public void keyPressed(KeyEvent e)
/*  968:     */   {
/*  969:1062 */     if ((e.getComponent() instanceof XComboBox)) {
/*  970:1064 */       for (int i = 0; i < this.xm.getNumChildren(); i++)
/*  971:     */       {
/*  972:1066 */         System.out.println(" item pressed" + this.xm.get(i).getId());
/*  973:1067 */         if ((this.xm.get(i).get().toString().startsWith(e.getKeyChar())) || (this.xm.get(i).getId().equals(e.getKeyChar()))) {
/*  974:1069 */           ((XComboBox)e.getComponent()).select(this.xm.get(i).get().toString());
/*  975:     */         }
/*  976:     */       }
/*  977:     */     }
/*  978:     */   }
/*  979:     */   
/*  980:     */   public void viewExit(Component c)
/*  981:     */     throws Exception
/*  982:     */   {
/*  983:1077 */     System.out.println(" View Exit" + c);
/*  984:1078 */     if ((c instanceof XEdit))
/*  985:     */     {
/*  986:1080 */       String value = ((XEdit)c).getText();
/*  987:     */       try
/*  988:     */       {
/*  989:1082 */         Integer.parseInt(value);
/*  990:     */       }
/*  991:     */       catch (Exception e)
/*  992:     */       {
/*  993:1086 */         e.printStackTrace();
/*  994:1087 */         displayError("You have to enter a number ");
/*  995:1088 */         hideViewElements(2, false);
/*  996:1089 */         return;
/*  997:     */       }
/*  998:1092 */       if ((this.view.getModel() != null) && (Integer.parseInt(value) < this.view.getModel().getNumChildren() - 1))
/*  999:     */       {
/* 1000:1094 */         displayError("Cannot make the value lesser than the number of rows ");
/* 1001:1095 */         hideViewElements(2, false);
/* 1002:     */       }
/* 1003:     */       else
/* 1004:     */       {
/* 1005:1099 */         hideViewElements(2, true);
/* 1006:1100 */         ((XEdit)c).transferFocus();
/* 1007:     */       }
/* 1008:     */     }
/* 1009:1104 */     else if ((c instanceof XComboBox))
/* 1010:     */     {
/* 1011:1106 */       String value = ((XComboBox)c).getSelectedItem();
/* 1012:1107 */       if (value.equals("No"))
/* 1013:     */       {
/* 1014:1109 */         if (!((XEdit)((Object[])this.viewElements[1])[1]).getText().equals(""))
/* 1015:     */         {
/* 1016:1111 */           displayError("Cannot change to No because you have already added a few rows");
/* 1017:1112 */           ((XComboBox)c).select("Yes");
/* 1018:     */         }
/* 1019:     */         else
/* 1020:     */         {
/* 1021:1116 */           hideViewElements(1, false);
/* 1022:1117 */           hideViewElements(2, false);
/* 1023:1118 */           ActionEvent e1 = new ActionEvent(c, 0, "Next");
/* 1024:1119 */           Rectangle r = getBounds();
/* 1025:     */           
/* 1026:1121 */           setBounds(r.x, r.y, r.width, 200);
/* 1027:1122 */           getParent().doLayout();
/* 1028:1123 */           actionPerformed(e1);
/* 1029:     */         }
/* 1030:     */       }
/* 1031:1127 */       else if (((XComboBox)c).getSelectedItem().equals(" Choose Any One"))
/* 1032:     */       {
/* 1033:1128 */         displayError("Please select a value");
/* 1034:     */       }
/* 1035:1130 */       else if (((XComboBox)c).getSelectedItem().equals("Yes"))
/* 1036:     */       {
/* 1037:1132 */         hideViewElements(1, true);
/* 1038:1133 */         this.view.setVisible(true);
/* 1039:     */         
/* 1040:1135 */         ((XComboBox)c).transferFocus();
/* 1041:     */       }
/* 1042:     */     }
/* 1043:     */   }
/* 1044:     */   
/* 1045:     */   public void displayError(String err)
/* 1046:     */   {
/* 1047:1142 */     XMessageBox mbox = new XMessageBox();
/* 1048:1143 */     Dimension size = getSize();
/* 1049:1144 */     Point location = getLocationOnScreen();
/* 1050:1145 */     size = new Dimension(size.width + 2 * location.x, size.height + 2 * location.y);
/* 1051:     */     
/* 1052:1147 */     mbox.setup("Error", err, size, this);
/* 1053:     */   }
/* 1054:     */   
/* 1055:     */   public void keyReleased(KeyEvent e)
/* 1056:     */   {
/* 1057:1152 */     System.out.println(" Key released" + e.getKeyChar() + " " + e.getComponent().getName() + " " + e.isConsumed());
/* 1058:1153 */     if ((e.getKeyCode() == 10) && (!e.isConsumed())) {
/* 1059:     */       try
/* 1060:     */       {
/* 1061:1156 */         System.out.println("Enter released");
/* 1062:1158 */         if (this.qModel.get("@type").equals("view"))
/* 1063:     */         {
/* 1064:1160 */           viewExit((Component)e.getSource());
/* 1065:1161 */           e.consume();
/* 1066:1162 */           return;
/* 1067:     */         }
/* 1068:1165 */         ActionEvent e1 = new ActionEvent(e.getSource(), 0, "Next");
/* 1069:     */         
/* 1070:1167 */         actionPerformed(e1);
/* 1071:1168 */         e.consume();
/* 1072:1169 */         return;
/* 1073:     */       }
/* 1074:     */       catch (Exception e1)
/* 1075:     */       {
/* 1076:1173 */         e.consume();
/* 1077:     */       }
/* 1078:     */     }
/* 1079:     */   }
/* 1080:     */   
/* 1081:     */   public void keyTyped(KeyEvent e) {}
/* 1082:     */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.QuestionPanel
 * JD-Core Version:    0.7.0.1
 */