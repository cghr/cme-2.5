/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.Graphics2D;
/*   7:    */ import java.awt.event.KeyAdapter;
/*   8:    */ import java.awt.event.KeyEvent;
/*   9:    */ import java.awt.event.MouseAdapter;
/*  10:    */ import java.awt.event.MouseEvent;
/*  11:    */ import java.awt.event.MouseMotionAdapter;
/*  12:    */ import java.awt.image.BufferedImage;
/*  13:    */ import java.awt.image.RescaleOp;
/*  14:    */ import java.io.File;
/*  15:    */ import java.io.IOException;
/*  16:    */ import javax.imageio.ImageIO;
/*  17:    */ import javax.swing.JPanel;
/*  18:    */ 
/*  19:    */ class ScribblePane2
/*  20:    */   extends JPanel
/*  21:    */ {
/*  22:324 */   private int width = 0;
/*  23:325 */   private int height = 0;
/*  24:326 */   boolean first = true;
/*  25:327 */   private static final File templateFile = new File("template");
/*  26:330 */   public static BufferedImage imagesrc = null;
/*  27:    */   protected int last_x;
/*  28:    */   protected int last_y;
/*  29:    */   
/*  30:    */   public void paint(Graphics g)
/*  31:    */   {
/*  32:334 */     g.drawImage(imagesrc, 0, 0, null);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public ScribblePane2(String path)
/*  36:    */   {
/*  37:    */     try
/*  38:    */     {
/*  39:341 */       File file = new File(path);
/*  40:342 */       if (file.exists()) {
/*  41:343 */         imagesrc = ImageIO.read(file);
/*  42:    */       } else {
/*  43:345 */         imagesrc = ImageIO.read(templateFile);
/*  44:    */       }
/*  45:348 */       this.width = imagesrc.getWidth();
/*  46:349 */       this.height = imagesrc.getHeight();
/*  47:    */     }
/*  48:    */     catch (IOException e1)
/*  49:    */     {
/*  50:353 */       e1.printStackTrace();
/*  51:    */     }
/*  52:357 */     setPreferredSize(new Dimension(450, 200));
/*  53:    */     
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:362 */     addMouseListener(new MouseAdapter()
/*  58:    */     {
/*  59:    */       public void mousePressed(MouseEvent e)
/*  60:    */       {
/*  61:364 */         ScribblePane2.this.moveto(e.getX(), e.getY());
/*  62:365 */         ScribblePane2.this.requestFocus();
/*  63:    */       }
/*  64:372 */     });
/*  65:373 */     addMouseMotionListener(new MouseMotionAdapter()
/*  66:    */     {
/*  67:    */       public void mouseDragged(MouseEvent e)
/*  68:    */       {
/*  69:375 */         ScribblePane2.this.lineto(e.getX(), e.getY());
/*  70:    */       }
/*  71:379 */     });
/*  72:380 */     addKeyListener(new KeyAdapter()
/*  73:    */     {
/*  74:    */       public void keyPressed(KeyEvent e)
/*  75:    */       {
/*  76:382 */         if (e.getKeyCode() == 67) {
/*  77:383 */           ScribblePane2.this.clear();
/*  78:    */         }
/*  79:    */       }
/*  80:    */     });
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void moveto(int x, int y)
/*  84:    */   {
/*  85:393 */     this.last_x = x;
/*  86:394 */     this.last_y = y;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void lineto(int x, int y)
/*  90:    */   {
/*  91:402 */     Graphics componentG = getGraphics();
/*  92:403 */     Graphics2D imageGraphics = (Graphics2D)imagesrc.getGraphics();
/*  93:404 */     imageGraphics.setColor(this.color);
/*  94:405 */     imageGraphics.drawLine(this.last_x, this.last_y, x, y);
/*  95:406 */     componentG.setColor(this.color);
/*  96:407 */     componentG.drawLine(this.last_x, this.last_y, x, y);
/*  97:408 */     moveto(x, y);
/*  98:    */     
/*  99:410 */     float[] scales = { 1.0F, 1.0F, 1.0F, 0.5F };
/* 100:    */     
/* 101:412 */     float[] offset = new float[4];
/* 102:    */     
/* 103:414 */     RescaleOp rop = new RescaleOp(scales, offset, null);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void clear()
/* 107:    */   {
/* 108:    */     try
/* 109:    */     {
/* 110:428 */       imagesrc = ImageIO.read(templateFile);
/* 111:    */       
/* 112:430 */       repaint();
/* 113:    */     }
/* 114:    */     catch (IOException e)
/* 115:    */     {
/* 116:433 */       e.printStackTrace();
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:438 */   Color color = Color.black;
/* 121:    */   
/* 122:    */   public void setColor(Color color)
/* 123:    */   {
/* 124:442 */     this.color = color;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public Color getColor()
/* 128:    */   {
/* 129:447 */     return this.color;
/* 130:    */   }
/* 131:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.ScribblePane2
 * JD-Core Version:    0.7.0.1
 */