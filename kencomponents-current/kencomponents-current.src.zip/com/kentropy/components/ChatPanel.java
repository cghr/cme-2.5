/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Frame;
/*   5:    */ import java.awt.event.ActionEvent;
/*   6:    */ import java.awt.event.ActionListener;
/*   7:    */ import java.awt.event.WindowEvent;
/*   8:    */ import java.awt.event.WindowListener;
/*   9:    */ import java.io.FileNotFoundException;
/*  10:    */ import java.io.FileReader;
/*  11:    */ import java.io.PrintStream;
/*  12:    */ import net.xoetrope.awt.XButton;
/*  13:    */ import net.xoetrope.awt.XPanel;
/*  14:    */ import net.xoetrope.awt.XTextArea;
/*  15:    */ import net.xoetrope.data.XDataSource;
/*  16:    */ import net.xoetrope.xui.XProjectManager;
/*  17:    */ import net.xoetrope.xui.data.XModel;
/*  18:    */ 
/*  19:    */ public class ChatPanel
/*  20:    */   extends XPanel
/*  21:    */   implements ActionListener
/*  22:    */ {
/*  23: 27 */   XTextArea xt = new XTextArea();
/*  24: 28 */   XTextArea xt1 = new XTextArea();
/*  25: 29 */   public int currentSection = -1;
/*  26: 30 */   public int currentQ = -1;
/*  27:    */   public XModel questions;
/*  28: 33 */   int count = 0;
/*  29:    */   
/*  30:    */   public void askQuestion(String question)
/*  31:    */   {
/*  32: 36 */     this.xt.setForeground(Color.red);
/*  33: 37 */     this.xt.append(question + "\r\n");
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void nextQuestion()
/*  37:    */   {
/*  38: 42 */     if (this.currentSection == -1)
/*  39:    */     {
/*  40: 44 */       askFilterQuestion(this.questions.get(0).getId());
/*  41: 45 */       this.currentSection = 0;
/*  42:    */     }
/*  43: 48 */     else if (this.currentQ == -1)
/*  44:    */     {
/*  45: 50 */       askQuestion(this.questions.get(this.currentSection).get(0).get("@question").toString());
/*  46: 51 */       this.currentQ += 1;
/*  47:    */     }
/*  48: 55 */     else if (this.currentQ == this.questions.get(this.currentSection).getNumChildren())
/*  49:    */     {
/*  50: 57 */       this.currentSection += 1;
/*  51:    */       
/*  52: 59 */       this.currentQ = -1;
/*  53: 60 */       if (this.currentSection < this.questions.getNumChildren()) {
/*  54: 62 */         askFilterQuestion(this.questions.get(this.currentSection).getId());
/*  55:    */       }
/*  56:    */     }
/*  57:    */     else
/*  58:    */     {
/*  59: 67 */       askQuestion(this.questions.get(this.currentSection).get(this.currentQ).get("@question").toString());
/*  60: 68 */       this.currentQ += 1;
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void askFilterQuestion(String filter)
/*  65:    */   {
/*  66: 84 */     askQuestion("Did he have " + filter + "?");
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setAnswer(String answer)
/*  70:    */   {
/*  71: 89 */     this.xt.append("A :" + answer + "\r\n\r\n");
/*  72: 90 */     nextQuestion();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void init()
/*  76:    */   {
/*  77: 99 */     this.xt.setBounds(10, 10, getWidth() - 20, 400);
/*  78:100 */     this.xt.setEditable(false);
/*  79:101 */     this.xt.setText("");
/*  80:102 */     add(this.xt);
/*  81:    */     
/*  82:104 */     this.xt1.setBounds(10, 420, getWidth() - 20, 100);
/*  83:    */     
/*  84:106 */     add(this.xt1);
/*  85:107 */     XButton b = new XButton();
/*  86:108 */     b.setBounds(10, 520, 100, 20);
/*  87:109 */     b.setName("Submit");
/*  88:110 */     b.setLabel("Submit");
/*  89:111 */     b.addActionListener(this);
/*  90:112 */     add(b);
/*  91:113 */     nextQuestion();
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static void main(String[] args)
/*  95:    */     throws FileNotFoundException
/*  96:    */   {
/*  97:120 */     XDataSource ds = new XDataSource();
/*  98:121 */     ds.read(new FileReader("e:/workspace/components/datasets.xml"));
/*  99:    */     
/* 100:123 */     XModel xm = XProjectManager.getModel();
/* 101:    */     
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:134 */     XModel xm1 = (XModel)xm.get("symptomlist");
/* 112:135 */     System.out.println("List no " + xm1.getNumChildren());
/* 113:    */     
/* 114:137 */     Frame frame = new Frame("test");
/* 115:138 */     ChatPanel cp = new ChatPanel();
/* 116:139 */     cp.setBounds(10, 10, 700, 500);
/* 117:140 */     frame.setBounds(10, 10, 800, 600);
/* 118:141 */     frame.add(cp);
/* 119:142 */     frame.show();
/* 120:143 */     cp.questions = xm1;
/* 121:144 */     cp.init();
/* 122:145 */     frame.addWindowListener(new WindowListener()
/* 123:    */     {
/* 124:    */       public void windowActivated(WindowEvent e) {}
/* 125:    */       
/* 126:    */       public void windowClosed(WindowEvent e) {}
/* 127:    */       
/* 128:    */       public void windowClosing(WindowEvent e)
/* 129:    */       {
/* 130:159 */         System.exit(0);
/* 131:    */       }
/* 132:    */       
/* 133:    */       public void windowDeactivated(WindowEvent e) {}
/* 134:    */       
/* 135:    */       public void windowDeiconified(WindowEvent e) {}
/* 136:    */       
/* 137:    */       public void windowIconified(WindowEvent e) {}
/* 138:    */       
/* 139:    */       public void windowOpened(WindowEvent e) {}
/* 140:    */     });
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void actionPerformed(ActionEvent e)
/* 144:    */   {
/* 145:193 */     if (e.getActionCommand().equals("Submit"))
/* 146:    */     {
/* 147:195 */       setAnswer(this.xt1.getText());
/* 148:196 */       this.xt1.setText("");
/* 149:    */     }
/* 150:    */   }
/* 151:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.ChatPanel
 * JD-Core Version:    0.7.0.1
 */