/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.BorderLayout;
/*  4:   */ import java.awt.Container;
/*  5:   */ import java.awt.event.ActionEvent;
/*  6:   */ import java.awt.event.ActionListener;
/*  7:   */ import java.io.FileReader;
/*  8:   */ import java.io.PrintStream;
/*  9:   */ import javax.swing.JFrame;
/* 10:   */ import javax.swing.JLabel;
/* 11:   */ import javax.swing.JPanel;
/* 12:   */ import javax.swing.JScrollPane;
/* 13:   */ import javax.swing.JTextField;
/* 14:   */ import javax.swing.JTextPane;
/* 15:   */ import javax.swing.UIManager;
/* 16:   */ import javax.swing.event.DocumentEvent;
/* 17:   */ import javax.swing.event.DocumentListener;
/* 18:   */ import javax.swing.text.BadLocationException;
/* 19:   */ import javax.swing.text.Document;
/* 20:   */ import javax.swing.text.Highlighter;
/* 21:   */ 
/* 22:   */ public class HighlightExample
/* 23:   */ {
/* 24:   */   public static String word;
/* 25:   */   
/* 26:   */   public static void main(String[] args)
/* 27:   */   {
/* 28:   */     try
/* 29:   */     {
/* 30:41 */       UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
/* 31:   */     }
/* 32:   */     catch (Exception localException1) {}
/* 33:44 */     JFrame f = new JFrame("Highlight example");
/* 34:45 */     final JTextPane textPane = new JTextPane();
/* 35:46 */     textPane.setHighlighter(highlighter);
/* 36:47 */     JPanel pane = new JPanel();
/* 37:48 */     pane.setLayout(new BorderLayout());
/* 38:49 */     pane.add(new JLabel("Enter word: "), "West");
/* 39:50 */     JTextField tf = new JTextField();
/* 40:51 */     pane.add(tf, "Center");
/* 41:52 */     f.getContentPane().add(pane, "South");
/* 42:53 */     f.getContentPane().add(new JScrollPane(textPane), "Center");
/* 43:   */     try
/* 44:   */     {
/* 45:56 */       textPane.read(new FileReader("links1.html"), null);
/* 46:   */     }
/* 47:   */     catch (Exception e)
/* 48:   */     {
/* 49:58 */       System.out.println("Failed to load file " + args[0]);
/* 50:59 */       System.out.println(e);
/* 51:   */     }
/* 52:61 */     final WordSearcher searcher = new WordSearcher(textPane);
/* 53:   */     
/* 54:63 */     tf.addActionListener(new ActionListener()
/* 55:   */     {
/* 56:   */       public void actionPerformed(ActionEvent evt)
/* 57:   */       {
/* 58:65 */         HighlightExample.word = HighlightExample.this.getText().trim();
/* 59:66 */         int offset = searcher.search(HighlightExample.word);
/* 60:67 */         if (offset != -1) {
/* 61:   */           try
/* 62:   */           {
/* 63:69 */             textPane.scrollRectToVisible(textPane
/* 64:70 */               .modelToView(offset));
/* 65:   */           }
/* 66:   */           catch (BadLocationException localBadLocationException) {}
/* 67:   */         }
/* 68:   */       }
/* 69:76 */     });
/* 70:77 */     textPane.getDocument().addDocumentListener(new DocumentListener()
/* 71:   */     {
/* 72:   */       public void insertUpdate(DocumentEvent evt)
/* 73:   */       {
/* 74:79 */         HighlightExample.this.search(HighlightExample.word);
/* 75:   */       }
/* 76:   */       
/* 77:   */       public void removeUpdate(DocumentEvent evt)
/* 78:   */       {
/* 79:83 */         HighlightExample.this.search(HighlightExample.word);
/* 80:   */       }
/* 81:   */       
/* 82:   */       public void changedUpdate(DocumentEvent evt) {}
/* 83:89 */     });
/* 84:90 */     f.setSize(400, 400);
/* 85:91 */     f.setVisible(true);
/* 86:   */   }
/* 87:   */   
/* 88:96 */   public static Highlighter highlighter = new UnderlineHighlighter(null);
/* 89:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.HighlightExample
 * JD-Core Version:    0.7.0.1
 */