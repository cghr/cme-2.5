/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import java.awt.Color;
/*  5:   */ import java.awt.Dimension;
/*  6:   */ import java.awt.Graphics;
/*  7:   */ 
/*  8:   */ class SmileyCanvas
/*  9:   */   extends Canvas
/* 10:   */ {
/* 11:   */   public SmileyCanvas(Color faceColor)
/* 12:   */   {
/* 13:36 */     setForeground(faceColor);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Dimension getPreferredSize()
/* 17:   */   {
/* 18:40 */     return new Dimension(300, 300);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void paint(Graphics g)
/* 22:   */   {
/* 23:49 */     Dimension size = getSize();
/* 24:50 */     int d = Math.min(size.width, size.height);
/* 25:51 */     int ed = d / 20;
/* 26:52 */     int x = (size.width - d) / 2;
/* 27:53 */     int y = (size.height - d) / 2;
/* 28:   */     
/* 29:   */ 
/* 30:56 */     g.fillOval(x, y, d, d);
/* 31:57 */     g.setColor(Color.black);
/* 32:58 */     g.drawOval(x, y, d, d);
/* 33:   */     
/* 34:   */ 
/* 35:61 */     g.fillOval(x + d / 3 - ed / 2, y + d / 3 - ed / 2, ed, ed);
/* 36:62 */     g.fillOval(x + 2 * (d / 3) - ed / 2, y + d / 3 - ed / 2, ed, ed);
/* 37:   */     
/* 38:   */ 
/* 39:65 */     g.drawArc(x + d / 4, y + 2 * (d / 5), d / 2, d / 3, 0, -180);
/* 40:   */   }
/* 41:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.SmileyCanvas
 * JD-Core Version:    0.7.0.1
 */