/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.inet.jortho.SpellChecker;
/*   4:    */ import com.kentropy.db.TestXUIDB;
/*   5:    */ import java.awt.Color;
/*   6:    */ import java.awt.Component;
/*   7:    */ import java.awt.Container;
/*   8:    */ import java.awt.FlowLayout;
/*   9:    */ import java.awt.Font;
/*  10:    */ import java.awt.Frame;
/*  11:    */ import java.awt.Point;
/*  12:    */ import java.awt.event.ActionEvent;
/*  13:    */ import java.awt.event.ActionListener;
/*  14:    */ import java.awt.event.FocusEvent;
/*  15:    */ import java.awt.event.FocusListener;
/*  16:    */ import java.awt.event.ItemEvent;
/*  17:    */ import java.awt.event.ItemListener;
/*  18:    */ import java.awt.event.MouseEvent;
/*  19:    */ import java.awt.event.MouseListener;
/*  20:    */ import java.awt.event.WindowAdapter;
/*  21:    */ import java.awt.event.WindowEvent;
/*  22:    */ import java.io.PrintStream;
/*  23:    */ import java.util.Vector;
/*  24:    */ import javax.swing.JPanel;
/*  25:    */ import javax.swing.JTextArea;
/*  26:    */ import net.xoetrope.awt.XButton;
/*  27:    */ import net.xoetrope.awt.XComboBox;
/*  28:    */ import net.xoetrope.awt.XLabel;
/*  29:    */ import net.xoetrope.awt.XPanel;
/*  30:    */ import net.xoetrope.awt.XScrollPane;
/*  31:    */ import net.xoetrope.awt.XToolTip;
/*  32:    */ import net.xoetrope.xui.XPage;
/*  33:    */ import net.xoetrope.xui.XProject;
/*  34:    */ import net.xoetrope.xui.XProjectManager;
/*  35:    */ import net.xoetrope.xui.data.XBaseModel;
/*  36:    */ import net.xoetrope.xui.data.XModel;
/*  37:    */ 
/*  38:    */ public class KeywordPanel
/*  39:    */   extends JPanel
/*  40:    */   implements MouseListener, ActionListener, FocusListener, ItemListener
/*  41:    */ {
/*  42: 42 */   KeywordPanel kp = null;
/*  43: 44 */   Vector physicians = new Vector();
/*  44:    */   
/*  45:    */   public Vector getPhysicians()
/*  46:    */   {
/*  47: 47 */     return this.physicians;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void setPhysicians(Vector physicians)
/*  51:    */   {
/*  52: 51 */     this.physicians = physicians;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public KeywordPanel(XPanel mainPanel, JTextArea commentArea, XButton[] xb)
/*  56:    */   {
/*  57: 55 */     this.editPanel = mainPanel;
/*  58: 56 */     this.commentArea = commentArea;
/*  59: 57 */     this.saveButton = null;
/*  60: 58 */     this.editButton = null;
/*  61: 59 */     this.closeButton = null;
/*  62: 60 */     this.cancelButton = null;
/*  63: 61 */     this.deleteButton = null;
/*  64:    */   }
/*  65:    */   
/*  66: 68 */   XPage page = null;
/*  67: 70 */   Container parent = null;
/*  68: 72 */   private static int BUTTON_WIDTH = 50;
/*  69: 73 */   private static int BUTTON_HEIGHT = 20;
/*  70: 75 */   int currentSelected = -1;
/*  71: 76 */   XScrollPane scr = new XScrollPane();
/*  72: 77 */   public XPanel mainPanel = null;
/*  73: 78 */   XPanel listPanel = null;
/*  74: 79 */   public XPanel editPanel = null;
/*  75:    */   private static final int ROWS = 1;
/*  76:    */   private static final int COLUMNS = 8;
/*  77: 82 */   private String deleteFunc = null;
/*  78: 83 */   private String saveFunc = null;
/*  79: 84 */   private String cancelFunc = null;
/*  80: 85 */   private String closeFunc = null;
/*  81: 86 */   private String selectFunc = null;
/*  82: 87 */   private String currentPhysician = null;
/*  83: 88 */   private String report = null;
/*  84: 89 */   private String stage = null;
/*  85: 90 */   private JTextArea commentArea = null;
/*  86: 91 */   private XLabel heading = null;
/*  87: 95 */   private XButton saveButton = null;
/*  88: 96 */   private XButton editButton = null;
/*  89: 97 */   private XButton closeButton = null;
/*  90: 98 */   private XButton cancelButton = null;
/*  91: 99 */   private XButton deleteButton = null;
/*  92:102 */   public String keywordPhysician = null;
/*  93:    */   
/*  94:    */   public KeywordPanel() {}
/*  95:    */   
/*  96:    */   public String getKeywordPhysician()
/*  97:    */   {
/*  98:105 */     return this.keywordPhysician;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void remove()
/* 102:    */   {
/* 103:    */     try
/* 104:    */     {
/* 105:111 */       if (this.mainPanel.getParent() != null) {
/* 106:112 */         this.mainPanel.getParent().remove(this.mainPanel);
/* 107:    */       }
/* 108:    */     }
/* 109:    */     catch (Exception e)
/* 110:    */     {
/* 111:116 */       e.printStackTrace();
/* 112:    */     }
/* 113:    */     try
/* 114:    */     {
/* 115:119 */       if (this.editPanel.getParent() != null) {
/* 116:120 */         this.editPanel.getParent().remove(this.editPanel);
/* 117:    */       }
/* 118:    */     }
/* 119:    */     catch (Exception e)
/* 120:    */     {
/* 121:124 */       e.printStackTrace();
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setKeywordPhysician(String keywordPhysician)
/* 126:    */   {
/* 127:129 */     System.out.println("setting physician:" + keywordPhysician);
/* 128:130 */     this.keywordPhysician = keywordPhysician;
/* 129:131 */     String str = "";
/* 130:132 */     if (keywordPhysician.equals(this.currentPhysician)) {
/* 131:133 */       str = "Your Keywords";
/* 132:    */     } else {
/* 133:135 */       str = "Others Keywords";
/* 134:    */     }
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void setParent(Container parent)
/* 138:    */   {
/* 139:143 */     this.parent = parent;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setCurrentPhysician(String currentPhysician)
/* 143:    */   {
/* 144:147 */     System.out.println("Setting current physician:" + currentPhysician);
/* 145:148 */     this.currentPhysician = currentPhysician;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public String getCurrentPhysician()
/* 149:    */   {
/* 150:152 */     return this.currentPhysician;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void setReport(String report)
/* 154:    */   {
/* 155:156 */     this.report = report;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public String getReport()
/* 159:    */   {
/* 160:160 */     return this.report;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void setStage(String stage)
/* 164:    */   {
/* 165:164 */     this.stage = stage;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public String getStage()
/* 169:    */   {
/* 170:168 */     return this.stage;
/* 171:    */   }
/* 172:    */   
/* 173:171 */   String[] keywords = { "Key1", "Lorem Ipsium", 
/* 174:172 */     "This is a multiline keyword that spans a paragraph", 
/* 175:173 */     "Lots of Keywords", "Even More Keywords", "Comments gone crazy" };
/* 176:    */   XModel cm;
/* 177:    */   
/* 178:    */   public void setPage(XPage page)
/* 179:    */   {
/* 180:178 */     this.page = page;
/* 181:    */   }
/* 182:    */   
/* 183:    */   private Color getRowColor(int i)
/* 184:    */   {
/* 185:182 */     if (i % 2 == 0) {
/* 186:183 */       return new Color(220, 220, 220);
/* 187:    */     }
/* 188:185 */     return Color.WHITE;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void setModel(XModel cm)
/* 192:    */   {
/* 193:190 */     clearKeywords();
/* 194:191 */     int currentY = 10;
/* 195:192 */     for (int i = 0; i < cm.getNumChildren(); i++)
/* 196:    */     {
/* 197:193 */       System.out.println(">>kp " + cm.get(i).getId());
/* 198:194 */       JTextArea keywordArea = new JTextArea();
/* 199:195 */       keywordArea.setLineWrap(true);
/* 200:196 */       keywordArea.setWrapStyleWord(true);
/* 201:197 */       String text = ((XModel)cm.get(i).get("text")).get().toString();
/* 202:    */       
/* 203:    */ 
/* 204:200 */       keywordArea.setBounds(1, currentY, 125, 
/* 205:201 */         (text.length() / 20 + 1) * 15);
/* 206:202 */       currentY += (text.length() / 20 + 1) * 15;
/* 207:203 */       keywordArea.setText(text);
/* 208:    */       
/* 209:    */ 
/* 210:    */ 
/* 211:207 */       keywordArea.setName(cm.get(i).getId());
/* 212:208 */       keywordArea.addMouseListener(this);
/* 213:    */       
/* 214:    */ 
/* 215:    */ 
/* 216:    */ 
/* 217:213 */       keywordArea.setBackground(getRowColor(i));
/* 218:    */       
/* 219:215 */       keywordArea.setEditable(false);
/* 220:    */       
/* 221:217 */       this.listPanel.add(keywordArea);
/* 222:    */     }
/* 223:224 */     this.scr.doLayout();
/* 224:225 */     this.listPanel.repaint();
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void setCommentModel(XModel cm)
/* 228:    */   {
/* 229:229 */     this.cm = cm;
/* 230:230 */     display();
/* 231:    */   }
/* 232:    */   
/* 233:    */   public void display()
/* 234:    */   {
/* 235:244 */     setModel(this.cm);
/* 236:    */   }
/* 237:    */   
/* 238:247 */   String changePhyFunc = null;
/* 239:248 */   String confirmDelete = null;
/* 240:249 */   String changeKeywordPrompt = null;
/* 241:    */   
/* 242:    */   public void setCallback(String action, String function)
/* 243:    */   {
/* 244:253 */     if (action.equals("Delete")) {
/* 245:254 */       this.deleteFunc = function;
/* 246:    */     }
/* 247:257 */     if (action.equals("Save")) {
/* 248:258 */       this.saveFunc = function;
/* 249:    */     }
/* 250:261 */     if (action.equals("Cancel")) {
/* 251:262 */       this.cancelFunc = function;
/* 252:    */     }
/* 253:265 */     if (action.equals("Select")) {
/* 254:266 */       this.selectFunc = function;
/* 255:    */     }
/* 256:269 */     if (action.equals("Close")) {
/* 257:270 */       this.closeFunc = function;
/* 258:    */     }
/* 259:273 */     if (action.equals("ChangePhy")) {
/* 260:274 */       this.changePhyFunc = function;
/* 261:    */     }
/* 262:276 */     if (action.equals("ConfirmDelete")) {
/* 263:277 */       this.confirmDelete = function;
/* 264:    */     }
/* 265:279 */     if (action.equals("ChangeKeywordPrompt")) {
/* 266:280 */       this.changeKeywordPrompt = function;
/* 267:    */     }
/* 268:    */   }
/* 269:    */   
/* 270:    */   public void clearKeywords()
/* 271:    */   {
/* 272:285 */     if (this.listPanel != null)
/* 273:    */     {
/* 274:286 */       Component[] components = this.listPanel.getComponents();
/* 275:288 */       for (Component c : components) {
/* 276:289 */         if (((c instanceof JTextArea)) && 
/* 277:290 */           (!((JTextArea)c).getName().equals("commentArea"))) {
/* 278:291 */           this.listPanel.remove(c);
/* 279:    */         }
/* 280:    */       }
/* 281:    */     }
/* 282:    */   }
/* 283:    */   
/* 284:297 */   Vector items = new Vector();
/* 285:    */   
/* 286:    */   public void setCommentActionListeners()
/* 287:    */   {
/* 288:299 */     this.saveButton.addActionListener(this);
/* 289:300 */     this.editButton.addActionListener(this);
/* 290:301 */     this.deleteButton.addActionListener(this);
/* 291:302 */     this.closeButton.addActionListener(this);
/* 292:303 */     this.cancelButton.addActionListener(this);
/* 293:    */   }
/* 294:    */   
/* 295:    */   public void initCommentBox()
/* 296:    */   {
/* 297:308 */     Font buttonFont = new Font("SANS_SERIF", 1, 12);
/* 298:309 */     Color buttonColor = new Color(215, 25, 32);
/* 299:    */     
/* 300:311 */     this.editPanel.setBackground(new Color(220, 220, 220));
/* 301:312 */     this.editPanel.setBounds(560, 150, 250, 200);
/* 302:    */     
/* 303:    */ 
/* 304:    */ 
/* 305:    */ 
/* 306:317 */     this.commentArea.setOpaque(true);
/* 307:318 */     this.commentArea.setLineWrap(true);
/* 308:319 */     this.commentArea.setWrapStyleWord(true);
/* 309:    */     
/* 310:321 */     SpellChecker.registerDictionaries(null, "en");
/* 311:322 */     SpellChecker.register(this.commentArea);
/* 312:    */     
/* 313:    */ 
/* 314:325 */     XLabel commentLabel = new XLabel();
/* 315:326 */     commentLabel.setText("Keywords:");
/* 316:327 */     commentLabel.setFont(buttonFont);
/* 317:328 */     commentLabel.setBounds(3, 3, 150, 20);
/* 318:329 */     commentLabel.setForeground(Color.BLACK);
/* 319:330 */     this.editPanel.add(this.saveButton);
/* 320:331 */     this.editPanel.add(this.editButton);
/* 321:332 */     this.editPanel.add(this.deleteButton);
/* 322:333 */     this.editPanel.add(this.closeButton);
/* 323:334 */     this.editPanel.add(this.cancelButton);
/* 324:335 */     this.editPanel.add(this.commentArea);
/* 325:336 */     this.editPanel.add(commentLabel);
/* 326:337 */     this.commentArea.setName("commentArea");
/* 327:338 */     this.commentArea.setBounds(5, 25, this.editPanel.getWidth() - 10, 140);
/* 328:    */     
/* 329:    */ 
/* 330:341 */     this.commentArea.setBackground(Color.WHITE);
/* 331:342 */     this.commentArea.setForeground(Color.BLACK);
/* 332:    */     
/* 333:344 */     this.saveButton.setName("Save");
/* 334:345 */     this.saveButton.setLabel("Save");
/* 335:346 */     this.saveButton.setBounds(this.commentArea.getLocation().x, this.commentArea.getY() + 
/* 336:347 */       this.commentArea.getHeight() + 10, BUTTON_WIDTH, BUTTON_HEIGHT);
/* 337:348 */     this.editButton.setName("Edit");
/* 338:349 */     this.editButton.setLabel("Edit");
/* 339:350 */     this.editButton.setBounds(this.commentArea.getLocation().x, this.commentArea.getY() + 
/* 340:351 */       this.commentArea.getHeight() + 10, BUTTON_WIDTH, BUTTON_HEIGHT);
/* 341:352 */     this.deleteButton.setName("Delete");
/* 342:353 */     this.deleteButton.setLabel("Delete");
/* 343:354 */     this.deleteButton.setBounds(this.saveButton.getX() + this.saveButton.getWidth() + 20, 
/* 344:355 */       this.saveButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/* 345:356 */     this.closeButton.setName("Close");
/* 346:357 */     this.closeButton.setLabel("Close");
/* 347:358 */     this.closeButton.setBounds(this.deleteButton.getX() + this.deleteButton.getWidth() + 
/* 348:359 */       20, this.deleteButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/* 349:360 */     this.cancelButton.setName("Cancel");
/* 350:361 */     this.cancelButton.setLabel("Cancel");
/* 351:362 */     this.cancelButton.setBounds(this.deleteButton.getX() + this.deleteButton.getWidth() + 
/* 352:363 */       20, this.deleteButton.getY(), BUTTON_WIDTH, BUTTON_HEIGHT);
/* 353:364 */     this.cancelButton.setVisible(false);
/* 354:    */     
/* 355:366 */     this.saveButton.setBackground(buttonColor);
/* 356:367 */     this.saveButton.setForeground(Color.WHITE);
/* 357:368 */     this.saveButton.setFont(buttonFont);
/* 358:369 */     setCommentActionListeners();
/* 359:370 */     new XToolTip("Click to Save changes", this.saveButton);
/* 360:371 */     this.editButton.setBackground(buttonColor);
/* 361:372 */     this.editButton.setForeground(Color.WHITE);
/* 362:373 */     this.editButton.setFont(buttonFont);
/* 363:374 */     new XToolTip("Click to Edit this comment", this.editButton);
/* 364:375 */     this.deleteButton.setBackground(buttonColor);
/* 365:376 */     this.deleteButton.setForeground(Color.WHITE);
/* 366:377 */     this.deleteButton.setFont(buttonFont);
/* 367:378 */     new XToolTip("Click to Delete this comment", this.deleteButton);
/* 368:379 */     this.closeButton.setBackground(buttonColor);
/* 369:380 */     this.closeButton.setForeground(Color.WHITE);
/* 370:381 */     this.closeButton.setFont(buttonFont);
/* 371:382 */     new XToolTip("Close Comment Box", this.closeButton);
/* 372:383 */     this.cancelButton.setBackground(buttonColor);
/* 373:384 */     this.cancelButton.setForeground(Color.WHITE);
/* 374:385 */     this.cancelButton.setFont(buttonFont);
/* 375:386 */     new XToolTip("Cancel Changes", this.cancelButton);
/* 376:    */   }
/* 377:    */   
/* 378:    */   public void init()
/* 379:    */   {
/* 380:390 */     Font buttonFont = new Font("SANS_SERIF", 1, 12);
/* 381:391 */     Color buttonColor = new Color(215, 25, 32);
/* 382:    */     
/* 383:    */ 
/* 384:394 */     setLayout(new FlowLayout());
/* 385:    */     
/* 386:396 */     initCommentBox();
/* 387:    */     
/* 388:    */ 
/* 389:399 */     System.out.println(" parent=" + getParent());
/* 390:    */   }
/* 391:    */   
/* 392:    */   public XPanel getMainPanel()
/* 393:    */   {
/* 394:404 */     return this.mainPanel;
/* 395:    */   }
/* 396:    */   
/* 397:    */   public XPanel getEditPanel()
/* 398:    */   {
/* 399:408 */     return this.editPanel;
/* 400:    */   }
/* 401:    */   
/* 402:    */   public static void main(String[] args)
/* 403:    */   {
/* 404:412 */     String[] strArray = { "Hello! This is a very long comment", 
/* 405:413 */       "This is another comment" };
/* 406:    */     
/* 407:    */ 
/* 408:416 */     Frame frame = new Frame("KeywordPanel1");
/* 409:    */     
/* 410:418 */     XProjectManager.getCurrentProject().setAppFrame(frame);
/* 411:    */     
/* 412:420 */     XProjectManager.getCurrentProject().initialise("startup.properties");
/* 413:421 */     frame.setBounds(10, 10, 800, 600);
/* 414:    */     
/* 415:423 */     KeywordPanel1 kp = new KeywordPanel1(new XPanel(), new JTextArea(), null);
/* 416:424 */     kp.setBounds(0, 0, 100, 500);
/* 417:    */     
/* 418:426 */     XModel xm = new XBaseModel();
/* 419:427 */     String parentPath = "/cme/01200001_01_02/Coding/Comments/9";
/* 420:428 */     kp.setCurrentPhysician("9");
/* 421:429 */     kp.setReport("01200001_01_02");
/* 422:430 */     TestXUIDB.getInstance().getKeyValues(xm, "keyvalue", parentPath);
/* 423:    */     
/* 424:432 */     kp.setParent(frame);
/* 425:433 */     kp.init();
/* 426:434 */     kp.setCommentModel(xm);
/* 427:435 */     kp.display();
/* 428:    */     
/* 429:    */ 
/* 430:    */ 
/* 431:    */ 
/* 432:    */ 
/* 433:    */ 
/* 434:    */ 
/* 435:    */ 
/* 436:    */ 
/* 437:    */ 
/* 438:    */ 
/* 439:    */ 
/* 440:448 */     frame.add(kp);
/* 441:449 */     frame.repaint();
/* 442:    */     
/* 443:451 */     frame.addWindowListener(new WindowAdapter()
/* 444:    */     {
/* 445:    */       public void windowClosing(WindowEvent w)
/* 446:    */       {
/* 447:453 */         System.exit(0);
/* 448:    */       }
/* 449:455 */     });
/* 450:456 */     frame.setVisible(true);
/* 451:    */   }
/* 452:    */   
/* 453:    */   public void mouseClicked(MouseEvent arg0) {}
/* 454:    */   
/* 455:    */   public void setMode(String mode)
/* 456:    */   {
/* 457:489 */     System.out.println("KeywordPanel1.setMode(" + mode + ")");
/* 458:490 */     if (mode.equals("New"))
/* 459:    */     {
/* 460:491 */       setEditable(true);
/* 461:492 */       this.deleteButton.setVisible(false);
/* 462:    */     }
/* 463:493 */     else if (mode.equals("Edit"))
/* 464:    */     {
/* 465:494 */       setEditable(true);
/* 466:    */     }
/* 467:495 */     else if (mode.equals("showEditable"))
/* 468:    */     {
/* 469:496 */       setEditable(false);
/* 470:    */     }
/* 471:497 */     else if (mode.equals("showUnEditable"))
/* 472:    */     {
/* 473:498 */       setEditable(false);
/* 474:499 */       this.deleteButton.setVisible(false);
/* 475:500 */       this.editButton.setVisible(false);
/* 476:    */     }
/* 477:502 */     showCommentPanel(true);
/* 478:    */   }
/* 479:    */   
/* 480:    */   public int getLastComment()
/* 481:    */   {
/* 482:506 */     String maxId = "";
/* 483:507 */     for (int i = 0; i < this.cm.getNumChildren(); i++) {
/* 484:509 */       if (this.cm.get(i).getId().compareTo(maxId) > 0) {
/* 485:510 */         maxId = this.cm.get(i).getId();
/* 486:    */       }
/* 487:    */     }
/* 488:513 */     if (maxId.equals("")) {
/* 489:514 */       return 0;
/* 490:    */     }
/* 491:516 */     return Integer.parseInt(maxId.substring("comments".length()));
/* 492:    */   }
/* 493:    */   
/* 494:519 */   String mode = "Edit";
/* 495:    */   
/* 496:    */   public void selectComment(String comment)
/* 497:    */   {
/* 498:522 */     System.out.println("CurrentSelected::" + this.currentSelected);
/* 499:523 */     if ((this.currentSelected != -1) && 
/* 500:524 */       (this.listPanel.getComponents().length > this.currentSelected)) {
/* 501:525 */       this.listPanel.getComponent(this.currentSelected).setBackground(
/* 502:526 */         getRowColor(this.currentSelected));
/* 503:    */     }
/* 504:528 */     setEditable(false);
/* 505:529 */     for (int i = 0; i < this.cm.getNumChildren(); i++) {
/* 506:530 */       if (this.cm.get(i).getId().equals(comment))
/* 507:    */       {
/* 508:532 */         this.currentSelected = i;
/* 509:533 */         this.commentArea.setText(((XModel)this.cm.get(i).get("text")).get()
/* 510:534 */           .toString());
/* 511:535 */         this.listPanel.getComponent(i).setBackground(Color.YELLOW);
/* 512:536 */         System.out.println("currPhy:" + this.currentPhysician + 
/* 513:537 */           " keywordPhy::" + this.keywordPhysician);
/* 514:538 */         this.page.evaluateAttribute("${" + this.selectFunc + "(" + this.stage + 
/* 515:539 */           "-" + this.keywordPhysician + "-" + comment + ")}");
/* 516:541 */         if (this.currentPhysician.equals(this.keywordPhysician))
/* 517:    */         {
/* 518:546 */           setMode("showEditable"); break;
/* 519:    */         }
/* 520:553 */         setMode("showUnEditable");
/* 521:    */         
/* 522:555 */         break;
/* 523:    */       }
/* 524:    */     }
/* 525:    */   }
/* 526:    */   
/* 527:    */   public void addComment(XModel cm1)
/* 528:    */   {
/* 529:563 */     String commId = getLastComment() + 1;
/* 530:564 */     cm1.setId("comments" + commId);
/* 531:565 */     this.cm.append(cm1);
/* 532:566 */     display();
/* 533:567 */     selectComment("comments" + commId);
/* 534:568 */     showCommentPanel(true);
/* 535:569 */     setEditable(true);
/* 536:570 */     this.newComment = true;
/* 537:    */   }
/* 538:    */   
/* 539:    */   public void changeKeywordPrompt()
/* 540:    */   {
/* 541:576 */     this.mp.setAction("OK", "DeleteOK");
/* 542:577 */     this.mp.okButton.addActionListener(this);
/* 543:578 */     this.mp.setTitle("Enter Keyword");
/* 544:579 */     this.mp.setMessage("Please enter a keyword to continue");
/* 545:580 */     this.mp.setBounds(600, 200, 300, 100);
/* 546:581 */     this.mp.init();
/* 547:582 */     this.mp.remove(this.mp.cancelButton);
/* 548:583 */     this.mp.okButton.setBounds((this.mp.getWidth() - 80) / 2, this.mp.getHeight() - 3 * 3 - 20, 80, 20);
/* 549:    */     
/* 550:    */ 
/* 551:    */ 
/* 552:587 */     this.mp.setVisible(true);
/* 553:    */   }
/* 554:    */   
/* 555:    */   public boolean saveComment()
/* 556:    */     throws Exception
/* 557:    */   {
/* 558:593 */     System.out.println("Inside KeywordPanel1.saveComment()");
/* 559:    */     
/* 560:595 */     String path = "/cme/" + this.report + "/Coding/Comments/" + this.currentPhysician;
/* 561:    */     
/* 562:597 */     String text = this.commentArea.getText();
/* 563:599 */     if (text.trim().equals(""))
/* 564:    */     {
/* 565:600 */       System.out.println("Keyword is empty");
/* 566:601 */       this.page.evaluateAttribute("${" + this.changeKeywordPrompt + "()}");
/* 567:602 */       return false;
/* 568:    */     }
/* 569:604 */     System.out.println("Keyword is not empty");
/* 570:    */     
/* 571:606 */     text = text.replaceAll("[^A-Z^a-z^0-9^\\s]", " ");
/* 572:607 */     ((XModel)getSelectedComment().get("text")).set(text);
/* 573:608 */     System.out.println("Text::" + text);
/* 574:    */     
/* 575:610 */     TestXUIDB.getInstance().saveTree(getSelectedComment(), "keyvalue", 
/* 576:611 */       path);
/* 577:612 */     if (this.saveFunc != null) {
/* 578:613 */       this.page.evaluateAttribute("${" + this.saveFunc + "()}");
/* 579:    */     }
/* 580:615 */     showCommentPanel(false);
/* 581:616 */     display();
/* 582:617 */     this.disableSelect = false;
/* 583:618 */     setEditable(false);
/* 584:    */     
/* 585:    */ 
/* 586:621 */     return true;
/* 587:    */   }
/* 588:    */   
/* 589:    */   public void mouseEntered(MouseEvent arg0) {}
/* 590:    */   
/* 591:    */   public void mouseExited(MouseEvent arg0) {}
/* 592:    */   
/* 593:    */   public void mousePressed(MouseEvent arg0)
/* 594:    */   {
/* 595:633 */     if (this.disableSelect) {
/* 596:634 */       return;
/* 597:    */     }
/* 598:636 */     this.commentArea.setText(((JTextArea)arg0.getSource()).getText());
/* 599:    */     
/* 600:    */ 
/* 601:639 */     System.out.println("TextArea::" + 
/* 602:640 */       ((JTextArea)arg0.getSource()).getName());
/* 603:641 */     selectComment(((JTextArea)arg0.getSource()).getName());
/* 604:    */     
/* 605:643 */     showCommentPanel(true);
/* 606:    */   }
/* 607:    */   
/* 608:    */   public void mouseReleased(MouseEvent arg0) {}
/* 609:    */   
/* 610:    */   public void setEditable(boolean status)
/* 611:    */   {
/* 612:652 */     System.out.println("KeywordPanel.setEditable(" + status + ")");
/* 613:653 */     this.disableSelect = status;
/* 614:654 */     this.saveButton.setVisible(status);
/* 615:655 */     this.editButton.setVisible(!status);
/* 616:656 */     this.deleteButton.setVisible(!status);
/* 617:657 */     this.commentArea.setEditable(status);
/* 618:658 */     this.closeButton.setVisible(!status);
/* 619:659 */     this.cancelButton.setVisible(status);
/* 620:    */     
/* 621:    */ 
/* 622:    */ 
/* 623:    */ 
/* 624:    */ 
/* 625:    */ 
/* 626:    */ 
/* 627:    */ 
/* 628:    */ 
/* 629:    */ 
/* 630:    */ 
/* 631:    */ 
/* 632:    */ 
/* 633:    */ 
/* 634:    */ 
/* 635:    */ 
/* 636:    */ 
/* 637:    */ 
/* 638:    */ 
/* 639:    */ 
/* 640:    */ 
/* 641:    */ 
/* 642:    */ 
/* 643:    */ 
/* 644:    */ 
/* 645:    */ 
/* 646:    */ 
/* 647:687 */     System.out.println(this.currentPhysician + " " + this.keywordPhysician);
/* 648:688 */     if (!this.currentPhysician.equals(this.keywordPhysician))
/* 649:    */     {
/* 650:692 */       this.editButton.setVisible(false);
/* 651:693 */       this.deleteButton.setVisible(false);
/* 652:    */     }
/* 653:695 */     this.editPanel.repaint();
/* 654:    */   }
/* 655:    */   
/* 656:    */   public void showMainPanel()
/* 657:    */   {
/* 658:700 */     this.mainPanel.setBounds(315, 90, 150, 209);
/* 659:    */     
/* 660:    */ 
/* 661:    */ 
/* 662:    */ 
/* 663:    */ 
/* 664:    */ 
/* 665:    */ 
/* 666:708 */     System.out.println(" Hiding 1");
/* 667:    */     
/* 668:710 */     System.out.println(" Hiding 2");
/* 669:    */   }
/* 670:    */   
/* 671:    */   public void hideMainPanel()
/* 672:    */   {
/* 673:720 */     this.mainPanel.setBounds(315, 90, 150, 30);
/* 674:    */     
/* 675:    */ 
/* 676:    */ 
/* 677:    */ 
/* 678:    */ 
/* 679:    */ 
/* 680:    */ 
/* 681:    */ 
/* 682:    */ 
/* 683:730 */     System.out.println(" Hiding 1");
/* 684:    */     
/* 685:732 */     System.out.println(" Hiding 2");
/* 686:    */     
/* 687:    */ 
/* 688:735 */     this.mainPanel.doLayout();
/* 689:    */   }
/* 690:    */   
/* 691:    */   public void removeMainPanel()
/* 692:    */   {
/* 693:741 */     this.parent.remove(this.mainPanel);
/* 694:    */   }
/* 695:    */   
/* 696:    */   public void addMainPanel()
/* 697:    */   {
/* 698:745 */     this.parent.add(this.mainPanel, 0);
/* 699:    */   }
/* 700:    */   
/* 701:748 */   public MessagePanel mp = new MessagePanel();
/* 702:    */   
/* 703:    */   public void confirmDelete()
/* 704:    */   {
/* 705:751 */     this.mp = new MessagePanel();
/* 706:    */     
/* 707:753 */     this.mp.setAction("OK", "DeleteOK");
/* 708:754 */     this.mp.okButton.addActionListener(this);
/* 709:755 */     this.mp.setTitle("Delete Keyword");
/* 710:756 */     this.mp.setMessage("Are you sure you want to delete this comment?");
/* 711:757 */     this.mp.init();
/* 712:758 */     this.mp.repaint();
/* 713:    */     
/* 714:    */ 
/* 715:    */ 
/* 716:    */ 
/* 717:763 */     this.mp.repaint();
/* 718:    */   }
/* 719:    */   
/* 720:    */   public XModel getSelectedComment()
/* 721:    */   {
/* 722:768 */     return this.cm.get(this.currentSelected);
/* 723:    */   }
/* 724:    */   
/* 725:771 */   boolean disableSelect = false;
/* 726:    */   
/* 727:    */   public void deleteComment1()
/* 728:    */   {
/* 729:775 */     String path = "/cme/" + this.report + "/Coding/Comments/" + 
/* 730:776 */       this.currentPhysician + "/" + getSelectedComment().getId();
/* 731:    */     try
/* 732:    */     {
/* 733:778 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/text");
/* 734:779 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/x");
/* 735:780 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/y");
/* 736:781 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/endx");
/* 737:782 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/endy");
/* 738:783 */       TestXUIDB.getInstance().deleteKeyValue("keyvalue", path + "/stage");
/* 739:785 */       if (this.deleteFunc != null) {
/* 740:786 */         this.page.evaluateAttribute("${" + this.deleteFunc + "()}");
/* 741:    */       }
/* 742:788 */       ((XBaseModel)this.cm).removeChild(getSelectedComment().getId());
/* 743:    */       
/* 744:790 */       display();
/* 745:791 */       setEditable(false);
/* 746:    */       
/* 747:    */ 
/* 748:    */ 
/* 749:795 */       this.disableSelect = false;
/* 750:796 */       showCommentPanel(false);
/* 751:    */     }
/* 752:    */     catch (Exception e)
/* 753:    */     {
/* 754:798 */       e.printStackTrace();
/* 755:    */     }
/* 756:    */   }
/* 757:    */   
/* 758:    */   public void showCommentPanel(boolean b)
/* 759:    */   {
/* 760:804 */     this.editPanel.setVisible(b);
/* 761:    */   }
/* 762:    */   
/* 763:832 */   private boolean newComment = false;
/* 764:    */   
/* 765:    */   public void actionPerformed(ActionEvent arg0)
/* 766:    */   {
/* 767:836 */     if (arg0.getActionCommand().equals("Save"))
/* 768:    */     {
/* 769:    */       try
/* 770:    */       {
/* 771:838 */         if (!saveComment()) {
/* 772:    */           return;
/* 773:    */         }
/* 774:839 */         this.newComment = false;
/* 775:840 */         setEditable(false);
/* 776:    */       }
/* 777:    */       catch (Exception e)
/* 778:    */       {
/* 779:844 */         e.printStackTrace();
/* 780:    */       }
/* 781:    */     }
/* 782:847 */     else if (arg0.getActionCommand().equals("Edit"))
/* 783:    */     {
/* 784:848 */       setEditable(true);
/* 785:    */     }
/* 786:849 */     else if (arg0.getActionCommand().equals("Close"))
/* 787:    */     {
/* 788:850 */       this.disableSelect = false;
/* 789:851 */       this.page.evaluateAttribute("${" + this.closeFunc + "()}");
/* 790:    */       
/* 791:853 */       showCommentPanel(false);
/* 792:    */     }
/* 793:854 */     else if (arg0.getActionCommand().equals("Delete"))
/* 794:    */     {
/* 795:855 */       System.out.println("Confirm");
/* 796:856 */       this.page.evaluateAttribute("${" + this.confirmDelete + "()}");
/* 797:    */     }
/* 798:858 */     else if (arg0.getActionCommand().equals("DeleteOK"))
/* 799:    */     {
/* 800:859 */       System.out.println("Deleting Comment");
/* 801:    */       try
/* 802:    */       {
/* 803:861 */         deleteComment1();
/* 804:    */       }
/* 805:    */       catch (NullPointerException e)
/* 806:    */       {
/* 807:863 */         e.printStackTrace();
/* 808:    */       }
/* 809:    */     }
/* 810:866 */     else if (arg0.getActionCommand().equals("Cancel"))
/* 811:    */     {
/* 812:867 */       if (this.newComment) {
/* 813:870 */         ((XBaseModel)this.cm).removeChild(getSelectedComment().getId());
/* 814:    */       }
/* 815:872 */       this.disableSelect = false;
/* 816:873 */       this.editPanel.setVisible(false);
/* 817:874 */       this.page.evaluateAttribute("${" + this.cancelFunc + "()}");
/* 818:875 */       display();
/* 819:876 */       this.newComment = false;
/* 820:    */     }
/* 821:877 */     else if (arg0.getActionCommand().equals("hide"))
/* 822:    */     {
/* 823:878 */       hideMainPanel();
/* 824:    */     }
/* 825:880 */     else if (arg0.getActionCommand().equals("show"))
/* 826:    */     {
/* 827:881 */       showMainPanel();
/* 828:    */     }
/* 829:882 */     else if (arg0.getActionCommand().equals("ChangePhy"))
/* 830:    */     {
/* 831:883 */       String phy = null;
/* 832:884 */       if (this.keywordPhysician.equals(this.physicians.get(0))) {
/* 833:885 */         phy = (String)this.physicians.get(1);
/* 834:886 */       } else if (this.keywordPhysician.equals(this.physicians.get(1))) {
/* 835:887 */         phy = (String)this.physicians.get(0);
/* 836:    */       }
/* 837:889 */       System.out.println("changePhyFunc::${" + this.changePhyFunc + "(" + 
/* 838:890 */         phy + ")}");
/* 839:891 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + phy + ")}");
/* 840:    */     }
/* 841:    */   }
/* 842:    */   
/* 843:    */   public void focusGained(FocusEvent arg0) {}
/* 844:    */   
/* 845:    */   public void focusLost(FocusEvent arg0)
/* 846:    */   {
/* 847:902 */     System.out.println(" Focus Lost 111");
/* 848:    */   }
/* 849:    */   
/* 850:    */   public void reset()
/* 851:    */   {
/* 852:907 */     hideMainPanel();
/* 853:    */   }
/* 854:    */   
/* 855:    */   public void itemStateChanged(ItemEvent arg0)
/* 856:    */   {
/* 857:911 */     XComboBox xc = (XComboBox)arg0.getSource();
/* 858:912 */     System.out.println("Item::" + arg0.getItem());
/* 859:913 */     String otherPhysician = this.physicians.get(0).equals(this.currentPhysician) ? this.physicians
/* 860:914 */       .get(1).toString() : this.physicians.get(0).toString();
/* 861:915 */     if (getStage().equals("Adjudication"))
/* 862:    */     {
/* 863:916 */       if (arg0.getItem().equals("First Physician")) {
/* 864:917 */         this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 865:918 */           this.physicians.get(0) + ")}");
/* 866:919 */       } else if (arg0.getItem().equals("Second Physician")) {
/* 867:920 */         this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 868:921 */           this.physicians.get(1) + ")}");
/* 869:    */       }
/* 870:    */     }
/* 871:924 */     else if (arg0.getItem().equals("Your Keywords")) {
/* 872:925 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 873:926 */         this.currentPhysician + ")}");
/* 874:927 */     } else if (arg0.getItem().equals("Others Keywords")) {
/* 875:928 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 876:929 */         otherPhysician + ")}");
/* 877:    */     }
/* 878:    */   }
/* 879:    */   
/* 880:    */   public void setTitle(String title)
/* 881:    */   {
/* 882:935 */     this.heading.setText(title);
/* 883:936 */     repaint();
/* 884:    */   }
/* 885:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.KeywordPanel
 * JD-Core Version:    0.7.0.1
 */