/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.event.ActionEvent;
/*  4:   */ import javax.swing.JEditorPane;
/*  5:   */ import javax.swing.text.MutableAttributeSet;
/*  6:   */ import javax.swing.text.SimpleAttributeSet;
/*  7:   */ import javax.swing.text.StyleConstants;
/*  8:   */ import javax.swing.text.StyledEditorKit;
/*  9:   */ import javax.swing.text.StyledEditorKit.StyledTextAction;
/* 10:   */ 
/* 11:   */ class BoldAction
/* 12:   */   extends StyledEditorKit.StyledTextAction
/* 13:   */ {
/* 14:   */   private static final long serialVersionUID = 9174670038684056758L;
/* 15:   */   
/* 16:   */   public BoldAction()
/* 17:   */   {
/* 18:80 */     super("font-bold");
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String toString()
/* 22:   */   {
/* 23:84 */     return "Bold";
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void actionPerformed(ActionEvent e)
/* 27:   */   {
/* 28:88 */     JEditorPane editor = getEditor(e);
/* 29:89 */     if (editor != null)
/* 30:   */     {
/* 31:90 */       StyledEditorKit kit = getStyledEditorKit(editor);
/* 32:91 */       MutableAttributeSet attr = kit.getInputAttributes();
/* 33:92 */       boolean bold = !StyleConstants.isBold(attr);
/* 34:93 */       SimpleAttributeSet sas = new SimpleAttributeSet();
/* 35:94 */       StyleConstants.setBold(sas, bold);
/* 36:95 */       setCharacterAttributes(editor, sas, false);
/* 37:   */     }
/* 38:   */   }
/* 39:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.BoldAction
 * JD-Core Version:    0.7.0.1
 */