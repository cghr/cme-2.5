/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import com.kentropy.db.TestXUIDB;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.FlowLayout;
/*   8:    */ import java.awt.Font;
/*   9:    */ import java.awt.Frame;
/*  10:    */ import java.awt.event.FocusEvent;
/*  11:    */ import java.awt.event.FocusListener;
/*  12:    */ import java.awt.event.ItemEvent;
/*  13:    */ import java.awt.event.ItemListener;
/*  14:    */ import java.awt.event.MouseEvent;
/*  15:    */ import java.awt.event.MouseListener;
/*  16:    */ import java.awt.event.WindowAdapter;
/*  17:    */ import java.awt.event.WindowEvent;
/*  18:    */ import java.io.PrintStream;
/*  19:    */ import java.util.Vector;
/*  20:    */ import javax.swing.JTextArea;
/*  21:    */ import net.xoetrope.awt.XButton;
/*  22:    */ import net.xoetrope.awt.XComboBox;
/*  23:    */ import net.xoetrope.awt.XLabel;
/*  24:    */ import net.xoetrope.awt.XPanel;
/*  25:    */ import net.xoetrope.awt.XScrollPane;
/*  26:    */ import net.xoetrope.xui.XPage;
/*  27:    */ import net.xoetrope.xui.XProject;
/*  28:    */ import net.xoetrope.xui.XProjectManager;
/*  29:    */ import net.xoetrope.xui.data.XBaseModel;
/*  30:    */ import net.xoetrope.xui.data.XModel;
/*  31:    */ 
/*  32:    */ public class KeywordListPanel
/*  33:    */   extends XPanel
/*  34:    */   implements MouseListener, FocusListener, ItemListener
/*  35:    */ {
/*  36: 42 */   KeywordListPanel kp = null;
/*  37: 44 */   Vector physicians = new Vector();
/*  38:    */   
/*  39:    */   public Vector getPhysicians()
/*  40:    */   {
/*  41: 47 */     return this.physicians;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setPhysicians(Vector physicians)
/*  45:    */   {
/*  46: 51 */     this.physicians = physicians;
/*  47:    */   }
/*  48:    */   
/*  49: 64 */   XPage page = null;
/*  50: 66 */   Container parent = null;
/*  51: 68 */   private static int BUTTON_WIDTH = 50;
/*  52: 69 */   private static int BUTTON_HEIGHT = 20;
/*  53: 71 */   int currentSelected = -1;
/*  54: 72 */   XScrollPane scr = new XScrollPane();
/*  55: 74 */   XPanel listPanel = null;
/*  56:    */   private static final int ROWS = 1;
/*  57:    */   private static final int COLUMNS = 8;
/*  58: 78 */   private String deleteFunc = null;
/*  59: 79 */   private String saveFunc = null;
/*  60: 80 */   private String cancelFunc = null;
/*  61: 81 */   private String closeFunc = null;
/*  62: 82 */   private String selectFunc = null;
/*  63: 83 */   private String currentPhysician = null;
/*  64: 84 */   private String report = null;
/*  65: 85 */   private String stage = null;
/*  66: 86 */   private JTextArea commentArea = null;
/*  67: 87 */   private XLabel heading = null;
/*  68: 92 */   public String keywordPhysician = null;
/*  69:    */   
/*  70:    */   public KeywordListPanel(XPanel mainPanel, JTextArea commentArea, XButton[] xb) {}
/*  71:    */   
/*  72:    */   public KeywordListPanel() {}
/*  73:    */   
/*  74:    */   public String getKeywordPhysician()
/*  75:    */   {
/*  76: 95 */     return this.keywordPhysician;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void init()
/*  80:    */   {
/*  81:100 */     Font buttonFont = new Font("SANS_SERIF", 1, 12);
/*  82:101 */     Color buttonColor = new Color(215, 25, 32);
/*  83:102 */     this.listPanel = new XPanel();
/*  84:    */     
/*  85:104 */     setLayout(new FlowLayout());
/*  86:    */     
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:121 */     this.scr.setBounds(0, 20, 150, 180);
/* 103:122 */     this.listPanel = new XPanel();
/* 104:    */     
/* 105:124 */     this.listPanel.setBounds(2, 2, 170, 1000);
/* 106:    */     
/* 107:126 */     FlowLayout flow = new FlowLayout();
/* 108:    */     
/* 109:    */ 
/* 110:129 */     this.scr.add(this.listPanel);
/* 111:    */     
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:138 */     this.heading = new XLabel();
/* 120:    */     
/* 121:140 */     this.heading.setFont(new Font("SansSerif", 1, 12));
/* 122:    */     
/* 123:142 */     this.heading.setForeground(Color.BLACK);
/* 124:    */     
/* 125:    */ 
/* 126:145 */     this.heading.setBounds(0, 0, 150, 20);
/* 127:146 */     this.heading.setBackground(new Color(220, 220, 220));
/* 128:    */     
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:    */ 
/* 135:    */ 
/* 136:    */ 
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:164 */     add(this.scr);
/* 146:165 */     add(this.heading);
/* 147:    */     
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:173 */     System.out.println(" parent=" + getParent());
/* 155:    */     
/* 156:175 */     addMainPanel();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setKeywordPhysician(String keywordPhysician)
/* 160:    */   {
/* 161:182 */     System.out.println("setting physician:" + keywordPhysician);
/* 162:183 */     this.keywordPhysician = keywordPhysician;
/* 163:184 */     String str = "";
/* 164:185 */     if (keywordPhysician.equals(this.currentPhysician)) {
/* 165:186 */       str = "Your Keywords";
/* 166:    */     } else {
/* 167:188 */       str = "Others Keywords";
/* 168:    */     }
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void setParent(Container parent)
/* 172:    */   {
/* 173:196 */     this.parent = parent;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public void setCurrentPhysician(String currentPhysician)
/* 177:    */   {
/* 178:200 */     System.out.println("Setting current physician:" + currentPhysician);
/* 179:201 */     this.currentPhysician = currentPhysician;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public String getCurrentPhysician()
/* 183:    */   {
/* 184:205 */     return this.currentPhysician;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void setReport(String report)
/* 188:    */   {
/* 189:209 */     this.report = report;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public String getReport()
/* 193:    */   {
/* 194:213 */     return this.report;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public void setStage(String stage)
/* 198:    */   {
/* 199:217 */     this.stage = stage;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public String getStage()
/* 203:    */   {
/* 204:221 */     return this.stage;
/* 205:    */   }
/* 206:    */   
/* 207:224 */   String[] keywords = { "Key1", "Lorem Ipsium", 
/* 208:225 */     "This is a multiline keyword that spans a paragraph", 
/* 209:226 */     "Lots of Keywords", "Even More Keywords", "Comments gone crazy" };
/* 210:    */   XModel cm;
/* 211:    */   
/* 212:    */   public void setPage(XPage page)
/* 213:    */   {
/* 214:231 */     this.page = page;
/* 215:    */   }
/* 216:    */   
/* 217:    */   private Color getRowColor(int i)
/* 218:    */   {
/* 219:235 */     if (i % 2 == 0) {
/* 220:236 */       return new Color(220, 220, 220);
/* 221:    */     }
/* 222:238 */     return Color.WHITE;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public void setModel(XModel cm)
/* 226:    */   {
/* 227:243 */     clearKeywords();
/* 228:244 */     int currentY = 10;
/* 229:245 */     for (int i = 0; i < cm.getNumChildren(); i++)
/* 230:    */     {
/* 231:246 */       System.out.println(">>kp " + cm.get(i).getId());
/* 232:247 */       JTextArea keywordArea = new JTextArea();
/* 233:248 */       keywordArea.setLineWrap(true);
/* 234:249 */       keywordArea.setWrapStyleWord(true);
/* 235:250 */       String text = ((XModel)cm.get(i).get("text")).get().toString();
/* 236:    */       
/* 237:    */ 
/* 238:253 */       keywordArea.setBounds(1, currentY, 125, 
/* 239:254 */         (text.length() / 20 + 1) * 15);
/* 240:255 */       currentY += (text.length() / 20 + 1) * 15;
/* 241:256 */       keywordArea.setText(text);
/* 242:    */       
/* 243:    */ 
/* 244:    */ 
/* 245:260 */       keywordArea.setName(cm.get(i).getId());
/* 246:261 */       keywordArea.addMouseListener(this);
/* 247:    */       
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:266 */       keywordArea.setBackground(getRowColor(i));
/* 252:    */       
/* 253:268 */       keywordArea.setEditable(false);
/* 254:    */       
/* 255:270 */       this.listPanel.add(keywordArea);
/* 256:    */     }
/* 257:277 */     this.scr.doLayout();
/* 258:278 */     this.listPanel.repaint();
/* 259:    */   }
/* 260:    */   
/* 261:    */   public void setCommentModel(XModel cm)
/* 262:    */   {
/* 263:282 */     this.cm = cm;
/* 264:283 */     display();
/* 265:    */   }
/* 266:    */   
/* 267:    */   public void display()
/* 268:    */   {
/* 269:297 */     setModel(this.cm);
/* 270:    */   }
/* 271:    */   
/* 272:300 */   String changePhyFunc = null;
/* 273:301 */   String confirmDelete = null;
/* 274:302 */   String changeKeywordPrompt = null;
/* 275:    */   
/* 276:    */   public void setCallback(String action, String function)
/* 277:    */   {
/* 278:306 */     if (action.equals("Delete")) {
/* 279:307 */       this.deleteFunc = function;
/* 280:    */     }
/* 281:310 */     if (action.equals("Save")) {
/* 282:311 */       this.saveFunc = function;
/* 283:    */     }
/* 284:314 */     if (action.equals("Cancel")) {
/* 285:315 */       this.cancelFunc = function;
/* 286:    */     }
/* 287:318 */     if (action.equals("Select")) {
/* 288:319 */       this.selectFunc = function;
/* 289:    */     }
/* 290:322 */     if (action.equals("Close")) {
/* 291:323 */       this.closeFunc = function;
/* 292:    */     }
/* 293:326 */     if (action.equals("ChangePhy")) {
/* 294:327 */       this.changePhyFunc = function;
/* 295:    */     }
/* 296:329 */     if (action.equals("ConfirmDelete")) {
/* 297:330 */       this.confirmDelete = function;
/* 298:    */     }
/* 299:332 */     if (action.equals("ChangeKeywordPrompt")) {
/* 300:333 */       this.changeKeywordPrompt = function;
/* 301:    */     }
/* 302:    */   }
/* 303:    */   
/* 304:    */   public void clearKeywords()
/* 305:    */   {
/* 306:338 */     if (this.listPanel != null)
/* 307:    */     {
/* 308:339 */       Component[] components = this.listPanel.getComponents();
/* 309:341 */       for (Component c : components) {
/* 310:342 */         if (((c instanceof JTextArea)) && 
/* 311:343 */           (!((JTextArea)c).getName().equals("commentArea"))) {
/* 312:344 */           this.listPanel.remove(c);
/* 313:    */         }
/* 314:    */       }
/* 315:    */     }
/* 316:    */   }
/* 317:    */   
/* 318:350 */   Vector items = new Vector();
/* 319:    */   
/* 320:    */   public void initold()
/* 321:    */   {
/* 322:354 */     Font buttonFont = new Font("SANS_SERIF", 1, 12);
/* 323:355 */     Color buttonColor = new Color(215, 25, 32);
/* 324:    */     
/* 325:    */ 
/* 326:358 */     setLayout(new FlowLayout());
/* 327:    */     
/* 328:    */ 
/* 329:    */ 
/* 330:362 */     System.out.println(" parent=" + getParent());
/* 331:    */   }
/* 332:    */   
/* 333:    */   public XPanel getMainPanel()
/* 334:    */   {
/* 335:367 */     return this;
/* 336:    */   }
/* 337:    */   
/* 338:    */   public XPanel getEditPanel()
/* 339:    */   {
/* 340:371 */     return null;
/* 341:    */   }
/* 342:    */   
/* 343:    */   public static void main(String[] args)
/* 344:    */   {
/* 345:375 */     String[] strArray = { "Hello! This is a very long comment", 
/* 346:376 */       "This is another comment" };
/* 347:    */     
/* 348:    */ 
/* 349:379 */     Frame frame = new Frame("KeywordPanel1");
/* 350:    */     
/* 351:381 */     XProjectManager.getCurrentProject().setAppFrame(frame);
/* 352:    */     
/* 353:383 */     XProjectManager.getCurrentProject().initialise("startup.properties");
/* 354:384 */     frame.setBounds(10, 10, 800, 600);
/* 355:    */     
/* 356:386 */     KeywordListPanel kp = new KeywordListPanel();
/* 357:387 */     kp.setBounds(0, 0, 100, 500);
/* 358:    */     
/* 359:389 */     XModel xm = new XBaseModel();
/* 360:390 */     String parentPath = "/cme/01100009_01_01/Coding/Comments/9";
/* 361:391 */     kp.setCurrentPhysician("9");
/* 362:392 */     kp.setReport("01200001_01_02");
/* 363:393 */     TestXUIDB.getInstance().getKeyValues(xm, "keyvalue", parentPath);
/* 364:    */     
/* 365:395 */     kp.setParent(frame);
/* 366:396 */     kp.init();
/* 367:397 */     kp.setCommentModel(xm);
/* 368:398 */     kp.display();
/* 369:    */     
/* 370:    */ 
/* 371:    */ 
/* 372:    */ 
/* 373:    */ 
/* 374:    */ 
/* 375:    */ 
/* 376:    */ 
/* 377:    */ 
/* 378:    */ 
/* 379:    */ 
/* 380:    */ 
/* 381:411 */     frame.add(kp);
/* 382:412 */     frame.repaint();
/* 383:    */     
/* 384:414 */     frame.addWindowListener(new WindowAdapter()
/* 385:    */     {
/* 386:    */       public void windowClosing(WindowEvent w)
/* 387:    */       {
/* 388:416 */         System.exit(0);
/* 389:    */       }
/* 390:418 */     });
/* 391:419 */     frame.setVisible(true);
/* 392:    */   }
/* 393:    */   
/* 394:    */   public void mouseClicked(MouseEvent arg0) {}
/* 395:    */   
/* 396:    */   public int getLastComment()
/* 397:    */   {
/* 398:453 */     String maxId = "";
/* 399:454 */     for (int i = 0; i < this.cm.getNumChildren(); i++) {
/* 400:456 */       if (this.cm.get(i).getId().compareTo(maxId) > 0) {
/* 401:457 */         maxId = this.cm.get(i).getId();
/* 402:    */       }
/* 403:    */     }
/* 404:460 */     if (maxId.equals("")) {
/* 405:461 */       return 0;
/* 406:    */     }
/* 407:463 */     return Integer.parseInt(maxId.substring("comments".length()));
/* 408:    */   }
/* 409:    */   
/* 410:466 */   String mode = "Edit";
/* 411:    */   
/* 412:    */   public void selectComment(String comment)
/* 413:    */   {
/* 414:469 */     System.out.println("CurrentSelected::" + this.currentSelected);
/* 415:470 */     if ((this.currentSelected != -1) && 
/* 416:471 */       (this.listPanel.getComponents().length > this.currentSelected)) {
/* 417:472 */       this.listPanel.getComponent(this.currentSelected).setBackground(
/* 418:473 */         getRowColor(this.currentSelected));
/* 419:    */     }
/* 420:476 */     for (int i = 0; i < this.cm.getNumChildren(); i++) {
/* 421:477 */       if (this.cm.get(i).getId().equals(comment))
/* 422:    */       {
/* 423:479 */         this.currentSelected = i;
/* 424:480 */         this.commentArea.setText(((XModel)this.cm.get(i).get("text")).get()
/* 425:481 */           .toString());
/* 426:482 */         this.listPanel.getComponent(i).setBackground(Color.YELLOW);
/* 427:483 */         System.out.println("currPhy:" + this.currentPhysician + 
/* 428:484 */           " keywordPhy::" + this.keywordPhysician);
/* 429:485 */         this.page.evaluateAttribute("${" + this.selectFunc + "(" + this.stage + 
/* 430:486 */           "-" + this.keywordPhysician + "-" + comment + ")}");
/* 431:    */         
/* 432:488 */         this.currentPhysician.equals(this.keywordPhysician);
/* 433:    */         
/* 434:    */ 
/* 435:    */ 
/* 436:    */ 
/* 437:    */ 
/* 438:    */ 
/* 439:    */ 
/* 440:    */ 
/* 441:    */ 
/* 442:    */ 
/* 443:    */ 
/* 444:    */ 
/* 445:    */ 
/* 446:502 */         break;
/* 447:    */       }
/* 448:    */     }
/* 449:    */   }
/* 450:    */   
/* 451:    */   public void addComment(XModel cm1)
/* 452:    */   {
/* 453:510 */     String commId = getLastComment() + 1;
/* 454:511 */     cm1.setId("comments" + commId);
/* 455:512 */     this.cm.append(cm1);
/* 456:513 */     display();
/* 457:514 */     selectComment("comments" + commId);
/* 458:515 */     showCommentPanel(true);
/* 459:    */     
/* 460:517 */     this.newComment = true;
/* 461:    */   }
/* 462:    */   
/* 463:    */   public boolean saveComment()
/* 464:    */     throws Exception
/* 465:    */   {
/* 466:522 */     System.out.println("Inside KeywordPanel1.saveComment()");
/* 467:    */     
/* 468:524 */     String path = "/cme/" + this.report + "/Coding/Comments/" + this.currentPhysician;
/* 469:    */     
/* 470:526 */     String text = this.commentArea.getText();
/* 471:528 */     if (text.trim().equals(""))
/* 472:    */     {
/* 473:529 */       System.out.println("Keyword is empty");
/* 474:530 */       this.page.evaluateAttribute("${" + this.changeKeywordPrompt + "()}");
/* 475:531 */       return false;
/* 476:    */     }
/* 477:533 */     System.out.println("Keyword is not empty");
/* 478:    */     
/* 479:535 */     text = text.replaceAll("[^A-Z^a-z^0-9^\\s]", " ");
/* 480:536 */     ((XModel)getSelectedComment().get("text")).set(text);
/* 481:537 */     System.out.println("Text::" + text);
/* 482:    */     
/* 483:539 */     TestXUIDB.getInstance().saveTree(getSelectedComment(), "keyvalue", 
/* 484:540 */       path);
/* 485:541 */     if (this.saveFunc != null) {
/* 486:542 */       this.page.evaluateAttribute("${" + this.saveFunc + "()}");
/* 487:    */     }
/* 488:544 */     showCommentPanel(false);
/* 489:545 */     display();
/* 490:546 */     this.disableSelect = false;
/* 491:    */     
/* 492:    */ 
/* 493:    */ 
/* 494:550 */     return true;
/* 495:    */   }
/* 496:    */   
/* 497:    */   public void mouseEntered(MouseEvent arg0) {}
/* 498:    */   
/* 499:    */   public void mouseExited(MouseEvent arg0) {}
/* 500:    */   
/* 501:    */   public void mousePressed(MouseEvent arg0)
/* 502:    */   {
/* 503:562 */     if (this.disableSelect) {
/* 504:563 */       return;
/* 505:    */     }
/* 506:565 */     this.commentArea.setText(((JTextArea)arg0.getSource()).getText());
/* 507:    */     
/* 508:    */ 
/* 509:568 */     System.out.println("TextArea::" + 
/* 510:569 */       ((JTextArea)arg0.getSource()).getName());
/* 511:570 */     selectComment(((JTextArea)arg0.getSource()).getName());
/* 512:    */     
/* 513:572 */     showCommentPanel(true);
/* 514:    */   }
/* 515:    */   
/* 516:    */   public void mouseReleased(MouseEvent arg0) {}
/* 517:    */   
/* 518:    */   public void showMainPanel()
/* 519:    */   {
/* 520:584 */     setBounds(315, 90, 150, 209);
/* 521:    */     
/* 522:    */ 
/* 523:    */ 
/* 524:    */ 
/* 525:    */ 
/* 526:    */ 
/* 527:    */ 
/* 528:592 */     System.out.println(" Hiding 1");
/* 529:    */     
/* 530:594 */     System.out.println(" Hiding 2");
/* 531:    */   }
/* 532:    */   
/* 533:    */   public void hideMainPanel()
/* 534:    */   {
/* 535:604 */     setBounds(315, 90, 150, 30);
/* 536:    */     
/* 537:    */ 
/* 538:    */ 
/* 539:    */ 
/* 540:    */ 
/* 541:    */ 
/* 542:    */ 
/* 543:    */ 
/* 544:    */ 
/* 545:614 */     System.out.println(" Hiding 1");
/* 546:    */     
/* 547:616 */     System.out.println(" Hiding 2");
/* 548:    */     
/* 549:    */ 
/* 550:619 */     doLayout();
/* 551:    */   }
/* 552:    */   
/* 553:    */   public void removeMainPanel()
/* 554:    */   {
/* 555:625 */     this.parent.remove(this);
/* 556:    */   }
/* 557:    */   
/* 558:    */   public void addMainPanel()
/* 559:    */   {
/* 560:629 */     this.parent.add(this, 0);
/* 561:    */   }
/* 562:    */   
/* 563:632 */   public MessagePanel mp = new MessagePanel();
/* 564:    */   
/* 565:    */   public XModel getSelectedComment()
/* 566:    */   {
/* 567:637 */     return this.cm.get(this.currentSelected);
/* 568:    */   }
/* 569:    */   
/* 570:640 */   boolean disableSelect = false;
/* 571:674 */   private boolean newComment = false;
/* 572:    */   
/* 573:    */   public void showCommentPanel(boolean b) {}
/* 574:    */   
/* 575:    */   public void focusGained(FocusEvent arg0) {}
/* 576:    */   
/* 577:    */   public void focusLost(FocusEvent arg0)
/* 578:    */   {
/* 579:685 */     System.out.println(" Focus Lost 111");
/* 580:    */   }
/* 581:    */   
/* 582:    */   public void reset()
/* 583:    */   {
/* 584:690 */     hideMainPanel();
/* 585:    */   }
/* 586:    */   
/* 587:    */   public void itemStateChanged(ItemEvent arg0)
/* 588:    */   {
/* 589:694 */     XComboBox xc = (XComboBox)arg0.getSource();
/* 590:695 */     System.out.println("Item::" + arg0.getItem());
/* 591:696 */     String otherPhysician = this.physicians.get(0).equals(this.currentPhysician) ? this.physicians
/* 592:697 */       .get(1).toString() : this.physicians.get(0).toString();
/* 593:698 */     if (getStage().equals("Adjudication"))
/* 594:    */     {
/* 595:699 */       if (arg0.getItem().equals("First Physician")) {
/* 596:700 */         this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 597:701 */           this.physicians.get(0) + ")}");
/* 598:702 */       } else if (arg0.getItem().equals("Second Physician")) {
/* 599:703 */         this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 600:704 */           this.physicians.get(1) + ")}");
/* 601:    */       }
/* 602:    */     }
/* 603:707 */     else if (arg0.getItem().equals("Your Keywords")) {
/* 604:708 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 605:709 */         this.currentPhysician + ")}");
/* 606:710 */     } else if (arg0.getItem().equals("Others Keywords")) {
/* 607:711 */       this.page.evaluateAttribute("${" + this.changePhyFunc + "(" + 
/* 608:712 */         otherPhysician + ")}");
/* 609:    */     }
/* 610:    */   }
/* 611:    */   
/* 612:    */   public void setTitle(String title)
/* 613:    */   {
/* 614:718 */     this.heading.setText(title);
/* 615:719 */     repaint();
/* 616:    */   }
/* 617:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.KeywordListPanel
 * JD-Core Version:    0.7.0.1
 */