/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Component;
/*   6:    */ import java.awt.Container;
/*   7:    */ import java.awt.Graphics;
/*   8:    */ import java.awt.Rectangle;
/*   9:    */ import java.awt.Toolkit;
/*  10:    */ import java.awt.event.ActionEvent;
/*  11:    */ import java.awt.event.WindowAdapter;
/*  12:    */ import java.awt.event.WindowEvent;
/*  13:    */ import java.awt.image.BufferedImage;
/*  14:    */ import java.io.File;
/*  15:    */ import java.io.IOException;
/*  16:    */ import java.io.PrintStream;
/*  17:    */ import javax.imageio.ImageIO;
/*  18:    */ import javax.swing.AbstractAction;
/*  19:    */ import javax.swing.Action;
/*  20:    */ import javax.swing.Icon;
/*  21:    */ import javax.swing.JFrame;
/*  22:    */ import javax.swing.JMenu;
/*  23:    */ import javax.swing.JToolBar;
/*  24:    */ import javax.swing.border.BevelBorder;
/*  25:    */ 
/*  26:    */ public class Scribble
/*  27:    */   extends JFrame
/*  28:    */ {
/*  29: 55 */   private String path = null;
/*  30:    */   ScribblePane2 scribblePane;
/*  31:    */   
/*  32:    */   public static void main(String[] args)
/*  33:    */   {
/*  34: 71 */     Scribble scribble = new Scribble("test");
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Scribble(String path)
/*  38:    */   {
/*  39: 82 */     super("Scribble");
/*  40: 83 */     this.path = path;
/*  41: 84 */     System.out.println("Scribble.path=" + this.path);
/*  42:    */     
/*  43:    */ 
/*  44: 87 */     addWindowListener(new WindowAdapter()
/*  45:    */     {
/*  46:    */       public void windowClosing(WindowEvent e)
/*  47:    */       {
/*  48: 89 */         System.exit(0);
/*  49:    */       }
/*  50: 95 */     });
/*  51: 96 */     Container contentPane = getContentPane();
/*  52:    */     
/*  53:    */ 
/*  54: 99 */     contentPane.setLayout(new BorderLayout());
/*  55:    */     
/*  56:    */ 
/*  57:    */ 
/*  58:103 */     this.scribblePane = new ScribblePane2(path);
/*  59:104 */     this.scribblePane.setBorder(new BevelBorder(1));
/*  60:105 */     this.scribblePane.setBackground(Color.white);
/*  61:106 */     contentPane.add(this.scribblePane, "Center");
/*  62:    */     
/*  63:    */ 
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:115 */     JMenu filemenu = new JMenu("File");
/*  71:116 */     JMenu colormenu = new JMenu("Color");
/*  72:    */     
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:123 */     Action clear = new ClearAction();
/*  79:124 */     Action save = new SaveAction(path, this.scribblePane);
/*  80:    */     
/*  81:126 */     Action black = new ColorAction(Color.black);
/*  82:127 */     Action red = new ColorAction(Color.red);
/*  83:128 */     Action blue = new ColorAction(Color.blue);
/*  84:    */     
/*  85:    */ 
/*  86:    */ 
/*  87:132 */     filemenu.add(clear);
/*  88:133 */     filemenu.add(save);
/*  89:134 */     filemenu.addSeparator();
/*  90:    */     
/*  91:136 */     colormenu.add(black);
/*  92:137 */     colormenu.add(red);
/*  93:138 */     colormenu.add(blue);
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:143 */     JToolBar toolbar = new JToolBar();
/*  99:144 */     toolbar.add(clear);
/* 100:145 */     toolbar.add(save);
/* 101:    */     
/* 102:    */ 
/* 103:148 */     contentPane.add(toolbar, "North");
/* 104:    */     
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:159 */     Toolkit tk = Toolkit.getDefaultToolkit();
/* 115:160 */     setSize(tk.getScreenSize());
/* 116:161 */     setVisible(true);
/* 117:    */   }
/* 118:    */   
/* 119:    */   class ClearAction
/* 120:    */     extends AbstractAction
/* 121:    */   {
/* 122:    */     public ClearAction()
/* 123:    */     {
/* 124:167 */       super();
/* 125:    */     }
/* 126:    */     
/* 127:    */     public void actionPerformed(ActionEvent e)
/* 128:    */     {
/* 129:171 */       Scribble.this.scribblePane.clear();
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   class ColorAction
/* 134:    */     extends AbstractAction
/* 135:    */   {
/* 136:    */     Color color;
/* 137:    */     
/* 138:    */     public ColorAction(Color color)
/* 139:    */     {
/* 140:199 */       this.color = color;
/* 141:200 */       putValue("SmallIcon", new Scribble.ColorIcon(color));
/* 142:    */     }
/* 143:    */     
/* 144:    */     public void actionPerformed(ActionEvent e)
/* 145:    */     {
/* 146:204 */       Scribble.this.scribblePane.setColor(this.color);
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */   static class ColorIcon
/* 151:    */     implements Icon
/* 152:    */   {
/* 153:    */     Color color;
/* 154:    */     
/* 155:    */     public ColorIcon(Color color)
/* 156:    */     {
/* 157:218 */       this.color = color;
/* 158:    */     }
/* 159:    */     
/* 160:    */     public int getIconHeight()
/* 161:    */     {
/* 162:223 */       return 16;
/* 163:    */     }
/* 164:    */     
/* 165:    */     public int getIconWidth()
/* 166:    */     {
/* 167:227 */       return 16;
/* 168:    */     }
/* 169:    */     
/* 170:    */     public void paintIcon(Component c, Graphics g, int x, int y)
/* 171:    */     {
/* 172:232 */       g.setColor(this.color);
/* 173:233 */       g.fillRect(x, y, 16, 16);
/* 174:    */     }
/* 175:    */   }
/* 176:    */   
/* 177:    */   class SaveAction
/* 178:    */     extends AbstractAction
/* 179:    */   {
/* 180:    */     private static final int width = 600;
/* 181:    */     private static final int height = 800;
/* 182:258 */     String path = null;
/* 183:259 */     Component component = null;
/* 184:    */     
/* 185:    */     SaveAction(String path, Component component)
/* 186:    */     {
/* 187:262 */       super();
/* 188:    */       try
/* 189:    */       {
/* 190:264 */         this.path = path;
/* 191:265 */         System.out.println("SaveAction.path::" + this.path);
/* 192:266 */         this.component = component;
/* 193:    */       }
/* 194:    */       catch (Throwable e)
/* 195:    */       {
/* 196:268 */         e.printStackTrace();
/* 197:    */       }
/* 198:    */     }
/* 199:    */     
/* 200:    */     public void actionPerformed(ActionEvent arg0)
/* 201:    */     {
/* 202:    */       try
/* 203:    */       {
/* 204:275 */         File file = new File(this.path);
/* 205:276 */         if (!file.exists()) {
/* 206:277 */           file.createNewFile();
/* 207:    */         }
/* 208:289 */         Rectangle r = this.component.getBounds();
/* 209:    */         
/* 210:291 */         BufferedImage i = new BufferedImage(r.width, r.height, 1);
/* 211:292 */         Graphics g = i.getGraphics();
/* 212:293 */         this.component.paintAll(g);
/* 213:    */         
/* 214:    */ 
/* 215:296 */         ImageIO.write(i, "png", file);
/* 216:297 */         System.out.println("File::" + file.getAbsolutePath());
/* 217:    */       }
/* 218:    */       catch (IOException e)
/* 219:    */       {
/* 220:302 */         e.printStackTrace();
/* 221:    */       }
/* 222:    */     }
/* 223:    */   }
/* 224:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.Scribble
 * JD-Core Version:    0.7.0.1
 */