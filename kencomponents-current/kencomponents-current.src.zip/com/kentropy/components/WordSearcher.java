/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import javax.swing.text.BadLocationException;
/*   5:    */ import javax.swing.text.Document;
/*   6:    */ import javax.swing.text.Highlighter;
/*   7:    */ import javax.swing.text.Highlighter.Highlight;
/*   8:    */ import javax.swing.text.Highlighter.HighlightPainter;
/*   9:    */ import javax.swing.text.JTextComponent;
/*  10:    */ 
/*  11:    */ class WordSearcher
/*  12:    */ {
/*  13:    */   protected JTextComponent comp;
/*  14:    */   protected Highlighter.HighlightPainter painter;
/*  15:    */   
/*  16:    */   public WordSearcher(JTextComponent comp)
/*  17:    */   {
/*  18:104 */     this.comp = comp;
/*  19:105 */     this.painter = new UnderlineHighlighter.UnderlineHighlightPainter(
/*  20:106 */       Color.red);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public int search(String word)
/*  24:    */   {
/*  25:113 */     int firstOffset = -1;
/*  26:114 */     Highlighter highlighter = this.comp.getHighlighter();
/*  27:    */     
/*  28:    */ 
/*  29:117 */     Highlighter.Highlight[] highlights = highlighter.getHighlights();
/*  30:118 */     for (int i = 0; i < highlights.length; i++)
/*  31:    */     {
/*  32:119 */       Highlighter.Highlight h = highlights[i];
/*  33:120 */       if ((h.getPainter() instanceof UnderlineHighlighter.UnderlineHighlightPainter)) {
/*  34:121 */         highlighter.removeHighlight(h);
/*  35:    */       }
/*  36:    */     }
/*  37:125 */     if ((word == null) || (word.equals(""))) {
/*  38:126 */       return -1;
/*  39:    */     }
/*  40:130 */     String content = null;
/*  41:    */     try
/*  42:    */     {
/*  43:132 */       Document d = this.comp.getDocument();
/*  44:133 */       content = d.getText(0, d.getLength()).toLowerCase();
/*  45:    */     }
/*  46:    */     catch (BadLocationException e)
/*  47:    */     {
/*  48:136 */       return -1;
/*  49:    */     }
/*  50:139 */     word = word.toLowerCase();
/*  51:140 */     int lastIndex = 0;
/*  52:141 */     int wordSize = word.length();
/*  53:143 */     while ((lastIndex = content.indexOf(word, lastIndex)) != -1)
/*  54:    */     {
/*  55:144 */       int endIndex = lastIndex + wordSize;
/*  56:    */       try
/*  57:    */       {
/*  58:146 */         highlighter.addHighlight(lastIndex, endIndex, this.painter);
/*  59:    */       }
/*  60:    */       catch (BadLocationException localBadLocationException1) {}
/*  61:150 */       if (firstOffset == -1) {
/*  62:151 */         firstOffset = lastIndex;
/*  63:    */       }
/*  64:153 */       lastIndex = endIndex;
/*  65:    */     }
/*  66:156 */     return firstOffset;
/*  67:    */   }
/*  68:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.WordSearcher
 * JD-Core Version:    0.7.0.1
 */