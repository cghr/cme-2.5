/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.FlowLayout;
/*   6:    */ import java.awt.Font;
/*   7:    */ import java.awt.Frame;
/*   8:    */ import java.awt.event.ActionEvent;
/*   9:    */ import java.awt.event.ActionListener;
/*  10:    */ import java.awt.event.WindowAdapter;
/*  11:    */ import java.awt.event.WindowEvent;
/*  12:    */ import net.xoetrope.awt.XButton;
/*  13:    */ import net.xoetrope.awt.XLabel;
/*  14:    */ import net.xoetrope.awt.XPanel;
/*  15:    */ import net.xoetrope.xui.XProject;
/*  16:    */ import net.xoetrope.xui.XProjectManager;
/*  17:    */ 
/*  18:    */ public class MessagePanel
/*  19:    */   extends XPanel
/*  20:    */   implements ActionListener
/*  21:    */ {
/*  22: 22 */   XLabel titleLabel = new XLabel();
/*  23: 23 */   public XButton okButton = new XButton();
/*  24: 24 */   public XButton cancelButton = new XButton();
/*  25: 25 */   XLabel textLabel = new XLabel();
/*  26:    */   public static final int HEADING = 15;
/*  27:    */   public static final int BORDER = 3;
/*  28:    */   public static final int BUTTON_HEIGHT = 20;
/*  29:    */   public static final int BUTTON_WIDTH = 80;
/*  30:    */   private String okFunc;
/*  31:    */   
/*  32:    */   public void init()
/*  33:    */   {
/*  34: 34 */     setBackground(Color.BLUE);
/*  35: 35 */     this.titleLabel.setBounds(3, 3, getWidth() - 6, 
/*  36: 36 */       15);
/*  37: 37 */     this.titleLabel.setFont(new Font("SansSerif", 1, 11));
/*  38: 38 */     this.titleLabel.setForeground(Color.WHITE);
/*  39:    */     
/*  40: 40 */     this.textLabel.setBounds(3, 21, getWidth() - 
/*  41: 41 */       6, getHeight() - 9 - 15);
/*  42: 42 */     this.textLabel.setBackground(new Color(240, 240, 240));
/*  43:    */     
/*  44: 44 */     this.okButton.setName("OK");
/*  45: 45 */     this.okButton.setLabel("OK");
/*  46: 46 */     this.okButton.setBounds((getWidth() - 160) / 3, 
/*  47: 47 */       getHeight() - 9 - 20, 80, 
/*  48: 48 */       20);
/*  49:    */     
/*  50:    */ 
/*  51: 51 */     this.cancelButton.setName("Cancel");
/*  52: 52 */     this.cancelButton.setLabel("Cancel");
/*  53: 53 */     this.cancelButton.setBounds(2 * ((getWidth() - 160) / 3) + 
/*  54: 54 */       80, 
/*  55: 55 */       getHeight() - 9 - 20, 80, 
/*  56: 56 */       20);
/*  57: 57 */     this.cancelButton.addActionListener(this);
/*  58: 58 */     int x = (getWidth() - 160) / 3;
/*  59:    */     
/*  60: 60 */     add(this.titleLabel);
/*  61: 61 */     add(this.okButton);
/*  62: 62 */     add(this.cancelButton);
/*  63: 63 */     add(this.textLabel);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setTitle(String title)
/*  67:    */   {
/*  68: 71 */     this.titleLabel.setText(title);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setMessage(String msg)
/*  72:    */   {
/*  73: 75 */     this.textLabel.setText(msg);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void setAction(String action, String cmd)
/*  77:    */   {
/*  78: 83 */     if (action.equals("OK")) {
/*  79: 84 */       this.okButton.setActionCommand(cmd);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setCallback(String action, String function)
/*  84:    */   {
/*  85: 93 */     if (action.equals("OK")) {
/*  86: 94 */       this.okFunc = function;
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void setCallback(String action, ActionListener al)
/*  91:    */   {
/*  92: 99 */     if (action.equals("OK")) {
/*  93:100 */       this.okButton.addActionListener(al);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void main(String[] args)
/*  98:    */   {
/*  99:110 */     Frame frame = new Frame("test");
/* 100:111 */     frame.setLayout(new FlowLayout());
/* 101:    */     
/* 102:113 */     XProjectManager.getCurrentProject().setAppFrame(frame);
/* 103:    */     
/* 104:115 */     XProjectManager.getCurrentProject().initialise("startup.properties");
/* 105:116 */     frame.setBounds(10, 10, 800, 600);
/* 106:117 */     MessagePanel mp = new MessagePanel();
/* 107:118 */     mp.setBounds(10, 10, 300, 200);
/* 108:119 */     mp.init();
/* 109:120 */     frame.add(mp);
/* 110:    */     
/* 111:122 */     mp.setTitle("Delete Comment");
/* 112:123 */     mp.setMessage("Are you sure you want to Delete this comment?");
/* 113:124 */     mp.init();
/* 114:125 */     frame.addWindowListener(new WindowAdapter()
/* 115:    */     {
/* 116:    */       public void windowClosing(WindowEvent w)
/* 117:    */       {
/* 118:127 */         System.exit(0);
/* 119:    */       }
/* 120:129 */     });
/* 121:130 */     frame.setVisible(true);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void actionPerformed(ActionEvent arg0)
/* 125:    */   {
/* 126:134 */     ((XButton)arg0.getSource()).getParent().setVisible(false);
/* 127:    */   }
/* 128:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.MessagePanel
 * JD-Core Version:    0.7.0.1
 */