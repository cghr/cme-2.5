/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import com.kentropy.db.TestXUIDB;
/*  4:   */ import java.awt.Frame;
/*  5:   */ import java.io.PrintStream;
/*  6:   */ import net.xoetrope.awt.XPanel;
/*  7:   */ import net.xoetrope.xui.XProject;
/*  8:   */ import net.xoetrope.xui.XProjectManager;
/*  9:   */ import net.xoetrope.xui.data.XBaseModel;
/* 10:   */ import net.xoetrope.xui.data.XModel;
/* 11:   */ 
/* 12:   */ public class TestingFrame
/* 13:   */   extends XPanel
/* 14:   */ {
/* 15:   */   TestingFrame()
/* 16:   */   {
/* 17:15 */     Frame frame = new Frame("test");
/* 18:   */     
/* 19:17 */     XProjectManager.getCurrentProject().setAppFrame(frame);
/* 20:   */     
/* 21:19 */     XProjectManager.getCurrentProject().initialise("startup.properties");
/* 22:20 */     frame.setBounds(10, 10, 800, 600);
/* 23:21 */     KeywordPanel kp = new KeywordPanel();
/* 24:22 */     kp.setBounds(10, 10, 500, 300);
/* 25:23 */     XModel xm = new XBaseModel();
/* 26:24 */     String parentPath = "/cme/01200001_01_02/Coding/Comments/9";
/* 27:25 */     TestXUIDB.getInstance().getKeyValues(xm, "keyvalue", parentPath);
/* 28:   */     
/* 29:27 */     kp.init();
/* 30:28 */     System.out.println(xm.get(0).getNumChildren());
/* 31:29 */     System.out.println(xm.get(1).getId());
/* 32:30 */     frame.add(kp);
/* 33:31 */     kp.setCommentModel(xm);
/* 34:   */     
/* 35:33 */     frame.setVisible(true);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static void main(String[] args)
/* 39:   */   {
/* 40:40 */     TestingFrame testingFrame = new TestingFrame();
/* 41:   */   }
/* 42:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.TestingFrame
 * JD-Core Version:    0.7.0.1
 */