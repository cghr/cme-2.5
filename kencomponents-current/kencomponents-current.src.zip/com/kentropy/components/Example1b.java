/*  1:   */ package com.kentropy.components;
/*  2:   */ 
/*  3:   */ import java.awt.Color;
/*  4:   */ import java.awt.Component;
/*  5:   */ import java.awt.Container;
/*  6:   */ import java.awt.Dimension;
/*  7:   */ import javax.swing.JFrame;
/*  8:   */ import javax.swing.JPanel;
/*  9:   */ import javax.swing.JScrollPane;
/* 10:   */ import javax.swing.JTable;
/* 11:   */ import javax.swing.JViewport;
/* 12:   */ import javax.swing.table.DefaultTableCellRenderer;
/* 13:   */ import javax.swing.table.TableColumn;
/* 14:   */ 
/* 15:   */ public class Example1b
/* 16:   */ {
/* 17:   */   private static final String window_title = "Edit table display";
/* 18:   */   private static final int locate_X = 50;
/* 19:   */   private static final int locate_Y = 50;
/* 20:   */   private static final int window_width = 320;
/* 21:   */   private static final int window_height = 160;
/* 22:   */   private static final int table_width = 300;
/* 23:   */   private static final int table_height = 120;
/* 24:   */   private static final int table_row_height = 20;
/* 25:26 */   Object[] colNames = { "name", "amount", "size", "color", "note" };
/* 26:28 */   Object[][] rowData = { { "A01", "20", "large", "white", "soft" }, 
/* 27:29 */     { "K01", "5", "thin", "red", "strong" }, 
/* 28:30 */     { "U01", "100", "middle", "yellow", "cheap" }, 
/* 29:31 */     { "S01", "2.5", "middle", "black", "quality" } };
/* 30:   */   
/* 31:   */   public static void main(String[] args)
/* 32:   */   {
/* 33:35 */     Example1b sample = new Example1b();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Example1b()
/* 37:   */   {
/* 38:40 */     JFrame f = new JFrame("Edit table display");
/* 39:41 */     f.setDefaultCloseOperation(3);
/* 40:   */     
/* 41:43 */     JTable t = new JTable(this.rowData, this.colNames);
/* 42:44 */     t.setRowHeight(20);
/* 43:45 */     t.setGridColor(Color.gray);
/* 44:47 */     for (int i = 0; i < t.getColumnCount(); i++)
/* 45:   */     {
/* 46:48 */       TableColumn tc = t.getColumn(t.getColumnName(i));
/* 47:49 */       tc.setCellRenderer(new MyRenderer());
/* 48:   */     }
/* 49:52 */     JScrollPane sp = new JScrollPane();
/* 50:53 */     sp.getViewport().setView(t);
/* 51:54 */     sp.setPreferredSize(new Dimension(300, 
/* 52:55 */       120));
/* 53:   */     
/* 54:57 */     JPanel p = new JPanel();
/* 55:58 */     p.add(sp);
/* 56:59 */     f.getContentPane().add(p, "Center");
/* 57:   */     
/* 58:61 */     f.setBounds(50, 50, 
/* 59:62 */       320, 160);
/* 60:63 */     f.setVisible(true);
/* 61:   */   }
/* 62:   */   
/* 63:   */   class MyRenderer
/* 64:   */     extends DefaultTableCellRenderer
/* 65:   */   {
/* 66:   */     private static final long serialVersionUID = 1L;
/* 67:   */     
/* 68:   */     MyRenderer() {}
/* 69:   */     
/* 70:   */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/* 71:   */     {
/* 72:74 */       switch (column)
/* 73:   */       {
/* 74:   */       case 1: 
/* 75:76 */         setHorizontalAlignment(4);
/* 76:77 */         break;
/* 77:   */       case 2: 
/* 78:79 */         setHorizontalAlignment(0);
/* 79:80 */         break;
/* 80:   */       case 3: 
/* 81:82 */         setHorizontalAlignment(0);
/* 82:83 */         switch (row)
/* 83:   */         {
/* 84:   */         case 0: 
/* 85:85 */           setBackground(Color.black);
/* 86:86 */           setForeground(Color.white);
/* 87:87 */           break;
/* 88:   */         default: 
/* 89:89 */           setBackground(Color.yellow);
/* 90:90 */           setForeground(Color.red);
/* 91:   */         }
/* 92:   */         break;
/* 93:   */       }
/* 94:96 */       return super.getTableCellRendererComponent(table, value, 
/* 95:97 */         isSelected, hasFocus, row, column);
/* 96:   */     }
/* 97:   */   }
/* 98:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.Example1b
 * JD-Core Version:    0.7.0.1
 */