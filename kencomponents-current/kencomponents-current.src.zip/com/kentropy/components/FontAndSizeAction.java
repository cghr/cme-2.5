/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Container;
/*   5:    */ import java.awt.GraphicsEnvironment;
/*   6:    */ import java.awt.GridLayout;
/*   7:    */ import java.awt.event.ActionEvent;
/*   8:    */ import java.awt.event.ActionListener;
/*   9:    */ import javax.swing.JButton;
/*  10:    */ import javax.swing.JComboBox;
/*  11:    */ import javax.swing.JDialog;
/*  12:    */ import javax.swing.JFrame;
/*  13:    */ import javax.swing.JLabel;
/*  14:    */ import javax.swing.JPanel;
/*  15:    */ import javax.swing.JTextPane;
/*  16:    */ import javax.swing.text.AttributeSet;
/*  17:    */ import javax.swing.text.Element;
/*  18:    */ import javax.swing.text.MutableAttributeSet;
/*  19:    */ import javax.swing.text.SimpleAttributeSet;
/*  20:    */ import javax.swing.text.StyleConstants;
/*  21:    */ import javax.swing.text.StyledDocument;
/*  22:    */ import javax.swing.text.StyledEditorKit.StyledTextAction;
/*  23:    */ 
/*  24:    */ class FontAndSizeAction
/*  25:    */   extends StyledEditorKit.StyledTextAction
/*  26:    */ {
/*  27:    */   private static final long serialVersionUID = 584531387732416339L;
/*  28:    */   private String family;
/*  29:    */   private float fontSize;
/*  30:    */   JDialog formatText;
/*  31:225 */   private boolean accept = false;
/*  32:    */   JComboBox fontFamilyChooser;
/*  33:    */   JComboBox fontSizeChooser;
/*  34:    */   
/*  35:    */   public FontAndSizeAction()
/*  36:    */   {
/*  37:232 */     super("Font and Size");
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String toString()
/*  41:    */   {
/*  42:236 */     return "Font and Size";
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void actionPerformed(ActionEvent e)
/*  46:    */   {
/*  47:240 */     JTextPane editor = (JTextPane)getEditor(e);
/*  48:241 */     int p0 = editor.getSelectionStart();
/*  49:242 */     StyledDocument doc = getStyledDocument(editor);
/*  50:243 */     Element paragraph = doc.getCharacterElement(p0);
/*  51:244 */     AttributeSet as = paragraph.getAttributes();
/*  52:    */     
/*  53:246 */     this.family = StyleConstants.getFontFamily(as);
/*  54:247 */     this.fontSize = StyleConstants.getFontSize(as);
/*  55:    */     
/*  56:249 */     this.formatText = new JDialog(new JFrame(), "Font and Size", true);
/*  57:250 */     this.formatText.getContentPane().setLayout(new BorderLayout());
/*  58:    */     
/*  59:252 */     JPanel choosers = new JPanel();
/*  60:253 */     choosers.setLayout(new GridLayout(2, 1));
/*  61:    */     
/*  62:255 */     JPanel fontFamilyPanel = new JPanel();
/*  63:256 */     fontFamilyPanel.add(new JLabel("Font"));
/*  64:    */     
/*  65:258 */     GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*  66:259 */     String[] fontNames = ge.getAvailableFontFamilyNames();
/*  67:    */     
/*  68:261 */     this.fontFamilyChooser = new JComboBox();
/*  69:262 */     for (int i = 0; i < fontNames.length; i++) {
/*  70:263 */       this.fontFamilyChooser.addItem(fontNames[i]);
/*  71:    */     }
/*  72:265 */     this.fontFamilyChooser.setSelectedItem(this.family);
/*  73:266 */     fontFamilyPanel.add(this.fontFamilyChooser);
/*  74:267 */     choosers.add(fontFamilyPanel);
/*  75:    */     
/*  76:269 */     JPanel fontSizePanel = new JPanel();
/*  77:270 */     fontSizePanel.add(new JLabel("Size"));
/*  78:271 */     this.fontSizeChooser = new JComboBox();
/*  79:272 */     this.fontSizeChooser.setEditable(true);
/*  80:273 */     this.fontSizeChooser.addItem(new Float(4.0F));
/*  81:274 */     this.fontSizeChooser.addItem(new Float(8.0F));
/*  82:275 */     this.fontSizeChooser.addItem(new Float(12.0F));
/*  83:276 */     this.fontSizeChooser.addItem(new Float(16.0F));
/*  84:277 */     this.fontSizeChooser.addItem(new Float(20.0F));
/*  85:278 */     this.fontSizeChooser.addItem(new Float(24.0F));
/*  86:279 */     this.fontSizeChooser.setSelectedItem(new Float(this.fontSize));
/*  87:280 */     fontSizePanel.add(this.fontSizeChooser);
/*  88:281 */     choosers.add(fontSizePanel);
/*  89:    */     
/*  90:283 */     JButton ok = new JButton("OK");
/*  91:284 */     ok.addActionListener(new ActionListener()
/*  92:    */     {
/*  93:    */       public void actionPerformed(ActionEvent ae)
/*  94:    */       {
/*  95:286 */         FontAndSizeAction.this.accept = true;
/*  96:287 */         FontAndSizeAction.this.formatText.dispose();
/*  97:288 */         FontAndSizeAction.this.family = ((String)FontAndSizeAction.this.fontFamilyChooser.getSelectedItem());
/*  98:289 */         FontAndSizeAction.this.fontSize = Float.parseFloat(FontAndSizeAction.this.fontSizeChooser.getSelectedItem().toString());
/*  99:    */       }
/* 100:292 */     });
/* 101:293 */     JButton cancel = new JButton("Cancel");
/* 102:294 */     cancel.addActionListener(new ActionListener()
/* 103:    */     {
/* 104:    */       public void actionPerformed(ActionEvent ae)
/* 105:    */       {
/* 106:296 */         FontAndSizeAction.this.formatText.dispose();
/* 107:    */       }
/* 108:299 */     });
/* 109:300 */     JPanel buttons = new JPanel();
/* 110:301 */     buttons.add(ok);
/* 111:302 */     buttons.add(cancel);
/* 112:303 */     this.formatText.getContentPane().add(choosers, "Center");
/* 113:304 */     this.formatText.getContentPane().add(buttons, "South");
/* 114:305 */     this.formatText.pack();
/* 115:306 */     this.formatText.setVisible(true);
/* 116:    */     
/* 117:308 */     MutableAttributeSet attr = null;
/* 118:309 */     if ((editor != null) && (this.accept))
/* 119:    */     {
/* 120:310 */       attr = new SimpleAttributeSet();
/* 121:311 */       StyleConstants.setFontFamily(attr, this.family);
/* 122:312 */       StyleConstants.setFontSize(attr, (int)this.fontSize);
/* 123:313 */       setCharacterAttributes(editor, attr, false);
/* 124:    */     }
/* 125:    */   }
/* 126:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.FontAndSizeAction
 * JD-Core Version:    0.7.0.1
 */