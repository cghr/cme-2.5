/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.BorderLayout;
/*   4:    */ import java.awt.Color;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.event.ActionEvent;
/*   7:    */ import java.awt.event.ActionListener;
/*   8:    */ import javax.swing.JButton;
/*   9:    */ import javax.swing.JColorChooser;
/*  10:    */ import javax.swing.JDialog;
/*  11:    */ import javax.swing.JOptionPane;
/*  12:    */ import javax.swing.JPanel;
/*  13:    */ import javax.swing.JTextPane;
/*  14:    */ import javax.swing.text.AttributeSet;
/*  15:    */ import javax.swing.text.Element;
/*  16:    */ import javax.swing.text.MutableAttributeSet;
/*  17:    */ import javax.swing.text.SimpleAttributeSet;
/*  18:    */ import javax.swing.text.StyleConstants;
/*  19:    */ import javax.swing.text.StyledDocument;
/*  20:    */ import javax.swing.text.StyledEditorKit.StyledTextAction;
/*  21:    */ 
/*  22:    */ class ForegroundAction
/*  23:    */   extends StyledEditorKit.StyledTextAction
/*  24:    */ {
/*  25:    */   private static final long serialVersionUID = 6384632651737400352L;
/*  26:129 */   JColorChooser colorChooser = new JColorChooser();
/*  27:131 */   JDialog dialog = new JDialog();
/*  28:133 */   boolean noChange = false;
/*  29:135 */   boolean cancelled = false;
/*  30:    */   private Color fg;
/*  31:    */   
/*  32:    */   public ForegroundAction()
/*  33:    */   {
/*  34:138 */     super("foreground");
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void actionPerformed(ActionEvent e)
/*  38:    */   {
/*  39:143 */     JTextPane editor = (JTextPane)getEditor(e);
/*  40:145 */     if (editor == null)
/*  41:    */     {
/*  42:146 */       JOptionPane.showMessageDialog(null, 
/*  43:147 */         "You need to select the editor pane before you can change the color.", "Error", 
/*  44:148 */         0);
/*  45:149 */       return;
/*  46:    */     }
/*  47:151 */     int p0 = editor.getSelectionStart();
/*  48:152 */     StyledDocument doc = getStyledDocument(editor);
/*  49:153 */     Element paragraph = doc.getCharacterElement(p0);
/*  50:154 */     AttributeSet as = paragraph.getAttributes();
/*  51:155 */     this.fg = StyleConstants.getForeground(as);
/*  52:156 */     if (this.fg == null) {
/*  53:157 */       this.fg = Color.BLACK;
/*  54:    */     }
/*  55:159 */     this.colorChooser.setColor(this.fg);
/*  56:    */     
/*  57:161 */     JButton accept = new JButton("OK");
/*  58:162 */     accept.addActionListener(new ActionListener()
/*  59:    */     {
/*  60:    */       public void actionPerformed(ActionEvent ae)
/*  61:    */       {
/*  62:164 */         ForegroundAction.this.fg = ForegroundAction.this.colorChooser.getColor();
/*  63:165 */         ForegroundAction.this.dialog.dispose();
/*  64:    */       }
/*  65:168 */     });
/*  66:169 */     JButton cancel = new JButton("Cancel");
/*  67:170 */     cancel.addActionListener(new ActionListener()
/*  68:    */     {
/*  69:    */       public void actionPerformed(ActionEvent ae)
/*  70:    */       {
/*  71:172 */         ForegroundAction.this.cancelled = true;
/*  72:173 */         ForegroundAction.this.dialog.dispose();
/*  73:    */       }
/*  74:176 */     });
/*  75:177 */     JButton none = new JButton("None");
/*  76:178 */     none.addActionListener(new ActionListener()
/*  77:    */     {
/*  78:    */       public void actionPerformed(ActionEvent ae)
/*  79:    */       {
/*  80:180 */         ForegroundAction.this.noChange = true;
/*  81:181 */         ForegroundAction.this.dialog.dispose();
/*  82:    */       }
/*  83:184 */     });
/*  84:185 */     JPanel buttons = new JPanel();
/*  85:186 */     buttons.add(accept);
/*  86:187 */     buttons.add(none);
/*  87:188 */     buttons.add(cancel);
/*  88:    */     
/*  89:190 */     this.dialog.getContentPane().setLayout(new BorderLayout());
/*  90:191 */     this.dialog.getContentPane().add(this.colorChooser, "Center");
/*  91:192 */     this.dialog.getContentPane().add(buttons, "South");
/*  92:193 */     this.dialog.setModal(true);
/*  93:194 */     this.dialog.pack();
/*  94:195 */     this.dialog.setVisible(true);
/*  95:197 */     if (!this.cancelled)
/*  96:    */     {
/*  97:199 */       MutableAttributeSet attr = null;
/*  98:201 */       if ((this.fg != null) && (!this.noChange))
/*  99:    */       {
/* 100:202 */         attr = new SimpleAttributeSet();
/* 101:203 */         StyleConstants.setForeground(attr, this.fg);
/* 102:204 */         setCharacterAttributes(editor, attr, false);
/* 103:    */       }
/* 104:    */     }
/* 105:208 */     this.noChange = false;
/* 106:209 */     this.cancelled = false;
/* 107:    */   }
/* 108:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.ForegroundAction
 * JD-Core Version:    0.7.0.1
 */