/*   1:    */ package com.kentropy.components;
/*   2:    */ 
/*   3:    */ import java.awt.event.ActionEvent;
/*   4:    */ import javax.swing.JEditorPane;
/*   5:    */ import javax.swing.text.MutableAttributeSet;
/*   6:    */ import javax.swing.text.SimpleAttributeSet;
/*   7:    */ import javax.swing.text.StyleConstants;
/*   8:    */ import javax.swing.text.StyledEditorKit;
/*   9:    */ import javax.swing.text.StyledEditorKit.StyledTextAction;
/*  10:    */ 
/*  11:    */ class ItalicAction
/*  12:    */   extends StyledEditorKit.StyledTextAction
/*  13:    */ {
/*  14:    */   private static final long serialVersionUID = -1428340091100055456L;
/*  15:    */   
/*  16:    */   public ItalicAction()
/*  17:    */   {
/*  18:106 */     super("font-italic");
/*  19:    */   }
/*  20:    */   
/*  21:    */   public String toString()
/*  22:    */   {
/*  23:110 */     return "Italic";
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void actionPerformed(ActionEvent e)
/*  27:    */   {
/*  28:114 */     JEditorPane editor = getEditor(e);
/*  29:115 */     if (editor != null)
/*  30:    */     {
/*  31:116 */       StyledEditorKit kit = getStyledEditorKit(editor);
/*  32:117 */       MutableAttributeSet attr = kit.getInputAttributes();
/*  33:118 */       boolean italic = !StyleConstants.isItalic(attr);
/*  34:119 */       SimpleAttributeSet sas = new SimpleAttributeSet();
/*  35:120 */       StyleConstants.setItalic(sas, italic);
/*  36:121 */       setCharacterAttributes(editor, sas, false);
/*  37:    */     }
/*  38:    */   }
/*  39:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.components.ItalicAction
 * JD-Core Version:    0.7.0.1
 */