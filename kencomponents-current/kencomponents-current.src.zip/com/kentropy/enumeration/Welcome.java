/*   1:    */ package com.kentropy.enumeration;
/*   2:    */ 
/*   3:    */ import com.kentropy.survey.common.NavPanel;
/*   4:    */ import java.awt.event.KeyEvent;
/*   5:    */ import java.awt.event.MouseEvent;
/*   6:    */ import java.awt.event.TextEvent;
/*   7:    */ import java.io.File;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.text.SimpleDateFormat;
/*  10:    */ import java.util.Date;
/*  11:    */ import net.xoetrope.awt.XButton;
/*  12:    */ import net.xoetrope.awt.XDialog;
/*  13:    */ import net.xoetrope.awt.XEdit;
/*  14:    */ import net.xoetrope.awt.XPassword;
/*  15:    */ import net.xoetrope.xui.XPage;
/*  16:    */ import net.xoetrope.xui.XPageHelper;
/*  17:    */ import net.xoetrope.xui.XPageManager;
/*  18:    */ import net.xoetrope.xui.XTarget;
/*  19:    */ import net.xoetrope.xui.data.XModel;
/*  20:    */ 
/*  21:    */ public class Welcome
/*  22:    */   extends NavPanel
/*  23:    */ {
/*  24:    */   public void openAbout()
/*  25:    */   {
/*  26: 40 */     XDialog dlg = (XDialog)this.pageMgr.loadPage("about");
/*  27: 41 */     dlg.pack();
/*  28: 42 */     dlg.showDialog(this);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void pageCreated() {}
/*  32:    */   
/*  33:    */   public static void main(String[] args)
/*  34:    */   {
/*  35: 54 */     System.out.println("  HEre and now !!");
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void pageActivated()
/*  39:    */   {
/*  40: 62 */     System.out.println("Page activated called: welcome");
/*  41: 63 */     XTarget bTarget = (XTarget)this.pageMgr.getTarget("bottom");
/*  42: 64 */     if (bTarget != null)
/*  43:    */     {
/*  44: 66 */       XPage bottomPage = (XPage)bTarget.getComponent(0);
/*  45: 67 */       XButton parentBtn = (XButton)bottomPage.findComponent("prevBtn");
/*  46: 68 */       XButton nextBtn = (XButton)bottomPage.findComponent("nextBtn");
/*  47: 69 */       XButton saveBtn = (XButton)bottomPage.findComponent("saveBtn");
/*  48: 70 */       XButton homeBtn = (XButton)bottomPage.findComponent("homeBtn");
/*  49: 71 */       parentBtn.setVisible(false);
/*  50: 72 */       nextBtn.setVisible(false);
/*  51: 73 */       saveBtn.setVisible(false);
/*  52: 74 */       homeBtn.setVisible(false);
/*  53:    */     }
/*  54: 76 */     XEdit userEdit = (XEdit)findComponent("username");
/*  55: 77 */     userEdit.requestFocus();
/*  56: 78 */     userEdit.setText("");
/*  57: 79 */     XPassword passwordEdit = (XPassword)findComponent("password");
/*  58: 80 */     passwordEdit.setText("");
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void nextPage()
/*  62:    */   {
/*  63: 87 */     Integer level = validateUser();
/*  64: 94 */     if (level.intValue() != 2)
/*  65:    */     {
/*  66: 96 */       this.pageMgr.showPage("testqp");
/*  67: 97 */       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*  68: 98 */       String dt1 = sdf.format(new Date());
/*  69: 99 */       XModel today = (XModel)this.rootModel.get("survey/statistics/" + dt1 + "/logintime");
/*  70:100 */       if (today.get() == null) {
/*  71:101 */         today.set(new SimpleDateFormat("hh:mm:ss a").format(new Date()));
/*  72:    */       }
/*  73:    */     }
/*  74:    */     else
/*  75:    */     {
/*  76:104 */       showMessagePanel("Error", "Error while validating User name /password ", "qpanel0");
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void nextPageByEnter()
/*  81:    */   {
/*  82:111 */     KeyEvent evt = (KeyEvent)getCurrentEvent();
/*  83:112 */     if ((((KeyEvent)getCurrentEvent()).getID() == 401) && 
/*  84:113 */       (evt.getKeyCode() == 10)) {
/*  85:114 */       nextPage();
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void nextPage1()
/*  90:    */   {
/*  91:119 */     Integer level = validateUser();
/*  92:120 */     MouseEvent evt = (MouseEvent)getCurrentEvent();
/*  93:    */     
/*  94:122 */     System.out.println("next mouse" + evt);
/*  95:124 */     if (evt.getID() == 501)
/*  96:    */     {
/*  97:    */       XPage newPage;
/*  98:125 */       if (level.intValue() != 2) {
/*  99:127 */         newPage = (XPage)this.pageMgr.showPage("selectsurvey", "content");
/* 100:    */       } else {
/* 101:130 */         this.pageHelper.showMessage("Error", "Error while validating User name /password ");
/* 102:    */       }
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void pageDeactivated()
/* 107:    */   {
/* 108:137 */     if (isValid())
/* 109:    */     {
/* 110:139 */       XPage bottomPage = (XPage)((XTarget)this.pageMgr.getTarget("bottom")).getComponent(0);
/* 111:140 */       XButton parentBtn = (XButton)bottomPage.findComponent("prevBtn");
/* 112:141 */       XButton nextBtn = (XButton)bottomPage.findComponent("nextBtn");
/* 113:142 */       XButton saveBtn = (XButton)bottomPage.findComponent("saveBtn");
/* 114:143 */       XButton homeBtn = (XButton)bottomPage.findComponent("homeBtn");
/* 115:144 */       parentBtn.setVisible(true);
/* 116:145 */       nextBtn.setVisible(true);
/* 117:146 */       saveBtn.setVisible(true);
/* 118:147 */       homeBtn.setVisible(true);
/* 119:    */     }
/* 120:    */   }
/* 121:    */   
/* 122:    */   public Integer validateUser()
/* 123:    */   {
/* 124:152 */     System.out.println("Validate user called");
/* 125:153 */     int level = 2;
/* 126:154 */     XEdit userLbl = (XEdit)findComponent("username");
/* 127:155 */     XPassword passwordLbl = (XPassword)findComponent("password");
/* 128:156 */     String username = userLbl.getText();
/* 129:157 */     System.out.println("The User name entered is:" + username);
/* 130:158 */     String password = passwordLbl.getText();
/* 131:159 */     System.out.println("The Password entered is:" + password);
/* 132:160 */     if ((username.equals("")) || (password.equals("")))
/* 133:    */     {
/* 134:162 */       level = 2;
/* 135:    */     }
/* 136:    */     else
/* 137:    */     {
/* 138:170 */       String userPath = "teamdata/users/" + username;
/* 139:171 */       XModel userM = (XModel)this.rootModel.get(userPath);
/* 140:172 */       if (userM == null)
/* 141:    */       {
/* 142:173 */         level = 2;
/* 143:    */       }
/* 144:    */       else
/* 145:    */       {
/* 146:176 */         int attrIndex = userM.getAttribute("password");
/* 147:177 */         String passwd = userM.getAttribValueAsString(attrIndex);
/* 148:178 */         if (!password.equals(passwd))
/* 149:    */         {
/* 150:179 */           level = 2;
/* 151:    */         }
/* 152:    */         else
/* 153:    */         {
/* 154:182 */           level = 0;
/* 155:183 */           XModel currentUserM = (XModel)this.rootModel.get("temp/currentuser");
/* 156:184 */           currentUserM.set(username);
/* 157:185 */           XModel teamsM = (XModel)this.rootModel.get("teamdata/teams");
/* 158:186 */           for (int tIndex = 0; tIndex < teamsM.getNumChildren(); tIndex++)
/* 159:    */           {
/* 160:188 */             XModel cTeam = teamsM.get(tIndex);
/* 161:189 */             for (int mIndex = 0; mIndex < cTeam.getNumChildren(); mIndex++)
/* 162:    */             {
/* 163:191 */               XModel cMember = cTeam.get(mIndex);
/* 164:192 */               if (((String)cMember.get()).equals(username))
/* 165:    */               {
/* 166:194 */                 XModel currentTeamM = (XModel)this.rootModel.get("temp/currentteam");
/* 167:195 */                 currentTeamM.set(cTeam.getId());
/* 168:    */                 
/* 169:197 */                 String userDir = System.getProperty("user.dir");
/* 170:198 */                 String path = userDir + System.getProperty("file.separator") + "resources" + System.getProperty("file.separator") + "save.xml";
/* 171:199 */                 File saveFile = new File(path);
/* 172:    */                 
/* 173:    */ 
/* 174:202 */                 int attIndex = userM.getAttribute("code");
/* 175:203 */                 String code = (String)userM.getAttribValue(attIndex);
/* 176:204 */                 XModel surveyM = (XModel)this.rootModel.get("survey");
/* 177:    */                 
/* 178:206 */                 surveyM.set("@team", currentTeamM.get());
/* 179:207 */                 surveyM.set("@participant", code);
/* 180:    */                 
/* 181:    */ 
/* 182:    */ 
/* 183:211 */                 attIndex = surveyM.getAttribute("team");
/* 184:212 */                 String teamInSave = (String)surveyM.getAttribValue(attIndex);
/* 185:213 */                 attIndex = surveyM.getAttribute("participant");
/* 186:214 */                 String participantInSave = (String)surveyM.getAttribValue(attIndex);
/* 187:215 */                 String otherUser = "";
/* 188:216 */                 if ((!cTeam.getId().equals(teamInSave)) || (!code.equals(participantInSave)))
/* 189:    */                 {
/* 190:219 */                   XModel allUserM = (XModel)this.rootModel.get("teamdata/users");
/* 191:220 */                   for (int uindex = 0; uindex < allUserM.getNumChildren(); uindex++)
/* 192:    */                   {
/* 193:222 */                     XModel uM = allUserM.get(uindex);
/* 194:223 */                     int aIndex = uM.getAttribute("code");
/* 195:224 */                     String uCode = (String)uM.getAttribValue(aIndex);
/* 196:225 */                     if (participantInSave.equals(uCode)) {
/* 197:226 */                       otherUser = uM.getId();
/* 198:    */                     }
/* 199:    */                   }
/* 200:    */                 }
/* 201:    */               }
/* 202:    */             }
/* 203:    */           }
/* 204:    */         }
/* 205:    */       }
/* 206:    */     }
/* 207:243 */     return new Integer(level);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void textValueChanged(TextEvent e)
/* 211:    */   {
/* 212:248 */     XPassword passwordEdit = (XPassword)findComponent("password");
/* 213:249 */     if (passwordEdit.getText().length() == 4)
/* 214:    */     {
/* 215:251 */       XButton loginBtn = (XButton)findComponent("loginBtn");
/* 216:252 */       loginBtn.requestFocus();
/* 217:    */     }
/* 218:    */   }
/* 219:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.enumeration.Welcome
 * JD-Core Version:    0.7.0.1
 */