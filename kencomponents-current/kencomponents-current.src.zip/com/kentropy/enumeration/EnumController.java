/*   1:    */ package com.kentropy.enumeration;
/*   2:    */ 
/*   3:    */ import com.kentropy.components.QuestionFlowPanel;
/*   4:    */ import com.kentropy.components.TransferPanel;
/*   5:    */ import com.kentropy.db.TestXUIDB;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.Component;
/*   8:    */ import java.awt.Container;
/*   9:    */ import java.awt.Dimension;
/*  10:    */ import java.awt.Font;
/*  11:    */ import java.awt.Point;
/*  12:    */ import java.awt.event.ActionEvent;
/*  13:    */ import java.awt.im.InputContext;
/*  14:    */ import java.io.File;
/*  15:    */ import java.io.PrintStream;
/*  16:    */ import java.net.URL;
/*  17:    */ import java.util.Locale;
/*  18:    */ import javax.media.Manager;
/*  19:    */ import javax.media.Player;
/*  20:    */ import net.xoetrope.awt.XButton;
/*  21:    */ import net.xoetrope.awt.XLabel;
/*  22:    */ import net.xoetrope.awt.XPanel;
/*  23:    */ import net.xoetrope.awt.XScrollPane;
/*  24:    */ import net.xoetrope.swing.XMessageBox;
/*  25:    */ import net.xoetrope.xui.XPage;
/*  26:    */ import net.xoetrope.xui.data.XBaseModel;
/*  27:    */ import net.xoetrope.xui.data.XModel;
/*  28:    */ 
/*  29:    */ public class EnumController
/*  30:    */   extends XPage
/*  31:    */ {
/*  32:    */   public void updateHouseStats(String house) {}
/*  33:    */   
/*  34:    */   public void closeCurrentSubFlow()
/*  35:    */   {
/*  36: 55 */     String cur = ((XModel)this.rootModel.get("currentPanel")).get().toString();
/*  37: 56 */     QuestionFlowPanel comp = (QuestionFlowPanel)findComponent(cur);
/*  38:    */     
/*  39: 58 */     Container cont = comp.getParent();
/*  40:    */     
/*  41:    */ 
/*  42: 61 */     Component prev = (Component)((XModel)this.rootModel.get("prevPanel")).get();
/*  43: 62 */     System.out.println(prev);
/*  44: 63 */     cont.add(comp.parent);
/*  45:    */     
/*  46: 65 */     ((XModel)this.rootModel.get("currentPanel")).set(comp.parent.getName());
/*  47: 66 */     comp.parent.scrollToCurrent();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void sync()
/*  51:    */   {
/*  52: 78 */     XModel currentTeamM = (XModel)this.rootModel.get("temp/currentteam");
/*  53:    */     
/*  54:    */ 
/*  55: 81 */     String recepients = "admin";
/*  56: 82 */     XModel surveyM = (XModel)this.rootModel.get("survey");
/*  57: 83 */     String currentUser = (String)surveyM.get("@participant");
/*  58: 84 */     int count = 0;
/*  59: 85 */     TransferPanel tfp = new TransferPanel();
/*  60: 86 */     ((XPanel)findComponent("qpanel01")).add(tfp, 0);
/*  61: 87 */     tfp.actionStr = "upload";
/*  62: 88 */     tfp.currentUser = currentUser;
/*  63: 89 */     tfp.recepients = recepients;
/*  64: 90 */     System.out.println("Setting canClose false");
/*  65: 91 */     ((XModel)this.rootModel.get("canclose")).set("false");
/*  66: 92 */     ((XModel)this.rootModel.get("closereason")).set("Synchronizing tasks");
/*  67: 93 */     tfp.display("Upload", "Starting upload ");
/*  68: 94 */     tfp.setVisible(true);
/*  69: 95 */     addActionHandler(tfp.action, "sync2");
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void sync2()
/*  73:    */   {
/*  74:    */     try
/*  75:    */     {
/*  76:105 */       if ((getCurrentEvent() instanceof ActionEvent))
/*  77:    */       {
/*  78:107 */         ActionEvent a = (ActionEvent)getCurrentEvent();
/*  79:108 */         ((XModel)this.rootModel.get("canclose")).set("true");
/*  80:    */       }
/*  81:    */     }
/*  82:    */     catch (Exception e)
/*  83:    */     {
/*  84:112 */       e.printStackTrace();
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void saveHouseScreen()
/*  89:    */   {
/*  90:    */     try
/*  91:    */     {
/*  92:121 */       XModel xm = (XModel)this.rootModel.get("/temp");
/*  93:122 */       System.out.println(" Xui state has " + xm.getNumChildren());
/*  94:    */       
/*  95:124 */       saveBoundComponentValues();
/*  96:125 */       System.out.println(" Xui state has " + xm.getNumChildren());
/*  97:126 */       ((XModel)xm.get("enum_area")).set("99");
/*  98:127 */       ((XModel)xm.get("house")).set("99");
/*  99:128 */       ((XModel)xm.get("household")).set("99");
/* 100:129 */       ((XModel)xm.get("idc")).set("99");
/* 101:    */       
/* 102:131 */       System.out.println(" Xui state has " + xm.get(0).getId() + " " + xm.get(0).get());
/* 103:    */       
/* 104:133 */       new TestXUIDB().saveMember("99", "99", "99", "99", xm);
/* 105:    */     }
/* 106:    */     catch (Exception localException) {}
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void saveHouseHScreen()
/* 110:    */   {
/* 111:    */     try
/* 112:    */     {
/* 113:143 */       XModel xm = (XModel)this.rootModel.get("/temp");
/* 114:144 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 115:    */       
/* 116:146 */       saveBoundComponentValues();
/* 117:147 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 118:148 */       ((XModel)xm.get("enum_area")).set("99");
/* 119:149 */       ((XModel)xm.get("house")).set("99");
/* 120:150 */       ((XModel)xm.get("household")).set("99");
/* 121:    */       
/* 122:    */ 
/* 123:153 */       System.out.println(" Xui state has " + xm.get(0).getId() + " " + xm.get(0).get());
/* 124:    */       
/* 125:155 */       new TestXUIDB().saveHouseHold("99", "99", "99", xm);
/* 126:    */     }
/* 127:    */     catch (Exception localException) {}
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void saveHouseScreen1()
/* 131:    */   {
/* 132:    */     try
/* 133:    */     {
/* 134:165 */       XModel xm = (XModel)this.rootModel.get("/temp");
/* 135:166 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 136:    */       
/* 137:168 */       saveBoundComponentValues();
/* 138:169 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 139:170 */       ((XModel)xm.get("enum_area")).set("99");
/* 140:171 */       ((XModel)xm.get("houseno")).set("99");
/* 141:    */       
/* 142:    */ 
/* 143:    */ 
/* 144:175 */       System.out.println(" Xui state has " + xm.get(0).getId() + " " + xm.get(0).get());
/* 145:    */       
/* 146:177 */       new TestXUIDB().saveHouse("99", "99", xm);
/* 147:    */     }
/* 148:    */     catch (Exception localException) {}
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void confirmMessagePanel(String htext, String msg, String panel)
/* 152:    */   {
/* 153:209 */     if ((XPanel)findComponent("confirm") == null)
/* 154:    */     {
/* 155:211 */       XPanel guide = new XPanel();
/* 156:212 */       guide.setBounds(310, 50, 300, 170);
/* 157:213 */       guide.setName("confirm");
/* 158:214 */       guide.setBackground(new Color(50, 50, 255));
/* 159:215 */       XButton close = new XButton();
/* 160:216 */       close.setText("X");
/* 161:217 */       close.setForeground(Color.white);
/* 162:218 */       close.setBackground(Color.red);
/* 163:219 */       close.setBounds(280, 2, 18, 18);
/* 164:220 */       close.setFont(new Font("Verdana", 1, 12));
/* 165:221 */       addActionHandler(close, "cancelConfirmMessagePanel");
/* 166:222 */       guide.add(close);
/* 167:    */       
/* 168:224 */       XButton yes = new XButton();
/* 169:225 */       yes.setText("Yes");
/* 170:226 */       yes.setForeground(Color.white);
/* 171:227 */       yes.setBackground(Color.red);
/* 172:228 */       yes.setBounds(70, 150, 40, 17);
/* 173:229 */       yes.setFont(new Font("Verdana", 1, 12));
/* 174:230 */       addActionHandler(yes, "yesConfirmMessagePanel");
/* 175:231 */       guide.add(yes);
/* 176:    */       
/* 177:233 */       XButton no = new XButton();
/* 178:234 */       no.setText("No");
/* 179:235 */       no.setForeground(Color.white);
/* 180:236 */       no.setBackground(Color.red);
/* 181:237 */       no.setBounds(180, 150, 40, 17);
/* 182:238 */       no.setFont(new Font("Verdana", 1, 12));
/* 183:239 */       addActionHandler(no, "cancelConfirmMessagePanel");
/* 184:240 */       guide.add(no);
/* 185:    */       
/* 186:242 */       XLabel lbl = new XLabel();
/* 187:243 */       lbl.setName("errorContainer");
/* 188:244 */       lbl.setBackground(new Color(240, 240, 240));
/* 189:245 */       lbl.setForeground(Color.black);
/* 190:246 */       lbl.setBounds(3, 22, 294, 125);
/* 191:247 */       lbl.setText(msg);
/* 192:248 */       lbl.setVisible(true);
/* 193:249 */       XLabel header = new XLabel();
/* 194:250 */       header.setName("errorHeader");
/* 195:251 */       header.setBackground(new Color(50, 50, 255));
/* 196:252 */       header.setForeground(Color.red);
/* 197:253 */       header.setBounds(1, 1, 230, 18);
/* 198:254 */       header.setVisible(true);
/* 199:255 */       header.setFont(new Font("Verdana", 1, 12));
/* 200:256 */       header.setText(htext);
/* 201:257 */       guide.add(header);
/* 202:258 */       guide.add(lbl);
/* 203:259 */       guide.setVisible(true);
/* 204:260 */       ((XPanel)findComponent(panel)).add(guide, 0);
/* 205:261 */       close.requestFocus();
/* 206:    */     }
/* 207:    */     else
/* 208:    */     {
/* 209:265 */       ((XPanel)findComponent("confirm")).setVisible(true);
/* 210:266 */       ((XLabel)findComponent("errorContainer")).setText(msg);
/* 211:267 */       ((XLabel)findComponent("errorHeader")).setText(htext);
/* 212:    */     }
/* 213:    */   }
/* 214:    */   
/* 215:    */   public void playVideo()
/* 216:    */   {
/* 217:    */     try
/* 218:    */     {
/* 219:274 */       URL mediaURL = new File("training_video-dec13_controller.swf").toURL();
/* 220:275 */       Player mediaPlayer = Manager.createRealizedPlayer(mediaURL);
/* 221:    */       
/* 222:    */ 
/* 223:278 */       Component video = mediaPlayer.getVisualComponent();
/* 224:279 */       Component controls = mediaPlayer.getControlPanelComponent();
/* 225:280 */       video.setBounds(0, 0, 900, 600);
/* 226:281 */       controls.setBounds(0, 610, 900, 20);
/* 227:282 */       ((Component)findComponent("okbtn")).setVisible(false);
/* 228:283 */       ((XPanel)findComponent("videopanel0")).setVisible(true);
/* 229:    */       
/* 230:285 */       ((XPanel)findComponent("videopanel0")).add(video);
/* 231:    */       
/* 232:    */ 
/* 233:288 */       ((XPanel)findComponent("videopanel0")).add(controls);
/* 234:    */       
/* 235:290 */       mediaPlayer.start();
/* 236:    */     }
/* 237:    */     catch (Exception e)
/* 238:    */     {
/* 239:296 */       e.printStackTrace();
/* 240:    */     }
/* 241:    */   }
/* 242:    */   
/* 243:    */   public static void main(String[] args) {}
/* 244:    */   
/* 245:    */   public void pageActivated()
/* 246:    */   {
/* 247:309 */     super.pageActivated();
/* 248:    */     
/* 249:311 */     validate();
/* 250:    */   }
/* 251:    */   
/* 252:317 */   XModel context = new XBaseModel();
/* 253:    */   
/* 254:    */   public XModel testLookup()
/* 255:    */   {
/* 256:320 */     XModel currentContext = (XModel)this.rootModel.get("currentContext");
/* 257:321 */     XModel currentContextType = (XModel)this.rootModel.get("currentContextType");
/* 258:322 */     XModel currentContext1 = currentContext.get(0);
/* 259:323 */     XModel newContext = new XBaseModel();
/* 260:324 */     newContext.append(currentContext1.get(2));
/* 261:    */     
/* 262:326 */     System.out.println("new Context test " + newContext.getNumChildren());
/* 263:327 */     for (int i = 0; i < newContext.getNumChildren(); i++) {
/* 264:329 */       System.out.println(newContext.get(i).getId() + " " + newContext.get(i).get());
/* 265:    */     }
/* 266:    */     try
/* 267:    */     {
/* 268:332 */       XModel data = TestXUIDB.getInstance().getEnumData(newContext, currentContextType.get().toString(), "landmark,id");
/* 269:333 */       XModel options = new XBaseModel();
/* 270:334 */       for (int i = 0; i < data.getNumChildren(); i++)
/* 271:    */       {
/* 272:336 */         XModel xm = new XBaseModel();
/* 273:337 */         xm.setId(i + 1);
/* 274:338 */         xm.set(data.get(i).get(0).get());
/* 275:339 */         options.append(xm);
/* 276:    */       }
/* 277:341 */       return options;
/* 278:    */     }
/* 279:    */     catch (Exception e)
/* 280:    */     {
/* 281:344 */       e.printStackTrace();
/* 282:    */     }
/* 283:346 */     return null;
/* 284:    */   }
/* 285:    */   
/* 286:    */   public XModel testLookupArea(String field)
/* 287:    */   {
/* 288:351 */     XModel currentContext = (XModel)this.rootModel.get("currentContext");
/* 289:352 */     XModel currentContext1 = currentContext.get(0);
/* 290:353 */     XModel newContext = new XBaseModel();
/* 291:354 */     newContext.append((XModel)currentContext1.get("survey"));
/* 292:355 */     newContext.append((XModel)currentContext1.get("area"));
/* 293:356 */     newContext.append((XModel)currentContext1.get("surveyor"));
/* 294:    */     
/* 295:358 */     System.out.println("new Context test " + newContext.getNumChildren());
/* 296:359 */     for (int i = 0; i < newContext.getNumChildren(); i++) {
/* 297:361 */       System.out.println(newContext.get(i).getId() + " " + newContext.get(i).get());
/* 298:    */     }
/* 299:    */     try
/* 300:    */     {
/* 301:364 */       XModel data = TestXUIDB.getInstance().getEnumData(newContext, "area", field + ",id");
/* 302:365 */       XModel options = new XBaseModel();
/* 303:366 */       for (int i = 0; i < data.getNumChildren(); i++)
/* 304:    */       {
/* 305:368 */         XModel xm = new XBaseModel();
/* 306:369 */         xm.setId(i + 1);
/* 307:370 */         xm.set(data.get(i).get(0).get());
/* 308:371 */         options.append(xm);
/* 309:    */       }
/* 310:373 */       return options;
/* 311:    */     }
/* 312:    */     catch (Exception e)
/* 313:    */     {
/* 314:376 */       e.printStackTrace();
/* 315:    */     }
/* 316:378 */     return null;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public XModel lookupMember(String field)
/* 320:    */   {
/* 321:383 */     XModel currentContext = (XModel)this.rootModel.get("currentContext");
/* 322:384 */     XModel currentContext1 = currentContext.get(0);
/* 323:385 */     XModel newContext = new XBaseModel();
/* 324:386 */     newContext.append((XModel)currentContext1.get("survey"));
/* 325:387 */     newContext.append((XModel)currentContext1.get("area"));
/* 326:388 */     newContext.append((XModel)currentContext1.get("house"));
/* 327:389 */     newContext.append((XModel)currentContext1.get("household"));
/* 328:390 */     newContext.append((XModel)currentContext1.get("surveyor"));
/* 329:391 */     ((XModel)newContext.get("survey")).set("Enumeration");
/* 330:    */     
/* 331:393 */     System.out.println("new Context test " + newContext.getNumChildren());
/* 332:394 */     for (int i = 0; i < newContext.getNumChildren(); i++) {
/* 333:396 */       System.out.println(newContext.get(i).getId() + " " + newContext.get(i).get());
/* 334:    */     }
/* 335:    */     try
/* 336:    */     {
/* 337:399 */       XModel data = TestXUIDB.getInstance().getEnumDataChildren(newContext, "concat(name,'-',idc)", "deathStatus is null", "member");
/* 338:400 */       XModel options = new XBaseModel();
/* 339:401 */       System.out.println(" looking up members " + data.getNumChildren());
/* 340:402 */       for (int i = 0; i < data.getNumChildren(); i++)
/* 341:    */       {
/* 342:404 */         XModel xm = new XBaseModel();
/* 343:405 */         xm.setId(i + 1);
/* 344:406 */         xm.set(data.get(i).get(0).get());
/* 345:407 */         options.append(xm);
/* 346:    */       }
/* 347:409 */       return options;
/* 348:    */     }
/* 349:    */     catch (Exception e)
/* 350:    */     {
/* 351:412 */       e.printStackTrace();
/* 352:    */     }
/* 353:414 */     return null;
/* 354:    */   }
/* 355:    */   
/* 356:    */   public void pageCreated()
/* 357:    */   {
/* 358:431 */     XModel flowModel = new XBaseModel();
/* 359:    */   }
/* 360:    */   
/* 361:    */   public void launchEnumeration()
/* 362:    */   {
/* 363:505 */     launchSurvey("Enumeration", "surveyflow");
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void displayMsg(String msg)
/* 367:    */   {
/* 368:510 */     XMessageBox mbox = new XMessageBox();
/* 369:511 */     Dimension size = getSize();
/* 370:512 */     Point location = getLocationOnScreen();
/* 371:513 */     size = new Dimension(size.width + 2 * location.x, size.height + 2 * location.y);
/* 372:    */     
/* 373:515 */     mbox.setup("Message", msg, size, this);
/* 374:    */   }
/* 375:    */   
/* 376:    */   public void validateLang()
/* 377:    */   {
/* 378:520 */     String lang = (String)((XModel)this.rootModel.get("temp/lang")).get();
/* 379:521 */     System.out.println(" Lang ----" + lang);
/* 380:522 */     if (lang != null) {
/* 381:524 */       if (!InputContext.getInstance().getLocale().getLanguage().equals(lang))
/* 382:    */       {
/* 383:526 */         displayMsg(" Please select " + lang);
/* 384:527 */         InputContext.getInstance().selectInputMethod(new Locale("in", lang));
/* 385:    */       }
/* 386:    */     }
/* 387:    */   }
/* 388:    */   
/* 389:    */   public void launchVA()
/* 390:    */   {
/* 391:536 */     validateLang();
/* 392:537 */     launchSurvey("VA", "vasurveyflow");
/* 393:    */   }
/* 394:    */   
/* 395:540 */   String lang = "en";
/* 396:    */   
/* 397:    */   public void launchSurvey(String survey, String flow)
/* 398:    */   {
/* 399:544 */     XModel flowModel = (XModel)this.rootModel.get("flows/" + flow);
/* 400:545 */     System.out.println(" Flow is " + flowModel.getId() + " " + flowModel.getNumChildren());
/* 401:    */     
/* 402:    */ 
/* 403:    */ 
/* 404:    */ 
/* 405:    */ 
/* 406:    */ 
/* 407:    */ 
/* 408:    */ 
/* 409:    */ 
/* 410:    */ 
/* 411:    */ 
/* 412:557 */     QuestionFlowPanel qfp = new QuestionFlowPanel();
/* 413:558 */     qfp.rootModel = this.rootModel;
/* 414:    */     
/* 415:560 */     qfp.setName(flow);
/* 416:561 */     qfp.setBounds(50, 50, 800, 10000);
/* 417:562 */     qfp.setAttribute("border", "1");
/* 418:563 */     ((XScrollPane)findComponent("qpanel1")).add(qfp);
/* 419:564 */     this.context = new XBaseModel();
/* 420:565 */     ((XModel)this.context.get("survey")).set(survey);
/* 421:    */     
/* 422:567 */     XModel surveyM = (XModel)this.rootModel.get("survey");
/* 423:568 */     ((XModel)this.context.get("surveyor")).set(surveyM.get("@participant").toString());
/* 424:569 */     qfp.context = this.context;
/* 425:570 */     qfp.setQuestionFlowModel(flowModel, new XBaseModel());
/* 426:    */     
/* 427:    */ 
/* 428:573 */     qfp.setVisible(true);
/* 429:    */   }
/* 430:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.enumeration.EnumController
 * JD-Core Version:    0.7.0.1
 */