/*   1:    */ package com.kentropy.enumeration.swing;
/*   2:    */ 
/*   3:    */ import com.kentropy.components.TransferPanel;
/*   4:    */ import com.kentropy.components.swing.NetworkPanel;
/*   5:    */ import com.kentropy.components.swing.QuestionFlowPanel;
/*   6:    */ import com.kentropy.db.TestXUIDB;
/*   7:    */ import com.kentropy.transfer.Discovery;
/*   8:    */ import java.awt.Color;
/*   9:    */ import java.awt.Component;
/*  10:    */ import java.awt.Container;
/*  11:    */ import java.awt.Dimension;
/*  12:    */ import java.awt.Font;
/*  13:    */ import java.awt.Point;
/*  14:    */ import java.awt.Window;
/*  15:    */ import java.awt.event.ActionEvent;
/*  16:    */ import java.awt.im.InputContext;
/*  17:    */ import java.io.File;
/*  18:    */ import java.io.PrintStream;
/*  19:    */ import java.net.URL;
/*  20:    */ import java.util.Locale;
/*  21:    */ import java.util.Observable;
/*  22:    */ import java.util.Observer;
/*  23:    */ import javax.media.Manager;
/*  24:    */ import javax.media.Player;
/*  25:    */ import net.xoetrope.swing.XButton;
/*  26:    */ import net.xoetrope.swing.XLabel;
/*  27:    */ import net.xoetrope.swing.XMessageBox;
/*  28:    */ import net.xoetrope.swing.XPanel;
/*  29:    */ import net.xoetrope.swing.XScrollPane;
/*  30:    */ import net.xoetrope.swing.XTextArea;
/*  31:    */ import net.xoetrope.xui.XPage;
/*  32:    */ import net.xoetrope.xui.XProject;
/*  33:    */ import net.xoetrope.xui.XProjectManager;
/*  34:    */ import net.xoetrope.xui.data.XBaseModel;
/*  35:    */ import net.xoetrope.xui.data.XModel;
/*  36:    */ 
/*  37:    */ public class EnumController
/*  38:    */   extends XPage
/*  39:    */   implements Observer
/*  40:    */ {
/*  41:    */   public void displayMsg(String msg)
/*  42:    */   {
/*  43: 57 */     XMessageBox mbox = new XMessageBox();
/*  44: 58 */     Dimension size = getSize();
/*  45: 59 */     Point location = getLocationOnScreen();
/*  46: 60 */     size = new Dimension(size.width + 2 * location.x, size.height + 2 * location.y);
/*  47:    */     
/*  48: 62 */     mbox.setup("Message", msg, size, this);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean validateLang()
/*  52:    */   {
/*  53: 66 */     this.lang = ((String)((XModel)this.rootModel.get("temp/lang")).get());
/*  54: 67 */     System.out.println(" Lang ----" + this.lang);
/*  55: 68 */     if (this.lang != null) {
/*  56: 70 */       if (!InputContext.getInstance().getLocale().getLanguage().equals(this.lang))
/*  57:    */       {
/*  58: 72 */         displayMsg(" Please select " + this.lang);
/*  59: 73 */         InputContext.getInstance().selectInputMethod(new Locale("in", this.lang));
/*  60: 74 */         return false;
/*  61:    */       }
/*  62:    */     }
/*  63: 79 */     return true;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void updateHouseStats(String house) {}
/*  67:    */   
/*  68:    */   public void closeCurrentSubFlow()
/*  69:    */   {
/*  70: 88 */     String cur = ((XModel)this.rootModel.get("currentPanel")).get().toString();
/*  71: 89 */     Component comp1 = (Component)findComponent(cur);
/*  72:    */     
/*  73: 91 */     Container cont = comp1.getParent();
/*  74: 92 */     QuestionFlowPanel comp = (QuestionFlowPanel)comp1;
/*  75: 93 */     comp.close();
/*  76:    */     
/*  77:    */ 
/*  78: 96 */     Component prev = (Component)((XModel)this.rootModel.get("prevPanel")).get();
/*  79: 97 */     System.out.println(prev);
/*  80: 98 */     cont.add(comp.parent);
/*  81:    */     
/*  82:100 */     ((XModel)this.rootModel.get("currentPanel")).set(comp.parent.getName());
/*  83:101 */     comp.parent.scrollToCurrent();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void sync()
/*  87:    */   {
/*  88:113 */     XModel currentTeamM = (XModel)this.rootModel.get("temp/currentteam");
/*  89:    */     
/*  90:    */ 
/*  91:116 */     String recepients = "admin";
/*  92:117 */     XModel surveyM = (XModel)this.rootModel.get("survey");
/*  93:118 */     String currentUser = (String)surveyM.get("@participant");
/*  94:119 */     int count = 0;
/*  95:120 */     TransferPanel tfp = new TransferPanel();
/*  96:121 */     ((XPanel)findComponent("qpanel01")).add(tfp, 0);
/*  97:122 */     tfp.actionStr = "upload";
/*  98:123 */     tfp.currentUser = currentUser;
/*  99:124 */     tfp.recepients = recepients;
/* 100:125 */     System.out.println("Setting canClose false");
/* 101:126 */     ((XModel)this.rootModel.get("canclose")).set("false");
/* 102:127 */     ((XModel)this.rootModel.get("closereason")).set("Synchronizing tasks");
/* 103:128 */     tfp.display("Upload", "Starting upload ");
/* 104:129 */     tfp.setVisible(true);
/* 105:    */     
/* 106:    */ 
/* 107:132 */     addActionHandler(tfp.action, "sync2");
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void sync2()
/* 111:    */   {
/* 112:    */     try
/* 113:    */     {
/* 114:143 */       if ((getCurrentEvent() instanceof ActionEvent))
/* 115:    */       {
/* 116:145 */         ActionEvent a = (ActionEvent)getCurrentEvent();
/* 117:146 */         ((XModel)this.rootModel.get("canclose")).set("true");
/* 118:    */       }
/* 119:    */     }
/* 120:    */     catch (Exception e)
/* 121:    */     {
/* 122:150 */       e.printStackTrace();
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void saveHouseScreen()
/* 127:    */   {
/* 128:    */     try
/* 129:    */     {
/* 130:159 */       XModel xm = (XModel)this.rootModel.get("/temp");
/* 131:160 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 132:    */       
/* 133:162 */       saveBoundComponentValues();
/* 134:163 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 135:164 */       ((XModel)xm.get("enum_area")).set("99");
/* 136:165 */       ((XModel)xm.get("house")).set("99");
/* 137:166 */       ((XModel)xm.get("household")).set("99");
/* 138:167 */       ((XModel)xm.get("idc")).set("99");
/* 139:    */       
/* 140:169 */       System.out.println(" Xui state has " + xm.get(0).getId() + " " + xm.get(0).get());
/* 141:    */       
/* 142:171 */       new TestXUIDB().saveMember("99", "99", "99", "99", xm);
/* 143:    */     }
/* 144:    */     catch (Exception localException) {}
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void saveHouseHScreen()
/* 148:    */   {
/* 149:    */     try
/* 150:    */     {
/* 151:181 */       XModel xm = (XModel)this.rootModel.get("/temp");
/* 152:182 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 153:    */       
/* 154:184 */       saveBoundComponentValues();
/* 155:185 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 156:186 */       ((XModel)xm.get("enum_area")).set("99");
/* 157:187 */       ((XModel)xm.get("house")).set("99");
/* 158:188 */       ((XModel)xm.get("household")).set("99");
/* 159:    */       
/* 160:    */ 
/* 161:191 */       System.out.println(" Xui state has " + xm.get(0).getId() + " " + xm.get(0).get());
/* 162:    */       
/* 163:193 */       new TestXUIDB().saveHouseHold("99", "99", "99", xm);
/* 164:    */     }
/* 165:    */     catch (Exception localException) {}
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void saveHouseScreen1()
/* 169:    */   {
/* 170:    */     try
/* 171:    */     {
/* 172:203 */       XModel xm = (XModel)this.rootModel.get("/temp");
/* 173:204 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 174:    */       
/* 175:206 */       saveBoundComponentValues();
/* 176:207 */       System.out.println(" Xui state has " + xm.getNumChildren());
/* 177:208 */       ((XModel)xm.get("enum_area")).set("99");
/* 178:209 */       ((XModel)xm.get("houseno")).set("99");
/* 179:    */       
/* 180:    */ 
/* 181:    */ 
/* 182:213 */       System.out.println(" Xui state has " + xm.get(0).getId() + " " + xm.get(0).get());
/* 183:    */       
/* 184:215 */       new TestXUIDB().saveHouse("99", "99", xm);
/* 185:    */     }
/* 186:    */     catch (Exception localException) {}
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void confirmMessagePanel(String htext, String msg, String panel)
/* 190:    */   {
/* 191:247 */     if ((XPanel)findComponent("confirm") == null)
/* 192:    */     {
/* 193:249 */       XPanel guide = new XPanel();
/* 194:250 */       guide.setBounds(310, 50, 300, 170);
/* 195:251 */       guide.setName("confirm");
/* 196:252 */       guide.setBackground(new Color(50, 50, 255));
/* 197:253 */       XButton close = new XButton();
/* 198:254 */       close.setText("X");
/* 199:255 */       close.setForeground(Color.white);
/* 200:256 */       close.setBackground(Color.red);
/* 201:257 */       close.setBounds(280, 2, 18, 18);
/* 202:258 */       close.setFont(new Font("Verdana", 1, 12));
/* 203:259 */       addActionHandler(close, "cancelConfirmMessagePanel");
/* 204:260 */       guide.add(close);
/* 205:    */       
/* 206:262 */       XButton yes = new XButton();
/* 207:263 */       yes.setText("Yes");
/* 208:264 */       yes.setForeground(Color.white);
/* 209:265 */       yes.setBackground(Color.red);
/* 210:266 */       yes.setBounds(70, 150, 40, 17);
/* 211:267 */       yes.setFont(new Font("Verdana", 1, 12));
/* 212:268 */       addActionHandler(yes, "yesConfirmMessagePanel");
/* 213:269 */       guide.add(yes);
/* 214:    */       
/* 215:271 */       XButton no = new XButton();
/* 216:272 */       no.setText("No");
/* 217:273 */       no.setForeground(Color.white);
/* 218:274 */       no.setBackground(Color.red);
/* 219:275 */       no.setBounds(180, 150, 40, 17);
/* 220:276 */       no.setFont(new Font("Verdana", 1, 12));
/* 221:277 */       addActionHandler(no, "cancelConfirmMessagePanel");
/* 222:278 */       guide.add(no);
/* 223:    */       
/* 224:280 */       XLabel lbl = new XLabel();
/* 225:281 */       lbl.setName("errorContainer");
/* 226:282 */       lbl.setBackground(new Color(240, 240, 240));
/* 227:283 */       lbl.setForeground(Color.black);
/* 228:284 */       lbl.setBounds(3, 22, 294, 125);
/* 229:285 */       lbl.setText(msg);
/* 230:286 */       lbl.setVisible(true);
/* 231:287 */       XLabel header = new XLabel();
/* 232:288 */       header.setName("errorHeader");
/* 233:289 */       header.setBackground(new Color(50, 50, 255));
/* 234:290 */       header.setForeground(Color.red);
/* 235:291 */       header.setBounds(1, 1, 230, 18);
/* 236:292 */       header.setVisible(true);
/* 237:293 */       header.setFont(new Font("Verdana", 1, 12));
/* 238:294 */       header.setText(htext);
/* 239:295 */       guide.add(header);
/* 240:296 */       guide.add(lbl);
/* 241:297 */       guide.setVisible(true);
/* 242:298 */       ((XPanel)findComponent(panel)).add(guide, 0);
/* 243:299 */       close.requestFocus();
/* 244:    */     }
/* 245:    */     else
/* 246:    */     {
/* 247:303 */       ((XPanel)findComponent("confirm")).setVisible(true);
/* 248:304 */       ((XLabel)findComponent("errorContainer")).setText(msg);
/* 249:305 */       ((XLabel)findComponent("errorHeader")).setText(htext);
/* 250:    */     }
/* 251:    */   }
/* 252:    */   
/* 253:    */   public void playVideo()
/* 254:    */   {
/* 255:    */     try
/* 256:    */     {
/* 257:312 */       URL mediaURL = new File("training_video-dec13_controller.swf").toURL();
/* 258:313 */       Player mediaPlayer = Manager.createRealizedPlayer(mediaURL);
/* 259:    */       
/* 260:    */ 
/* 261:316 */       Component video = mediaPlayer.getVisualComponent();
/* 262:317 */       Component controls = mediaPlayer.getControlPanelComponent();
/* 263:318 */       video.setBounds(0, 0, 900, 600);
/* 264:319 */       controls.setBounds(0, 610, 900, 20);
/* 265:320 */       ((Component)findComponent("okbtn")).setVisible(false);
/* 266:321 */       ((XPanel)findComponent("videopanel0")).setVisible(true);
/* 267:    */       
/* 268:323 */       ((XPanel)findComponent("videopanel0")).add(video);
/* 269:    */       
/* 270:    */ 
/* 271:326 */       ((XPanel)findComponent("videopanel0")).add(controls);
/* 272:    */       
/* 273:328 */       mediaPlayer.start();
/* 274:    */     }
/* 275:    */     catch (Exception e)
/* 276:    */     {
/* 277:334 */       e.printStackTrace();
/* 278:    */     }
/* 279:    */   }
/* 280:    */   
/* 281:    */   public static void main(String[] args) {}
/* 282:    */   
/* 283:    */   public void pageActivated()
/* 284:    */   {
/* 285:347 */     super.pageActivated();
/* 286:    */   }
/* 287:    */   
/* 288:353 */   XModel context = new XBaseModel();
/* 289:    */   
/* 290:    */   public XModel testLookup()
/* 291:    */   {
/* 292:356 */     XModel currentContext = (XModel)this.rootModel.get("currentContext");
/* 293:357 */     XModel currentContextType = (XModel)this.rootModel.get("currentContextType");
/* 294:358 */     XModel currentContext1 = currentContext.get(0);
/* 295:359 */     XModel newContext = new XBaseModel();
/* 296:360 */     newContext.append(currentContext1.get(2));
/* 297:    */     
/* 298:362 */     System.out.println("new Context test " + newContext.getNumChildren());
/* 299:363 */     for (int i = 0; i < newContext.getNumChildren(); i++) {
/* 300:365 */       System.out.println(newContext.get(i).getId() + " " + newContext.get(i).get());
/* 301:    */     }
/* 302:    */     try
/* 303:    */     {
/* 304:368 */       XModel data = TestXUIDB.getInstance().getEnumData(newContext, currentContextType.get().toString(), "landmark,id");
/* 305:369 */       XModel options = new XBaseModel();
/* 306:370 */       for (int i = 0; i < data.getNumChildren(); i++)
/* 307:    */       {
/* 308:372 */         XModel xm = new XBaseModel();
/* 309:373 */         xm.setId(i + 1);
/* 310:374 */         xm.set(data.get(i).get(0).get());
/* 311:375 */         options.append(xm);
/* 312:    */       }
/* 313:377 */       return options;
/* 314:    */     }
/* 315:    */     catch (Exception e)
/* 316:    */     {
/* 317:380 */       e.printStackTrace();
/* 318:    */     }
/* 319:382 */     return null;
/* 320:    */   }
/* 321:    */   
/* 322:    */   public XModel testLookupArea(String field)
/* 323:    */   {
/* 324:387 */     XModel currentContext = (XModel)this.rootModel.get("currentContext");
/* 325:388 */     XModel currentContext1 = currentContext.get(0);
/* 326:389 */     XModel newContext = new XBaseModel();
/* 327:390 */     newContext.append((XModel)currentContext1.get("survey"));
/* 328:391 */     newContext.append((XModel)currentContext1.get("area"));
/* 329:392 */     newContext.append((XModel)currentContext1.get("surveyor"));
/* 330:    */     
/* 331:394 */     System.out.println("new Context test " + newContext.getNumChildren());
/* 332:395 */     for (int i = 0; i < newContext.getNumChildren(); i++) {
/* 333:397 */       System.out.println(newContext.get(i).getId() + " " + newContext.get(i).get());
/* 334:    */     }
/* 335:    */     try
/* 336:    */     {
/* 337:400 */       XModel data = TestXUIDB.getInstance().getEnumData(newContext, "area", field + ",id");
/* 338:401 */       XModel options = new XBaseModel();
/* 339:402 */       for (int i = 0; i < data.getNumChildren(); i++)
/* 340:    */       {
/* 341:404 */         XModel xm = new XBaseModel();
/* 342:405 */         xm.setId(i + 1);
/* 343:406 */         xm.set(data.get(i).get(0).get());
/* 344:407 */         options.append(xm);
/* 345:    */       }
/* 346:409 */       return options;
/* 347:    */     }
/* 348:    */     catch (Exception e)
/* 349:    */     {
/* 350:412 */       e.printStackTrace();
/* 351:    */     }
/* 352:414 */     return null;
/* 353:    */   }
/* 354:    */   
/* 355:    */   public XModel lookupMember(String field)
/* 356:    */   {
/* 357:419 */     XModel currentContext = (XModel)this.rootModel.get("currentContext");
/* 358:420 */     XModel currentContext1 = currentContext.get(0);
/* 359:421 */     XModel newContext = new XBaseModel();
/* 360:422 */     newContext.append((XModel)currentContext1.get("survey"));
/* 361:423 */     newContext.append((XModel)currentContext1.get("area"));
/* 362:424 */     newContext.append((XModel)currentContext1.get("house"));
/* 363:425 */     newContext.append((XModel)currentContext1.get("household"));
/* 364:426 */     newContext.append((XModel)currentContext1.get("surveyor"));
/* 365:427 */     ((XModel)newContext.get("survey")).set("Enumeration");
/* 366:    */     
/* 367:429 */     System.out.println("new Context test " + newContext.getNumChildren());
/* 368:430 */     for (int i = 0; i < newContext.getNumChildren(); i++) {
/* 369:432 */       System.out.println(newContext.get(i).getId() + " " + newContext.get(i).get());
/* 370:    */     }
/* 371:    */     try
/* 372:    */     {
/* 373:435 */       XModel data = TestXUIDB.getInstance().getEnumDataChildren(newContext, "concat(name,'-',idc)", "deathStatus is null", "member");
/* 374:436 */       XModel options = new XBaseModel();
/* 375:437 */       System.out.println(" looking up members " + data.getNumChildren());
/* 376:438 */       for (int i = 0; i < data.getNumChildren(); i++)
/* 377:    */       {
/* 378:440 */         XModel xm = new XBaseModel();
/* 379:441 */         xm.setId(i + 1);
/* 380:442 */         xm.set(data.get(i).get(0).get());
/* 381:443 */         options.append(xm);
/* 382:    */       }
/* 383:445 */       return options;
/* 384:    */     }
/* 385:    */     catch (Exception e)
/* 386:    */     {
/* 387:448 */       e.printStackTrace();
/* 388:    */     }
/* 389:450 */     return null;
/* 390:    */   }
/* 391:    */   
/* 392:452 */   NetworkPanel np = new NetworkPanel();
/* 393:    */   
/* 394:    */   public void pageCreated()
/* 395:    */   {
/* 396:466 */     XProjectManager.getCurrentProject().getAppWindow().resize(1024, 710);
/* 397:467 */     XScrollPane.setNextVertScrollPanePolicy(22);
/* 398:    */     try
/* 399:    */     {
/* 400:469 */       System.out.println("Processing pending imports");
/* 401:470 */       TestXUIDB.getInstance().processIncompleteImports();
/* 402:    */     }
/* 403:    */     catch (Exception e)
/* 404:    */     {
/* 405:474 */       e.printStackTrace();
/* 406:    */     }
/* 407:477 */     XModel flowModel = new XBaseModel();
/* 408:    */     
/* 409:    */ 
/* 410:480 */     this.np.setBounds(50, 100, 600, 400);
/* 411:481 */     this.np.init();
/* 412:482 */     this.np.setVisible(false);
/* 413:483 */     ((XPanel)findComponent("qpanel01")).add(this.np, 0);
/* 414:484 */     Thread th = new Thread(new Discovery(this.np));
/* 415:    */   }
/* 416:    */   
/* 417:    */   public void launchEnumeration()
/* 418:    */   {
/* 419:559 */     launchSurvey("Enumeration", "surveyflow");
/* 420:    */   }
/* 421:    */   
/* 422:    */   public void launchVA()
/* 423:    */   {
/* 424:565 */     if (validateLang()) {
/* 425:566 */       launchSurvey("VA", "vasurveyflow");
/* 426:    */     }
/* 427:    */   }
/* 428:    */   
/* 429:    */   public void launchISTP()
/* 430:    */   {
/* 431:572 */     System.out.println("ISTP");
/* 432:573 */     launchSurvey("istp", "istpsurveyflow");
/* 433:    */   }
/* 434:    */   
/* 435:576 */   String lang = "en";
/* 436:    */   
/* 437:    */   public void launchSurvey(String survey, String flow)
/* 438:    */   {
/* 439:580 */     XModel flowModel = (XModel)this.rootModel.get("flows/" + flow);
/* 440:581 */     System.out.println(" Flow is " + flowModel.getId() + " " + flowModel.getNumChildren());
/* 441:    */     
/* 442:    */ 
/* 443:    */ 
/* 444:    */ 
/* 445:    */ 
/* 446:    */ 
/* 447:    */ 
/* 448:    */ 
/* 449:    */ 
/* 450:    */ 
/* 451:    */ 
/* 452:593 */     QuestionFlowPanel qfp = new QuestionFlowPanel();
/* 453:594 */     qfp.lang = this.lang;
/* 454:595 */     qfp.rootModel = this.rootModel;
/* 455:    */     
/* 456:597 */     qfp.setName(flow);
/* 457:598 */     qfp.setBounds(50, 50, 800, 10000);
/* 458:599 */     qfp.setPreferredSize(new Dimension(800, 10000));
/* 459:600 */     qfp.setAttribute("border", "1");
/* 460:601 */     ((XScrollPane)findComponent("qpanel1")).setPreferredSize(new Dimension(800, 500));
/* 461:    */     
/* 462:603 */     ((XScrollPane)findComponent("qpanel1")).setViewportView(qfp);
/* 463:604 */     this.context = new XBaseModel();
/* 464:605 */     ((XModel)this.context.get("survey")).set(survey);
/* 465:    */     
/* 466:607 */     XModel surveyM = (XModel)this.rootModel.get("survey");
/* 467:608 */     ((XModel)this.context.get("surveyor")).set(surveyM.get("@participant").toString());
/* 468:609 */     qfp.context = this.context;
/* 469:610 */     qfp.setQuestionFlowModel(flowModel, new XBaseModel());
/* 470:    */     
/* 471:    */ 
/* 472:613 */     qfp.setVisible(true);
/* 473:    */   }
/* 474:    */   
/* 475:    */   public void update(Observable arg0, Object arg1)
/* 476:    */   {
/* 477:624 */     System.out.println(" --- " + arg1);
/* 478:625 */     XTextArea network = (XTextArea)findComponent("network");
/* 479:626 */     network.setText(arg1.toString());
/* 480:    */   }
/* 481:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.enumeration.swing.EnumController
 * JD-Core Version:    0.7.0.1
 */