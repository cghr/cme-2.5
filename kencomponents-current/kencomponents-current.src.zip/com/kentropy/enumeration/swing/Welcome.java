/*   1:    */ package com.kentropy.enumeration.swing;
/*   2:    */ 
/*   3:    */ import com.kentropy.survey.common.NavPanel;
/*   4:    */ import java.awt.event.KeyEvent;
/*   5:    */ import java.awt.event.MouseEvent;
/*   6:    */ import java.awt.event.TextEvent;
/*   7:    */ import java.io.File;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.text.SimpleDateFormat;
/*  10:    */ import java.util.Date;
/*  11:    */ import net.xoetrope.swing.XButton;
/*  12:    */ import net.xoetrope.swing.XComboBox;
/*  13:    */ import net.xoetrope.swing.XDialog;
/*  14:    */ import net.xoetrope.swing.XEdit;
/*  15:    */ import net.xoetrope.swing.XPassword;
/*  16:    */ import net.xoetrope.swing.XScrollPane;
/*  17:    */ import net.xoetrope.xui.XPage;
/*  18:    */ import net.xoetrope.xui.XPageHelper;
/*  19:    */ import net.xoetrope.xui.XPageManager;
/*  20:    */ import net.xoetrope.xui.XTarget;
/*  21:    */ import net.xoetrope.xui.data.XModel;
/*  22:    */ 
/*  23:    */ public class Welcome
/*  24:    */   extends NavPanel
/*  25:    */ {
/*  26:    */   public void openAbout()
/*  27:    */   {
/*  28: 41 */     XDialog dlg = (XDialog)this.pageMgr.loadPage("about");
/*  29: 42 */     dlg.pack();
/*  30: 43 */     dlg.showDialog(this);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void pageCreated()
/*  34:    */   {
/*  35: 49 */     XScrollPane.setNextVertScrollPanePolicy(22);
/*  36: 50 */     ((XComboBox)findComponent("language")).addItem("en");
/*  37: 51 */     ((XComboBox)findComponent("language")).addItem("mr");
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void main(String[] args)
/*  41:    */   {
/*  42: 58 */     System.out.println("  HEre and now !!");
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void pageActivated()
/*  46:    */   {
/*  47: 66 */     System.out.println("Page activated called: welcome");
/*  48: 67 */     XTarget bTarget = (XTarget)this.pageMgr.getTarget("bottom");
/*  49: 68 */     if (bTarget != null)
/*  50:    */     {
/*  51: 70 */       XPage bottomPage = (XPage)bTarget.getComponent(0);
/*  52: 71 */       XButton parentBtn = (XButton)bottomPage.findComponent("prevBtn");
/*  53: 72 */       XButton nextBtn = (XButton)bottomPage.findComponent("nextBtn");
/*  54: 73 */       XButton saveBtn = (XButton)bottomPage.findComponent("saveBtn");
/*  55: 74 */       XButton homeBtn = (XButton)bottomPage.findComponent("homeBtn");
/*  56: 75 */       parentBtn.setVisible(false);
/*  57: 76 */       nextBtn.setVisible(false);
/*  58: 77 */       saveBtn.setVisible(false);
/*  59: 78 */       homeBtn.setVisible(false);
/*  60:    */     }
/*  61: 80 */     XEdit userEdit = (XEdit)findComponent("username");
/*  62: 81 */     userEdit.requestFocus();
/*  63: 82 */     userEdit.setText("");
/*  64: 83 */     XPassword passwordEdit = (XPassword)findComponent("password");
/*  65: 84 */     passwordEdit.setText("");
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void nextPage()
/*  69:    */   {
/*  70: 91 */     Integer level = validateUser();
/*  71: 98 */     if (level.intValue() != 2)
/*  72:    */     {
/*  73:100 */       this.pageMgr.showPage("testqp");
/*  74:101 */       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
/*  75:102 */       String dt1 = sdf.format(new Date());
/*  76:103 */       XModel today = (XModel)this.rootModel.get("survey/statistics/" + dt1 + "/logintime");
/*  77:104 */       if (today.get() == null) {
/*  78:105 */         today.set(new SimpleDateFormat("hh:mm:ss a").format(new Date()));
/*  79:    */       }
/*  80:    */     }
/*  81:    */     else
/*  82:    */     {
/*  83:108 */       showMessagePanel("Error", "Error while validating User name /password ", "qpanel0");
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void nextPageByEnter()
/*  88:    */   {
/*  89:115 */     KeyEvent evt = (KeyEvent)getCurrentEvent();
/*  90:116 */     if ((((KeyEvent)getCurrentEvent()).getID() == 401) && 
/*  91:117 */       (evt.getKeyCode() == 10)) {
/*  92:118 */       nextPage();
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void nextPage1()
/*  97:    */   {
/*  98:123 */     Integer level = validateUser();
/*  99:124 */     MouseEvent evt = (MouseEvent)getCurrentEvent();
/* 100:    */     
/* 101:126 */     System.out.println("next mouse" + evt);
/* 102:128 */     if (evt.getID() == 501)
/* 103:    */     {
/* 104:    */       XPage newPage;
/* 105:129 */       if (level.intValue() != 2) {
/* 106:131 */         newPage = (XPage)this.pageMgr.showPage("selectsurvey", "content");
/* 107:    */       } else {
/* 108:134 */         this.pageHelper.showMessage("Error", "Error while validating User name /password ");
/* 109:    */       }
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void pageDeactivated()
/* 114:    */   {
/* 115:141 */     if (isValid())
/* 116:    */     {
/* 117:143 */       XPage bottomPage = (XPage)((XTarget)this.pageMgr.getTarget("bottom")).getComponent(0);
/* 118:144 */       XButton parentBtn = (XButton)bottomPage.findComponent("prevBtn");
/* 119:145 */       XButton nextBtn = (XButton)bottomPage.findComponent("nextBtn");
/* 120:146 */       XButton saveBtn = (XButton)bottomPage.findComponent("saveBtn");
/* 121:147 */       XButton homeBtn = (XButton)bottomPage.findComponent("homeBtn");
/* 122:148 */       parentBtn.setVisible(true);
/* 123:149 */       nextBtn.setVisible(true);
/* 124:150 */       saveBtn.setVisible(true);
/* 125:151 */       homeBtn.setVisible(true);
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   public Integer validateUser()
/* 130:    */   {
/* 131:156 */     System.out.println("Validate user called");
/* 132:157 */     int level = 2;
/* 133:158 */     XEdit userLbl = (XEdit)findComponent("username");
/* 134:159 */     XPassword passwordLbl = (XPassword)findComponent("password");
/* 135:160 */     String username = userLbl.getText();
/* 136:161 */     System.out.println("The User name entered is:" + username);
/* 137:162 */     String password = passwordLbl.getText();
/* 138:163 */     System.out.println("The Password entered is:" + password);
/* 139:164 */     if ((username.equals("")) || (password.equals("")))
/* 140:    */     {
/* 141:166 */       level = 2;
/* 142:    */     }
/* 143:    */     else
/* 144:    */     {
/* 145:174 */       String userPath = "teamdata/users/" + username;
/* 146:175 */       XModel userM = (XModel)this.rootModel.get(userPath);
/* 147:176 */       if (userM == null)
/* 148:    */       {
/* 149:177 */         level = 2;
/* 150:    */       }
/* 151:    */       else
/* 152:    */       {
/* 153:180 */         int attrIndex = userM.getAttribute("password");
/* 154:181 */         String passwd = userM.getAttribValueAsString(attrIndex);
/* 155:182 */         if (!password.equals(passwd))
/* 156:    */         {
/* 157:183 */           level = 2;
/* 158:    */         }
/* 159:    */         else
/* 160:    */         {
/* 161:186 */           XModel currentLang = (XModel)this.rootModel.get("temp/lang");
/* 162:187 */           currentLang.set(((XComboBox)findComponent("language")).getSelectedItem());
/* 163:188 */           level = 0;
/* 164:189 */           XModel currentUserM = (XModel)this.rootModel.get("temp/currentuser");
/* 165:190 */           currentUserM.set(username);
/* 166:191 */           XModel teamsM = (XModel)this.rootModel.get("teamdata/teams");
/* 167:192 */           for (int tIndex = 0; tIndex < teamsM.getNumChildren(); tIndex++)
/* 168:    */           {
/* 169:194 */             XModel cTeam = teamsM.get(tIndex);
/* 170:195 */             for (int mIndex = 0; mIndex < cTeam.getNumChildren(); mIndex++)
/* 171:    */             {
/* 172:197 */               XModel cMember = cTeam.get(mIndex);
/* 173:198 */               if (((String)cMember.get()).equals(username))
/* 174:    */               {
/* 175:200 */                 XModel currentTeamM = (XModel)this.rootModel.get("temp/currentteam");
/* 176:201 */                 currentTeamM.set(cTeam.getId());
/* 177:    */                 
/* 178:203 */                 String userDir = System.getProperty("user.dir");
/* 179:204 */                 String path = userDir + System.getProperty("file.separator") + "resources" + System.getProperty("file.separator") + "save.xml";
/* 180:205 */                 File saveFile = new File(path);
/* 181:    */                 
/* 182:    */ 
/* 183:208 */                 int attIndex = userM.getAttribute("code");
/* 184:209 */                 String code = (String)userM.getAttribValue(attIndex);
/* 185:210 */                 XModel surveyM = (XModel)this.rootModel.get("survey");
/* 186:    */                 
/* 187:212 */                 surveyM.set("@team", currentTeamM.get());
/* 188:213 */                 surveyM.set("@participant", code);
/* 189:    */                 
/* 190:    */ 
/* 191:    */ 
/* 192:217 */                 attIndex = surveyM.getAttribute("team");
/* 193:218 */                 String teamInSave = (String)surveyM.getAttribValue(attIndex);
/* 194:219 */                 attIndex = surveyM.getAttribute("participant");
/* 195:220 */                 String participantInSave = (String)surveyM.getAttribValue(attIndex);
/* 196:221 */                 String otherUser = "";
/* 197:222 */                 if ((!cTeam.getId().equals(teamInSave)) || (!code.equals(participantInSave)))
/* 198:    */                 {
/* 199:225 */                   XModel allUserM = (XModel)this.rootModel.get("teamdata/users");
/* 200:226 */                   for (int uindex = 0; uindex < allUserM.getNumChildren(); uindex++)
/* 201:    */                   {
/* 202:228 */                     XModel uM = allUserM.get(uindex);
/* 203:229 */                     int aIndex = uM.getAttribute("code");
/* 204:230 */                     String uCode = (String)uM.getAttribValue(aIndex);
/* 205:231 */                     if (participantInSave.equals(uCode)) {
/* 206:232 */                       otherUser = uM.getId();
/* 207:    */                     }
/* 208:    */                   }
/* 209:    */                 }
/* 210:    */               }
/* 211:    */             }
/* 212:    */           }
/* 213:    */         }
/* 214:    */       }
/* 215:    */     }
/* 216:249 */     return new Integer(level);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void textValueChanged(TextEvent e)
/* 220:    */   {
/* 221:254 */     XPassword passwordEdit = (XPassword)findComponent("password");
/* 222:255 */     if (passwordEdit.getText().length() == 4)
/* 223:    */     {
/* 224:257 */       XButton loginBtn = (XButton)findComponent("loginBtn");
/* 225:258 */       loginBtn.requestFocus();
/* 226:    */     }
/* 227:    */   }
/* 228:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kencomponents-current\kencomponents-current.jar
 * Qualified Name:     com.kentropy.enumeration.swing.Welcome
 * JD-Core Version:    0.7.0.1
 */