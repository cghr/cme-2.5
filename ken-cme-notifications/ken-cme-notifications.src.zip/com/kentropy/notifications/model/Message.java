/*  1:   */ package com.kentropy.notifications.model;
/*  2:   */ 
/*  3:   */ public class Message
/*  4:   */ {
/*  5:   */   private String query;
/*  6:   */   private String summaryquery;
/*  7:   */   private String template;
/*  8:   */   private String subject;
/*  9:   */   private String summary;
/* 10:   */   private String type;
/* 11:   */   
/* 12:   */   public String getSummaryquery()
/* 13:   */   {
/* 14:15 */     return this.summaryquery;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setSummaryquery(String summaryquery)
/* 18:   */   {
/* 19:18 */     this.summaryquery = summaryquery;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getQuery()
/* 23:   */   {
/* 24:23 */     return this.query;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setQuery(String query)
/* 28:   */   {
/* 29:26 */     this.query = query;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String getTemplate()
/* 33:   */   {
/* 34:29 */     return this.template;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setTemplate(String template)
/* 38:   */   {
/* 39:32 */     this.template = template;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getSubject()
/* 43:   */   {
/* 44:35 */     return this.subject;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setSubject(String subject)
/* 48:   */   {
/* 49:38 */     this.subject = subject;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String getSummary()
/* 53:   */   {
/* 54:41 */     return this.summary;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setSummary(String summary)
/* 58:   */   {
/* 59:44 */     this.summary = summary;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public String getType()
/* 63:   */   {
/* 64:47 */     return this.type;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setType(String type)
/* 68:   */   {
/* 69:50 */     this.type = type;
/* 70:   */   }
/* 71:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-cme-notifications\ken-cme-notifications.jar
 * Qualified Name:     com.kentropy.notifications.model.Message
 * JD-Core Version:    0.7.0.1
 */