package com.kentropy.process.qa;

public abstract interface ProcessQA
{
  public abstract boolean checkProcess(String paramString);
  
  public abstract boolean correctProcess(String paramString);
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.process.qa.ProcessQA
 * JD-Core Version:    0.7.0.1
 */