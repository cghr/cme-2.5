package com.kentropy.process;

public abstract interface Agent
{
  public abstract void stateChange(Process paramProcess);
  
  public abstract void batchExecute();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.process.Agent
 * JD-Core Version:    0.7.0.1
 */