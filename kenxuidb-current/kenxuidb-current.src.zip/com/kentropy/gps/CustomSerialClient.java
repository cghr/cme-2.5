/*  1:   */ package com.kentropy.gps;
/*  2:   */ 
/*  3:   */ import org.apache.log4j.Logger;
/*  4:   */ 
/*  5:   */ public class CustomSerialClient
/*  6:   */ {
/*  7:20 */   Logger logger = Logger.getLogger(getClass().getName());
/*  8:22 */   public int currentFix = 1;
/*  9:23 */   public String lat = "";
/* 10:24 */   public String longi = "";
/* 11:25 */   public String portstr = "COM5";
/* 12:   */   
/* 13:   */   public void read()
/* 14:   */   {
/* 15:92 */     throw new Error("Unresolved compilation problems: \n\tType mismatch: cannot convert from double to String\n\tType mismatch: cannot convert from double to String\n");
/* 16:   */   }
/* 17:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.gps.CustomSerialClient
 * JD-Core Version:    0.7.0.1
 */