/* 1:  */ package com.kentropy.db;
/* 2:  */ 
/* 3:  */ public class TestSystemTray
/* 4:  */ {
/* 5:  */   public static void main(String[] args)
/* 6:  */   {
/* 7:7 */     throw new Error("Unresolved compilation problems: \n\tTrayIcon cannot be resolved to a type\n\tTrayIcon cannot be resolved to a type\n\tSystemTray cannot be resolved\n\tSystemTray cannot be resolved\n\tSystemTray cannot be resolved to a type\n\tSystemTray cannot be resolved\n\tTrayIcon cannot be resolved to a type\n");
/* 8:  */   }
/* 9:  */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.db.TestSystemTray
 * JD-Core Version:    0.7.0.1
 */