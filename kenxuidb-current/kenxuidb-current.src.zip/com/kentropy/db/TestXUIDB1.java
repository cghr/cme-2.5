/*    1:     */ package com.kentropy.db;
/*    2:     */ 
/*    3:     */ import com.kentropy.model.KenList;
/*    4:     */ import com.kentropy.process.Process;
/*    5:     */ import java.text.DateFormat;
/*    6:     */ import java.util.Date;
/*    7:     */ import java.util.Vector;
/*    8:     */ import net.xoetrope.optional.data.sql.DatabaseTableModel;
/*    9:     */ import net.xoetrope.xml.XmlElement;
/*   10:     */ import net.xoetrope.xui.data.XModel;
/*   11:     */ 
/*   12:     */ public class TestXUIDB1
/*   13:     */ {
/*   14:     */   public static String driver;
/*   15:     */   public static String user;
/*   16:     */   public static String passwd;
/*   17:     */   public static String confStatus;
/*   18:     */   
/*   19:     */   public static void getReportData(String path, XModel dataM, int noOfColumns)
/*   20:     */   {
/*   21:  84 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   22:     */   }
/*   23:     */   
/*   24:     */   public static void getDiffDiagnosis(String icdCode, XModel dataM)
/*   25:     */   {
/*   26: 117 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   27:     */   }
/*   28:     */   
/*   29:     */   public static void getSearch(String searchKey, XModel dataM)
/*   30:     */   {
/*   31: 142 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   32:     */   }
/*   33:     */   
/*   34:     */   public static Vector findPhysicians(String vaId)
/*   35:     */   {
/*   36: 157 */     throw new Error("Unresolved compilation problem: \n");
/*   37:     */   }
/*   38:     */   
/*   39:     */   public static void saveProcess(Process p)
/*   40:     */   {
/*   41: 177 */     throw new Error("Unresolved compilation problem: \n");
/*   42:     */   }
/*   43:     */   
/*   44:     */   public static void execute(String table, String where, String sql)
/*   45:     */     throws Exception
/*   46:     */   {
/*   47: 208 */     throw new Error("Unresolved compilation problem: \n");
/*   48:     */   }
/*   49:     */   
/*   50:     */   public static void saveTransition(String id, String pid, int status)
/*   51:     */   {
/*   52: 221 */     throw new Error("Unresolved compilation problem: \n");
/*   53:     */   }
/*   54:     */   
/*   55:     */   public static String[] getNextTransition()
/*   56:     */     throws Exception
/*   57:     */   {
/*   58: 250 */     throw new Error("Unresolved compilation problem: \n");
/*   59:     */   }
/*   60:     */   
/*   61:     */   public static Process getProcess(String pid)
/*   62:     */     throws Exception
/*   63:     */   {
/*   64: 272 */     throw new Error("Unresolved compilation problem: \n");
/*   65:     */   }
/*   66:     */   
/*   67:     */   public static XModel getTasks(String surveyType, String team, String taskPath, KenList dataPath)
/*   68:     */   {
/*   69: 278 */     throw new Error("Unresolved compilation problem: \n");
/*   70:     */   }
/*   71:     */   
/*   72:     */   public static XModel getTasks1(String surveyType, String team, String taskPath, KenList dataPath)
/*   73:     */   {
/*   74: 300 */     throw new Error("Unresolved compilation problem: \n");
/*   75:     */   }
/*   76:     */   
/*   77:     */   public static void getTasks(XModel ioM, String team, String participant)
/*   78:     */     throws Exception
/*   79:     */   {
/*   80: 324 */     throw new Error("Unresolved compilation problem: \n");
/*   81:     */   }
/*   82:     */   
/*   83:     */   public static void checkDBServer()
/*   84:     */     throws Exception
/*   85:     */   {
/*   86: 331 */     throw new Error("Unresolved compilation problem: \n");
/*   87:     */   }
/*   88:     */   
/*   89:     */   public static String getTaskStatusPath(String task, String surveyType, String area, String house, String household, String individual)
/*   90:     */   {
/*   91: 338 */     throw new Error("Unresolved compilation problem: \n");
/*   92:     */   }
/*   93:     */   
/*   94:     */   public static int getTaskChildren(String parentPath, String team)
/*   95:     */   {
/*   96: 382 */     throw new Error("Unresolved compilation problem: \n");
/*   97:     */   }
/*   98:     */   
/*   99:     */   public static XLogisticsModel getLogisticsM(String table, String name, String path)
/*  100:     */   {
/*  101: 405 */     throw new Error("Unresolved compilation problem: \n");
/*  102:     */   }
/*  103:     */   
/*  104:     */   public static XDataModel getDataM(String table, String name, String area, String house, String household, String individual)
/*  105:     */   {
/*  106: 447 */     throw new Error("Unresolved compilation problem: \n");
/*  107:     */   }
/*  108:     */   
/*  109:     */   public static void createMessage()
/*  110:     */     throws Exception
/*  111:     */   {
/*  112: 492 */     throw new Error("Unresolved compilation problem: \n");
/*  113:     */   }
/*  114:     */   
/*  115:     */   public static String getLastChangeLog()
/*  116:     */     throws Exception
/*  117:     */   {
/*  118: 513 */     throw new Error("Unresolved compilation problem: \n");
/*  119:     */   }
/*  120:     */   
/*  121:     */   public static void sendServerLogs(String participant, String recepients, String frombookmark, String tobookmark)
/*  122:     */     throws Exception
/*  123:     */   {
/*  124: 532 */     throw new Error("Unresolved compilation problem: \n");
/*  125:     */   }
/*  126:     */   
/*  127:     */   public static void sendServerLogs2(String participant, String recepients, String frombookmark, String tobookmark)
/*  128:     */     throws Exception
/*  129:     */   {
/*  130: 558 */     throw new Error("Unresolved compilation problem: \n");
/*  131:     */   }
/*  132:     */   
/*  133:     */   public static void sendServerLogs1(String participant, String recepients)
/*  134:     */     throws Exception
/*  135:     */   {
/*  136: 608 */     throw new Error("Unresolved compilation problem: \n");
/*  137:     */   }
/*  138:     */   
/*  139:     */   public static void sendLogs(String participant, String recepients)
/*  140:     */     throws Exception
/*  141:     */   {
/*  142: 635 */     throw new Error("Unresolved compilation problem: \n");
/*  143:     */   }
/*  144:     */   
/*  145:     */   public static void sendLogsLocal(String path, String participant, String recepients)
/*  146:     */     throws Exception
/*  147:     */   {
/*  148: 661 */     throw new Error("Unresolved compilation problem: \n");
/*  149:     */   }
/*  150:     */   
/*  151:     */   public static void getTask(String path, String team, XTaskModel ioM, String surveyType, String area, String house, String household, String individual)
/*  152:     */   {
/*  153: 696 */     throw new Error("Unresolved compilation problem: \n");
/*  154:     */   }
/*  155:     */   
/*  156:     */   public static int getTaskChildCount(String parentPath, String team, XTaskModel ioM, String area, String house, String household, String individual)
/*  157:     */   {
/*  158: 754 */     throw new Error("Unresolved compilation problem: \n");
/*  159:     */   }
/*  160:     */   
/*  161:     */   public static void getLogisticsData(String parentPath, XLogisticsModel ioM)
/*  162:     */   {
/*  163: 777 */     throw new Error("Unresolved compilation problem: \n");
/*  164:     */   }
/*  165:     */   
/*  166:     */   public static void getTaskData(String where, XModel dataM)
/*  167:     */   {
/*  168: 820 */     throw new Error("Unresolved compilation problem: \n");
/*  169:     */   }
/*  170:     */   
/*  171:     */   public static void getTasks(String parentPath, String team, XTaskModel ioM, String surveyType, String area, String house, String household, String individual)
/*  172:     */   {
/*  173: 891 */     throw new Error("Unresolved compilation problem: \n");
/*  174:     */   }
/*  175:     */   
/*  176:     */   public static void testP(String parentPath, String team, XModel ioM)
/*  177:     */   {
/*  178: 967 */     throw new Error("Unresolved compilation problem: \n");
/*  179:     */   }
/*  180:     */   
/*  181:     */   public static String getPath(XModel taskM, XModel rel)
/*  182:     */   {
/*  183:1011 */     throw new Error("Unresolved compilation problem: \n");
/*  184:     */   }
/*  185:     */   
/*  186:     */   public static Vector split(String path, String sep, int index)
/*  187:     */   {
/*  188:1023 */     throw new Error("Unresolved compilation problem: \n");
/*  189:     */   }
/*  190:     */   
/*  191:     */   public static void dataPath(String taskPath)
/*  192:     */   {
/*  193:1053 */     throw new Error("Unresolved compilation problem: \n");
/*  194:     */   }
/*  195:     */   
/*  196:     */   public static DateFormat getMysqlDateFormat()
/*  197:     */   {
/*  198:1057 */     throw new Error("Unresolved compilation problem: \n");
/*  199:     */   }
/*  200:     */   
/*  201:     */   public static int toInt(String obj, int defaultVal)
/*  202:     */   {
/*  203:1063 */     throw new Error("Unresolved compilation problem: \n");
/*  204:     */   }
/*  205:     */   
/*  206:     */   public static Date toDatetime(String obj, Date defaultVal)
/*  207:     */   {
/*  208:1075 */     throw new Error("Unresolved compilation problem: \n");
/*  209:     */   }
/*  210:     */   
/*  211:     */   public static String toMySQlDatetime(Date obj, String defaultVal)
/*  212:     */   {
/*  213:1088 */     throw new Error("Unresolved compilation problem: \n");
/*  214:     */   }
/*  215:     */   
/*  216:     */   public static boolean checkIfTaskCanBeSaved(String dataPath, String taskPath)
/*  217:     */   {
/*  218:1101 */     throw new Error("Unresolved compilation problem: \n");
/*  219:     */   }
/*  220:     */   
/*  221:     */   public static int saveTaskToDb(XModel taskM, String parentTaskPath, String parentDataPath)
/*  222:     */   {
/*  223:1106 */     throw new Error("Unresolved compilation problem: \n");
/*  224:     */   }
/*  225:     */   
/*  226:     */   public static int saveTaskToSingle(XModel taskM, String parentTaskPath)
/*  227:     */   {
/*  228:1184 */     throw new Error("Unresolved compilation problem: \n");
/*  229:     */   }
/*  230:     */   
/*  231:     */   public static DateFormat getDateFormat()
/*  232:     */   {
/*  233:1254 */     throw new Error("Unresolved compilation problem: \n");
/*  234:     */   }
/*  235:     */   
/*  236:     */   public static XModel getAreas(String assignedTo, XModel dataM, String surveyType)
/*  237:     */     throws Exception
/*  238:     */   {
/*  239:1260 */     throw new Error("Unresolved compilation problem: \n");
/*  240:     */   }
/*  241:     */   
/*  242:     */   public static XModel getAreadetails(String area)
/*  243:     */   {
/*  244:1283 */     throw new Error("Unresolved compilation problem: \n");
/*  245:     */   }
/*  246:     */   
/*  247:     */   public static void getUsersForTeam(String team, KenList list)
/*  248:     */   {
/*  249:1310 */     throw new Error("Unresolved compilation problem: \n");
/*  250:     */   }
/*  251:     */   
/*  252:     */   public static XModel getHouses(String area, XModel areaM)
/*  253:     */     throws Exception
/*  254:     */   {
/*  255:1323 */     throw new Error("Unresolved compilation problem: \n");
/*  256:     */   }
/*  257:     */   
/*  258:     */   public static XModel getHousedetails(String house, String area)
/*  259:     */   {
/*  260:1347 */     throw new Error("Unresolved compilation problem: \n");
/*  261:     */   }
/*  262:     */   
/*  263:     */   public static String getCurrentUser()
/*  264:     */   {
/*  265:1371 */     throw new Error("Unresolved compilation problem: \n");
/*  266:     */   }
/*  267:     */   
/*  268:     */   public static void createChangeLog(String table, String where, Vector keyFields)
/*  269:     */     throws Exception
/*  270:     */   {
/*  271:1378 */     throw new Error("Unresolved compilation problem: \n");
/*  272:     */   }
/*  273:     */   
/*  274:     */   public static void saveDataM(String table, String where, XModel dataM)
/*  275:     */     throws Exception
/*  276:     */   {
/*  277:1412 */     throw new Error("Unresolved compilation problem: \n");
/*  278:     */   }
/*  279:     */   
/*  280:     */   public static void importChangeLog(String log)
/*  281:     */     throws Exception
/*  282:     */   {
/*  283:1478 */     throw new Error("Unresolved compilation problem: \n");
/*  284:     */   }
/*  285:     */   
/*  286:     */   public static void importChangeLogs(String logs)
/*  287:     */     throws Exception
/*  288:     */   {
/*  289:1493 */     throw new Error("Unresolved compilation problem: \n");
/*  290:     */   }
/*  291:     */   
/*  292:     */   public static void deliverMessage(String msg, String recepient)
/*  293:     */     throws Exception
/*  294:     */   {
/*  295:1519 */     throw new Error("Unresolved compilation problem: \n");
/*  296:     */   }
/*  297:     */   
/*  298:     */   public static void updateMessageStatus(String message, String recepient)
/*  299:     */     throws Exception
/*  300:     */   {
/*  301:1534 */     throw new Error("Unresolved compilation problem: \n");
/*  302:     */   }
/*  303:     */   
/*  304:     */   public static Vector getMessages(String recepient)
/*  305:     */     throws Exception
/*  306:     */   {
/*  307:1545 */     throw new Error("Unresolved compilation problem: \n");
/*  308:     */   }
/*  309:     */   
/*  310:     */   public static void saveChangeLog(String log)
/*  311:     */     throws Exception
/*  312:     */   {
/*  313:1566 */     throw new Error("Unresolved compilation problem: \n");
/*  314:     */   }
/*  315:     */   
/*  316:     */   public static void saveData(String table, String where, XModel dataM)
/*  317:     */     throws Exception
/*  318:     */   {
/*  319:1585 */     throw new Error("Unresolved compilation problem: \n");
/*  320:     */   }
/*  321:     */   
/*  322:     */   public static void saveConflictData(String table, String where, XModel dataM)
/*  323:     */     throws Exception
/*  324:     */   {
/*  325:1640 */     throw new Error("Unresolved compilation problem: \n");
/*  326:     */   }
/*  327:     */   
/*  328:     */   public static void saveData1(String table, String where, XmlElement dataM, String user1)
/*  329:     */     throws Exception
/*  330:     */   {
/*  331:1673 */     throw new Error("Unresolved compilation problem: \n");
/*  332:     */   }
/*  333:     */   
/*  334:     */   public static String getTaskContext(String task, String area, String house, String hh, String idc)
/*  335:     */   {
/*  336:1797 */     throw new Error("Unresolved compilation problem: \n");
/*  337:     */   }
/*  338:     */   
/*  339:     */   public static String getTaskContext(String task, String area, String house, String hh, String idc, String assignedTo)
/*  340:     */   {
/*  341:1829 */     throw new Error("Unresolved compilation problem: \n");
/*  342:     */   }
/*  343:     */   
/*  344:     */   public static void saveTask(XTaskModel taskM)
/*  345:     */     throws Exception
/*  346:     */   {
/*  347:1868 */     throw new Error("Unresolved compilation problem: \n");
/*  348:     */   }
/*  349:     */   
/*  350:     */   public static void saveTask(String task, String surveyType, String area, String house, String hh, String idc, XModel dataM)
/*  351:     */     throws Exception
/*  352:     */   {
/*  353:1873 */     throw new Error("Unresolved compilation problem: \n");
/*  354:     */   }
/*  355:     */   
/*  356:     */   public static XModel getHouseholds(String area, String house, XModel houseM)
/*  357:     */     throws Exception
/*  358:     */   {
/*  359:1957 */     throw new Error("Unresolved compilation problem: \n");
/*  360:     */   }
/*  361:     */   
/*  362:     */   public static XModel getHouseholddetails(String household, String house, String area)
/*  363:     */   {
/*  364:1983 */     throw new Error("Unresolved compilation problem: \n");
/*  365:     */   }
/*  366:     */   
/*  367:     */   public static String getMaxIndivId(String area, String house, String household)
/*  368:     */     throws Exception
/*  369:     */   {
/*  370:2009 */     throw new Error("Unresolved compilation problem: \n");
/*  371:     */   }
/*  372:     */   
/*  373:     */   public static XModel getIndividuals(String area, String house, String household, XModel hhM)
/*  374:     */     throws Exception
/*  375:     */   {
/*  376:2027 */     throw new Error("Unresolved compilation problem: \n");
/*  377:     */   }
/*  378:     */   
/*  379:     */   public static XModel getIndividualdetails(String individual, String household, String house, String area)
/*  380:     */   {
/*  381:2050 */     throw new Error("Unresolved compilation problem: \n");
/*  382:     */   }
/*  383:     */   
/*  384:     */   public static XModel getInterview(String individual, String household, String house, String area, XModel xm)
/*  385:     */   {
/*  386:2074 */     throw new Error("Unresolved compilation problem: \n");
/*  387:     */   }
/*  388:     */   
/*  389:     */   public static XModel getCC(String household, String house, String area, XModel xm)
/*  390:     */   {
/*  391:2096 */     throw new Error("Unresolved compilation problem: \n");
/*  392:     */   }
/*  393:     */   
/*  394:     */   public static void getDetails(DatabaseTableModel dt, XModel xm)
/*  395:     */   {
/*  396:2118 */     throw new Error("Unresolved compilation problem: \n");
/*  397:     */   }
/*  398:     */   
/*  399:     */   public static void getProto(String table, XModel dataM)
/*  400:     */   {
/*  401:2130 */     throw new Error("Unresolved compilation problem: \n");
/*  402:     */   }
/*  403:     */   
/*  404:     */   public static void init()
/*  405:     */   {
/*  406:2140 */     throw new Error("Unresolved compilation problem: \n");
/*  407:     */   }
/*  408:     */   
/*  409:     */   public static void test1(String[] args)
/*  410:     */     throws Exception
/*  411:     */   {
/*  412:2144 */     throw new Error("Unresolved compilation problem: \n");
/*  413:     */   }
/*  414:     */   
/*  415:     */   public static String getTaskPath(String path)
/*  416:     */   {
/*  417:2173 */     throw new Error("Unresolved compilation problem: \n");
/*  418:     */   }
/*  419:     */   
/*  420:     */   public static String join(Vector v)
/*  421:     */   {
/*  422:2178 */     throw new Error("Unresolved compilation problem: \n");
/*  423:     */   }
/*  424:     */   
/*  425:     */   public static void testImport(String file)
/*  426:     */     throws Exception
/*  427:     */   {
/*  428:2188 */     throw new Error("Unresolved compilation problem: \n");
/*  429:     */   }
/*  430:     */   
/*  431:     */   public static void main(String[] args)
/*  432:     */     throws Exception
/*  433:     */   {
/*  434:2204 */     throw new Error("Unresolved compilation problem: \n");
/*  435:     */   }
/*  436:     */   
/*  437:     */   public static void saveLogistics(XModel xm)
/*  438:     */     throws Exception
/*  439:     */   {
/*  440:2220 */     throw new Error("Unresolved compilation problem: \n");
/*  441:     */   }
/*  442:     */   
/*  443:     */   public static void saveTree(XModel root, String table, String parentPath)
/*  444:     */     throws Exception
/*  445:     */   {
/*  446:2230 */     throw new Error("Unresolved compilation problem: \n");
/*  447:     */   }
/*  448:     */   
/*  449:     */   public static void deleteKeyValue(String table, String key)
/*  450:     */     throws Exception
/*  451:     */   {
/*  452:2243 */     throw new Error("Unresolved compilation problem: \n");
/*  453:     */   }
/*  454:     */   
/*  455:     */   public static void saveKeyValue(String table, String key, String value)
/*  456:     */     throws Exception
/*  457:     */   {
/*  458:2259 */     throw new Error("Unresolved compilation problem: \n");
/*  459:     */   }
/*  460:     */   
/*  461:     */   public static void readTree(XModel root, String table, String path)
/*  462:     */   {
/*  463:2300 */     throw new Error("Unresolved compilation problem: \n");
/*  464:     */   }
/*  465:     */   
/*  466:     */   public static String getKeyValues(XModel xm, String table, String parentPath)
/*  467:     */   {
/*  468:2305 */     throw new Error("Unresolved compilation problem: \n");
/*  469:     */   }
/*  470:     */   
/*  471:     */   public static String getValue(String table, String key)
/*  472:     */   {
/*  473:2348 */     throw new Error("Unresolved compilation problem: \n");
/*  474:     */   }
/*  475:     */   
/*  476:     */   public static void saveInterview1(XModel xm)
/*  477:     */     throws Exception
/*  478:     */   {
/*  479:2372 */     throw new Error("Unresolved compilation problem: \n");
/*  480:     */   }
/*  481:     */   
/*  482:     */   public static void saveHouse(String area, String id, XModel houseM)
/*  483:     */     throws Exception
/*  484:     */   {
/*  485:2385 */     throw new Error("Unresolved compilation problem: \n");
/*  486:     */   }
/*  487:     */   
/*  488:     */   public static void saveHouseHold(String area, String house, String id, XModel hhM)
/*  489:     */     throws Exception
/*  490:     */   {
/*  491:2389 */     throw new Error("Unresolved compilation problem: \n");
/*  492:     */   }
/*  493:     */   
/*  494:     */   public static void saveMember(String area, String house, String hh, String id, XModel indvM)
/*  495:     */     throws Exception
/*  496:     */   {
/*  497:2394 */     throw new Error("Unresolved compilation problem: \n");
/*  498:     */   }
/*  499:     */   
/*  500:     */   public static void saveVisitInfo(String area, String house, String hh, String idc, String team, String doneBy, XModel visitM)
/*  501:     */     throws Exception
/*  502:     */   {
/*  503:2399 */     throw new Error("Unresolved compilation problem: \n");
/*  504:     */   }
/*  505:     */   
/*  506:     */   public static void saveInterview(String area, String house, String hh, String idc, XModel interviewM)
/*  507:     */     throws Exception
/*  508:     */   {
/*  509:2405 */     throw new Error("Unresolved compilation problem: \n");
/*  510:     */   }
/*  511:     */   
/*  512:     */   public static void saveResponse(String area, String house, String hh, String idc, XModel interviewM)
/*  513:     */     throws Exception
/*  514:     */   {
/*  515:2409 */     throw new Error("Unresolved compilation problem: \n");
/*  516:     */   }
/*  517:     */   
/*  518:     */   public static void saveCommon(String area, String house, String hh, XModel ccM)
/*  519:     */     throws Exception
/*  520:     */   {
/*  521:2414 */     throw new Error("Unresolved compilation problem: \n");
/*  522:     */   }
/*  523:     */   
/*  524:     */   public static void saveTask2(String taskPath, String surveyType, String area, String house, String hh, String individual, XModel taskM)
/*  525:     */     throws Exception
/*  526:     */   {
/*  527:2418 */     throw new Error("Unresolved compilation problem: \n");
/*  528:     */   }
/*  529:     */   
/*  530:     */   public static void save(XModel xM, String area, String house, String hh, String idc)
/*  531:     */     throws Exception
/*  532:     */   {
/*  533:2427 */     throw new Error("Unresolved compilation problem: \n");
/*  534:     */   }
/*  535:     */   
/*  536:     */   public static void get(XModel xM, String area, String house, String hh, String idc)
/*  537:     */     throws Exception
/*  538:     */   {
/*  539:2442 */     throw new Error("Unresolved compilation problem: \n");
/*  540:     */   }
/*  541:     */   
/*  542:     */   public static XModel get1(String path, String area, String house, String hh, String idc)
/*  543:     */     throws Exception
/*  544:     */   {
/*  545:2457 */     throw new Error("Unresolved compilation problem: \n");
/*  546:     */   }
/*  547:     */   
/*  548:     */   public static void authenticateUser(String user, String passwd)
/*  549:     */   {
/*  550:2472 */     throw new Error("Unresolved compilation problem: \n");
/*  551:     */   }
/*  552:     */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.db.TestXUIDB1
 * JD-Core Version:    0.7.0.1
 */