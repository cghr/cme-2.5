/*    1:     */ package com.kentropy.db;
/*    2:     */ 
/*    3:     */ import com.kentropy.model.KenList;
/*    4:     */ import com.kentropy.process.Process;
/*    5:     */ import java.text.DateFormat;
/*    6:     */ import java.util.Date;
/*    7:     */ import java.util.Vector;
/*    8:     */ import net.xoetrope.optional.data.sql.DatabaseTableModel;
/*    9:     */ import net.xoetrope.xml.XmlElement;
/*   10:     */ import net.xoetrope.xui.data.XModel;
/*   11:     */ 
/*   12:     */ public class TestXUIDB3
/*   13:     */ {
/*   14:     */   static String workload;
/*   15:     */   public static String driver;
/*   16:     */   public static String user;
/*   17:     */   public static String passwd;
/*   18:     */   public static String confStatus;
/*   19:     */   public static String imagePath;
/*   20:     */   public static String dwdb;
/*   21:     */   
/*   22:     */   public String getProperty(String property)
/*   23:     */   {
/*   24: 106 */     throw new Error("Unresolved compilation problem: \n");
/*   25:     */   }
/*   26:     */   
/*   27:     */   public void updateCODReport(String phys1, String phys2, String adjudicator, String report)
/*   28:     */     throws Exception
/*   29:     */   {
/*   30: 128 */     throw new Error("Unresolved compilation problem: \n");
/*   31:     */   }
/*   32:     */   
/*   33:     */   public String getICDDesc(String icd)
/*   34:     */   {
/*   35: 173 */     throw new Error("Unresolved compilation problem: \n");
/*   36:     */   }
/*   37:     */   
/*   38:     */   public boolean isValidIcdAge(String age, String icd)
/*   39:     */   {
/*   40: 189 */     throw new Error("Unresolved compilation problem: \n");
/*   41:     */   }
/*   42:     */   
/*   43:     */   public boolean isValidIcdSex(String age, String icd)
/*   44:     */   {
/*   45: 212 */     throw new Error("Unresolved compilation problem: \n");
/*   46:     */   }
/*   47:     */   
/*   48:     */   public boolean checkEquivalence(String icd1, String icd2)
/*   49:     */   {
/*   50: 227 */     throw new Error("Unresolved compilation problem: \n");
/*   51:     */   }
/*   52:     */   
/*   53:     */   public static XUIDB getInstance()
/*   54:     */   {
/*   55: 240 */     throw new Error("Unresolved compilation problem: \n");
/*   56:     */   }
/*   57:     */   
/*   58:     */   public String getImagePath()
/*   59:     */   {
/*   60: 245 */     throw new Error("Unresolved compilation problem: \n");
/*   61:     */   }
/*   62:     */   
/*   63:     */   public void getReportData(String path, XModel dataM, int noOfColumns)
/*   64:     */   {
/*   65: 261 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   66:     */   }
/*   67:     */   
/*   68:     */   public void getDiffDiagnosis(String icdCode, XModel dataM)
/*   69:     */   {
/*   70: 296 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   71:     */   }
/*   72:     */   
/*   73:     */   public void getSearch(String searchKey, String icdKey, XModel dataM)
/*   74:     */   {
/*   75: 320 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   76:     */   }
/*   77:     */   
/*   78:     */   public void getSearchIcd(String searchKey, XModel dataM)
/*   79:     */   {
/*   80: 345 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   81:     */   }
/*   82:     */   
/*   83:     */   public void getSearch(String searchKey, XModel dataM)
/*   84:     */   {
/*   85: 370 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XBaseModel is not applicable for the arguments (int)\n");
/*   86:     */   }
/*   87:     */   
/*   88:     */   public Vector findPhysicians(String vaId)
/*   89:     */   {
/*   90: 385 */     throw new Error("Unresolved compilation problem: \n");
/*   91:     */   }
/*   92:     */   
/*   93:     */   public void saveProcess(Process p)
/*   94:     */   {
/*   95: 405 */     throw new Error("Unresolved compilation problem: \n");
/*   96:     */   }
/*   97:     */   
/*   98:     */   public void execute(String table, String where, String sql)
/*   99:     */     throws Exception
/*  100:     */   {
/*  101: 436 */     throw new Error("Unresolved compilation problem: \n");
/*  102:     */   }
/*  103:     */   
/*  104:     */   public void saveTransition(String id, String pid, int status)
/*  105:     */   {
/*  106: 449 */     throw new Error("Unresolved compilation problem: \n");
/*  107:     */   }
/*  108:     */   
/*  109:     */   public String[] getNextTransition()
/*  110:     */     throws Exception
/*  111:     */   {
/*  112: 479 */     throw new Error("Unresolved compilation problem: \n");
/*  113:     */   }
/*  114:     */   
/*  115:     */   public Process getProcess(String pid)
/*  116:     */     throws Exception
/*  117:     */   {
/*  118: 501 */     throw new Error("Unresolved compilation problem: \n");
/*  119:     */   }
/*  120:     */   
/*  121:     */   public XModel getTasks(String surveyType, String team, String taskPath, KenList dataPath)
/*  122:     */   {
/*  123: 507 */     throw new Error("Unresolved compilation problem: \n");
/*  124:     */   }
/*  125:     */   
/*  126:     */   public XModel getTasks1(String surveyType, String team, String taskPath, KenList dataPath)
/*  127:     */   {
/*  128: 529 */     throw new Error("Unresolved compilation problem: \n");
/*  129:     */   }
/*  130:     */   
/*  131:     */   public void getTasks(XModel ioM, String team, String participant)
/*  132:     */     throws Exception
/*  133:     */   {
/*  134: 553 */     throw new Error("Unresolved compilation problem: \n");
/*  135:     */   }
/*  136:     */   
/*  137:     */   public void checkDBServer()
/*  138:     */     throws Exception
/*  139:     */   {
/*  140: 561 */     throw new Error("Unresolved compilation problem: \n");
/*  141:     */   }
/*  142:     */   
/*  143:     */   public String getTaskStatusPath(String task, String surveyType, String area, String house, String household, String individual)
/*  144:     */   {
/*  145: 568 */     throw new Error("Unresolved compilation problem: \n");
/*  146:     */   }
/*  147:     */   
/*  148:     */   public int getTaskChildren(String parentPath, String team)
/*  149:     */   {
/*  150: 612 */     throw new Error("Unresolved compilation problem: \n");
/*  151:     */   }
/*  152:     */   
/*  153:     */   public XLogisticsModel getLogisticsM(String table, String name, String path)
/*  154:     */   {
/*  155: 636 */     throw new Error("Unresolved compilation problem: \n");
/*  156:     */   }
/*  157:     */   
/*  158:     */   public XDataModel getDataM1(String table, String where)
/*  159:     */   {
/*  160: 678 */     throw new Error("Unresolved compilation problem: \n");
/*  161:     */   }
/*  162:     */   
/*  163:     */   public XDataModel getDataM2(String table, String where)
/*  164:     */   {
/*  165: 726 */     throw new Error("Unresolved compilation problem: \n\tThe method setId(String) in the type XModel is not applicable for the arguments (int)\n");
/*  166:     */   }
/*  167:     */   
/*  168:     */   public XDataModel getDataM(String table, String name, String area, String house, String household, String individual)
/*  169:     */   {
/*  170: 745 */     throw new Error("Unresolved compilation problem: \n");
/*  171:     */   }
/*  172:     */   
/*  173:     */   public void createMessage()
/*  174:     */     throws Exception
/*  175:     */   {
/*  176: 790 */     throw new Error("Unresolved compilation problem: \n");
/*  177:     */   }
/*  178:     */   
/*  179:     */   public String getLastChangeLog()
/*  180:     */     throws Exception
/*  181:     */   {
/*  182: 812 */     throw new Error("Unresolved compilation problem: \n");
/*  183:     */   }
/*  184:     */   
/*  185:     */   public String getPendingChanges()
/*  186:     */     throws Exception
/*  187:     */   {
/*  188: 831 */     throw new Error("Unresolved compilation problem: \n");
/*  189:     */   }
/*  190:     */   
/*  191:     */   public void sendServerLogs(String participant, String recepients, String frombookmark, String tobookmark)
/*  192:     */     throws Exception
/*  193:     */   {
/*  194: 846 */     throw new Error("Unresolved compilation problem: \n");
/*  195:     */   }
/*  196:     */   
/*  197:     */   public void sendServerLogs2(String participant, String recepients, String frombookmark, String tobookmark)
/*  198:     */     throws Exception
/*  199:     */   {
/*  200: 873 */     throw new Error("Unresolved compilation problem: \n");
/*  201:     */   }
/*  202:     */   
/*  203:     */   public void sendServerLogs1(String participant, String recepients)
/*  204:     */     throws Exception
/*  205:     */   {
/*  206: 923 */     throw new Error("Unresolved compilation problem: \n");
/*  207:     */   }
/*  208:     */   
/*  209:     */   public int sendLogs(String participant, String recepients)
/*  210:     */     throws Exception
/*  211:     */   {
/*  212: 950 */     throw new Error("Unresolved compilation problem: \n");
/*  213:     */   }
/*  214:     */   
/*  215:     */   public void sendLogsLocal(String path, String participant, String recepients)
/*  216:     */     throws Exception
/*  217:     */   {
/*  218: 979 */     throw new Error("Unresolved compilation problem: \n");
/*  219:     */   }
/*  220:     */   
/*  221:     */   public void getTask(String path, String team, XTaskModel ioM, String surveyType, String area, String house, String household, String individual)
/*  222:     */   {
/*  223:1014 */     throw new Error("Unresolved compilation problem: \n");
/*  224:     */   }
/*  225:     */   
/*  226:     */   public int getTaskChildCount(String parentPath, String team, XTaskModel ioM, String area, String house, String household, String individual)
/*  227:     */   {
/*  228:1072 */     throw new Error("Unresolved compilation problem: \n");
/*  229:     */   }
/*  230:     */   
/*  231:     */   public void getLogisticsData(String parentPath, XLogisticsModel ioM)
/*  232:     */   {
/*  233:1095 */     throw new Error("Unresolved compilation problem: \n");
/*  234:     */   }
/*  235:     */   
/*  236:     */   public void getTaskData(String where, XModel dataM)
/*  237:     */   {
/*  238:1138 */     throw new Error("Unresolved compilation problem: \n");
/*  239:     */   }
/*  240:     */   
/*  241:     */   public void getTasks(String parentPath, String team, XTaskModel ioM, String surveyType, String area, String house, String household, String individual)
/*  242:     */   {
/*  243:1209 */     throw new Error("Unresolved compilation problem: \n");
/*  244:     */   }
/*  245:     */   
/*  246:     */   public void testP(String parentPath, String team, XModel ioM)
/*  247:     */   {
/*  248:1286 */     throw new Error("Unresolved compilation problem: \n");
/*  249:     */   }
/*  250:     */   
/*  251:     */   public String getPath(XModel taskM, XModel rel)
/*  252:     */   {
/*  253:1331 */     throw new Error("Unresolved compilation problem: \n");
/*  254:     */   }
/*  255:     */   
/*  256:     */   public Vector split(String path, String sep, int index)
/*  257:     */   {
/*  258:1343 */     throw new Error("Unresolved compilation problem: \n");
/*  259:     */   }
/*  260:     */   
/*  261:     */   /**
/*  262:     */    * @deprecated
/*  263:     */    */
/*  264:     */   public void dataPath(String taskPath)
/*  265:     */   {
/*  266:1374 */     throw new Error("Unresolved compilation problem: \n");
/*  267:     */   }
/*  268:     */   
/*  269:     */   public DateFormat getMysqlDateFormat()
/*  270:     */   {
/*  271:1378 */     throw new Error("Unresolved compilation problem: \n");
/*  272:     */   }
/*  273:     */   
/*  274:     */   public int toInt(String obj, int defaultVal)
/*  275:     */   {
/*  276:1384 */     throw new Error("Unresolved compilation problem: \n");
/*  277:     */   }
/*  278:     */   
/*  279:     */   public Date toDatetime(String obj, Date defaultVal)
/*  280:     */   {
/*  281:1397 */     throw new Error("Unresolved compilation problem: \n");
/*  282:     */   }
/*  283:     */   
/*  284:     */   public String toMySQlDatetime(Date obj, String defaultVal)
/*  285:     */   {
/*  286:1410 */     throw new Error("Unresolved compilation problem: \n");
/*  287:     */   }
/*  288:     */   
/*  289:     */   /**
/*  290:     */    * @deprecated
/*  291:     */    */
/*  292:     */   public boolean checkIfTaskCanBeSaved(String dataPath, String taskPath)
/*  293:     */   {
/*  294:1424 */     throw new Error("Unresolved compilation problem: \n");
/*  295:     */   }
/*  296:     */   
/*  297:     */   public int saveTaskToDb(XModel taskM, String parentTaskPath, String parentDataPath)
/*  298:     */   {
/*  299:1429 */     throw new Error("Unresolved compilation problem: \n");
/*  300:     */   }
/*  301:     */   
/*  302:     */   public int saveTaskToSingle(XModel taskM, String parentTaskPath)
/*  303:     */   {
/*  304:1507 */     throw new Error("Unresolved compilation problem: \n");
/*  305:     */   }
/*  306:     */   
/*  307:     */   public DateFormat getDateFormat()
/*  308:     */   {
/*  309:1577 */     throw new Error("Unresolved compilation problem: \n");
/*  310:     */   }
/*  311:     */   
/*  312:     */   public XModel getAreas(String assignedTo, XModel dataM, String surveyType)
/*  313:     */     throws Exception
/*  314:     */   {
/*  315:1583 */     throw new Error("Unresolved compilation problem: \n");
/*  316:     */   }
/*  317:     */   
/*  318:     */   public XModel getAreadetails(String area)
/*  319:     */   {
/*  320:1606 */     throw new Error("Unresolved compilation problem: \n");
/*  321:     */   }
/*  322:     */   
/*  323:     */   public void getUsersForTeam(String team, KenList list)
/*  324:     */   {
/*  325:1633 */     throw new Error("Unresolved compilation problem: \n");
/*  326:     */   }
/*  327:     */   
/*  328:     */   public XModel getHouses(String area, XModel areaM)
/*  329:     */     throws Exception
/*  330:     */   {
/*  331:1646 */     throw new Error("Unresolved compilation problem: \n");
/*  332:     */   }
/*  333:     */   
/*  334:     */   public XModel getHousedetails(String house, String area)
/*  335:     */   {
/*  336:1670 */     throw new Error("Unresolved compilation problem: \n");
/*  337:     */   }
/*  338:     */   
/*  339:     */   public XModel getHousedetails(String house, String area, XModel xm)
/*  340:     */   {
/*  341:1694 */     throw new Error("Unresolved compilation problem: \n");
/*  342:     */   }
/*  343:     */   
/*  344:     */   public String getCurrentUser()
/*  345:     */   {
/*  346:1716 */     throw new Error("Unresolved compilation problem: \n");
/*  347:     */   }
/*  348:     */   
/*  349:     */   public void createChangeLog(String table, String where, Vector keyFields)
/*  350:     */     throws Exception
/*  351:     */   {
/*  352:1723 */     throw new Error("Unresolved compilation problem: \n");
/*  353:     */   }
/*  354:     */   
/*  355:     */   public void saveDataM(String table, String where, XModel dataM)
/*  356:     */     throws Exception
/*  357:     */   {
/*  358:1758 */     throw new Error("Unresolved compilation problem: \n");
/*  359:     */   }
/*  360:     */   
/*  361:     */   public void importChangeLog(String log)
/*  362:     */     throws Exception
/*  363:     */   {
/*  364:1824 */     throw new Error("Unresolved compilation problem: \n");
/*  365:     */   }
/*  366:     */   
/*  367:     */   public void importChangeLogs(String logs)
/*  368:     */     throws Exception
/*  369:     */   {
/*  370:1839 */     throw new Error("Unresolved compilation problem: \n");
/*  371:     */   }
/*  372:     */   
/*  373:     */   public void deliverMessage(String msg, String recepient)
/*  374:     */     throws Exception
/*  375:     */   {
/*  376:1865 */     throw new Error("Unresolved compilation problem: \n");
/*  377:     */   }
/*  378:     */   
/*  379:     */   public void updateMessageStatus(String message, String recepient)
/*  380:     */     throws Exception
/*  381:     */   {
/*  382:1880 */     throw new Error("Unresolved compilation problem: \n");
/*  383:     */   }
/*  384:     */   
/*  385:     */   public Vector getMessages(String recepient)
/*  386:     */     throws Exception
/*  387:     */   {
/*  388:1891 */     throw new Error("Unresolved compilation problem: \n");
/*  389:     */   }
/*  390:     */   
/*  391:     */   public void saveChangeLog(String log)
/*  392:     */     throws Exception
/*  393:     */   {
/*  394:1912 */     throw new Error("Unresolved compilation problem: \n");
/*  395:     */   }
/*  396:     */   
/*  397:     */   public void saveData(String table, String where, XModel dataM)
/*  398:     */     throws Exception
/*  399:     */   {
/*  400:1931 */     throw new Error("Unresolved compilation problem: \n");
/*  401:     */   }
/*  402:     */   
/*  403:     */   public void saveConflictData(String table, String where, XModel dataM)
/*  404:     */     throws Exception
/*  405:     */   {
/*  406:1986 */     throw new Error("Unresolved compilation problem: \n");
/*  407:     */   }
/*  408:     */   
/*  409:     */   public void saveData1(String table, String where, XmlElement dataM, String user1)
/*  410:     */     throws Exception
/*  411:     */   {
/*  412:2019 */     throw new Error("Unresolved compilation problem: \n");
/*  413:     */   }
/*  414:     */   
/*  415:     */   public String getTaskContext(String task, String area, String house, String hh, String idc)
/*  416:     */   {
/*  417:2144 */     throw new Error("Unresolved compilation problem: \n");
/*  418:     */   }
/*  419:     */   
/*  420:     */   public String getTaskContext(String task, String area, String house, String hh, String idc, String assignedTo)
/*  421:     */   {
/*  422:2176 */     throw new Error("Unresolved compilation problem: \n");
/*  423:     */   }
/*  424:     */   
/*  425:     */   public void saveTask(XTaskModel taskM)
/*  426:     */     throws Exception
/*  427:     */   {
/*  428:2215 */     throw new Error("Unresolved compilation problem: \n");
/*  429:     */   }
/*  430:     */   
/*  431:     */   public void saveTask(String task, String surveyType, String area, String house, String hh, String idc, XModel dataM)
/*  432:     */     throws Exception
/*  433:     */   {
/*  434:2220 */     throw new Error("Unresolved compilation problem: \n");
/*  435:     */   }
/*  436:     */   
/*  437:     */   public XModel getHouseholds(String area, String house, XModel houseM)
/*  438:     */     throws Exception
/*  439:     */   {
/*  440:2304 */     throw new Error("Unresolved compilation problem: \n");
/*  441:     */   }
/*  442:     */   
/*  443:     */   public XModel getHouseholddetails(String household, String house, String area, XModel xm)
/*  444:     */   {
/*  445:2330 */     throw new Error("Unresolved compilation problem: \n");
/*  446:     */   }
/*  447:     */   
/*  448:     */   public XModel getHouseholddetails(String household, String house, String area)
/*  449:     */   {
/*  450:2354 */     throw new Error("Unresolved compilation problem: \n");
/*  451:     */   }
/*  452:     */   
/*  453:     */   public String getMaxIndivId(String area, String house, String household)
/*  454:     */     throws Exception
/*  455:     */   {
/*  456:2380 */     throw new Error("Unresolved compilation problem: \n");
/*  457:     */   }
/*  458:     */   
/*  459:     */   public String getMaxHouseId(String area, String surveyorId)
/*  460:     */     throws Exception
/*  461:     */   {
/*  462:2398 */     throw new Error("Unresolved compilation problem: \n");
/*  463:     */   }
/*  464:     */   
/*  465:     */   public String getMaxHouseholdId(String area, String house)
/*  466:     */     throws Exception
/*  467:     */   {
/*  468:2414 */     throw new Error("Unresolved compilation problem: \n");
/*  469:     */   }
/*  470:     */   
/*  471:     */   public XModel getIndividuals(String area, String house, String household, XModel hhM)
/*  472:     */     throws Exception
/*  473:     */   {
/*  474:2430 */     throw new Error("Unresolved compilation problem: \n");
/*  475:     */   }
/*  476:     */   
/*  477:     */   public XModel getIndividualdetails(String individual, String household, String house, String area)
/*  478:     */   {
/*  479:2453 */     throw new Error("Unresolved compilation problem: \n");
/*  480:     */   }
/*  481:     */   
/*  482:     */   public XModel getInterview(String individual, String household, String house, String area, XModel xm)
/*  483:     */   {
/*  484:2477 */     throw new Error("Unresolved compilation problem: \n");
/*  485:     */   }
/*  486:     */   
/*  487:     */   public XModel getCC(String household, String house, String area, XModel xm)
/*  488:     */   {
/*  489:2499 */     throw new Error("Unresolved compilation problem: \n");
/*  490:     */   }
/*  491:     */   
/*  492:     */   public void getDetails(DatabaseTableModel dt, XModel xm)
/*  493:     */   {
/*  494:2521 */     throw new Error("Unresolved compilation problem: \n");
/*  495:     */   }
/*  496:     */   
/*  497:     */   public void getProto(String table, XModel dataM)
/*  498:     */   {
/*  499:2533 */     throw new Error("Unresolved compilation problem: \n");
/*  500:     */   }
/*  501:     */   
/*  502:     */   public void init()
/*  503:     */   {
/*  504:2543 */     throw new Error("Unresolved compilation problem: \n");
/*  505:     */   }
/*  506:     */   
/*  507:     */   public void test1(String[] args)
/*  508:     */     throws Exception
/*  509:     */   {
/*  510:2547 */     throw new Error("Unresolved compilation problem: \n");
/*  511:     */   }
/*  512:     */   
/*  513:     */   public String getTaskPath(String path)
/*  514:     */   {
/*  515:2576 */     throw new Error("Unresolved compilation problem: \n");
/*  516:     */   }
/*  517:     */   
/*  518:     */   public String join(Vector v)
/*  519:     */   {
/*  520:2581 */     throw new Error("Unresolved compilation problem: \n");
/*  521:     */   }
/*  522:     */   
/*  523:     */   public void testImport(String file)
/*  524:     */     throws Exception
/*  525:     */   {
/*  526:2591 */     throw new Error("Unresolved compilation problem: \n");
/*  527:     */   }
/*  528:     */   
/*  529:     */   public static void main(String[] args)
/*  530:     */     throws Exception
/*  531:     */   {
/*  532:2607 */     throw new Error("Unresolved compilation problem: \n");
/*  533:     */   }
/*  534:     */   
/*  535:     */   public void saveLogistics(XModel xm)
/*  536:     */     throws Exception
/*  537:     */   {
/*  538:2613 */     throw new Error("Unresolved compilation problem: \n");
/*  539:     */   }
/*  540:     */   
/*  541:     */   public void saveTree(XModel root, String table, String parentPath)
/*  542:     */     throws Exception
/*  543:     */   {
/*  544:2623 */     throw new Error("Unresolved compilation problem: \n");
/*  545:     */   }
/*  546:     */   
/*  547:     */   public void deleteKeyValue(String table, String key)
/*  548:     */     throws Exception
/*  549:     */   {
/*  550:2637 */     throw new Error("Unresolved compilation problem: \n");
/*  551:     */   }
/*  552:     */   
/*  553:     */   public void saveKeyValue(String table, String key, String value)
/*  554:     */     throws Exception
/*  555:     */   {
/*  556:2653 */     throw new Error("Unresolved compilation problem: \n");
/*  557:     */   }
/*  558:     */   
/*  559:     */   public void readTree(XModel root, String table, String path)
/*  560:     */   {
/*  561:2700 */     throw new Error("Unresolved compilation problem: \n");
/*  562:     */   }
/*  563:     */   
/*  564:     */   public String getKeyValues(XModel xm, String table, String parentPath)
/*  565:     */   {
/*  566:2705 */     throw new Error("Unresolved compilation problem: \n");
/*  567:     */   }
/*  568:     */   
/*  569:     */   public String getValue(String table, String key)
/*  570:     */   {
/*  571:2738 */     throw new Error("Unresolved compilation problem: \n");
/*  572:     */   }
/*  573:     */   
/*  574:     */   public void saveInterview1(XModel xm)
/*  575:     */     throws Exception
/*  576:     */   {
/*  577:2763 */     throw new Error("Unresolved compilation problem: \n");
/*  578:     */   }
/*  579:     */   
/*  580:     */   public void saveHouse(String area, String id, XModel houseM)
/*  581:     */     throws Exception
/*  582:     */   {
/*  583:2776 */     throw new Error("Unresolved compilation problem: \n");
/*  584:     */   }
/*  585:     */   
/*  586:     */   public void saveHouseHold(String area, String house, String id, XModel hhM)
/*  587:     */     throws Exception
/*  588:     */   {
/*  589:2780 */     throw new Error("Unresolved compilation problem: \n");
/*  590:     */   }
/*  591:     */   
/*  592:     */   public void saveMember(String area, String house, String hh, String id, XModel indvM)
/*  593:     */     throws Exception
/*  594:     */   {
/*  595:2785 */     throw new Error("Unresolved compilation problem: \n");
/*  596:     */   }
/*  597:     */   
/*  598:     */   public void saveVisitInfo(String area, String house, String hh, String idc, String team, String doneBy, XModel visitM)
/*  599:     */     throws Exception
/*  600:     */   {
/*  601:2790 */     throw new Error("Unresolved compilation problem: \n");
/*  602:     */   }
/*  603:     */   
/*  604:     */   public void saveInterview(String area, String house, String hh, String idc, XModel interviewM)
/*  605:     */     throws Exception
/*  606:     */   {
/*  607:2796 */     throw new Error("Unresolved compilation problem: \n");
/*  608:     */   }
/*  609:     */   
/*  610:     */   public void saveResponse(String area, String house, String hh, String idc, XModel interviewM)
/*  611:     */     throws Exception
/*  612:     */   {
/*  613:2800 */     throw new Error("Unresolved compilation problem: \n");
/*  614:     */   }
/*  615:     */   
/*  616:     */   public void saveCommon(String area, String house, String hh, XModel ccM)
/*  617:     */     throws Exception
/*  618:     */   {
/*  619:2805 */     throw new Error("Unresolved compilation problem: \n");
/*  620:     */   }
/*  621:     */   
/*  622:     */   public void saveTask2(String taskPath, String surveyType, String area, String house, String hh, String individual, XModel taskM)
/*  623:     */     throws Exception
/*  624:     */   {
/*  625:2809 */     throw new Error("Unresolved compilation problem: \n");
/*  626:     */   }
/*  627:     */   
/*  628:     */   public void save(XModel xM, String area, String house, String hh, String idc)
/*  629:     */     throws Exception
/*  630:     */   {
/*  631:2818 */     throw new Error("Unresolved compilation problem: \n");
/*  632:     */   }
/*  633:     */   
/*  634:     */   public void get(XModel xM, String area, String house, String hh, String idc)
/*  635:     */     throws Exception
/*  636:     */   {
/*  637:2833 */     throw new Error("Unresolved compilation problem: \n");
/*  638:     */   }
/*  639:     */   
/*  640:     */   public XModel get1(String path, String area, String house, String hh, String idc)
/*  641:     */     throws Exception
/*  642:     */   {
/*  643:2848 */     throw new Error("Unresolved compilation problem: \n");
/*  644:     */   }
/*  645:     */   
/*  646:     */   public void authenticateUser(String user, String passwd)
/*  647:     */   {
/*  648:2863 */     throw new Error("Unresolved compilation problem: \n");
/*  649:     */   }
/*  650:     */   
/*  651:     */   public void authoriseUser(String roles)
/*  652:     */   {
/*  653:2870 */     throw new Error("Unresolved compilation problem: \n");
/*  654:     */   }
/*  655:     */   
/*  656:     */   public boolean isPhysicianAway(String id, String date)
/*  657:     */   {
/*  658:2877 */     throw new Error("Unresolved compilation problem: \n");
/*  659:     */   }
/*  660:     */   
/*  661:     */   public boolean isPhysician(String username, String password)
/*  662:     */   {
/*  663:2889 */     throw new Error("Unresolved compilation problem: \n");
/*  664:     */   }
/*  665:     */   
/*  666:     */   public boolean updateAwayDate(String id, Date date)
/*  667:     */     throws Exception
/*  668:     */   {
/*  669:2901 */     throw new Error("Unresolved compilation problem: \n");
/*  670:     */   }
/*  671:     */   
/*  672:     */   public void createPhysician(String username, String name, String languages, String coder, String adjudicator, String id, String status)
/*  673:     */     throws Exception
/*  674:     */   {
/*  675:2915 */     throw new Error("Unresolved compilation problem: \n");
/*  676:     */   }
/*  677:     */   
/*  678:     */   public void createAccount(String username, String password, String roles)
/*  679:     */     throws Exception
/*  680:     */   {
/*  681:2934 */     throw new Error("Unresolved compilation problem: \n");
/*  682:     */   }
/*  683:     */   
/*  684:     */   public boolean physicianExists(String username)
/*  685:     */   {
/*  686:2947 */     throw new Error("Unresolved compilation problem: \n");
/*  687:     */   }
/*  688:     */   
/*  689:     */   public boolean userExists(String username)
/*  690:     */   {
/*  691:2960 */     throw new Error("Unresolved compilation problem: \n");
/*  692:     */   }
/*  693:     */   
/*  694:     */   public boolean getWorkLoad(String physician, XModel xm)
/*  695:     */   {
/*  696:2973 */     throw new Error("Unresolved compilation problem: \n");
/*  697:     */   }
/*  698:     */   
/*  699:     */   public boolean getPhysiciansWithLessWorkload(String language, String status, XModel xm)
/*  700:     */   {
/*  701:3002 */     throw new Error("Unresolved compilation problem: \n");
/*  702:     */   }
/*  703:     */   
/*  704:     */   public boolean getWorkLoad(String where, String groupBy, XModel xm)
/*  705:     */   {
/*  706:3032 */     throw new Error("Unresolved compilation problem: \n");
/*  707:     */   }
/*  708:     */   
/*  709:     */   public boolean getData(String table, String fields, String where, XModel xm)
/*  710:     */   {
/*  711:3059 */     throw new Error("Unresolved compilation problem: \n");
/*  712:     */   }
/*  713:     */   
/*  714:     */   public boolean getPhysicianDetails(String where, XModel xm)
/*  715:     */   {
/*  716:3082 */     throw new Error("Unresolved compilation problem: \n");
/*  717:     */   }
/*  718:     */   
/*  719:     */   public boolean getAccountDetails(String where, XModel xm)
/*  720:     */   {
/*  721:3106 */     throw new Error("Unresolved compilation problem: \n");
/*  722:     */   }
/*  723:     */   
/*  724:     */   public void getAllPhysicians(XModel xm)
/*  725:     */   {
/*  726:3130 */     throw new Error("Unresolved compilation problem: \n");
/*  727:     */   }
/*  728:     */   
/*  729:     */   public boolean removePhysician(int physicianId)
/*  730:     */   {
/*  731:3147 */     throw new Error("Unresolved compilation problem: \n");
/*  732:     */   }
/*  733:     */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.db.TestXUIDB3
 * JD-Core Version:    0.7.0.1
 */