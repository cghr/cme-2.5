package com.kentropy.transformation.source;

import java.util.Hashtable;

public abstract interface TransformationSource
{
  public abstract Hashtable getHashtable();
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.transformation.source.TransformationSource
 * JD-Core Version:    0.7.0.1
 */