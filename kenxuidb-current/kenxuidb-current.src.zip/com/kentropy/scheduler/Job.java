package com.kentropy.scheduler;

public abstract interface Job
{
  public abstract void execute()
    throws Exception;
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.scheduler.Job
 * JD-Core Version:    0.7.0.1
 */