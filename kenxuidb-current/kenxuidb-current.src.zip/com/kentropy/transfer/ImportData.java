/* 1:  */ package com.kentropy.transfer;
/* 2:  */ 
/* 3:  */ public class ImportData
/* 4:  */ {
/* 5:  */   public static void main(String[] args)
/* 6:  */   {
/* 7:7 */     throw new Error("Unresolved compilation problem: \n\trtx cannot be resolved to a type\n");
/* 8:  */   }
/* 9:  */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\kenxuidb-current\kenxuidb-current.jar
 * Qualified Name:     com.kentropy.transfer.ImportData
 * JD-Core Version:    0.7.0.1
 */