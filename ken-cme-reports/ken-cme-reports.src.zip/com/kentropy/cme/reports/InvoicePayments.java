/*   1:    */ package com.kentropy.cme.reports;
/*   2:    */ 
/*   3:    */ import com.kentropy.util.SpringUtils;
/*   4:    */ import org.apache.log4j.Logger;
/*   5:    */ import org.springframework.jdbc.core.JdbcTemplate;
/*   6:    */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*   7:    */ 
/*   8:    */ public class InvoicePayments
/*   9:    */ {
/*  10: 13 */   private static Logger log = Logger.getLogger("Billing");
/*  11: 54 */   JdbcTemplate jt = new SpringUtils().getJdbcTemplate();
/*  12: 55 */   SqlRowSet rs = null;
/*  13:    */   
/*  14:    */   public int generateInvoices(String month)
/*  15:    */   {
/*  16: 64 */     int res = this.jt.queryForInt("SELECT COUNT(*) FROM `bank_balance_details` WHERE `month` LIKE  DATE_FORMAT(NOW(),'%m%Y')");
/*  17: 65 */     if (res == 0) {
/*  18: 66 */       this.jt.update("INSERT INTO `bank_balance_details`VALUES(0,DATE_FORMAT(NOW(),'%m%Y'))");
/*  19:    */     }
/*  20: 69 */     int newInvoices = 0;
/*  21: 70 */     int[] effect = (int[])null;
/*  22:    */     try
/*  23:    */     {
/*  24: 74 */       String sql = "SELECT count(*) FROM billables WHERE DATE_FORMAT(date_of_billable,'%m%Y') LIKE '" + month + "%'";
/*  25:    */       
/*  26: 76 */       this.rs = this.jt.queryForRowSet(sql);
/*  27: 77 */       this.rs.next();
/*  28: 78 */       newInvoices = this.rs.getInt(1);
/*  29: 80 */       if (newInvoices == 0) {
/*  30: 81 */         return 0;
/*  31:    */       }
/*  32: 82 */       String[] sqls = {
/*  33: 83 */         "UPDATE billables SET invoice_id=CONCAT(DATE_FORMAT(date_of_billable,'%m%Y'),physician_id) WHERE DATE_FORMAT(date_of_billable,'%m%Y') LIKE '" + month + "%'", 
/*  34: 84 */         "INSERT IGNORE INTO  invoices(invoice_id,physician_id,amount)   (SELECT a.invoice_id,a.physician_id,(a.cod*(SELECT rate FROM rate_billables WHERE role='coding'))+(a.adj*(SELECT rate FROM rate_billables WHERE role='adjudication')) amount FROM (SELECT invoice_id,physician_id,SUM(IF(role='coding',1,0)) cod,SUM(IF(role='adjudication',1,0)) adj FROM billables WHERE DATE_FORMAT(date_of_billable,'%m%Y') LIKE '" + month + "%'  GROUP BY invoice_id ) a)", 
/*  35: 85 */         "UPDATE invoices SET tax=(amount) DIV  (SELECT tax FROM tax_details WHERE item='invoice') where invoice_id like '" + month + "%'", 
/*  36: 86 */         "UPDATE invoices SET net=amount-tax  where invoice_id like '" + month + "%'" };
/*  37:    */       
/*  38:    */ 
/*  39:    */ 
/*  40: 90 */       effect = this.jt.batchUpdate(sqls);
/*  41:    */     }
/*  42:    */     catch (Exception ex)
/*  43:    */     {
/*  44: 96 */       ex.printStackTrace();
/*  45:    */     }
/*  46: 99 */     log.info("==> No of Invoices to be Generated " + effect[2]);
/*  47:    */     
/*  48:101 */     return effect[2];
/*  49:    */   }
/*  50:    */   
/*  51:    */   public int startNewPayment(String month)
/*  52:    */   {
/*  53:105 */     int newPayments = 0;
/*  54:    */     
/*  55:107 */     String sql = "SELECT COUNT(*) FROM invoices WHERE payment_id IS  NULL AND invoice_id like '" + month + "%'";
/*  56:108 */     this.rs = this.jt.queryForRowSet(sql);
/*  57:    */     
/*  58:    */ 
/*  59:111 */     this.rs.next();
/*  60:112 */     newPayments = this.rs.getInt(1);
/*  61:113 */     if (newPayments == 0) {
/*  62:114 */       return 0;
/*  63:    */     }
/*  64:    */     try
/*  65:    */     {
/*  66:119 */       log.info("==> Trying to Insert data into Payments Table");
/*  67:120 */       sql = "INSERT INTO payments(DATE,amount,formonth) (SELECT CURDATE(),SUM(net),left(invoice_id,6) FROM invoices WHERE payment_id IS NULL AND invoice_id like '" + month + "%' GROUP BY CURDATE())";
/*  68:121 */       this.jt.update(sql);
/*  69:122 */       log.info("==> Inserted Data to payments Successfully");
/*  70:123 */       log.info("==> Trying to Update Invoices");
/*  71:124 */       sql = "UPDATE invoices SET payment_id=(SELECT MAX(payment_id) FROM payments) WHERE invoice_id like '" + month + "%'";
/*  72:125 */       this.jt.update(sql);
/*  73:126 */       log.info("==> Invoices Updated Successfully");
/*  74:127 */       payment_id = (String)this.jt.queryForObject("SELECT MAX(payment_id) from payments", String.class);
/*  75:    */     }
/*  76:    */     catch (Exception ex)
/*  77:    */     {
/*  78:    */       String payment_id;
/*  79:139 */       ex.printStackTrace();
/*  80:    */     }
/*  81:147 */     return newPayments;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void resetPaymentsModule()
/*  85:    */   {
/*  86:154 */     String[] sqls = {
/*  87:155 */       "truncate table invoices", 
/*  88:156 */       "truncate table payments", 
/*  89:157 */       "update billables set invoice_id=NULL" };
/*  90:    */     
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:162 */     this.jt.batchUpdate(sqls);
/*  95:163 */     log.info("==> Truncated Payments Module Tables");
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static void main(String[] args)
/*  99:    */   {
/* 100:166 */     InvoicePayments ob = new InvoicePayments();
/* 101:    */   }
/* 102:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-cme-reports\ken-cme-reports.jar
 * Qualified Name:     com.kentropy.cme.reports.InvoicePayments
 * JD-Core Version:    0.7.0.1
 */