/*  1:   */ package com.kentropy.cme.reports;
/*  2:   */ 
/*  3:   */ import com.kentropy.process.Process;
/*  4:   */ import com.kentropy.util.SpringUtils;
/*  5:   */ import java.io.PrintStream;
/*  6:   */ import org.springframework.jdbc.core.JdbcTemplate;
/*  7:   */ 
/*  8:   */ public class CmeReports
/*  9:   */ {
/* 10:   */   public static void performanceReports(String[] args)
/* 11:   */   {
/* 12:   */     try
/* 13:   */     {
/* 14:16 */       JdbcTemplate jt = new SpringUtils().getJdbcTemplate();
/* 15:17 */       String[] sql = {
/* 16:18 */         "TRUNCATE TABLE performance_report_cod", 
/* 17:19 */         "INSERT INTO performance_report_cod(SELECT MONTH,assignedto,SUM(IF(DATE_FORMAT(dateassigned,'%Y-%m')= MONTH,1,0)) cod,SUM(IF(STATUS=1 AND DATE_FORMAT(endtime,'%Y-%m')=MONTH,1,0)) comp,SUM(IF(DATE_FORMAT(duedate,'%Y-%m')<=MONTH ,1,0)) due,SUM(IF(DATE(duedate)<DATE(endtime)  OR ( DATE_FORMAT(duedate,'%Y-%m')<=MONTH  AND (STATUS IS NULL OR DATE_FORMAT(endtime,'%Y-%m')<=MONTH)) ,1,0))  `delayed`  FROM months a LEFT JOIN tasks b ON a.month>=DATE_FORMAT(b.dateassigned,'%Y-%m') WHERE task LIKE '%task0/task0'   GROUP BY MONTH,assignedto ORDER BY MONTH ASC) ;", 
/* 18:   */         
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:25 */         "TRUNCATE TABLE cod_pending", 
/* 24:26 */         "INSERT INTO cod_pending(SELECT  SUM(cod_assigned)-SUM(cod_completed) pending,a.month,physician_id FROM months a LEFT JOIN performance_report_cod b ON a.month>b.date  GROUP BY a.month,b.physician_id )", 
/* 25:   */         
/* 26:28 */         "TRUNCATE TABLE performance_report_recon", 
/* 27:29 */         "INSERT INTO performance_report_recon(SELECT MONTH,assignedto,SUM(IF(DATE_FORMAT(dateassigned,'%Y-%m')= MONTH,1,0)) cod,SUM(IF(STATUS=1 AND DATE_FORMAT(endtime,'%Y-%m')=MONTH,1,0)) comp,SUM(IF(DATE_FORMAT(duedate,'%Y-%m')<=MONTH ,1,0)) due,SUM(IF(DATE(duedate)<DATE(endtime)  OR( DATE_FORMAT(duedate,'%Y-%m')<=MONTH  AND (STATUS IS NULL OR DATE_FORMAT(endtime,'%Y-%m')<=MONTH)) ,1,0))  `delayed`  FROM months a LEFT JOIN tasks b ON a.month>=DATE_FORMAT(b.dateassigned,'%Y-%m')WHERE task LIKE '%task0/task1'   GROUP BY MONTH,assignedto ORDER BY MONTH ASC)", 
/* 28:   */         
/* 29:   */ 
/* 30:   */ 
/* 31:33 */         "TRUNCATE TABLE recon_pending", 
/* 32:34 */         "INSERT INTO recon_pending(SELECT  SUM(recon_assigned)-SUM(recon_completed) pending,a.month,physician_id FROM months a LEFT JOIN performance_report_recon b ON a.month>b.date  GROUP BY a.month,b.physician_id )", 
/* 33:35 */         "TRUNCATE TABLE performance_report_adj", 
/* 34:36 */         "INSERT INTO performance_report_adj(SELECT MONTH,assignedto,SUM(IF(DATE_FORMAT(dateassigned,'%Y-%m')= MONTH,1,0)) cod,SUM(IF(STATUS=1 AND DATE_FORMAT(endtime,'%Y-%m')=MONTH,1,0)) comp,SUM(IF(DATE_FORMAT(duedate,'%Y-%m')<=MONTH ,1,0)) due,SUM(IF(DATE(duedate)<DATE(endtime)  OR( DATE_FORMAT(duedate,'%Y-%m')<=MONTH  AND (STATUS IS NULL OR DATE_FORMAT(endtime,'%Y-%m')<=MONTH)) ,1,0))  `delayed`  FROM months a LEFT JOIN tasks b ON a.month>=DATE_FORMAT(b.dateassigned,'%Y-%m')WHERE task LIKE '%task0/task2'   GROUP BY MONTH,assignedto ORDER BY MONTH ASC)", 
/* 35:   */         
/* 36:   */ 
/* 37:   */ 
/* 38:40 */         "TRUNCATE TABLE adj_pending", 
/* 39:41 */         "INSERT INTO adj_pending(SELECT  SUM(adj_assigned)-SUM(adj_completed) pending,a.month,physician_id FROM months a LEFT JOIN performance_report_adj b ON a.month>b.date  GROUP BY a.month,b.physician_id )" };
/* 40:   */       
/* 41:   */ 
/* 42:44 */       jt.batchUpdate(sql);
/* 43:   */       
/* 44:46 */       Process.refreshProcessStatus();
/* 45:   */     }
/* 46:   */     catch (Exception e)
/* 47:   */     {
/* 48:49 */       e.printStackTrace();
/* 49:   */     }
/* 50:   */   }
/* 51:   */   
/* 52:   */   public static void refreshProcessStatus(String[] args)
/* 53:   */   {
/* 54:   */     try
/* 55:   */     {
/* 56:59 */       System.out.println("==>  CAlling Refresh Process STatus ");
/* 57:60 */       Process.refreshProcessStatus();
/* 58:   */     }
/* 59:   */     catch (Exception e)
/* 60:   */     {
/* 61:64 */       e.printStackTrace();
/* 62:   */     }
/* 63:   */   }
/* 64:   */   
/* 65:   */   public static void main(String[] args)
/* 66:   */   {
/* 67:70 */     performanceReports(args);
/* 68:   */   }
/* 69:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-cme-reports\ken-cme-reports.jar
 * Qualified Name:     com.kentropy.cme.reports.CmeReports
 * JD-Core Version:    0.7.0.1
 */