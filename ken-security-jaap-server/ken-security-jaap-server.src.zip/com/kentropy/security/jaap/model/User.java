/*  1:   */ package com.kentropy.security.jaap.model;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class User
/*  7:   */ {
/*  8:   */   private String username;
/*  9:   */   private String password;
/* 10:   */   private String status;
/* 11:   */   private String roles;
/* 12:15 */   private List<String> authorisedPages = new ArrayList();
/* 13:16 */   private List<String> unAuthorisedPages = new ArrayList();
/* 14:   */   
/* 15:   */   public String getRoles()
/* 16:   */   {
/* 17:21 */     return this.roles;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setRoles(String roles)
/* 21:   */   {
/* 22:24 */     this.roles = roles;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getStatus()
/* 26:   */   {
/* 27:27 */     return this.status;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setStatus(String status)
/* 31:   */   {
/* 32:30 */     this.status = status;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getUsername()
/* 36:   */   {
/* 37:33 */     return this.username;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setUsername(String username)
/* 41:   */   {
/* 42:36 */     this.username = username;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public String getPassword()
/* 46:   */   {
/* 47:39 */     return this.password;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void setPassword(String password)
/* 51:   */   {
/* 52:42 */     this.password = password;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public List<String> getAuthorisedPages()
/* 56:   */   {
/* 57:45 */     return this.authorisedPages;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public void setAuthorisedPages(List<String> authorisedPages)
/* 61:   */   {
/* 62:48 */     this.authorisedPages = authorisedPages;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public List<String> getUnAuthorisedPages()
/* 66:   */   {
/* 67:51 */     return this.unAuthorisedPages;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public void setUnAuthorisedPages(List<String> unAuthorisedPages)
/* 71:   */   {
/* 72:54 */     this.unAuthorisedPages = unAuthorisedPages;
/* 73:   */   }
/* 74:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.model.User
 * JD-Core Version:    0.7.0.1
 */