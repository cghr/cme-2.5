/*   1:    */ package com.kentropy.security.jaap.dao;
/*   2:    */ 
/*   3:    */ import com.kentropy.security.jaap.model.User;
/*   4:    */ import com.kentropy.util.DbUtil;
/*   5:    */ import com.kentropy.util.SpringApplicationContext;
/*   6:    */ import de.schlund.pfixxml.util.MD5Utils;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.HashSet;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Properties;
/*  13:    */ import javax.servlet.http.HttpSession;
/*  14:    */ import org.apache.log4j.Logger;
/*  15:    */ import org.springframework.context.ApplicationContext;
/*  16:    */ import org.springframework.jdbc.core.JdbcTemplate;
/*  17:    */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*  18:    */ 
/*  19:    */ public class UserDAO
/*  20:    */ {
/*  21: 36 */   private static Logger log = Logger.getLogger(UserDAO.class);
/*  22: 37 */   private ApplicationContext appContext = SpringApplicationContext.getApplicationContext();
/*  23: 38 */   DbUtil db = new DbUtil();
/*  24:    */   private JdbcTemplate jt;
/*  25:    */   
/*  26:    */   public JdbcTemplate getJt()
/*  27:    */   {
/*  28: 42 */     return this.jt;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setJt(JdbcTemplate jt)
/*  32:    */   {
/*  33: 45 */     this.jt = jt;
/*  34:    */   }
/*  35:    */   
/*  36: 48 */   Properties props = (Properties)this.appContext.getBean("authentication");
/*  37: 49 */   String table = this.props.getProperty("usersTable");
/*  38: 50 */   String username = this.props.getProperty("usernameField");
/*  39: 51 */   String password = this.props.getProperty("passwordField");
/*  40: 52 */   String roles = this.props.getProperty("rolesField");
/*  41:    */   
/*  42:    */   public boolean authenticate(User user)
/*  43:    */     throws IOException
/*  44:    */   {
/*  45: 57 */     log.info("Username==> " + user.getUsername());
/*  46: 58 */     String sql = "Select * from " + this.table + " where " + this.username + "=?";
/*  47:    */     
/*  48: 60 */     SqlRowSet rs = null;
/*  49:    */     try
/*  50:    */     {
/*  51: 65 */       rs = this.jt.queryForRowSet(sql, new Object[] { user.getUsername() });
/*  52: 67 */       if (!rs.next())
/*  53:    */       {
/*  54: 69 */         log.info("===> Login Failed No Such User as  " + user.getUsername());
/*  55: 70 */         return false;
/*  56:    */       }
/*  57: 72 */       if (rs.getString(this.password).equals(user.getPassword()))
/*  58:    */       {
/*  59: 76 */         log.info("===> Login Successful");
/*  60:    */         
/*  61: 78 */         return true;
/*  62:    */       }
/*  63: 81 */       log.debug("===> Login Failed");
/*  64: 82 */       return false;
/*  65:    */     }
/*  66:    */     catch (Exception e)
/*  67:    */     {
/*  68: 85 */       log.error(e.toString());
/*  69:    */     }
/*  70: 86 */     return false;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean authenticateMd5(User user, String sessionId, HttpSession session)
/*  74:    */     throws IOException
/*  75:    */   {
/*  76: 97 */     String sql = "Select * from " + this.table + " where " + this.username + "=?";
/*  77: 98 */     SqlRowSet rs = null;
/*  78:    */     try
/*  79:    */     {
/*  80:102 */       rs = this.jt.queryForRowSet(sql, new Object[] { user.getUsername() });
/*  81:104 */       if (!rs.next())
/*  82:    */       {
/*  83:107 */         log.info("===> Login Failed NO Such User as" + user.getUsername());
/*  84:108 */         return false;
/*  85:    */       }
/*  86:110 */       if (MD5Utils.hex_md5(rs.getString("password") + sessionId).equals(user.getPassword()))
/*  87:    */       {
/*  88:112 */         session.setAttribute("password", rs.getString("password"));
/*  89:    */         
/*  90:    */ 
/*  91:    */ 
/*  92:116 */         return true;
/*  93:    */       }
/*  94:126 */       return false;
/*  95:    */     }
/*  96:    */     catch (Exception e)
/*  97:    */     {
/*  98:129 */       log.error(e.toString());
/*  99:    */     }
/* 100:130 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean authorise(User user, String page)
/* 104:    */   {
/* 105:152 */     log.debug("==> Inside Authorise Method for user with Roles " + user.getRoles());
/* 106:    */     
/* 107:154 */     Iterator itr = user.getUnAuthorisedPages().iterator();
/* 108:155 */     while (itr.hasNext())
/* 109:    */     {
/* 110:157 */       String pg = (String)itr.next();
/* 111:158 */       log.debug("==> UnAuthorised Page " + page + " Check matching with" + pg);
/* 112:159 */       if (page.matches(".*(" + pg + ").*")) {
/* 113:160 */         return false;
/* 114:    */       }
/* 115:    */     }
/* 116:163 */     return true;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void logUser(User user, String status, String sessionId, String ipaddress)
/* 120:    */   {
/* 121:173 */     String sql = "INSERT INTO userlog(username,PASSWORD,LOGIN,STATUS,SESSIONID,ipaddress) VALUES(?,?,NOW(),?,?,?)";
/* 122:    */     try
/* 123:    */     {
/* 124:177 */       this.jt.update(sql, new Object[] { user.getUsername(), user.getPassword(), status, sessionId, ipaddress });
/* 125:    */     }
/* 126:    */     catch (Exception e)
/* 127:    */     {
/* 128:180 */       log.error("===> Table 'userlog' not found Or Incorrect Structure");
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void logUser2(User user, String sessionId, String pgs)
/* 133:    */   {
/* 134:    */     try
/* 135:    */     {
/* 136:198 */       String sql = "UPDATE userlog SET logout=NOW(),pages=? WHERE username=? AND sessionid=?";
/* 137:199 */       this.jt.update(sql, new Object[] { pgs, user.getUsername(), sessionId });
/* 138:    */     }
/* 139:    */     catch (Exception e)
/* 140:    */     {
/* 141:203 */       e.printStackTrace();
/* 142:204 */       log.error("===> Table 'userlog' not found Or Incorrect Structure ");
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   public void changePassword(User user)
/* 147:    */   {
/* 148:220 */     String sql = "update accounts set password=? where username=?";
/* 149:    */     
/* 150:222 */     this.jt.update(sql, new Object[] { user.getPassword(), user.getUsername() });
/* 151:    */   }
/* 152:    */   
/* 153:    */   public String getRoles(User user)
/* 154:    */   {
/* 155:229 */     String sql = "select " + this.roles + " from " + this.table + " where " + this.username + "=?";
/* 156:230 */     SqlRowSet rs = null;
/* 157:231 */     String userRoles = "";
/* 158:    */     try
/* 159:    */     {
/* 160:234 */       rs = this.jt.queryForRowSet(sql, new Object[] { user.getUsername() });
/* 161:235 */       rs.next();
/* 162:236 */       return rs.getString(this.roles);
/* 163:    */     }
/* 164:    */     catch (Exception e)
/* 165:    */     {
/* 166:242 */       log.error(e.toString());
/* 167:    */     }
/* 168:243 */     return null;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public boolean addNewUser(User user)
/* 172:    */   {
/* 173:250 */     String sql = "INSERT INTO accounts values(?,?,?,?)";
/* 174:    */     try
/* 175:    */     {
/* 176:253 */       this.jt.update(sql, new Object[] { user.getUsername(), user.getPassword(), user.getRoles(), user.getStatus() });
/* 177:    */     }
/* 178:    */     catch (Exception e)
/* 179:    */     {
/* 180:257 */       return false;
/* 181:    */     }
/* 182:259 */     return true;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void deleteUse(String username)
/* 186:    */   {
/* 187:265 */     String sql = "DELETE FROM accounts where username=?";
/* 188:266 */     this.jt.update(sql, new Object[] { username });
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void updateUser(User user)
/* 192:    */   {
/* 193:271 */     String sql = "UPDATE accounts SET PASSWORD=?,roles=?,STATUS=? WHERE username=?";
/* 194:272 */     this.jt.update(sql, new Object[] { user.getPassword(), user.getRoles(), user.getStatus(), user.getUsername() });
/* 195:    */   }
/* 196:    */   
/* 197:    */   public Object[] removeDuplicates(ArrayList al)
/* 198:    */   {
/* 199:277 */     HashSet hs = new HashSet(al);
/* 200:    */     
/* 201:279 */     return hs.toArray();
/* 202:    */   }
/* 203:    */   
/* 204:    */   public String passwardChanged(String username)
/* 205:    */   {
/* 206:284 */     String newp = null;
/* 207:285 */     String sql = "select newpassword from changepassword where username=? and status='pending'";
/* 208:286 */     SqlRowSet rs = this.jt.queryForRowSet(sql, new Object[] { username });
/* 209:287 */     while (rs.next()) {
/* 210:289 */       newp = rs.getString("newpassword");
/* 211:    */     }
/* 212:292 */     if (newp != null) {
/* 213:293 */       return newp;
/* 214:    */     }
/* 215:295 */     return null;
/* 216:    */   }
/* 217:    */   
/* 218:    */   public boolean confirmPassword(User user)
/* 219:    */   {
/* 220:300 */     String sql = "update accounts set password=? where username=? and roles='physician'";
/* 221:301 */     this.jt.update(sql, new Object[] { user.getPassword(), user.getUsername() });
/* 222:302 */     sql = "update changepassword set status='done' where username=? and status='pending'";
/* 223:303 */     this.jt.update(sql, new Object[] { user.getUsername() });
/* 224:304 */     return true;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public String getNewPasswor(String username)
/* 228:    */   {
/* 229:309 */     String sql = "select newpassword from changepassword where username=? and status='pending'";
/* 230:    */     
/* 231:311 */     return null;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public boolean hasChangedPassword(User user)
/* 235:    */   {
/* 236:316 */     String sql = "SELECT password from accounts where username=? and roles='physician'";
/* 237:317 */     String password = (String)this.jt.queryForObject(sql, new Object[] { user.getUsername() }, String.class);
/* 238:319 */     if (password.equals("5f4dcc3b5aa765d61d8327deb882cf99")) {
/* 239:322 */       return false;
/* 240:    */     }
/* 241:326 */     return true;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public void lockUser(User user)
/* 245:    */   {
/* 246:332 */     int cnt = this.jt.queryForInt("SELECT COUNT(*) FROM accounts WHERE username=?", new Object[] { user.getUsername() });
/* 247:334 */     if (cnt == 1) {
/* 248:335 */       this.jt.update("UPDATE accounts SET status=? WHERE username=?", new Object[] { "locked", user.getUsername() });
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   public boolean isLocked(User user)
/* 253:    */   {
/* 254:343 */     String status = this.db.uniqueResult("accounts", "IF(status IS NULL,'',status) status", "username=?", new Object[] { user.getUsername() });
/* 255:345 */     if (status.equals("locked")) {
/* 256:346 */       return true;
/* 257:    */     }
/* 258:348 */     return false;
/* 259:    */   }
/* 260:    */   
/* 261:    */   public boolean authenticateOneTimeLogin(User user, String sessionId, HttpSession session)
/* 262:    */     throws IOException
/* 263:    */   {
/* 264:355 */     DbUtil db = new DbUtil();
/* 265:    */     
/* 266:357 */     log.info("==> Username : " + user.getUsername());
/* 267:358 */     String sql = "Select * from one_time_login where " + this.username + "=?";
/* 268:359 */     SqlRowSet rs = null;
/* 269:    */     try
/* 270:    */     {
/* 271:363 */       rs = this.jt.queryForRowSet(sql, new Object[] { user.getUsername() });
/* 272:365 */       if (!rs.next()) {
/* 273:369 */         return false;
/* 274:    */       }
/* 275:371 */       if (MD5Utils.hex_md5(rs.getString("password") + sessionId).equals(user.getPassword()))
/* 276:    */       {
/* 277:373 */         session.setAttribute("password", rs.getString("password"));
/* 278:    */         
/* 279:    */ 
/* 280:    */ 
/* 281:377 */         log.info("One Time Login Successful for " + user.getUsername());
/* 282:    */         
/* 283:379 */         db.deleteData("one_time_login", "username=?", new Object[] { user.getUsername() });
/* 284:380 */         log.info("Delete Data for One Time Login for" + user.getUsername());
/* 285:    */         
/* 286:382 */         return true;
/* 287:    */       }
/* 288:389 */       log.info("===> Login Failed");
/* 289:    */       
/* 290:    */ 
/* 291:392 */       return false;
/* 292:    */     }
/* 293:    */     catch (Exception e)
/* 294:    */     {
/* 295:395 */       log.error(e.toString());
/* 296:    */     }
/* 297:396 */     return false;
/* 298:    */   }
/* 299:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.dao.UserDAO
 * JD-Core Version:    0.7.0.1
 */