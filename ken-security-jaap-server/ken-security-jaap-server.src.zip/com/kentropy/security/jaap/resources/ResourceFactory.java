/*  1:   */ package com.kentropy.security.jaap.resources;
/*  2:   */ 
/*  3:   */ import org.springframework.context.ApplicationContext;
/*  4:   */ import org.springframework.context.support.ClassPathXmlApplicationContext;
/*  5:   */ 
/*  6:   */ public class ResourceFactory
/*  7:   */ {
/*  8:19 */   private static ApplicationContext appContext = new ClassPathXmlApplicationContext("appContext.xml");
/*  9:   */   
/* 10:   */   public static ApplicationContext getAppContext()
/* 11:   */   {
/* 12:23 */     return appContext;
/* 13:   */   }
/* 14:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.resources.ResourceFactory
 * JD-Core Version:    0.7.0.1
 */