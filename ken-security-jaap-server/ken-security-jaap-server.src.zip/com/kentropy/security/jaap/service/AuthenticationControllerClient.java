/*   1:    */ package com.kentropy.security.jaap.service;
/*   2:    */ 
/*   3:    */ import com.kentropy.security.jaap.dao.UserDAO;
/*   4:    */ import com.kentropy.security.jaap.model.User;
/*   5:    */ import com.kentropy.util.DbUtil;
/*   6:    */ import com.kentropy.util.SpringApplicationContext;
/*   7:    */ import de.schlund.pfixxml.util.Base64Utils;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.PrintWriter;
/*  10:    */ import java.sql.SQLException;
/*  11:    */ import java.util.Date;
/*  12:    */ import java.util.Properties;
/*  13:    */ import javax.servlet.ServletException;
/*  14:    */ import javax.servlet.http.HttpServletRequest;
/*  15:    */ import javax.servlet.http.HttpServletResponse;
/*  16:    */ import javax.servlet.http.HttpSession;
/*  17:    */ import org.apache.log4j.Logger;
/*  18:    */ import org.springframework.context.ApplicationContext;
/*  19:    */ import org.springframework.web.servlet.ModelAndView;
/*  20:    */ import org.springframework.web.servlet.mvc.Controller;
/*  21:    */ 
/*  22:    */ public class AuthenticationControllerClient
/*  23:    */   implements Controller
/*  24:    */ {
/*  25: 39 */   private static Logger log = Logger.getLogger(AuthenticationControllerClient.class);
/*  26:    */   private static final long serialVersionUID = 1L;
/*  27: 42 */   DbUtil db = new DbUtil();
/*  28: 44 */   Properties props = null;
/*  29: 47 */   String md5 = "";
/*  30:    */   
/*  31:    */   public void init(HttpServletRequest request, HttpServletResponse response)
/*  32:    */     throws SQLException
/*  33:    */   {
/*  34: 56 */     ApplicationContext context = SpringApplicationContext.getApplicationContext();
/*  35: 57 */     this.props = ((Properties)context.getBean("authentication"));
/*  36:    */     
/*  37:    */ 
/*  38: 60 */     this.md5 = this.props.getProperty("md5");
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*  42:    */     throws ServletException, IOException
/*  43:    */   {
/*  44: 70 */     UserDAO dao = (UserDAO)SpringApplicationContext.getBean("userDAO");
/*  45:    */     
/*  46: 72 */     User user = new User();
/*  47: 73 */     user.setUsername(request.getParameter("username"));
/*  48: 74 */     user.setPassword(request.getParameter("password"));
/*  49: 75 */     String credentials = request.getParameter("credentials");
/*  50: 76 */     boolean check = false;
/*  51: 78 */     if ((this.md5.equals("enable")) && (credentials == null))
/*  52:    */     {
/*  53: 80 */       if (dao.isLocked(user))
/*  54:    */       {
/*  55: 83 */         dao.logUser(user, "failure", null, request.getRemoteAddr());
/*  56: 84 */         response.setStatus(401);
/*  57: 85 */         log.info(user.getUsername() + " ==> Account locked");
/*  58: 86 */         return;
/*  59:    */       }
/*  60: 95 */       check = dao.authenticateMd5(user, request.getSession().getId(), request.getSession());
/*  61:    */     }
/*  62: 99 */     else if (credentials != null)
/*  63:    */     {
/*  64:101 */       log.debug("==> Inside Credentials");
/*  65:102 */       String[] cred = new String(Base64Utils.decode(credentials)).split(";");
/*  66:    */       
/*  67:104 */       user.setUsername(cred[0]);
/*  68:105 */       user.setPassword(cred[1]);
/*  69:106 */       user.setRoles(cred[2]);
/*  70:107 */       long timestmp = Long.parseLong(cred[3]);
/*  71:108 */       log.debug("==> " + user.getUsername() + "  " + user.getPassword() + " " + user.getRoles());
/*  72:109 */       if (new Date().getTime() - timestmp > 10000L) {
/*  73:110 */         check = false;
/*  74:    */       } else {
/*  75:112 */         check = dao.authenticate(user);
/*  76:    */       }
/*  77:    */     }
/*  78:    */     else
/*  79:    */     {
/*  80:119 */       if (dao.isLocked(user))
/*  81:    */       {
/*  82:122 */         dao.logUser(user, "failure", null, request.getRemoteAddr());
/*  83:123 */         response.setStatus(401);
/*  84:124 */         log.info(user.getUsername() + " ==> Account locked");
/*  85:125 */         return;
/*  86:    */       }
/*  87:130 */       check = dao.authenticate(user);
/*  88:    */       
/*  89:132 */       request.getSession(true).setAttribute("password", user.getPassword());
/*  90:    */     }
/*  91:138 */     if (check)
/*  92:    */     {
/*  93:149 */       HttpSession session = request.getSession();
/*  94:    */       
/*  95:151 */       session.setAttribute("username", user.getUsername());
/*  96:    */       
/*  97:153 */       session.setAttribute("loginStatus", "true");
/*  98:154 */       session.setAttribute("roles", dao.getRoles(user));
/*  99:155 */       session.setAttribute("browsedPages", "/login");
/* 100:    */       try
/* 101:    */       {
/* 102:159 */         new SetSessionAttributes().service(request, response);
/* 103:    */         
/* 104:    */ 
/* 105:162 */         System.gc();
/* 106:    */       }
/* 107:    */       catch (Exception e)
/* 108:    */       {
/* 109:165 */         e.printStackTrace();
/* 110:    */       }
/* 111:168 */       log.info(user.getUsername() + " ==> login success");
/* 112:169 */       dao.logUser(user, "success", session.getId(), request.getRemoteAddr());
/* 113:170 */       session.setAttribute("oneTimeLogin", Boolean.valueOf(false));
/* 114:    */       
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:176 */       String teamId = (String)session.getAttribute("teamId");
/* 120:    */       
/* 121:    */ 
/* 122:179 */       response.getWriter().println("username=" + user.getUsername() + "&fullname=" + session.getAttribute("fullname") + "&teamId=" + teamId + "&id=" + (String)session.getAttribute("id"));
/* 123:180 */       response.setStatus(200);
/* 124:    */     }
/* 125:    */     else
/* 126:    */     {
/* 127:187 */       HttpSession currSession = request.getSession(true);
/* 128:189 */       if (currSession.getAttribute("failAttempts") == null)
/* 129:    */       {
/* 130:190 */         currSession.setAttribute("failAttempts", Integer.valueOf(1));
/* 131:    */       }
/* 132:    */       else
/* 133:    */       {
/* 134:196 */         int fails = ((Integer)currSession.getAttribute("failAttempts")).intValue();
/* 135:197 */         int attempts = Integer.parseInt(this.db.uniqueResult("configuration", "value", "property=?", new Object[] { "failAttempts" }));
/* 136:199 */         if (fails == attempts)
/* 137:    */         {
/* 138:201 */           dao.lockUser(user);
/* 139:202 */           dao.logUser(user, "failure", null, request.getRemoteAddr());
/* 140:203 */           response.setStatus(401);
/* 141:204 */           log.info(user.getUsername() + " ==> Account locked");
/* 142:205 */           return;
/* 143:    */         }
/* 144:210 */         currSession.setAttribute("failAttempts", Integer.valueOf(fails + 1));
/* 145:    */       }
/* 146:215 */       dao.logUser(user, "failure", null, request.getRemoteAddr());
/* 147:216 */       response.setStatus(403);
/* 148:217 */       log.info(user.getUsername() + " ==> login failed");
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void doGet(HttpServletRequest req, HttpServletResponse resp)
/* 153:    */     throws ServletException, IOException
/* 154:    */   {
/* 155:225 */     UserDAO dao = (UserDAO)SpringApplicationContext.getBean("userDAO");
/* 156:226 */     log.debug("Inside doGet ..");
/* 157:227 */     HttpSession session = req.getSession();
/* 158:228 */     String action = req.getParameter("action");
/* 159:229 */     if (action != null)
/* 160:    */     {
/* 161:231 */       if (action.equals("getSession"))
/* 162:    */       {
/* 163:235 */         log.debug(session.getId());
/* 164:236 */         resp.getWriter().print("SessionId=" + session.getId());
/* 165:    */       }
/* 166:238 */       if (action.equals("confirmPassword"))
/* 167:    */       {
/* 168:240 */         log.debug("SessionId " + session.getId());
/* 169:241 */         log.debug("Inside confirm password request from client");
/* 170:242 */         User user = new User();
/* 171:243 */         user.setUsername((String)session.getAttribute("username"));
/* 172:244 */         user.setPassword(dao.passwardChanged(user.getUsername()));
/* 173:245 */         dao.confirmPassword(user);
/* 174:    */       }
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
/* 179:    */     throws Exception
/* 180:    */   {
/* 181:257 */     init(request, response);
/* 182:258 */     if (request.getMethod().equals("POST")) {
/* 183:260 */       doPost(request, response);
/* 184:    */     } else {
/* 185:263 */       doGet(request, response);
/* 186:    */     }
/* 187:266 */     return null;
/* 188:    */   }
/* 189:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.service.AuthenticationControllerClient
 * JD-Core Version:    0.7.0.1
 */