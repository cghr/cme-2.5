/*   1:    */ package com.kentropy.security.jaap.service;
/*   2:    */ 
/*   3:    */ import com.kentropy.security.jaap.dao.UserDAO;
/*   4:    */ import com.kentropy.security.jaap.model.User;
/*   5:    */ import com.kentropy.util.SpringApplicationContext;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Properties;
/*  10:    */ import javax.servlet.Filter;
/*  11:    */ import javax.servlet.FilterChain;
/*  12:    */ import javax.servlet.FilterConfig;
/*  13:    */ import javax.servlet.ServletException;
/*  14:    */ import javax.servlet.ServletRequest;
/*  15:    */ import javax.servlet.ServletResponse;
/*  16:    */ import javax.servlet.http.HttpServletRequest;
/*  17:    */ import javax.servlet.http.HttpServletResponse;
/*  18:    */ import javax.servlet.http.HttpSession;
/*  19:    */ import org.apache.log4j.Logger;
/*  20:    */ import org.springframework.context.ApplicationContext;
/*  21:    */ 
/*  22:    */ public class SecureAccess
/*  23:    */   implements Filter
/*  24:    */ {
/*  25: 39 */   private static Logger log = Logger.getLogger(SecureAccess.class);
/*  26:    */   FilterConfig config;
/*  27: 41 */   UserDAO dao = new UserDAO();
/*  28: 42 */   ApplicationContext context = SpringApplicationContext.getApplicationContext();
/*  29: 43 */   Properties props = (Properties)this.context.getBean("authorisation");
/*  30:    */   
/*  31:    */   public void destroy()
/*  32:    */   {
/*  33: 48 */     this.config = null;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
/*  37:    */     throws IOException, ServletException
/*  38:    */   {
/*  39: 55 */     List<String> browsedPages = new ArrayList();
/*  40:    */     
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46: 62 */     HttpSession session = ((HttpServletRequest)req).getSession(true);
/*  47: 63 */     String loginStatus = session.getAttribute("loginStatus") != null ? (String)session.getAttribute("loginStatus") : "false";
/*  48:    */     
/*  49: 65 */     HttpServletResponse response = (HttpServletResponse)resp;
/*  50: 66 */     HttpServletRequest request = (HttpServletRequest)req;
/*  51: 71 */     if (!loginStatus.equals("true"))
/*  52:    */     {
/*  53: 73 */       response.sendRedirect(this.props.getProperty("failurePage"));
/*  54:    */     }
/*  55:    */     else
/*  56:    */     {
/*  57: 79 */       String uri = ((HttpServletRequest)req).getRequestURI().toString();
/*  58:    */       
/*  59: 81 */       session.setAttribute("browsedPages", (String)session.getAttribute("browsedPages") + "," + uri);
/*  60: 82 */       String pgs = (String)session.getAttribute("browsedPages");
/*  61:    */       
/*  62:    */ 
/*  63: 85 */       log.debug("==> Browsed Pages  " + pgs);
/*  64: 86 */       String roles = "";
/*  65:    */       try
/*  66:    */       {
/*  67: 90 */         roles = (String)session.getAttribute("roles");
/*  68: 91 */         User user = (User)this.context.getBean(roles);
/*  69:    */         
/*  70:    */ 
/*  71: 94 */         user.setRoles(roles);
/*  72:    */         
/*  73: 96 */         log.debug("==> Requested Url  " + uri + "  with Role" + user.getRoles());
/*  74: 98 */         if (!this.dao.authorise(user, uri))
/*  75:    */         {
/*  76:100 */           log.info("===> " + session.getAttribute("username") + "  tried to Aceess Unauthorised Page");
/*  77:101 */           ((HttpServletResponse)resp).sendError(403);
/*  78:102 */           return;
/*  79:    */         }
/*  80:111 */         System.gc();
/*  81:112 */         chain.doFilter(req, resp);
/*  82:    */       }
/*  83:    */       catch (Exception e)
/*  84:    */       {
/*  85:118 */         log.info("===> No Roles to the User OR No bean found with roles as " + roles);
/*  86:119 */         chain.doFilter(req, resp);
/*  87:    */       }
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void init(FilterConfig config)
/*  92:    */     throws ServletException
/*  93:    */   {
/*  94:130 */     this.config = config;
/*  95:    */   }
/*  96:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.service.SecureAccess
 * JD-Core Version:    0.7.0.1
 */