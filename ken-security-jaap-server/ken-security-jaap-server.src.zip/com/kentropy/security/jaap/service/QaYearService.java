/*  1:   */ package com.kentropy.security.jaap.service;
/*  2:   */ 
/*  3:   */ import com.kentropy.util.SpringApplicationContext;
/*  4:   */ import java.io.PrintStream;
/*  5:   */ import java.sql.SQLException;
/*  6:   */ import javax.servlet.http.HttpServletRequest;
/*  7:   */ import org.apache.commons.dbcp.BasicDataSource;
/*  8:   */ 
/*  9:   */ public class QaYearService
/* 10:   */ {
/* 11:   */   public void service(HttpServletRequest request)
/* 12:   */     throws SQLException
/* 13:   */   {
/* 14:16 */     String year = request.getParameter("year");
/* 15:17 */     System.out.println("Year =" + year);
/* 16:   */     
/* 17:19 */     BasicDataSource ds = (BasicDataSource)SpringApplicationContext.getBean("dataSource");
/* 18:   */     
/* 19:21 */     ds.setUrl((String)SpringApplicationContext.getBean("databaseUrl" + year));
/* 20:   */     
/* 21:23 */     System.out.println("New Database " + ds.getConnection());
/* 22:   */   }
/* 23:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.service.QaYearService
 * JD-Core Version:    0.7.0.1
 */