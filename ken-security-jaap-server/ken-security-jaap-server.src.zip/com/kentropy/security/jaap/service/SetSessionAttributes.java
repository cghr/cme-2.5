/*  1:   */ package com.kentropy.security.jaap.service;
/*  2:   */ 
/*  3:   */ import com.kentropy.util.SpringUtils;
/*  4:   */ import javax.servlet.http.HttpServletRequest;
/*  5:   */ import javax.servlet.http.HttpServletResponse;
/*  6:   */ import javax.servlet.http.HttpSession;
/*  7:   */ import org.springframework.jdbc.core.JdbcTemplate;
/*  8:   */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*  9:   */ 
/* 10:   */ public class SetSessionAttributes
/* 11:   */ {
/* 12:   */   public void service(HttpServletRequest request, HttpServletResponse response)
/* 13:   */   {
/* 14:17 */     JdbcTemplate jt = new SpringUtils().getJdbcTemplate();
/* 15:18 */     HttpSession session = request.getSession(true);
/* 16:19 */     String username = (String)session.getAttribute("username");
/* 17:20 */     String roles = (String)session.getAttribute("roles");
/* 18:23 */     if (roles.equals("physician"))
/* 19:   */     {
/* 20:27 */       String sql = "select * from physician where username=?";
/* 21:28 */       SqlRowSet rs = jt.queryForRowSet(sql, new Object[] { username });
/* 22:29 */       rs.next();
/* 23:30 */       String id = rs.getString("id");
/* 24:   */       
/* 25:32 */       session.setAttribute("id", id);
/* 26:33 */       session.setAttribute("fullname", rs.getString("name"));
/* 27:34 */       session.setAttribute("gender", "1");
/* 28:35 */       session.setAttribute("teamId", id);
/* 29:36 */       session.setAttribute("idsInTeam", id);
/* 30:   */     }
/* 31:40 */     else if (!roles.equals("admin"))
/* 32:   */     {
/* 33:46 */       if (roles.equals("surveyor"))
/* 34:   */       {
/* 35:51 */         String sql = "select * from accounts where username=?";
/* 36:52 */         SqlRowSet rs = jt.queryForRowSet(sql, new Object[] { username });
/* 37:53 */         rs.next();
/* 38:54 */         String id = rs.getString("id");
/* 39:   */         
/* 40:56 */         session.setAttribute("id", id);
/* 41:57 */         session.setAttribute("name", rs.getString("name"));
/* 42:58 */         session.setAttribute("gender", "1");
/* 43:59 */         session.setAttribute("teamId", id);
/* 44:60 */         session.setAttribute("idsInTeam", id);
/* 45:   */       }
/* 46:   */       else
/* 47:   */       {
/* 48:66 */         roles.equals("qa");
/* 49:   */       }
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.service.SetSessionAttributes
 * JD-Core Version:    0.7.0.1
 */