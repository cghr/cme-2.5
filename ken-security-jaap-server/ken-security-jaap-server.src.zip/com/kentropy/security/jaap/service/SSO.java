/*  1:   */ package com.kentropy.security.jaap.service;
/*  2:   */ 
/*  3:   */ import java.util.Hashtable;
/*  4:   */ 
/*  5:   */ public class SSO
/*  6:   */ {
/*  7: 9 */   public static Hashtable tokens = new Hashtable();
/*  8:   */   
/*  9:   */   public static String findTokenDetails(String token)
/* 10:   */   {
/* 11:18 */     String tk = (String)tokens.get(token);
/* 12:20 */     if (tk != null) {
/* 13:22 */       tokens.remove(token);
/* 14:   */     }
/* 15:26 */     return tk;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static String createToken(String username)
/* 19:   */   {
/* 20:35 */     String tmptk = Math.random();
/* 21:36 */     tokens.put(tmptk, username);
/* 22:   */     
/* 23:   */ 
/* 24:39 */     return tmptk;
/* 25:   */   }
/* 26:   */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.service.SSO
 * JD-Core Version:    0.7.0.1
 */