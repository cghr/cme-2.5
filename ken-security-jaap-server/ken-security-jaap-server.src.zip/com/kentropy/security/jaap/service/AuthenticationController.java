/*   1:    */ package com.kentropy.security.jaap.service;
/*   2:    */ 
/*   3:    */ import com.kentropy.security.jaap.dao.UserDAO;
/*   4:    */ import com.kentropy.security.jaap.model.User;
/*   5:    */ import com.kentropy.util.DbUtil;
/*   6:    */ import com.kentropy.util.SpringApplicationContext;
/*   7:    */ import de.schlund.pfixxml.util.Base64Utils;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.PrintWriter;
/*  10:    */ import java.sql.SQLException;
/*  11:    */ import java.util.Date;
/*  12:    */ import java.util.Properties;
/*  13:    */ import javax.servlet.ServletException;
/*  14:    */ import javax.servlet.http.HttpServletRequest;
/*  15:    */ import javax.servlet.http.HttpServletResponse;
/*  16:    */ import javax.servlet.http.HttpSession;
/*  17:    */ import org.apache.log4j.Logger;
/*  18:    */ import org.springframework.context.ApplicationContext;
/*  19:    */ import org.springframework.web.servlet.ModelAndView;
/*  20:    */ import org.springframework.web.servlet.mvc.Controller;
/*  21:    */ 
/*  22:    */ public class AuthenticationController
/*  23:    */   implements Controller
/*  24:    */ {
/*  25: 39 */   private static Logger log = Logger.getLogger(AuthenticationController.class);
/*  26:    */   private static final long serialVersionUID = 1L;
/*  27: 42 */   DbUtil db = new DbUtil();
/*  28: 44 */   Properties props = null;
/*  29: 47 */   String md5 = "";
/*  30:    */   
/*  31:    */   public void init(HttpServletRequest request, HttpServletResponse response)
/*  32:    */     throws SQLException
/*  33:    */   {
/*  34: 56 */     ApplicationContext context = SpringApplicationContext.getApplicationContext();
/*  35: 57 */     this.props = ((Properties)context.getBean("authentication"));
/*  36:    */     
/*  37:    */ 
/*  38: 60 */     this.md5 = this.props.getProperty("md5");
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected void doPost(HttpServletRequest request, HttpServletResponse response)
/*  42:    */     throws ServletException, IOException
/*  43:    */   {
/*  44: 70 */     UserDAO dao = (UserDAO)SpringApplicationContext.getBean("userDAO");
/*  45:    */     
/*  46: 72 */     User user = new User();
/*  47: 73 */     user.setUsername(request.getParameter("username"));
/*  48: 74 */     user.setPassword(request.getParameter("password"));
/*  49: 75 */     String credentials = request.getParameter("credentials");
/*  50: 76 */     boolean check = false;
/*  51: 78 */     if ((this.md5.equals("enable")) && (credentials == null))
/*  52:    */     {
/*  53: 80 */       if (dao.isLocked(user))
/*  54:    */       {
/*  55: 83 */         dao.logUser(user, "failure", null, request.getRemoteAddr());
/*  56: 84 */         response.setStatus(401);
/*  57: 85 */         log.info(user.getUsername() + " ==> Account locked");
/*  58: 86 */         return;
/*  59:    */       }
/*  60: 95 */       check = dao.authenticateMd5(user, request.getSession().getId(), request.getSession());
/*  61:    */     }
/*  62: 99 */     else if (credentials != null)
/*  63:    */     {
/*  64:101 */       log.debug("==> Inside Credentials");
/*  65:102 */       String[] cred = new String(Base64Utils.decode(credentials)).split(";");
/*  66:    */       
/*  67:104 */       user.setUsername(cred[0]);
/*  68:105 */       user.setPassword(cred[1]);
/*  69:106 */       user.setRoles(cred[2]);
/*  70:107 */       long timestmp = Long.parseLong(cred[3]);
/*  71:108 */       log.debug("==> " + user.getUsername() + "  " + user.getPassword() + " " + user.getRoles());
/*  72:109 */       if (new Date().getTime() - timestmp > 10000L) {
/*  73:110 */         check = false;
/*  74:    */       } else {
/*  75:112 */         check = dao.authenticate(user);
/*  76:    */       }
/*  77:    */     }
/*  78:    */     else
/*  79:    */     {
/*  80:119 */       if (dao.isLocked(user))
/*  81:    */       {
/*  82:122 */         dao.logUser(user, "failure", null, request.getRemoteAddr());
/*  83:123 */         response.setStatus(401);
/*  84:124 */         log.info(user.getUsername() + " ==> Account locked");
/*  85:125 */         return;
/*  86:    */       }
/*  87:130 */       check = dao.authenticate(user);
/*  88:    */       
/*  89:132 */       request.getSession(true).setAttribute("password", user.getPassword());
/*  90:    */     }
/*  91:138 */     if (check)
/*  92:    */     {
/*  93:140 */       HttpSession oldSession = request.getSession(true);
/*  94:141 */       oldSession.invalidate();
/*  95:    */       
/*  96:143 */       HttpSession session = request.getSession(true);
/*  97:    */       
/*  98:    */ 
/*  99:146 */       String sessionid = request.getSession().getId();
/* 100:    */       
/* 101:148 */       response.setHeader("SET-COOKIE", "JSESSIONID=" + sessionid + "; HttpOnly");
/* 102:    */       
/* 103:150 */       session.setAttribute("username", user.getUsername());
/* 104:    */       
/* 105:152 */       session.setAttribute("loginStatus", "true");
/* 106:153 */       session.setAttribute("roles", dao.getRoles(user));
/* 107:154 */       session.setAttribute("browsedPages", "/login");
/* 108:    */       try
/* 109:    */       {
/* 110:158 */         new SetSessionAttributes().service(request, response);
/* 111:    */         
/* 112:    */ 
/* 113:161 */         System.gc();
/* 114:    */       }
/* 115:    */       catch (Exception e)
/* 116:    */       {
/* 117:164 */         e.printStackTrace();
/* 118:    */       }
/* 119:167 */       log.info(user.getUsername() + " ==> login success");
/* 120:168 */       dao.logUser(user, "success", session.getId(), request.getRemoteAddr());
/* 121:169 */       session.setAttribute("oneTimeLogin", Boolean.valueOf(false));
/* 122:    */       
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:175 */       String teamId = (String)session.getAttribute("teamId");
/* 128:    */       
/* 129:    */ 
/* 130:178 */       response.getWriter().println("username=" + user.getUsername() + "&fullname=" + session.getAttribute("fullname") + "&teamId=" + teamId + "&id=" + (String)session.getAttribute("id"));
/* 131:179 */       response.setStatus(200);
/* 132:    */     }
/* 133:    */     else
/* 134:    */     {
/* 135:186 */       HttpSession currSession = request.getSession(true);
/* 136:188 */       if (currSession.getAttribute("failAttempts") == null)
/* 137:    */       {
/* 138:189 */         currSession.setAttribute("failAttempts", Integer.valueOf(1));
/* 139:    */       }
/* 140:    */       else
/* 141:    */       {
/* 142:195 */         int fails = ((Integer)currSession.getAttribute("failAttempts")).intValue();
/* 143:196 */         int attempts = Integer.parseInt(this.db.uniqueResult("configuration", "value", "property=?", new Object[] { "failAttempts" }));
/* 144:198 */         if (fails == attempts)
/* 145:    */         {
/* 146:200 */           dao.lockUser(user);
/* 147:201 */           dao.logUser(user, "failure", null, request.getRemoteAddr());
/* 148:202 */           response.setStatus(401);
/* 149:203 */           log.info(user.getUsername() + " ==> Account locked");
/* 150:204 */           return;
/* 151:    */         }
/* 152:209 */         currSession.setAttribute("failAttempts", Integer.valueOf(fails + 1));
/* 153:    */       }
/* 154:214 */       dao.logUser(user, "failure", null, request.getRemoteAddr());
/* 155:215 */       response.setStatus(403);
/* 156:216 */       log.info(user.getUsername() + " ==> login failed");
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void doGet(HttpServletRequest req, HttpServletResponse resp)
/* 161:    */     throws ServletException, IOException
/* 162:    */   {
/* 163:224 */     UserDAO dao = (UserDAO)SpringApplicationContext.getBean("userDAO");
/* 164:225 */     log.debug("Inside doGet ..");
/* 165:226 */     HttpSession session = req.getSession();
/* 166:227 */     String action = req.getParameter("action");
/* 167:228 */     if (action != null)
/* 168:    */     {
/* 169:230 */       if (action.equals("getSession"))
/* 170:    */       {
/* 171:234 */         log.debug(session.getId());
/* 172:235 */         resp.getWriter().print("SessionId=" + session.getId());
/* 173:    */       }
/* 174:237 */       if (action.equals("confirmPassword"))
/* 175:    */       {
/* 176:239 */         log.debug("SessionId " + session.getId());
/* 177:240 */         log.debug("Inside confirm password request from client");
/* 178:241 */         User user = new User();
/* 179:242 */         user.setUsername((String)session.getAttribute("username"));
/* 180:243 */         user.setPassword(dao.passwardChanged(user.getUsername()));
/* 181:244 */         dao.confirmPassword(user);
/* 182:    */       }
/* 183:    */     }
/* 184:    */   }
/* 185:    */   
/* 186:    */   public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response)
/* 187:    */     throws Exception
/* 188:    */   {
/* 189:256 */     init(request, response);
/* 190:257 */     if (request.getMethod().equals("POST")) {
/* 191:259 */       doPost(request, response);
/* 192:    */     } else {
/* 193:262 */       doGet(request, response);
/* 194:    */     }
/* 195:265 */     return null;
/* 196:    */   }
/* 197:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.service.AuthenticationController
 * JD-Core Version:    0.7.0.1
 */