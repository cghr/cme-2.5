package com.kentropy.security.jaap.service;

public abstract interface SSOIF
{
  public abstract String findTokenDetails(String paramString);
  
  public abstract String createToken(String paramString);
}


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-security-jaap-server\ken-security-jaap-server.jar
 * Qualified Name:     com.kentropy.security.jaap.service.SSOIF
 * JD-Core Version:    0.7.0.1
 */