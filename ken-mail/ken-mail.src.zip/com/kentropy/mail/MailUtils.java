/*   1:    */ package com.kentropy.mail;
/*   2:    */ 
/*   3:    */ import com.kentropy.util.SpringApplicationContext;
/*   4:    */ import java.net.URL;
/*   5:    */ import java.util.Properties;
/*   6:    */ import org.apache.commons.mail.Email;
/*   7:    */ import org.apache.commons.mail.EmailAttachment;
/*   8:    */ import org.apache.commons.mail.HtmlEmail;
/*   9:    */ import org.apache.commons.mail.SimpleEmail;
/*  10:    */ import org.apache.log4j.Logger;
/*  11:    */ 
/*  12:    */ public class MailUtils
/*  13:    */ {
/*  14:    */   static Properties props;
/*  15: 24 */   static String host = null;
/*  16: 25 */   static String user = null;
/*  17: 26 */   static String password = null;
/*  18: 27 */   private static Logger log = Logger.getLogger(MailUtils.class);
/*  19:    */   
/*  20:    */   static
/*  21:    */   {
/*  22:    */     try
/*  23:    */     {
/*  24: 32 */       props = (Properties)SpringApplicationContext.getBean("mail");
/*  25:    */       
/*  26:    */ 
/*  27: 35 */       host = props.getProperty("host");
/*  28: 36 */       user = props.getProperty("smtpuser");
/*  29: 37 */       password = props.getProperty("smtppassword");
/*  30:    */       
/*  31: 39 */       log.debug("Initializing to send Emails...");
/*  32:    */     }
/*  33:    */     catch (Exception e)
/*  34:    */     {
/*  35: 42 */       e.printStackTrace();
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean sendMail(String from, String to, String subject, String msg)
/*  40:    */   {
/*  41:    */     try
/*  42:    */     {
/*  43: 53 */       Email email = new SimpleEmail();
/*  44: 54 */       email.setHostName("localhost");
/*  45: 55 */       email.setFrom(from);
/*  46: 56 */       email.addTo(to);
/*  47: 57 */       email.setSubject(subject);
/*  48: 58 */       email.setMsg(msg);
/*  49: 59 */       email.send();
/*  50: 60 */       log.info("Sent mail to " + to);
/*  51:    */     }
/*  52:    */     catch (Exception e)
/*  53:    */     {
/*  54: 65 */       e.printStackTrace();
/*  55:    */     }
/*  56: 67 */     return true;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean sendHTMLMail(String from, String to, String subject, String msg, String attachmentUrl, String cc)
/*  60:    */   {
/*  61:    */     try
/*  62:    */     {
/*  63: 73 */       log.debug("==> Inside SendHtmlMail Method");
/*  64: 74 */       HtmlEmail email = new HtmlEmail();
/*  65:    */       
/*  66: 76 */       email.setHostName(host);
/*  67: 77 */       email.setFrom(from);
/*  68: 78 */       email.addTo(to);
/*  69: 79 */       email.setSubject(subject);
/*  70: 80 */       email.setHtmlMsg(msg);
/*  71: 83 */       if (attachmentUrl != null)
/*  72:    */       {
/*  73: 85 */         EmailAttachment attachment = new EmailAttachment();
/*  74: 86 */         attachment.setURL(new URL(attachmentUrl));
/*  75: 87 */         email.attach(attachment);
/*  76:    */       }
/*  77: 89 */       if (cc != null)
/*  78:    */       {
/*  79: 91 */         email.addCc(cc);
/*  80: 92 */         log.info("==> Sent cc to " + to);
/*  81:    */       }
/*  82: 96 */       email.send();
/*  83:    */       
/*  84: 98 */       log.info("==> Sent mail to " + to);
/*  85:    */     }
/*  86:    */     catch (Exception e)
/*  87:    */     {
/*  88:101 */       e.printStackTrace();
/*  89:    */     }
/*  90:103 */     return true;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static void main(String[] args)
/*  94:    */   {
/*  95:107 */     new MailUtils().sendMail("support@kentropy.com", "ravi.tej@kentropy.com", " subject", " msg");
/*  96:    */   }
/*  97:    */ }


/* Location:           Z:\home\sagpatke\cme-workspace\cme\ken-mail\ken-mail.jar
 * Qualified Name:     com.kentropy.mail.MailUtils
 * JD-Core Version:    0.7.0.1
 */